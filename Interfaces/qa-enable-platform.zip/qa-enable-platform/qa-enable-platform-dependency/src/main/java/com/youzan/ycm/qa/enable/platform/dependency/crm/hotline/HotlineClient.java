package com.youzan.ycm.qa.enable.platform.dependency.crm.hotline;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.*;

/**
 * 描述:
 * 热线外部调用接口
 *
 * @author beidou
 * @create 2021-01-21
 */
@Component
@Slf4j
public class HotlineClient {

    @Resource
    RestTemplate restTemplate;

    @Value("${http.site.panama-core-kefu.domain}")
    private String panamaCoreHost;



    public void onRinging(String cookies, String seatNo,String mobile,String timestamp){
        log.info("head:{} ", JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));

        ResponseEntity<String> response = restTemplate.exchange(panamaCoreHost+"hotline/callRecord/onRinging", HttpMethod.POST, hotlineEntity(cookies,seatNo,mobile,timestamp), String.class);
        log.info("响铃记录返回",JSON.toJSONString(response),JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));
        if (!response.getStatusCode().is2xxSuccessful()) {
            log.error("响铃记录创建失败{}", JSON.toJSONString(response),  JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));
            throw new RuntimeException("创建响铃记录失败");
        }
        JSONObject ringObject = JSON.parseObject(response.getBody());
        if(ringObject.getInteger("code") != 0){
            log.error("响铃记录创建失败{}", JSON.toJSONString(response),  JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));
            throw new RuntimeException("创建响铃记录失败");
        }

    }

    public void onEstablished(String cookies, String seatNo,String mobile,String timestamp){
        ResponseEntity<String> response = restTemplate.exchange(panamaCoreHost+"hotline/callRecord/onEstablished", HttpMethod.POST, hotlineEntity(cookies,seatNo,mobile,timestamp), String.class);
        if (!response.getStatusCode().is2xxSuccessful()) {
            log.error("响铃记录创建失败{}", JSON.toJSONString(response),  JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));
            throw new RuntimeException("创建接听记录失败");
        }
        JSONObject establishedObject = JSON.parseObject(response.getBody());
        if(establishedObject.getInteger("code") != 0){
            log.error("响铃记录创建失败{}", JSON.toJSONString(response),  JSON.toJSONString(hotlineEntity(cookies,seatNo,mobile,timestamp)));
            throw new RuntimeException("创建接听记录失败");
        }

    }


    public HttpEntity<String> hotlineEntity(String cookies, String seatNo,String mobile,String timestamp){
        Map<String,Object>param = new HashMap<>();
        param.put("ANI", mobile);
        param.put("agentID",seatNo);
        String sessionIdInit = MessageFormat.format("${0}#{1}", 10010, timestamp);
        param.put("connID",sessionIdInit);
        param.put("thisDN",123456789L);
        param.put("uuid","数据工厂");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.COOKIE,cookies);
        httpHeaders.set(HttpHeaders.CONTENT_TYPE,"application/json");
        HttpEntity<String> entity = new HttpEntity<>(JSON.toJSONString(param), httpHeaders);
        return entity;

    }


}




