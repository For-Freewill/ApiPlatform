package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import java.io.Serializable;

/**
 * pf_order 与 pf_order_detail联合查询
 *
 * @Author wulei
 * @Date 2020/10/28 15:52
 */
public class PfOrderDetailMoreEntity extends PfOrderEntity implements Serializable {
    private String appName;
    private String itemName;
}
