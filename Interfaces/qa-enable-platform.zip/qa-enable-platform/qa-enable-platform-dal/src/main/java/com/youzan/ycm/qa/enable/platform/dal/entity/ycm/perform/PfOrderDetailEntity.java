package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-28 10:37
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("pf_order_detail")
public class PfOrderDetailEntity implements Serializable {
    private String id;

    private Long pfOrderId;

    private String buyKdtId;

    private String buyYcmId;

    private String buyYcmType;

    private String applyKdtId;

    private String applyYcmId;

    private String applyYcmType;

    private String buyType;

    private String appId;

    private String appName;

    private String itemId;

    private String itemName;

    private String level;

    private String performType;

    private String performRule;

    private String performState;

    private String groupId;

    private String groupType;

    private Long giftAssetId;

    private Long giftTemplateId;

    private Byte useDetailId;

    private String bizExt;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}
