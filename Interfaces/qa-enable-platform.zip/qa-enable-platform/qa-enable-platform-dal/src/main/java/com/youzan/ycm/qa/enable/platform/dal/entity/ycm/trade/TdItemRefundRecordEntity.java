package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @author wulei
 * @date 2020-10-10
 * 空表-忽略
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_item_refund_record")
public class TdItemRefundRecordEntity extends BaseOrderDO implements Serializable {

    /**
     * 营销id
     */
    private String promotionId;
    /**
     * 营销类别
     */
    private String promotionType;
    /**
     * 营销内容
     */
    private String promotionBehavior;
    /**
     * 营销级别
     */
    private String promotionScope;
    /**
     * 目标ID
     */
    private Long relateId;
    /**
     * 目标类型
     */
    private String relateType;
    /**
     * 营销名
     */
    private String promotionName;
    /**
     * 营销描述
     */
    private String promotionDesc;
    /**
     * 优惠金额
     */
    private Long reduceAmt;
    /**
     * 是否有赠品
     */
    private Boolean hasPresent;
    /**
     * 赠送yzb
     */
    private Long presentYzb;
}
