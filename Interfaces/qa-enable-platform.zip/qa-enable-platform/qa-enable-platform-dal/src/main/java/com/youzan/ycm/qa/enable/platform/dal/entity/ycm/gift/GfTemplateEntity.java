package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:12
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("gf_template")
public class GfTemplateEntity implements Serializable {
    private Long id;

    private String name;

    private String descInfo;

    private String type;

    private Integer isDeleted;

    private Date createdAt;

    private Date updatedAt;

    private String sign;

    private Long value;

    private String bizExt;
}
