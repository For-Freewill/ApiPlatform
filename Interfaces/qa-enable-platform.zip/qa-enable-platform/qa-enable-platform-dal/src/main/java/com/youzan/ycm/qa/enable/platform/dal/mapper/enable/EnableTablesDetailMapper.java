package com.youzan.ycm.qa.enable.platform.dal.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableTablesDetailEntity;

/**
 * @author wulei
 * @date 2020/11/19 16:03
 */
@DS("ycmqa")
public interface EnableTablesDetailMapper extends BaseMapper<EnableTablesDetailEntity> {
}