package com.youzan.ycm.qa.enable.platform.dal.entity.crm.kefu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-15 11:35
 */
@Data
public class ServiceRecord implements Serializable {
    /**
     * 服务表自增id
     */
    private Long id;

    /**
     * 开始聊天记录ID
     */
    private Long startChatId;

    /**
     * 结束聊天记录ID（0表示未结束）
     */
    private Long endChatId;

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 客户类型
     */
    private Integer customerType;

    /**
     * 客服ID
     */
    private Long servantId;

    /**
     * 服务开始时间
     */
    private Date startTime;

    /**
     * 服务结束时间
     */
    private Date endTime;

    /**
     * 第一次回复时间
     */
    private Date firstReplyTime;

    /**
     * 服务是否结束（0，服务中 2，服务完结）
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;

    /**
     * 咨询时间
     */
    private Date consultTime;

    /**
     * 问题类型标签
     */
    private String qLabel;

    /**
     * 小节
     */
    private String summary;

    /**
     * 问题类型
     */
    private Integer questionType;

    /**
     * 接待类型
     */
    private Integer receptionType;

    /**
     * 消息来源 wsc_pc,wsc_app,wxd_app,mars_mp,manual_create
     */
    private String msgSource;

    /**
     * 客户转会话情况：0无转会话操作，1转过留言，2转过人工
     */
    private Integer transferStatus;

    /**
     * 是否是一次完成服务，0：未更新，1：不是，2：是
     */
    private Integer isOneTimeCompleted;

    /**
     * 是否转接 0 未转接  1 有转接
     */
    private Integer hasTransfer;


    /**
     * 是否是一次完成服务，0：未更新，1：手工关闭，2：自动关闭
     */
    private Integer closeType;


    /**
     * 满意度 1非常不满意 2不满意 3一般 4满意 5 非常满意
     */
    private Integer serviceScore;

    /**
     * 0：服务持续时间(秒)
     */
    private Long serviceDuration;

    /**
     * 首次服务人员
     */
    private Long firstServantId;

    /**
     * 最后服务人员
     */
    private Long lastServantId;

    /**
     * 是否被选中为精选
     */
    private int isSelected;

    /**
     * 精选原因
     */
    private String selectedReasons;

    /**
     * 精选标签
     */
    private String tag;

    /**
     * 服务记录额外信息
     */
    private String extra;

    /**
     * 接待状态
     */
    private int model;
}
