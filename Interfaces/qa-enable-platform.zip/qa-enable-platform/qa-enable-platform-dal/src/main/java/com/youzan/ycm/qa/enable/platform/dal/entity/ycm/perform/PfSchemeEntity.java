package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:53
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_scheme")
public class PfSchemeEntity implements Serializable {
    /**
     * 方案id
     */
    private Long id;

    /**
     * 方案拥有者ID
     */
    private String ownerId;

    /**
     * 方案拥有者类型
     */
    private String ownerType;

    /**
     * 方案使用者ID
     */
    private String applierId;

    /**
     * 方案使用者类型
     */
    private String applierType;

    /**
     * 方案状态
     */
    private String state;

    /**
     * 应用id
     */
    private String appId;

    /**
     * 使用时间
     */
    private Date applyTime;

    /**
     * 失效时间
     */
    private Date invalidTime;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;
}
