package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 店铺产品ACK
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
@Data
public class FwShopProductAckDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**订单ID*/
	private Long orderId;

	/**成单业绩归属已确认*/
	private Integer acked;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
