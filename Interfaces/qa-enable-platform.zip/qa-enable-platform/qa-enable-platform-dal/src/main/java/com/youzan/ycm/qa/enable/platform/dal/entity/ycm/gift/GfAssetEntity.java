package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("gf_asset")
public class GfAssetEntity implements Serializable {
    private Long id;

    private Date createdAt;

    private Date updatedAt;

    private Byte isDeleted;

    private String assetName;

    private String assetDesc;

    private String icon;

    private String state;

    private Date beginTime;

    private Date endTime;

    private Date receiveTime;

    private Date refundTime;

    private Date sentTime;

    private String ownerYcmid;

    private String ownerYcmidType;

    private Long templateId;

    private String remark;

    private String operator;

    private String bizId;

    private String bizType;

    private String originType;

    private String type;

    private Long value;

    private String bizExt;

    private String migrateTag;
}
