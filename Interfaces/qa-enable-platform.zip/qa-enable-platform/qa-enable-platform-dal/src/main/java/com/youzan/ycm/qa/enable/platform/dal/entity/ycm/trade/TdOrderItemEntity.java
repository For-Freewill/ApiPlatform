package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_order_item")
public class TdOrderItemEntity extends BaseOrderDO implements Serializable {
    private String orderId;

    private String buyerId;

    private String buyerType;

    private String spuId;

    private String spuSnapshot;

    private String atomicityType;

    private String spuName;

    private String spuAppType;

    private String skuId;

    private String skuSnapshot;

    private String skuName;

    private Long skuPrice;

    private String specType;

    private String specDesc;

    private Long quantitySpec;

    private Long periodSpec;

    private Long skuNum;

    private Long itemOrigPrice;

    private Long currencyAmt;

    private Long yzbAmt;

    private Long deductionAmt;

    private Long promotionAmt;

    private Long accountAmt;

    private Long sharedPromotionAmt;

    private Long goodsPromotionAmt;

    private String tdExt;

    private String bizExt;

    private String migrateTag;

    private Long priceChangeAmt;

    private Long mergedChangeAmt;

}
