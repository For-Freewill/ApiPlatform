package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:12
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("gf_template_goods")
public class GfTemplateGoodsEntity implements Serializable {
    private Long id;

    private Long templateId;

    private String spuId;

    private String spuSnapshot;

    private String skuId;

    private String skuSnapshot;

    private Long skuNum;

    private Long specPeriod;

    private Long specQuantity;

    private String paramGenerateRules;

    private Long totalStock;

    private Long maxKdtStock;

    private Integer isDeleted;

    private Date createdAt;

    private Date updatedAt;
}
