package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020/12/17 19:18
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_doc_detail")
public class EnableDocEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 文档名称
     */
    @TableField(value = "doc_name")
    private String docName;

    /**
     * 商业化赋能表DDL语句
     */
    @TableField(value = "doc_url")
    private String docUrl;

    /**
     * 商业化赋能表描述信息
     */
    @TableField(value = "doc_ext")
    private String docExt;

    /**
     * 商业化赋能表描述信息
     */
    @TableField(value = "doc_type")
    private String docType;

    /**
     * 商业化赋能表其他信息
     */
    @TableField(value = "doc_author")
    private String docAuthor;

}
