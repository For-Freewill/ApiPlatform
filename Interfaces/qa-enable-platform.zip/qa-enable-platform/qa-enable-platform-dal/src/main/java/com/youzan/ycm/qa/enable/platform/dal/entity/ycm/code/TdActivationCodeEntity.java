package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/5 15:42
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_activation_code")
public class TdActivationCodeEntity implements Serializable {
    private Long id;

    private String code;

    private String batchNo;

    private String price;

    private String sellChannel;

    private String codeApplyScene;

    private String bizExt;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}
