package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_pmt_result_detail")
public class TdPmtResultDetailEntity extends BaseOrderDO implements Serializable {

    private String pmtId;

    private String pmtType;

    private String pmtBehav;

    private String pmtScope;

    private Long relateId;

    private String relateType;

    private String pmtName;

    private String pmtDesc;

    private Long reduceAmt;

    private Boolean hasPresent;

    private Long presentYzb;
}
