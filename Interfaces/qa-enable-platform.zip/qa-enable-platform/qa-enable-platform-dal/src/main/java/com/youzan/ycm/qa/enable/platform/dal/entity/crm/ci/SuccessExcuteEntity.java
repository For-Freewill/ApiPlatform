package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * <p>
 * 执行成功
 * </p>
 *
 * @author xiongrun
 * @since 2021-08-11
 */
@Data
public class SuccessExcuteEntity {
     // 应用
     String caseBelongApp;

     // 执行成功次数
     int successTotal;
}
