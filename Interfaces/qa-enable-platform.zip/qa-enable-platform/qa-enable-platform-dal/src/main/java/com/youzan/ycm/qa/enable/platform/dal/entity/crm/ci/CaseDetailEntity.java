package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用例详情
 * </p>
 *
 * @author hujiping
 * @since 2021-08-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("case_detail")
public class CaseDetailEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * case名称
     */
    private String caseName;

    /**
     * case所属测试类
     */
    private String caseBelongClass;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * case作者
     */
    private String caseAuthor;

    /**
     * case路径
     */
    private String caseUrl;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;

    /**
     * 是否删除
     */
    private boolean isDelete;
}
