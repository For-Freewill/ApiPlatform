package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 店铺角色状态历史
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
@Data
public class FwShopRoleStateHistDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺角色ID*/
	private Long shopRoleId;

	/**店铺ID（冗余）*/
	private Long kdtId;

	/**角色类型（冗余）*/
	private String roleType;

	/**变更前角色状态*/
	private Integer fromState;

	/**变更后角色状态*/
	private Integer toState;

	/**毫秒级时间戳*/
	private Long seq;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
