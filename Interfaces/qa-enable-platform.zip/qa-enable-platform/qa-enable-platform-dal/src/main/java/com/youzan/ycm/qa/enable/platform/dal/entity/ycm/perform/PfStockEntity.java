package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by baoyan on 1/21/22.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_stock")
public class PfStockEntity implements Serializable {

    /**
     * 库存id
     */
    private Long id;

    /**
     * 使用店铺id
     */
    private String applyKdtId;

    private String applyYcmId;

    private String applyYcmType;

    /**
     * 应用id
     */
    private String appId;

    /**
     * 总库存
     */
    private Long totalStock;

    /**
     * 已使用的库存
     */
    private Long usedStock;

    /**
     * 剩余有效库存
     */
    private Long validStock;

    /**
     * 是否删除
     */
    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}

