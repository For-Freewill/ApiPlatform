package com.youzan.ycm.qa.enable.platform.dal.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScorePO;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreQAPO;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableURLCounterEntity;

import java.util.List;

/**
 * @Author wulei
 * @Date 2021-12-21
 */
@DS("ycmqa")
public interface EnableURLCounterMapper extends BaseMapper<EnableURLCounterEntity> {


}
