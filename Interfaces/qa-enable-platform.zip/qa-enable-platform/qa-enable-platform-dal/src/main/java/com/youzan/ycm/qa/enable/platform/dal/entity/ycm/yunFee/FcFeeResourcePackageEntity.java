package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 计费-fc_fee_resource_package 表
 *
 * @author wulei
 * @date 2021-01-20 14:40
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("fc_fee_resource_package")
public class FcFeeResourcePackageEntity implements Serializable {
    private long id;

    private long kdtId;

    private String resourceNo;

    private String relatedNo;

    private Integer feeType;

    private String used;

    private String total;

    private Integer state;

    private long version;

    private Date effectTime;

    private Date expireTime;

    private Integer resourceMode;

    private Date createdAt;

    private Date updatedAt;

    private String remark;

    private String extension;
}

