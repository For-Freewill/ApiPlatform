package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_pst")
public class TdPstEntity extends BaseOrderDO implements Serializable {

    private String pmtRsId;

    private Long relateId;

    private String relateType;

    private Long pstAssetId;

    private Long pstTmpId;

    private String pstName;

    private String pstDesc;

    private String pstType;

    private String bizExt;

}
