package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/8 14:24
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("cd_redeem_code_batch")
public class CdRedeemCodeBatchEntity implements Serializable {
    private static final long serialVersionUID = -1419564906739495499L;

    private Long id;

    private String batchNo;

    private String performType;

    private String type;

    private Date applyStartTime;

    private Date applyEndTime;

    private Integer initStock;

    private Integer codeNum;

    private Integer createdCodeNum;

    private String codeCreateBizContent;

    private String createrYcmType;

    private String createrYcmId;

    private String createrName;

    private String bizExt;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;

}