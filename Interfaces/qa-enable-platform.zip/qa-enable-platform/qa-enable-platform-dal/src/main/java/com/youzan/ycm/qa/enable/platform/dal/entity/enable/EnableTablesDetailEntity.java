package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020/11/19 15:36
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_tables_detail")
public class EnableTablesDetailEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 商业化赋能表名称
     */
    @TableField(value = "table_name")
    private String tableName;

    /**
     * 商业化赋能表DDL语句
     */
    @TableField(value = "table_desc")
    private String tableDesc;

    /**
     * 商业化赋能表描述信息
     */
    @TableField(value = "table_seq")
    private Integer tableSeq;

    /**
     * 商业化赋能表描述信息
     */
    @TableField(value = "table_type")
    private String tableType;

    /**
     * 商业化赋能表其他信息
     */
    @TableField(value = "ext")
    private String ext;

}
