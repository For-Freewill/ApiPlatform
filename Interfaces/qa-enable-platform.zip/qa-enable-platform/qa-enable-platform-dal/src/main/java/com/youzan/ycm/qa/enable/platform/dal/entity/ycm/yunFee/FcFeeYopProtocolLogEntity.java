package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/20 14:45
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("fc_fee_yop_protocol_log")
public class FcFeeYopProtocolLogEntity implements Serializable {
    private long id;

    private long kdtId;

    private String orderId;

    private int changeType;

    private String changeContent;

    private Date createdAt;

    private Date updatedAt;
}
