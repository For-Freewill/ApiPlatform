package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_coupon_record")
public class PfCouponRecordEntity implements Serializable {

    private String id;

    private Long couponId;

    private Long applyYcmId;

    private String applyYcmType;

    private String state;

    private Long pfOrderId;

    private Long orderDetailId;

    private Long grantNum;

    private String grantDetail;

    private Date grantTime;

    private Long recycleNum;

    private String recycleDetail;

    private Date recycleTime;

    private Date createdAt;

    private Date updatedAt;
}
