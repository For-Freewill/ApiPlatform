package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020-10-27
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_query_history")
public class EnableQueryHistoryEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 保存的方案名称
     */
    private String recordName;

    /**
     * 方案涉及的表列表
     */
    @TableField(value = "tables")
    private String tables;

    /**
     * biz后台操作人ID
     */
    private String operatorId;

    /**
     * biz后台操作人类型
     */
    private String operatorType;

    /**
     * biz后台操作人名称
     */
    private String operatorName;

}
