package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-05-12 13:52
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_fee_resource_package")
public class PfFeeResourcePackageEntity implements Serializable {

    private Long id;

    private Date createdAt;

    private Date updatedAt;

    private Byte isDelete;

    private String relatedNo;

    private Long pfOrderId;

    private Long pfOrderDetailId;

    private Long grantQuota;

    private String applyYcmType;

    private String applyYcmId;

    private Integer state;

    private Date effectTime;

    private Date expireTime;

    private Date recallTime;

    private Integer quotaType;

    private String appCategory;
}
