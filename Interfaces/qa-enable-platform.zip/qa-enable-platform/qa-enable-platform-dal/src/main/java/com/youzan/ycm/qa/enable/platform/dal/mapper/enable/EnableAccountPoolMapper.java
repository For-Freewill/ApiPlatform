package com.youzan.ycm.qa.enable.platform.dal.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableAccountPoolEntity;

/**
 * @author wuwu
 * @date 2021/2/6 6:46 PM
 */
@DS("ycmqa")
public interface EnableAccountPoolMapper extends BaseMapper<EnableAccountPoolEntity> {
}
