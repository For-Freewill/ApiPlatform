package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:41
 **/

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_dct_result_detail")
public class TdDeductionResultDetailEntity extends BaseOrderDO implements Serializable {
    /**
     * 交易单号
     */
    private String tradeNo;
    /**
     * 营销id
     */
    private String regulationId;
    /**
     * 营销类别
     */
    private String regulationType;
    /**
     * 营销内容
     */
    private String regulationBehavior;
    /**
     * 营销级别
     */
    private String regulationScope;
    /**
     * 目标ID
     */
    private Long relateId;
    /**
     * 目标类型
     */
    private String relateType;
    /**
     * 营销名
     */
    private String regulationName;
    /**
     * 营销描述
     */
    private String regulationDesc;
    /**
     * 优惠金额
     */
    private Long reduceAmt;
    /**
     * 赠送yzb
     */
    private Long returnYzb;
}
