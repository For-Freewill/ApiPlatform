package com.youzan.ycm.qa.enable.platform.dal.entity.repeater;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("replay")
public class ReplayEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField(value = "gmt_create", fill = FieldFill.INSERT)
    private Date gmtCreate;

    @TableField(value = "gmt_modified", fill = FieldFill.INSERT_UPDATE)
    private Date gmtModified;

    private String appName;

    private String environment;

    private String ip;

    private String repeatId;

    private Integer status;

    private String traceId;

    private Long cost;

    private String diffResult;

    private String response;

    private String mockInvocation;

    private Boolean success;

    private String recordId;

    /**
     * 生成时间
     */
    @TableField(value = "created_at", fill = FieldFill.INSERT)
    private Date createdAt;

    /**
     * 更新时间
     */
    @TableField(value = "updated_at", fill = FieldFill.INSERT_UPDATE)
    private Date updatedAt;

}
