package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 服务归属划拨
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
@Data
public class FwFuwuBelongAssignDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**订单ID*/
	private Long orderId;

	/**划拨的服务归属团队*/
	private String assignedFuwuBelongTeam;

	/**划拨的服务归属ID*/
	private Long assignedFuwuBelongId;

	/**划拨时间*/
	private Date assignedTime;

	/**操作人ID*/
	private Long operatorId;

	/**操作人类型*/
	private Integer operatorType;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
