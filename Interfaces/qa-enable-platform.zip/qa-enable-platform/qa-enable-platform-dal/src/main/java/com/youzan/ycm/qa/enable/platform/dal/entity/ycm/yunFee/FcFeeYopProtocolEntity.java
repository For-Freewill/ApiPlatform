package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 计费-fc_fee_resource_package 表
 *
 * @author wulei
 * @date 2021-01-20 14:40
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("fc_fee_yop_protocol")
public class FcFeeYopProtocolEntity implements Serializable {

    private long id;

    private long kdtId;

    private String orderId;

    private String protocolNo;

    private Date effectTime;

    private Date expireTime;

    private Integer state;

    private Integer quotaType;

    private String quota;

    private String extension;

    private Date createdAt;

    private Date updatedAt;

}
