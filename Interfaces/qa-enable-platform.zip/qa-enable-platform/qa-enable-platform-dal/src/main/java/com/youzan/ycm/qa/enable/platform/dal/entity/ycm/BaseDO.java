package com.youzan.ycm.qa.enable.platform.dal.entity.ycm;

import lombok.Data;

import java.util.Date;

@Data
public abstract class BaseDO {
    /**
     * 主键ID
     */
    protected String id;

    /**
     * 创建时间
     */
    protected Date createdAt;

    /**
     * 更新时间
     */
    protected Date updatedAt;

    /**
     * 是否已删除 [0: 未删除，1或其它值代表已删除]
     */
    protected Boolean isDeleted;
}
