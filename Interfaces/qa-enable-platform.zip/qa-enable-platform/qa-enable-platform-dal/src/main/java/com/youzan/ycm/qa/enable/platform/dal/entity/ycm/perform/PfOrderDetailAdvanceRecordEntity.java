package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_order_detail_advance_record")
public class PfOrderDetailAdvanceRecordEntity implements Serializable {
    private String id;

    private Long advanceActiveRecordId;

    private Long advancePfOrderId;

    private Long advancePfOrderDetailId;

    private String buyYcmId;

    private String buyYcmType;

    private String applyYcmId;

    private String applyYcmType;

    private String appId;

    private String appName;

    private String itemId;

    private String itemName;

    private String level;

    private String performRule;

    private String groupId;

    private String groupType;

    private Date advanceTime;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}