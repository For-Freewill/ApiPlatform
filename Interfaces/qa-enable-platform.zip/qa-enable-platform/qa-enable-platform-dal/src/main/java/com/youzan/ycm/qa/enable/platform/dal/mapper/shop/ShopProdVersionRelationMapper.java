package com.youzan.ycm.qa.enable.platform.dal.mapper.shop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.shop.ShopProdVersionRelationEntity;

/**
 * @author wuwu
 * @date 2021/1/18 1:59 PM
 */
@DS("shop")
public interface ShopProdVersionRelationMapper extends BaseMapper<ShopProdVersionRelationEntity> {
}
