package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-30 16:36
 */
@Data
public class CountByOwnerEntity {

    /**
     * case所属应用
     */
    private String owner;

    /**
     * case总数
     */
    private int totalCount;
}
