package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-27 11:57
 */
@Data
public class SingleOwnerCaseExcuteDetailEntity {

    /**
     * 关联用例id
     */
    private Long caseId;

    /**
     * 执行成功率
     */
    private double successRate;

    /**
     * case名
     */
    private String caseName;

    /**
     * case路径
     */
    private String caseUrl;

    /**
     * case所属应用
     */
    private String caseBelongApp;

}
