package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 服务流程实例
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:51
 */
@Data
public class FwProcInstDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**流程实例ID*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**流程模版*/
	private String procTemplate;

	/**流程开启时间*/
	private Date startTime;

	/**流程开启时的变量*/
	private String startVariable;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
