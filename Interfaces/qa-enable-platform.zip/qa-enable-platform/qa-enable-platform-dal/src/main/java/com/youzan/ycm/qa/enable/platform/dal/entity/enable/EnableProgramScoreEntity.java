package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2021-05-31
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_program_score")
public class EnableProgramScoreEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 项目名称
     */
    private String programName;

    /**
     * 项目测试
     */
    private String programQa;

    /**
     * 项目开发
     */
    private String programDev;

    /**
     * 上线时间
     */
    private Date programOnlineTime;

    /**
     * 总分-满5分
     */
    private Double scoreTotal;

    /**
     * 需求扣分
     */
    private Double scorePrd;

    /**
     * 研发扣分
     */
    private Double scoreDev;

    /**
     * 测试扣分
     */
    private Double scoreQa;

    /**
     * 上线扣分
     */
    private Double scoreOnline;

    /**
     * 项目管理扣分
     */
    private Double scorePm;

    /**
     * 效率地址
     */
    private String xiaolvUrl;

    /**
     * 报告地址
     */
    private String reportUrl;

    /**
     * 测试分析地址
     */
    private String testCase;

    /**
     * 小组
     */
    private String team;

    /**
     * 说明
     */
    private String ext;

    /**
     * 扣分tags
     */
    private String tags;

}
