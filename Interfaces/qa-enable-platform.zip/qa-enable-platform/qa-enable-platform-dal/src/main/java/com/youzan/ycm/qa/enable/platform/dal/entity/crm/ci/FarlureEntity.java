package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * <p>
 * 失败处理
 * </p>
 *
 * @author hujiping
 * @since 2021-08-11
 */
@Data
public class FarlureEntity {
     int totalCount;
     int failureTotal;
}
