package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_order")
public class TdOrderEntity extends BaseOrderDO implements Serializable {
    private String outBizNo;

    private String crmApprovalNo;

    private String state;

    private String env;

    private Date retryTime;

    private String retryCount;

    private String isVisible;

    private Long buyerId;

    private String buyerType;

    private String buyerName;

    private String sellerId;

    private String sellerType;

    private Long operatorId;

    private String operatorType;

    private Long origPrice;

    private Long currencyAmt;

    private Long yzbAmt;

    private Long deductionAmt;

    private Long promotionAmt;

    private Long accountAmt;

    private String frontSource;

    private String outChannel;

    private String memo;

    private Date paidTime;

    private Date payExpireTime;

    private String closeReason;

    private Date closeTime;

    private String tdExt;

    private String bizExt;

    private String migrateTag;

    private String channel;

    private String showState;

    private Long priceChangeAmt;

    private Long mergedChangeAmt;
}
