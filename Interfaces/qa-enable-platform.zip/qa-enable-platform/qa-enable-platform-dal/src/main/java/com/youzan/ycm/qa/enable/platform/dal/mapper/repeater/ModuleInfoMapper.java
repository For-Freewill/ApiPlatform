package com.youzan.ycm.qa.enable.platform.dal.mapper.repeater;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ModuleInfoEntity;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 */
@DS("ycmqa")
public interface ModuleInfoMapper extends BaseMapper<ModuleInfoEntity> {
}
