package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_biz_record")
public class PfBizRecordEntity implements Serializable {
    private Long id;
    private String bizOrderId;
    private String bizOrderType;
    private String bizState;
    private Date createdAt;
    private Date updatedAt;
}
