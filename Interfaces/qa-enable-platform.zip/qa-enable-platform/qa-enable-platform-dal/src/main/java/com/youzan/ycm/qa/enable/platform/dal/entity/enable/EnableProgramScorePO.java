package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @program: qa-enable-platform
 * @description
 * @author: 吴磊
 * @create: 2021-11-08
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableProgramScorePO implements Serializable {

    /**
     * 月份
     */
    private String month;

    /**
     * 统计
     */
    private Integer total;

}
