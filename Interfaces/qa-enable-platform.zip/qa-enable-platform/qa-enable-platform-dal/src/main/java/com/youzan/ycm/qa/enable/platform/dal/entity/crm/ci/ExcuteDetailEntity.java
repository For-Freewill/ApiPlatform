package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用例执行详情
 * </p>
 *
 * @author hujiping
 * @since 2021-08-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("excute_detail")
public class ExcuteDetailEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * jenkinsjob id
     */
    private Long jobId;

    /**
     * 关联用例id
     */
    private Long caseId;

    /**
     * 执行结果
     */
    private Integer excuteResult;

    /**
     * 执行耗时
     */
    private String excuteCost;

    /**
     * 执行jenkins
     */
    private String excuteJenkins;

    /**
     * 错误信息
     */
    private String errorDetail;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * 执行环境
     */
    private String env;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;


}
