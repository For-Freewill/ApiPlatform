package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wuwu
 * @date 2021/2/6 6:40 PM
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_account_pool")
public class EnableAccountPoolEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 店铺Id
     */
    @TableField(value = "kdt_id")
    private String kdtId;

    /**
     * 店铺名称
     */
    @TableField(value = "kdt_name")
    private String kdtName;

    /**
     * 店铺是否被占用
     */
    @TableField(value = "is_applied")
    private Integer isApplied;

    /**
     * 店铺是否被清理
     */
    @TableField(value = "is_new")
    private Integer isNew;

    /**
     *  店铺编码-店铺产品线类型
     */
    @TableField(value = "prod_code")
    private String prodCode;

    /**
     * user id
     */
    @TableField(value = "user_id")
    private String userId;

    /**
     * 乐观锁版本
     */
    @TableField(value = "version")
    @Version
    private Integer version;

}
