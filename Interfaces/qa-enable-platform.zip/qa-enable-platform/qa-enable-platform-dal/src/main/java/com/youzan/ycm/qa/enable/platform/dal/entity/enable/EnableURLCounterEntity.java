package com.youzan.ycm.qa.enable.platform.dal.entity.enable;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021-12-21
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("enable_uri_counter")
public class EnableURLCounterEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 请求URL
     */
    private String url;

    /**
     * 展示=1
     */
    private Byte isShow;

    /**
     * 计数器
     */
    private Integer count;

    /**
     * 工具开发
     */
    private String author;

    /**
     * 说明
     */
    private String ext;
}
