package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-05-12 13:36
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_biz_record")
public class TdBizRecordEntity extends BaseOrderDO implements Serializable {
    private String bizOrderId;

    private String bizOrderType;

    private String bizState;

    private Date created_at;

    private Date updated_at;
}
