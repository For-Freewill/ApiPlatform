package com.youzan.ycm.qa.enable.platform.dal.entity.ycm;

import lombok.Data;

@Data
public abstract class BaseOrderDO extends BaseDO {
    /**
     * td_no
     */
    private String tdNo;
}
