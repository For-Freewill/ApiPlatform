package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:12
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("gf_biz_record")
public class GfBizRecordEntity implements Serializable {
    private Long id;

    private String bizId;

    private String bizType;

    private String state;

    private Date createdAt;

    private Date updatedAt;
}
