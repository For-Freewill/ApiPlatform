package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_yzb_grant_order")
public class TdYzbGrantOrderEntity extends BaseOrderDO implements Serializable {

    private String state;

    private Boolean inRefundOrder;

    private String outBizNo;

    private String outBizType;

    private String targetId;

    private String targetType;

    private Long orderItemId;

    private Long applyAmt;

    private Long settleAmt;

    private String grantReason;

    private Date applyTime;

    private Date finishTime;

    private String memo;
}
