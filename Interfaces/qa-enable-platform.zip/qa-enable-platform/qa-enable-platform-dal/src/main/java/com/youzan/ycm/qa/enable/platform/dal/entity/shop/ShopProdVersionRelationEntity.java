package com.youzan.ycm.qa.enable.platform.dal.entity.shop;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wuwu
 * @date 2021/1/18 1:51 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("shop_prod_version_relation")
public class ShopProdVersionRelationEntity implements Serializable {
    private Long id;

    /**
     * 店铺kdtId
     */
    private Long kdtId;

    /**
     * 产品编码
     */
    private String prodCode;

    /**
     * 版本编码
     */
    private String versionCode;

    /**
     * 生命周期状态
     */
    private String lifecycleStatus;

    /**
     * 生命周期开始时间
     */
    private Date lifecycleBeginTime;

    /**
     * 生命周期结束时间
     */
    private Date lifecycleEndTime;

    /**
     * 有效期开始时间
     */
    private Date validBeginTime;

    /**
     * 有效期结束时间
     */
    private Date validEndTime;

    /**
     * 是否聚合结果（1：是；0：否）
     */
    private Integer isAggr;

//    private Date createdTime;
//
//    private Date updatedTime;

    /**
     * 创建时间
     */
    protected Date createdAt;

    /**
     * 更新时间
     */
    protected Date updatedAt;
}
