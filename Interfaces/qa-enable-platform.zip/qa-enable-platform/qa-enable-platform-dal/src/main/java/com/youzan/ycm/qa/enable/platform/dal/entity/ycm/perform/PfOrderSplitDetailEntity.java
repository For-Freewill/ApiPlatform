package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/25 14:56
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_order_split_detail")
public class PfOrderSplitDetailEntity implements Serializable {
    private Long id;

    private String bizId;

    private String bizType;

    private String bizItemId;

    private String splitId;

    private String splitType;

    private String state;

    private Date createdAt;

    private Date updatedAt;
}