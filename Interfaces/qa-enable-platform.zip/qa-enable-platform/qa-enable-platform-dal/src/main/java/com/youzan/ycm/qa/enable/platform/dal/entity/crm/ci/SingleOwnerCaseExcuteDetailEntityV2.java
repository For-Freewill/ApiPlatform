package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-30 14:53
 */
@Data
public class SingleOwnerCaseExcuteDetailEntityV2 {
    /**
     * 关联用例id
     */
    private Long caseId;

    /**
     * case名
     */
    private String caseName;

    /**
     * case路径
     */
    private String caseUrl;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * 平均执行时长
     */
    private double averageExcuteCost;

}
