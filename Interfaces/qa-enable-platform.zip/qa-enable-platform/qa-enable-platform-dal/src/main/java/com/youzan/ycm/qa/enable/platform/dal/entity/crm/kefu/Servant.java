package com.youzan.ycm.qa.enable.platform.dal.entity.crm.kefu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2022-02-21 18:02
 */
@Data
public class Servant implements Serializable {
    /**
     * 自增id
     */
    private Long id;

    /**
     * cas_uid
     */
    private Long casUid;

    /**
     * 注册在消息中心mercury的用户ID
     */
    private String uid;

    /**
     * crm部门ID
     */
    private Long departmentId;


    /**
     * 客服头像
     */
    private String avatar;

    /**
     * 用户名称
     */
    private String username;

    /**
     * 真名
     */
    private String name;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 客服状态（在线1 忙碌2 离线3 就餐4 会议5 小休6）
     */
    private Integer status;

    /**
     * 客服连接状态（连接1 未连接0）
     */
    private Integer connectionStatus;

    /**
     * 客满接待上限
     */
    private Integer receptionLimit;

    /**
     * 是否有技能组
     */
    private Integer skillCount;

    /**
     * 标签列表
     */
    private String labelJson;

    /**
     * 职位
     */
    private String title;

    /**
     * 扩展
     */
    private String extra;

    /**
     * 是否被删除
     */
    private Integer isDeleted;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;

    /**
     * 接待的范围
     */
    private String receptionRange;
}
