package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_order_item_biz")
public class PfOrderItemBizEntity implements Serializable {
    /**
     * 主键编号
     */
    private String id;

    /**
     * 商品业务拓展号
     */
    private String itemBizNo;

    /**
     * 个数
     */
    private Long quantity;

    /**
     * 周期
     */
    private Long duration;

    /**
     * 购买类型
     */
    private String buyType;

    /**
     * 可操作时间
     * 履约单可履约的操作时间限制
     */
    private Date operableTime;

    /**
     * 购买主体id
     */
    private String buyId;

    /**
     * 购买主体类型
     */
    private String buyerType;

    /**
     * 应用店铺id
     */
    private String applyKdtId;

    /**
     * 使用主体
     */
    private String applyYcmId;

    /**
     * 使用主体
     */
    private String applyYcmType;

    /**
     * 是否体验卡
     */
    private Boolean isTryCard;

    /**
     * 被追加的方案id
     */
    private Long schemeIdToAppend;
    /**
     * 追加履约单id
     */
    private Long pfOrderIdToAppend;

    /**
     * 立即使用的门店列表
     */
    private String storesToApply;

    /**
     * 立即使用的网店列表
     */
    private String netStoresToApply;

    /**
     * 拓展字段
     */
    private String bizExt;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;

    /**
     * 产品线切换时的信息，json字符串
     */
    private String prodUpgradeInfo;

}