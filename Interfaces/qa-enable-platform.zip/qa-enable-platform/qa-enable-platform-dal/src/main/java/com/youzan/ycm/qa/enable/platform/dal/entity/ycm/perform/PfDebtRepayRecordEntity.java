package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_debt_repay_record")
public class PfDebtRepayRecordEntity implements Serializable {
    private String id;

    private Long debtRecordId;

    private Long repayPfOrderDetailId;

    private Long repayPfOrderId;

    private Long repayQuota;

    private String bizIdempotent;

    private String applyYcmId;

    private String applyYcmType;

    private String appId;

    private String appName;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}