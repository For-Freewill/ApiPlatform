package com.youzan.ycm.qa.enable.platform.dal.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScorePO;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreQAPO;

import java.util.List;

/**
 * @Author wulei
 * @Date 2021-05-31
 */
@DS("ycmqa")
public interface EnableProgramScoreMapper extends BaseMapper<EnableProgramScoreEntity> {

    //    @Select("select EXTRACT(YEAR_MONTH from program_online_time ) as month,count(1) as total from enable_program_score where team=${team} and program_online_time>'2021-01-01' group by month")
    //项目：按照月份汇总
    List<EnableProgramScorePO> monthAnalytics(String team);

    //项目：21年H2按照人员统计
    List<EnableProgramScoreQAPO> qaAnalytics(String team);

}
