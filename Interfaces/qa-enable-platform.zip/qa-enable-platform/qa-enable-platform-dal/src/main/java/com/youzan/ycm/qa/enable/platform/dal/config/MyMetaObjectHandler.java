package com.youzan.ycm.qa.enable.platform.dal.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author wulei
 * @date 2020/11/19 15:38
 * 自动填充功能
 */
@Slf4j
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("start auto insert fill ....");
        if (metaObject.hasGetter("createdAt") && metaObject.hasGetter("updatedAt") && metaObject.hasGetter("isDelete")) {
            setFieldValByName("isDelete", Byte.valueOf("0"), metaObject);
            setFieldValByName("createdAt", new Date(), metaObject);
            setFieldValByName("updatedAt", new Date(), metaObject);
        }
        this.strictInsertFill(metaObject, "isApplied", Integer.class, 0);
        this.strictInsertFill(metaObject, "isNew", Integer.class, 1);


    }

    @Override
    public void updateFill(MetaObject metaObject) {
        log.info("start auto update fill ....");
        if (metaObject.hasGetter("updatedAt")) {
            setFieldValByName("updatedAt", new Date(), metaObject);
        }
    }
}