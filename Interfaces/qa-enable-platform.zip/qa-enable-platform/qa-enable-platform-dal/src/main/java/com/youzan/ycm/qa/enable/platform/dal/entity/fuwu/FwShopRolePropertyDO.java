package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 店铺角色属性
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
@Data
public class FwShopRolePropertyDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺角色ID*/
	private Long shopRoleId;

	/**店铺ID（冗余）*/
	private Long kdtId;

	/**角色类型（冗余）*/
	private String roleType;

	/**最近拜访时间*/
	private Date lastVisitTime;

	/**最近有效拜访时间*/
	private Date lastEffectiveVisitTime;

	/**更新时间戳*/
	private Long touch;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
