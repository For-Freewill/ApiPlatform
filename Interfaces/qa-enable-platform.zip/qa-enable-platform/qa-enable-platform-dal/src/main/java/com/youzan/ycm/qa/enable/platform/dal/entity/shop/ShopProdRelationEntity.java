package com.youzan.ycm.qa.enable.platform.dal.entity.shop;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wuwu
 * @date 2021/1/18 1:53 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("shop_prod_relation")
public class ShopProdRelationEntity implements Serializable {
    private Long id;

    private Long kdtId;

    private String prodCode;

    private String lifecycleStatus;

    private Date beginTime;

    private Date endTime;

    /**
     * 是否聚合结果（1：是；0：否）
     */
    private Integer isAggr;

//    private Date createdTime;
//
//    private Date updatedTime;
    /**
     * 创建时间
     */
    protected Date createdAt;

    /**
     * 更新时间
     */
    protected Date updatedAt;
}
