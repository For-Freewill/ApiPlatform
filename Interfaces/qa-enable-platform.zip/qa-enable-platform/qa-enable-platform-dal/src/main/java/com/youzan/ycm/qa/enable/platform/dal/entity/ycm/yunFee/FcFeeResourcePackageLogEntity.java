package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 计费-fc_fee_resource_package_log 表
 *
 * @author wulei
 * @date 2021-01-20 14:40
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("fc_fee_resource_package_log")
public class FcFeeResourcePackageLogEntity implements Serializable {
    private Long id;

    private String waterNo;

    private Long kdtId;

    private String resourceNo;

    private Integer type;

    private String bizNo;

    private String bizSubNo;

    private Long amount;

    private Long remain;

    private String remark;

    private Date createdAt;

    private Date updatedAt;

    private String extension;
}

