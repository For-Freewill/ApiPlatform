package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_pay_order")
public class TdPayOrderEntity extends BaseOrderDO implements Serializable {
    private String state;

    private String payerId;

    private String payerType;

    private String payeeId;

    private String payeeType;

    private String acctNo;

    private String buyerAcctNo;

    private String partnerId;

    private Long mchId;

    private String mchName;

    private Integer payBizProd;

    private Integer payBizMode;

    private String payBizAction;

    private String payTool;

    private String payBizType;

    private String payAcquireNo;

    private Date startTime;

    private Date expireTime;

    private String tradeDesc;

    private String payWay;

    private Date payFinishTime;

    private Long applyAmt;

    private Long settleAmt;

    private Date voucherCreateTime;

    private Date voucherAuditTime;

    private Boolean isNewPay;

    private Date applyTime;

    private Date settleTime;

    private String bizExt;
}
