package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * jenkins执行表
 * </p>
 *
 * @author hujiping
 * @since 2021-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("ci_jenkins_job")
public class CiJenkinsJobEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * job名称
     */
    private String jobName;

    /**
     * job状态
     */
    private Integer jobState;

    /**
     * job类型(0：普通job，1：重试job)
     */
    private Integer jobType;

    /**
     * 重试job
     */
    private Long referJobId;

    /**
     * job执行环境
     */
    private String jobEnv;

    /**
     * 报告地址
     */
    private String reportUrl;

    /**
     * job分组
     */
    private Integer jobGroup;

    /**
     * job耗时
     */
    private String jobCost;

    /**
     * 总case
     */
    private Integer totalCase;

    /**
     * 失败case
     */
    private Integer failureTotalCase;

    /**
     * 跳过case
     */
    private Integer skipTotalCase;

    /**
     * 成功case
     */
    private Integer successTotalCase;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;


}
