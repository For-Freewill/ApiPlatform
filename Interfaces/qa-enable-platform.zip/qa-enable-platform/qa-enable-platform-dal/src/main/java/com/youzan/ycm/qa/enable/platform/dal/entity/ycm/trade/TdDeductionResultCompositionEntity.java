package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;

import java.io.Serializable;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:44
 **/
@TableName("td_dct_result_composition")
public class TdDeductionResultCompositionEntity extends BaseOrderDO implements Serializable {

    private String tradeNo;

    private Long deductionResultId;

    private Long pfAssetId;

    private String pfAssetSimple;

    private Long cnyReduce;

    private Long yzbReturn;

    private Long presentRecordId;

}