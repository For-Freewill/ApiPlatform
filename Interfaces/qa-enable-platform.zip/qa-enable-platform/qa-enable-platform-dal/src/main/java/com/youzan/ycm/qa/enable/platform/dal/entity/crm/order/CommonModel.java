package com.youzan.ycm.qa.enable.platform.dal.entity.crm.order;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-27 09:48
 **/
@Data
@AllArgsConstructor
public class CommonModel<T> {

    public CommonModel(T code, String label) {
        this.code = code;
        this.label = label;
    }

    private T code;
    private String label;
    private List<CommonModel> children;

}
