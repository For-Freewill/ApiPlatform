package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import lombok.Data;

import java.util.Date;

/**
 * @program: bit-enable
 * @description: 角色池
 * @author: linliying
 * @create: 2021-03-05 16:10
 **/
@Data
public class FwShoprolePool {
    /**
     * 主键
     */
    private Long id;

    /**
     * 角色池名称
     */
    private String name;

    /**
     * 角色池类型 TERRITORY:公海, PROVIDER:渠道商, USER:员工
     */
    private String type;

    /**
     * 当前库存数
     */
    private Integer stock;

    /**
     * 用户类型
     */
    private String userType;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 渠道商ID
     */
    private Long providerId;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;
}
