package com.youzan.ycm.qa.enable.platform.dal.mapper.shop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.shop.ShopProdRelationEntity;

/**
 * @author wuwu
 * @date 2021/1/18 1:57 PM
 */
@DS("shop")
public interface ShopProdRelationMapper extends BaseMapper<ShopProdRelationEntity> {
}
