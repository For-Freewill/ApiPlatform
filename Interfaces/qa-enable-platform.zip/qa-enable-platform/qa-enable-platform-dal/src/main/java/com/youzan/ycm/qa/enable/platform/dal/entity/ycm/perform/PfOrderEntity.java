package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_order")
public class PfOrderEntity implements Serializable {
    private Long id;

    private String bizOrderId;

    private String bizOrderItemId;

    private String crmApprovalNo;

    private String bizOrderType;

    private Long parentId;

    private Long rootId;

    private Boolean isLeaf;

    private String buyKdtId;

    private String buyYcmId;

    private String buyYcmType;

    private String applyKdtId;

    private String applyYcmId;

    private String applyYcmType;

    private String appId;

    private String appName;

    private String itemId;

    private String itemName;

    private Long quantity;

    private String appCategory;

    private String level;

    private String buyType;

    private Long price;

    private Long realPrice;

    private Long yzbPrice;

    private Long promotionPrice;

    private Long goodsPmtPrice;

    private Long orderPmtPrice;

    private Long deductionPrice;

    private Long returnRealPrice;

    private Long returnYzbPrice;

    private String tradeState;

    private String performState;

    private String progressState;

    private Date performTime;

    private Date payTime;

    private Date refundTime;

    private String sourceChannel;

    private String prodUpgradeInfo;

    private String bizExt;

    private String migrateTag;

    private String channel;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}
