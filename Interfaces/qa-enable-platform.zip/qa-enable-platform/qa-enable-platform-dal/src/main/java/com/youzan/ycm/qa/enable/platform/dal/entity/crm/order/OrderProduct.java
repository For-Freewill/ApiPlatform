package com.youzan.ycm.qa.enable.platform.dal.entity.crm.order;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description: 产品类型
 * @author: linliying
 * @create: 2021-04-14 14:42
 **/
@Data
@Accessors(chain = true)
public class OrderProduct {
    /**
     * 自增id
     */
    private Long id;

    /**
     * crm端对产品分类标识
     */
    private String appType;

    /**
     * crm端对产品分类中文名
     */
    private String appTypeName;

    /**
     * 产品id
     */
    private Integer appId;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 版本id
     */

    private Integer itemId;

    /**
     * 版本名称
     */

    private String itemName;

    /**
     * 版本类型
     */
    private String itemType;

    /**
     * 是否生效，1生效 0未生效
     */

    private Boolean isActive;

    /**
     * 是否是主产品, 1是 0不是
     */
    private Boolean isMainProduct;

    /**
     * 成单判单是否关心(是否算业绩)，1:是 0:不是
     */

    private Boolean isOrderConcerned;

    /**
     * 资源流转(聚合计算)是否关心，1:是 0:不是
     */

    private Boolean isResourceConcerned;

    /**
     * 创建时间
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdAt;

    /**
     * 修改时间
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updatedAt;

}
