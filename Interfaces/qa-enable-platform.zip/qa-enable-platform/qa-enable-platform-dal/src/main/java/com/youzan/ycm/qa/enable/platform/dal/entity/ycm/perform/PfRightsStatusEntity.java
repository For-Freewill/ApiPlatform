package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_rights_status")
public class PfRightsStatusEntity implements Serializable {
    private String id;

    private Long orderDetailId;

    private Long pfOrderId;

    private String buyKdtId;

    private String buyYcmId;

    private String buyYcmType;

    private String applyKdtId;

    private String applyYcmId;

    private String applyYcmType;

    private String rightsId;

    private String rightsName;

    private String rightsDesc;

    private Date effectTime;

    private Date expireTime;

    private Long totalQuantity;

    private Long validQuantity;

    private Long checkedQuantity;

    private String state;

    private String groupId;

    private String groupType;

    private Byte isDelete;

    private String channel;

    private String bizExt;

    private Date createdAt;

    private Date updatedAt;
}
