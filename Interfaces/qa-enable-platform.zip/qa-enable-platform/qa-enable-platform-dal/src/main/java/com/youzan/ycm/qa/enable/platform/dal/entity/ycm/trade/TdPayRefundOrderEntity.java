package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_pay_refund_order")
public class TdPayRefundOrderEntity extends BaseOrderDO implements Serializable {
    private String state;

    private Long payOrderId;

    private String payTradeNo;

    private String payAcquireNo;

    private String payPartnerId;

    private String outBizNo;

    private String outBizType;

    private String retryBizNo;

    private String refundWay;

    private String payWay;

    private String refundScene;

    private Long refundApplyAmt;

    private Long refundFeeAmt;

    private Date refundApplyTime;

    private Date refundFinishTime;

    private String memo;

    private Boolean inRefundOrder;
}
