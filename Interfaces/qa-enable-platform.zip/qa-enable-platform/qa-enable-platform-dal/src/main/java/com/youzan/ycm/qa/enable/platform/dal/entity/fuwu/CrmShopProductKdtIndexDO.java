package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 店铺最近一次软件状态
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
@Data
public class CrmShopProductKdtIndexDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺id*/
	private Long kdtId;

	/**购买软件的状态: EFFECTIVE生效中、DISCONTINUED已断约、EFFECTIVE_IN_FUTURE将来生效*/
	private String status;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
