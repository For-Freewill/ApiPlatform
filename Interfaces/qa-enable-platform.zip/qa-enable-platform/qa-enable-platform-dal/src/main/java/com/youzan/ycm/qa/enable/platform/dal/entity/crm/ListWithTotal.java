package com.youzan.ycm.qa.enable.platform.dal.entity.crm;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 15:15
 **/
@Data
@AllArgsConstructor
public class ListWithTotal<T> {
    private List<T> items;

    private int total;

    public static <T> ListWithTotal<T> defaultInstance() {
        return new ListWithTotal<>(Lists.newArrayList(), 0);
    }

    public static <T> ListWithTotal<T> newInstance(List<T> items, int total) {
        return new ListWithTotal<>(items, total);
    }
}
