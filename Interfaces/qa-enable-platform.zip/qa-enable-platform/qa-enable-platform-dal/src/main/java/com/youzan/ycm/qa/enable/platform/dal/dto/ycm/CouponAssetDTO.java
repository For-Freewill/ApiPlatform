package com.youzan.ycm.qa.enable.platform.dal.dto.ycm;

import java.io.Serializable;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:29
 **/
public class CouponAssetDTO implements Serializable {

    /**
     * 券资产id
     */
    private String couponAssetId;

    /**
     * 优惠券id
     */
    private String couponId;

    /**
     * 优惠券名称
     */
    private String couponName;

    /**
     * 发放时间
     */
    private String sendTime;

    /**
     * 领取时间
     */
    private String receiveTime;

    /**
     * 回收时间
     */
    private String recycleTime;

    /**
     * 使用时间
     */
    private String useTime;

    /**
     * 店铺Id
     */
    private String kdtId;

    /**
     * 券资产状态
     * 待领取：WAIT_RECEIVE ;  已领取：RECEIVED ;  已使用：USED ;  已回收：RECYCLED ; 已过期: EXPIRED
     */
    private String state;

    /**
     * 发放人姓名
     */
    private String operator;

    /**
     * 券描述
     */
    private String couponDesc;

    /**
     * 参与商家类型=发放类型
     * 发券单 COUPON_SEND_RECORD
     */
    private String sourceOrderType;

    /**
     * 发放Id
     */
    private String sourceOrderId;

    /**
     * 可用开始时间
     */
    private String useBeginTime;

    /**
     * 可用结束时间
     */
    private String useEndTime;

    /**
     * 可领取结束时间
     */
    private String receiveEndTime;

    /**
     * 可领取开始时间
     */
    private String receiveBeginTime;

    /**
     * 使用链接
     */
    private String url;
}
