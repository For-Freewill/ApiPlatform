package com.youzan.ycm.qa.enable.platform.dal.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableQueryHistoryEntity;

/**
 * @Author wulei
 * @Date 2020/10/27 15:08
 */
@DS("ycmqa")
public interface EnableQueryHistoryMapper extends BaseMapper<EnableQueryHistoryEntity> {
}
