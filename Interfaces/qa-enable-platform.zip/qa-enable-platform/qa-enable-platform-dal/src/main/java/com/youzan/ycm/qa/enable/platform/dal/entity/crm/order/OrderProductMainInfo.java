package com.youzan.ycm.qa.enable.platform.dal.entity.crm.order;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 17:09
 **/
@Data
@Accessors(chain = true)
public class OrderProductMainInfo {
    /**
     * 产品id
     */

    private Integer appId;

    /**
     * 应用名称
     */

    private String appName;

    /**
     * 版本id
     */

    private Integer itemId;

    /**
     * 版本名称
     */

    private String itemName;
}
