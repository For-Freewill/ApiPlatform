package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_scheme_order_relation")
public class PfSchemeOrderRelationEntity implements Serializable {
    /**
     * 主键
     */
    private String id;

    /**
     * 方案ID,不可为空
     */
    private Long schemeId;

    /**
     * 订单ID,不可为空
     */
    private Long orderId;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;
}
