package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_settle_order")
public class TdSettleOrderEntity extends BaseOrderDO implements Serializable {

    private String state;

    private String settleType;

    private String payerId;

    private String payerType;

    private String payeeId;

    private String payeeType;

    private String acquireNo;

    private String memo;

    private Long applyAmt;

    private Long settleAmt;

    private Boolean isApplied;

    private Date applyTime;

    private Date settleTime;

    private Date cancelTime;

}
