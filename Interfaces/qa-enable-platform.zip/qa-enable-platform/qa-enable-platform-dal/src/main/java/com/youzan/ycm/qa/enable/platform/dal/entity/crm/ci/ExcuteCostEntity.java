package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import lombok.Data;

/**
 * <p>
 * 执行时间处理
 * </p>
 *
 * @author xiongrun
 * @since 2021-08-11
 */
@Data
public class ExcuteCostEntity {
     // 应用
     String caseBelongApp;

     // 执行次数
     int totalCount;

     // 执行总时长
     float executeCostTotal;
}
