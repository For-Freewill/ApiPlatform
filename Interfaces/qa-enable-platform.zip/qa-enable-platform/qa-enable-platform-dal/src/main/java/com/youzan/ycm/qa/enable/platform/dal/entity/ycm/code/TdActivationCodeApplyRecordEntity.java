package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/5 15:42
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_activation_code_apply_record")
public class TdActivationCodeApplyRecordEntity implements Serializable {
    private Long id;

    private String bizId;

    private String bizType;

    private String code;

    private String applyYcmTradeNo;

    private String applyYcmId;

    private String applyYcmType;

    private String applyYcmName;

    private String applyYcmMobile;

    private String state;

    private String bizExt;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}
