package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:51
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_recharge_config")
public class PfRechargeConfigEntity implements Serializable {
    private Long id;

    private String applyKdtId;

    private String applyYcmId;

    private String applyYcmType;

    private String appId;

    private String rechargeItemId;

    private Byte isAutoRecharge;

    private String rechargeCondition;

    private Date createdAt;

    private Date updatedAt;
}
