package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 流程依赖的变量快照表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
@Data
public class FwProcDepVarSnapshotDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**订单ID*/
	private Long orderId;

	/**生效产品 appId*/
	private Integer appId;

	/**生效产品 itemId*/
	private Integer itemId;

	/**生效产品类型别名*/
	private String productTypeAlias;

	/**生效产品等级*/
	private String level;

	/**是否包含KA插件*/
	private Integer includeKaPlugin;

	/**到期时间*/
	private Date expireTime;

	/**业绩归属祖先部门ID*/
	private String belongDepartmentIds;

	/**业绩归属渠道商ID*/
	private Long belongProviderId;

	/**服务归属团队*/
	private String fuwuBelongTeam;

	/**服务归属ID*/
	private Long fuwuBelongId;

	/**内部店铺标识*/
	private Integer innerFlag;

	/**版本号*/
	private Integer version;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
