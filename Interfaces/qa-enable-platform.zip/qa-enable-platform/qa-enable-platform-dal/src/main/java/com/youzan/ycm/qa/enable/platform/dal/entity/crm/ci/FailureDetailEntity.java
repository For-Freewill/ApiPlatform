package com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 失败处理
 * </p>
 *
 * @author hujiping
 * @since 2021-08-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("failure_detail")
public class FailureDetailEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 错误caseid
     */
    private Long caseId;


    private Long jobId;

    private Long excuteId;

    /**
     * 失败原因
     */
    private int failureCause;

    /**
     * 是否处理
     */
    private int handle;

    /**
     * 创建时间
     */
    private Date createdAt;

    /**
     * 更新时间
     */
    private Date updatedAt;

}
