package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Created by baoyan on 1/21/22.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("pf_protection_period")
public class PfProtectionPeriodEntity  {
    private Long id;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;

    private String applyYcmId;

    private String applyYcmType;

    private Integer protectionPeriod;
}
