package com.youzan.ycm.qa.enable.platform.dal.entity.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 店铺基础数据和CRM业务关键数据
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:55
 */
@Data
public class ShopDO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**客户ID*/
	private Long customerId;

	/**商机联系人ID*/
	private Long contactId;

	/**店铺名称*/
	private String name;

	/**手机号*/
	private String mobile;

	/**店铺类型*/
	private Integer shopType;

	/**店铺经营类目ID*/
	private Integer categoryId;

	/**店铺地址国家code*/
	private String countryCode;

	/**省份*/
	private Integer provinceId;

	/**城市*/
	private Integer cityId;

	/**区*/
	private Integer countyId;

	/**地址*/
	private String address;

	/**店铺经营状态-后续可能不维护*/
	private Integer openStatus;

	/**当前生效的product-后续可能不维护*/
	private Integer currentItemId;

	/**当前生效的app-后续可能不维护*/
	private Integer currentAppId;

	/**销售绑定的用户ID*/
	private Long salesUserId;

	/**销售绑定的部门ID*/
	private Long salesDepartmentId;

	/**销售侧绑定的组织类型，1、有赞；2、渠道*/
	private Integer salesOrgType;

	/**内部店铺标识，0：正常店铺；1、测试店铺；2、公益店铺*/
	private Integer innerFlag;

	/**店铺锁定状态*/
	private Integer isLock;

	/**店铺在有赞创建的时间*/
	private Date createdTime;

	/**店铺角色*/
	private Integer shopRole;

	/**总店ID*/
	private Long rootKdtId;

	/**标记店铺来源 GDT：广点通精简版店铺*/
	private String shopSource;

	/**0：默认，1：微商城教育版*/
	private Integer shopTopic;

	/**店铺来源入口;0:PC浏览器（默认值）,1:手机app,2:pad app,3:微信小程序,4:h5手机浏览器*/
	private Integer shopEntrance;

	/**是否精简版,0:不是,1:是*/
	private Integer isSimplified;

	/**合作来源渠道（0：普通；1：快手；2：广点通；3：百度）*/
	private Integer sourceChannel;

	/**解决方案*/
	private Integer saasSolution;

	/**连锁网店模式(网店分布)*/
	private Integer chainOnlineShopMode;

	/**加盟商总部店铺ID*/
	private Long franchisorKdtId;

	/**连锁店铺角色*/
	private Integer shopChainRole;

	/**更新时间*/
	private Date updatedAt;

	/**创建时间*/
	private Date createdAt;

}
