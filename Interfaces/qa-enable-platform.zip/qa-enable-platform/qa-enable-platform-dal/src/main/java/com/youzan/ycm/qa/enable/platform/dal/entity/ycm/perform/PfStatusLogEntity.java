package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("pf_status_log")
public class PfStatusLogEntity implements Serializable {
    private String id;

    private String applyYcmId;

    private String applyYcmType;

    private String appId;

    private Date effectTime;

    private Date expireTime;

    private Long pfOrderId;

    private String bizOrderId;

    private String bizOrderType;

    private Date bizOperateTime;

    private String bizOperateType;

    private String extInfo;

    private String md5;

    private Date createdAt;

    private Date updatedAt;
}
