package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade;

import com.baomidou.mybatisplus.annotation.TableName;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.BaseOrderDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @author wulei
 * @date 2020-10-10
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_dct_result_detail")
public class TdDctResultDetailEntity extends BaseOrderDO implements Serializable {

    private String rglId;

    private String rglType;

    private String rglBehav;

    private String rglScope;

    private String rglName;

    private String rglDesc;

    private Long relateId;

    private String relateType;

    private Long reduceAmt;

    private Long returnYzb;
}
