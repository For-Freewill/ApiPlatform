package com.youzan.ycm.qa.enable.platform.dal.entity.crm.order;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 15:07
 **/
@Data
@Accessors(chain=true)
public class OrderProductSO {

    /**
     * 产品分类别名
     */
    private String appType;

    /**
     * 应用id
     */
    private Integer appId;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 版本id
     */
    private Integer itemId;

    private Integer page;

    private Integer pageSize;
}
