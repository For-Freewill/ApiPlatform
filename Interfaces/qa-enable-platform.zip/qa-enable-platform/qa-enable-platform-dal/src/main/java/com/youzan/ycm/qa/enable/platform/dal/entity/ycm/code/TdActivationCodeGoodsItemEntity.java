package com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2021/1/5 15:42
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("td_activation_code_goods_item")
public class TdActivationCodeGoodsItemEntity implements Serializable {
    private Long id;

    private String code;

    private String spuId;

    private String spuName;

    private String spuSnapshot;

    private String skuId;

    private String skuName;

    private String skuSnapshot;

    private Integer skuNum;

    private Byte isDelete;

    private Date createdAt;

    private Date updatedAt;
}
