package com.youzan.ycm.qa.enable.platform.web.controller.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:33
 **/
//@Slf4j
//@RestController
//@RequestMapping("/queryCouponAssetListByKdtId")
//public class QueryCouponAssetListByKdtIdController {
//
//    @Resource
//    private CouponAssetRemoteService couponAssetRemoteService;
//
//    /**
//     * 查询券
//     */
//    @RequestMapping(value = "/query", method = RequestMethod.POST)
//    public RestResult<PageResponse<CouponAssetDTO>> queryCouponAssetListByKdtId(@RequestBody QueryCouponAssetRequest request) {
//        PlainResult<PageResponse<CouponAssetDTO>> result = couponAssetRemoteService.queryCouponAssetListByKdtId(request);
//        return RestResultUtil.build(result);
//    }
//
//}
