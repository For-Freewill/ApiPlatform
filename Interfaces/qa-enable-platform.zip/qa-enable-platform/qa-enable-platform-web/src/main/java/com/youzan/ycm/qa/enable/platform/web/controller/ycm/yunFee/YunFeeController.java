package com.youzan.ycm.qa.enable.platform.web.controller.ycm.yunFee;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.ResetShopTryTimeRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.yunFee.FcFeeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.yunFee.FcFeeResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.perform.ShopTryPerformService;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.yunFee.YunFeeService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author wulei
 * @date 2021/1/20 15:27
 */
//@Auth
@Slf4j
@RestController
@RequestMapping("/yunFee")
public class YunFeeController {
    @Resource
    private YunFeeService yunFeeService;

    @Resource
    private ShopTryPerformService shopTryPerformService;
    /**
     * 根据kdtId,查询计费侧的表
     */
    @RequestMapping(value = "/selectFcFee", method = RequestMethod.POST)
    public RestResult<FcFeeResponse> selectCodeDetail(@RequestBody FcFeeRequest request) {
        PlainResult<FcFeeResponse> result = yunFeeService.selectFcFee(request);
        return RestResultUtil.build(result);
    }

    /**
     * 测试
     */
    @RequestMapping(value = "/test", method = RequestMethod.POST)
    public RestResult<Boolean> selectCodeDetail2(@RequestBody ResetShopTryTimeRequest request) {
        PlainResult<Boolean> result = shopTryPerformService.resetShopTryTime(request);
        return RestResultUtil.build(result);
    }

}
