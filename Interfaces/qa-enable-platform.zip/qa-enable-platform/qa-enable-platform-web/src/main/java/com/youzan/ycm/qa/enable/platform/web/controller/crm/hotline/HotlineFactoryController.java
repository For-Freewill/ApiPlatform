package com.youzan.ycm.qa.enable.platform.web.controller.crm.hotline;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.hotline.CreateHotlineRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.hotline.HotlineFactoryService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 描述:
 *
 * @author beidou
 * @create 2021-01-21
 */
//@Auth
@Slf4j
@RestController
@RequestMapping("/enable/hotline")
public class HotlineFactoryController {

    @Resource
    private HotlineFactoryService hotlineFactoryService;

    @ResponseBody
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public RestResult<Boolean> createHotline(HttpServletRequest httpRequest, @RequestBody CreateHotlineRequest createHotlineRequest) {
        String cookies = httpRequest.getHeader("Cookie");
        PlainResult<Boolean> result = hotlineFactoryService.createHotline(cookies, createHotlineRequest);
        return RestResultUtil.build(result);
    }
}
