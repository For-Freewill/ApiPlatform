package com.youzan.ycm.qa.enable.platform.web.controller.ycm.cache;

import com.alibaba.fastjson.JSON;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.cache.FlushGoodsAllCatchService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:05
 **/
@Slf4j
@RestController
@RequestMapping("/flushCache")
public class FlushGoodsAllCatchController {

    @Resource
    private FlushGoodsAllCatchService flushGoodsAllCatchService;

    /**
     * 清理商品缓存
     */
    @RequestMapping(value = "/flushGoodsAllCatch", method = RequestMethod.POST)
    public RestResult<Void> flushGoodsAllCatch(@RequestBody String appIdString) {

        System.out.println("appId:" + appIdString);

        Integer appId = Integer.parseInt(JSON.parseObject(appIdString).get("appId").toString());

        flushGoodsAllCatchService.flushGoodsAllCatch(appId);
        return RestResultUtil.buildResult(ResultCode.SUCCESS);
    }
}
