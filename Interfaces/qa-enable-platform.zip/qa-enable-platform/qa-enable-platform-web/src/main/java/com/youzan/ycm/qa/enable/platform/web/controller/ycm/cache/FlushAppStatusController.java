package com.youzan.ycm.qa.enable.platform.web.controller.ycm.cache;

import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.cache.FlushAppStatusService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:05
 **/
@Slf4j
@RestController
@RequestMapping("/flushAppCatch")
public class FlushAppStatusController {

    @Resource
    private FlushAppStatusService flushAppStatusService;

    /**
     * 清理服务期缓存
     * 1、先从服务期表里查询下数据
     * 2、移动服务期
     * 3、清理缓存
     * 4、再次查询服务期表，然后和自己从表里读取的数据一致
     */
    @RequestMapping(value = "/flushAppStatusCatch", method = RequestMethod.POST)
    public RestResult<Void> flushAppStatusCatch(@RequestBody String kdtId, String appId) {

        flushAppStatusService.flushAppStatusCatch(kdtId, appId);
        return RestResultUtil.buildResult(ResultCode.SUCCESS);
    }
}


