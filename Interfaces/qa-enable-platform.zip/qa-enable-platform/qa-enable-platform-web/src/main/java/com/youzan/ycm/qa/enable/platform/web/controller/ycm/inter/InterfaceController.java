package com.youzan.ycm.qa.enable.platform.web.controller.ycm.inter;

import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.BaseInvokeRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.inter.InterfaceService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:46
 **/
@Slf4j
@RestController
@RequestMapping("/interface")
public class InterfaceController {


    @Resource(name="Dubbo_interfaceService")
    private InterfaceService interfaceService;

    @Resource
    private Map<String, InterfaceService> interfaceServiceMap;

    /**
     *
     */
    @RequestMapping(value = "/invoke", method = RequestMethod.POST)
    public RestResult<Object> doInvoke(@RequestBody BaseInvokeRequest baseInvokeRequest) {
        InterfaceService interfaceService = interfaceServiceMap.get(baseInvokeRequest.getInvokeType() + "_interfaceService");
        return RestResultUtil.buildResult(interfaceService.doMethodInvoke(baseInvokeRequest));
    }
}
