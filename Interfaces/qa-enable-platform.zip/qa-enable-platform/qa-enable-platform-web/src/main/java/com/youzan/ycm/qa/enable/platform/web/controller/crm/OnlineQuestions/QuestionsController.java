package com.youzan.ycm.qa.enable.platform.web.controller.crm.OnlineQuestions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@Slf4j
@RestController
@RequestMapping("/enable/online")
public class QuestionsController {

}
