package com.youzan.ycm.qa.enable.platform.web.controller.crm;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmForC.CrmCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.crmForC.CreateCrmService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author leifeiyun
 * @date 2021/8/26
 **/
@RestController
@RequestMapping("crmForC")
public class CrmForCCreateController {
    @Resource
    CreateCrmService createCrmService;
    @RequestMapping(value = "/newCreateCrmForC",method = RequestMethod.POST)
    public RestResult<CreateOfflineOrderRep> CreateCrmForC (@RequestBody CrmCreateRequest crmCreateRequest) {
        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        PlainResult<CreateOfflineOrderRep> result = createCrmService.CreateOfflineOrderV2(crmCreateRequest);
        System.out.println(result.getData());
        return RestResultUtil.build(result);
    }
}
