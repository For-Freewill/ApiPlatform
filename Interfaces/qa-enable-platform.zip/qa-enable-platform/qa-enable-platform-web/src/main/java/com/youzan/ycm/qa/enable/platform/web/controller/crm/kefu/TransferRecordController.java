package com.youzan.ycm.qa.enable.platform.web.controller.crm.kefu;

import com.youzan.api.common.response.PlainBoolResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.kefu.TransferRecordRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.kefu.TransferRecordService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-09 20:41
 */
@Slf4j
@RestController
@RequestMapping("/enable/transfer")
public class TransferRecordController {

    @Resource
    private TransferRecordService transferRecordService;

    @ResponseBody
    @RequestMapping(value = "/record", method = RequestMethod.POST)
    public RestResult<Boolean> transferToServant(@RequestBody TransferRecordRequest transferRecordRequest) {
        PlainResult<Boolean> result = transferRecordService.transferRecordToServant(transferRecordRequest);
        return RestResultUtil.build(result);
    }
}
