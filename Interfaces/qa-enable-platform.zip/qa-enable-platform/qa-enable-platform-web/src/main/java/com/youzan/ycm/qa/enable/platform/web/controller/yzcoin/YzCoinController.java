package com.youzan.ycm.qa.enable.platform.web.controller.yzcoin;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.yzcoin.YzCoinRequest;
import com.youzan.ycm.qa.enable.platform.api.response.yzcoin.YzCoinRep;
import com.youzan.ycm.qa.enable.platform.api.service.yzcoin.YzCoinEnableService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author leifeiyun
 * @date 2020/12/30
 **/
@Slf4j
@RestController
@RequestMapping("/yzcoin")
public class YzCoinController {
    @Resource
    YzCoinEnableService yzCoinEnableService;

    @RequestMapping(value = "/grantYzCoin",method = RequestMethod.POST)
    public RestResult<YzCoinRep> grantYzCoin (@RequestBody YzCoinRequest yzCoinRequest) {
        PlainResult<YzCoinRep> result = yzCoinEnableService.grantYzCoin(yzCoinRequest);
        System.out.println(result.getData());
        return RestResultUtil.build(result);

    }


    @RequestMapping(value = "/resetYzCoin",method = RequestMethod.POST)
    public RestResult<YzCoinRep> resetYzCoin (@RequestBody YzCoinRequest yzCoinRequest) {
        PlainResult<YzCoinRep> result = yzCoinEnableService.resetYzCoin(yzCoinRequest);
        System.out.println(result.getData());
        return RestResultUtil.build(result);
    }



}
