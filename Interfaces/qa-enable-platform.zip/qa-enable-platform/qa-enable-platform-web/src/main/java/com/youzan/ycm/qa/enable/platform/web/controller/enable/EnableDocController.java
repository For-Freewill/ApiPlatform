package com.youzan.ycm.qa.enable.platform.web.controller.enable;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableDocRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableDocResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableDocService;
import com.youzan.ycm.qa.enable.platform.web.annotation.Auth;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:22
 */
@Auth
@Slf4j
@RestController
@RequestMapping("/enable/doc")
public class EnableDocController {
    @Resource
    private EnableDocService enableDocService;

    /**
     * 查询指定类型的记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/selectByDocType", method = RequestMethod.GET)
    public RestResult<List<EnableDocResponse>> selectAllByType(@RequestParam("doc_type") String doc_type) {
        PlainResult<List<EnableDocResponse>> result = enableDocService.selectAllByType(doc_type);
        return RestResultUtil.build(result);
    }

    /**
     * 类型+名称模糊查询记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/selectByDocTypeName", method = RequestMethod.GET)
    public RestResult<List<EnableDocResponse>> selectAll(@RequestParam("doc_name") String doc_name, @RequestParam("doc_type") String doc_type) {
        PlainResult<List<EnableDocResponse>> result = enableDocService.selectByYcmDocName(doc_name, doc_type);
        return RestResultUtil.build(result);
    }

    /**
     * 根据ID删除记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteById", method = RequestMethod.GET)
    public RestResult<Boolean> deleteById(@RequestParam("id") Long id) {
        PlainResult<Boolean> result = enableDocService.deleteById(id);
        return RestResultUtil.build(result);
    }

    /**
     * 新增记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public RestResult<Boolean> insert(@RequestBody EnableDocRequest enableDocRequest, @RequestAttribute("user") SessionUser user) {
        enableDocRequest.setDocAuthor(user.getRealname());
        PlainResult<Boolean> result = enableDocService.insert(enableDocRequest);
        return RestResultUtil.build(result);
    }
}
