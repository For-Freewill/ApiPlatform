package com.youzan.ycm.qa.enable.platform.web.controller.ycm.code;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.code.NewActivationCodeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.code.NewActivationCodeResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.code.NewActivationCodeService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Author wulei
 * @Date 2021/01/13 15:03
 */
//@Auth
@Slf4j
@RestController
@RequestMapping("/code")
public class NewActivationCodeController {
    @Resource
    private NewActivationCodeService newActivationCodeService;

    /**
     * 根据code,表查询激活码的详细信息
     */
    @RequestMapping(value = "/selectCodeDetail", method = RequestMethod.POST)
    public RestResult<NewActivationCodeResponse> selectCodeDetail(@RequestBody NewActivationCodeRequest request) {
        PlainResult<NewActivationCodeResponse> result = newActivationCodeService.selectCodeDetail(request);
        return RestResultUtil.build(result);
    }

}
