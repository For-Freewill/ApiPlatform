package com.youzan.ycm.qa.enable.platform.web.controller.ycm.fileTransfer;

import com.baomidou.mybatisplus.extension.api.R;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.fileTransfer.FileTransferService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author leifeiyun
 * @date 2021/9/16
 **/
@RestController
@RequestMapping("/fileTransfer")
@Slf4j
public class FileTransferController {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger(FileTransferController.class);
    @Resource
    private FileTransferService fileTransferService;
    @RequestMapping(value = "/forReplay",method = RequestMethod.POST)
    public RestResult<Map<String, List>> getDiffInterfaceMethods(@RequestParam("file1") MultipartFile file1,@RequestParam("file2") MultipartFile file2){
        REQUEST_LOGGER.info(file1.getOriginalFilename());
        RestResult restResult = new RestResult();
        Map<String, List> resultMap= new HashMap<>();

        //两个文件名必须不一致
        if(file1.getOriginalFilename().equals(file2.getOriginalFilename())){
            restResult.setData(null);
            restResult.setCode(1226);
            restResult.setMsg("文件名必须不一致！");
            return restResult;
        }else {
            String file1Path = fileTransferService.transferFileToDest(file1);
            String file2Path = fileTransferService.transferFileToDest(file2);
            resultMap=fileTransferService.getDiffInterFaceAndMethod(file1Path,file2Path);
        }

        restResult.setData(resultMap);
        return restResult;
    }

    @RequestMapping(value = "/getBeautifulMethods",method = RequestMethod.POST)
    public RestResult<List<String>> getDiffInterfaceMethods(@RequestParam("file") MultipartFile file){
        REQUEST_LOGGER.info(file.getOriginalFilename());
        RestResult restResult = new RestResult();
        String filePath = fileTransferService.transferFileToDest(file);
        List<String> interfaceMethods = fileTransferService.getInterFaceAndMethod(filePath);
        restResult.setData(interfaceMethods);
        return restResult;
    }

}
