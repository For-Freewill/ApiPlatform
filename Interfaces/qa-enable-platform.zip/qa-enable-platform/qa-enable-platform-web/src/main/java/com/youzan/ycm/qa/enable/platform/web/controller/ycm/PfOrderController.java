package com.youzan.ycm.qa.enable.platform.web.controller.ycm;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.OrderQueryRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.OrderQueryResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.PfOrderService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * ycm service controller
 *
 * @author wulei
 * @date 2020-10-10
 */
//@Auth
@Slf4j
@RestController
@RequestMapping("/pforder")
public class PfOrderController {
    @Resource
    private PfOrderService pfOrderService;

    /**
     * 根据td_order id查询关联表信息
     */
    @RequestMapping(value = "/orderId", method = RequestMethod.POST)
    public RestResult<OrderQueryResponse> queryByTdOrderId(@RequestBody OrderQueryRequest orderQueryRequest) {
        PlainResult<OrderQueryResponse> result = pfOrderService.queryByTdOrderId(orderQueryRequest);
        return RestResultUtil.build(result);
    }

    @RequestMapping(value = "/recycleForPfOrder",method = RequestMethod.GET )
    public RestResult<Boolean> recycleForPfOrder(@RequestParam(value = "pfOrderId") String pfOrderId) {
        PlainResult<Boolean> result = pfOrderService.recycleForPfOrder(Long.valueOf(pfOrderId));
        return RestResultUtil.build(result);
    }

}
