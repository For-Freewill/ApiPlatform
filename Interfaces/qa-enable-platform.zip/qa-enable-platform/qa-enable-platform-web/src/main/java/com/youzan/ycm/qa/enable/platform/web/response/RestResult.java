package com.youzan.ycm.qa.enable.platform.web.response;


import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import lombok.Data;

/**
 * @Author wulei
 * @Date 2020/10/27 17:12
 */
@Data
public class RestResult<T> {
    /**
     * 返回值code
     */
    private Integer code;

    /**
     * 返回值message
     */
    private String msg;

    /**
     * 返回值data
     */
    private T data;

    public RestResult(T data) {
        this.code = ResultCode.SUCCESS.getCode();
        this.msg = ResultCode.SUCCESS.getMessage();
        this.data = data;
    }

    public RestResult() {
        this.code = ResultCode.SUCCESS.getCode();
        this.msg = ResultCode.SUCCESS.getMessage();
    }

    /**
     * 通常用于返回错误码
     *
     * @param code the code
     * @param msg  the msg
     */
    public RestResult(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * 通常用于返回错误码
     *
     * @param resultCode
     */
    public RestResult(ResultCode resultCode) {
        this.code = resultCode.getCode();
        this.msg = resultCode.getMsg();
    }

    /**
     * @param resultCode
     * @param data
     */
    public RestResult(ResultCode resultCode, T data) {
        this.code = resultCode.getCode();
        this.msg = resultCode.getMsg();
        this.data = data;
    }
}