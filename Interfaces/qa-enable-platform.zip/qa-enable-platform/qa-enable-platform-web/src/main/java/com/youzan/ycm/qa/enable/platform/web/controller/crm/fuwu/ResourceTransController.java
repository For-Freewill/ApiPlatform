package com.youzan.ycm.qa.enable.platform.web.controller.crm.fuwu;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu.ResourceTransDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu.ShopRoleAssignDTO;
import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ResourceTransResponseDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu.ResourceTransService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu.ShopRoleOperationService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @Author Jiping.Hu
 * @Description 资源流转
 * @Date 2021-04-06
 **/
@Slf4j
@RestController
@RequestMapping("/enable/fw")
public class ResourceTransController {

    @Resource
    private ResourceTransService resourceTransService;

    @Resource
    private ShopRoleOperationService shopRoleOperationService;

    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public RestResult<ResourceTransResponseDTO> queryByTdKdtId(@RequestBody ResourceTransDTO resourceTransDTO) {
        PlainResult<ResourceTransResponseDTO> result = resourceTransService.queryByTdKdtId(resourceTransDTO.getKdtId(),resourceTransDTO.getEnv());
        return RestResultUtil.build(result);
    }

    @ResponseBody
    @RequestMapping(value = "/shopRole/assign", method = RequestMethod.POST)
    public RestResult<Boolean> assignShopRole (@RequestBody ShopRoleAssignDTO shopRoleAssignDTO){
        PlainResult<Boolean> result = shopRoleOperationService.assignShopRole(shopRoleAssignDTO);
        return RestResultUtil.build(result);
    }


}
