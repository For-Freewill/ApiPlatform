package com.youzan.ycm.qa.enable.platform.web.controller.enable;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreInsertRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreQueryRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreUpdateRequest;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableProgramScoreService;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2020/10/27 15:19
 */
@Slf4j
@RestController
@RequestMapping("/enable")
public class EnableProgramScoreController {

    @Resource
    private EnableProgramScoreService enableProgramScoreService;

    /**
     * 新增质量分记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/insert", method = RequestMethod.POST)
    public RestResult<Boolean> insert(@RequestBody EnableProgramScoreInsertRequest request) {
        PlainResult<Boolean> result = enableProgramScoreService.insert(request);
        return RestResultUtil.build(result);
    }


    /**
     * 分页查询全部记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/queryAll", method = RequestMethod.GET)
    public RestResult<IPage<EnableProgramScoreEntity>> queryAll(@RequestParam(value = "team") String team, Page page) {
        PlainResult<IPage<EnableProgramScoreEntity>> result = enableProgramScoreService.selectAll(team, page);
        return RestResultUtil.build(result);
    }

    /**
     * 条件查询记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/selectByParam", method = RequestMethod.GET)
    public RestResult<Map<String, List>> selectByParam(@RequestParam(value = "programQa") String programQa,
                                                       @RequestParam(value = "programName") String programName,
                                                       @RequestParam(value = "scoreTotal") String scoreTotal,
                                                       @RequestParam(value = "beginOnlineTime") String beginOnlineTime,
                                                       @RequestParam(value = "endOnlineTime") String endOnlineTime,
                                                       @RequestParam(value = "team") String team) {
        EnableProgramScoreQueryRequest request = EnableProgramScoreQueryRequest.builder().programQa(programQa).programName(programName).scoreTotal(scoreTotal).beginOnlineTime(beginOnlineTime).endOnlineTime(endOnlineTime).team(team).build();
        PlainResult<Map<String, List>> result = enableProgramScoreService.selectByParam(request);
        return RestResultUtil.build(result);
    }

    /**
     * id更新记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/updateById", method = RequestMethod.POST)
    public RestResult<Boolean> updateById(@RequestBody EnableProgramScoreUpdateRequest request) {
        PlainResult<Boolean> result = enableProgramScoreService.updateById(request);
        return RestResultUtil.build(result);
    }

    /**
     * id查询记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/selectById", method = RequestMethod.GET)
    public RestResult<EnableProgramScoreEntity> selectById(@RequestParam(value = "id") Long id) {
        PlainResult<EnableProgramScoreEntity> result = enableProgramScoreService.selectById(id);
        return RestResultUtil.build(result);
    }


    /**
     * id删除记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/score/deleteById", method = RequestMethod.GET)
    public RestResult<Boolean> deleteById(@RequestParam(value = "id") Long id) {
        PlainResult<Boolean> result = enableProgramScoreService.deleteById(id);
        return RestResultUtil.build(result);
    }

    /**
     * 项目汇总
     */
    @ResponseBody
    @RequestMapping(value = "/score/analytics", method = RequestMethod.GET)
    public RestResult<Map<String, List>> listAll(@RequestParam(value = "team") String team) {
        EnableProgramScoreQueryRequest request = EnableProgramScoreQueryRequest.builder().team(team).build();
        PlainResult<Map<String, List>> result = enableProgramScoreService.analyticByParam(request);
        return RestResultUtil.build(result);
    }
}
