package com.youzan.ycm.qa.enable.platform.web.exception;

import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @Author qibu
 * @create 2020/11/10 11:06 AM
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 处理自定义的业务异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(EnableException.class)
    @ResponseBody
    public RestResult enableExceptionHandler(EnableException e) {
        log.info("enable platform 异常！原因：{}", e.getMsg());
        return RestResultUtil.buildErrorResult(e.getCode(), e.getMsg());
    }

    /**
     * 处理登录异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(UnauthorizedException.class)
    @ResponseBody
    public RestResult unauthorizedExceptionHandler(UnauthorizedException e) {
        log.info("用户没有登录！原因：{}", e.getMessage());
        return RestResultUtil.buildResult(ResultCode.AUTHORIZATION_REQUIRED);
    }

    /**
     * 参数非法异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public RestResult illegalArgumentExceptionHandler(IllegalArgumentException e) {
        log.info("参数非法！原因：{}", e.getMessage());
        return RestResultUtil.buildErrorResult(ResultCode.BAD_REQUEST.getCode(), e.getMessage());
    }

    /**
     * 处理未知异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public RestResult exceptionHandler(Exception e) {
        log.info("请求异常！原因：{}", e.getMessage(), e);
        return RestResultUtil.buildErrorResult(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
    }

}
