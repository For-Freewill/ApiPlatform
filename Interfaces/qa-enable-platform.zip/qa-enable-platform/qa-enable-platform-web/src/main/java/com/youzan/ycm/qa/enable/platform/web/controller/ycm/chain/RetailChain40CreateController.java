package com.youzan.ycm.qa.enable.platform.web.controller.ycm.chain;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.CreateOrderService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author leifeiyun
 * @date 2020/12/30
 **/
@RestController
@RequestMapping("/youzanRetail40")
public class RetailChain40CreateController {
    @Resource
    CreateOrderService createOrderService;
    /**
     * {"discountAmount":0,"originPrice":4980000,"realPrice":4980000,"kdtId":"58811158","kdtName":"30437-retailChain-1","items":[{"itemId":8414,"quantity":1,"buyType":1,"applyKdtId":"58811158","newMigration":false,"appId":50666}],"type":0,"needAdminSign":0,"useCapitalAccount":0,"needInvoice":true,"userId":2135}
     */
  /*  @RequestMapping(value = "/newCreate",method = RequestMethod.POST)
    public RestResult<EnableCreateOfflineOrderResponse> CreateOfflineOrderV2 (@RequestParam(value = "prodType")String prodType, @RequestParam(value = "kdtId") String kdtId) {
        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        PlainResult<EnableCreateOfflineOrderResponse> result = createOrderService.CreateOfflineOrderV2(kdtId, prodType);
        System.out.println(result.getData());
        return RestResultUtil.build(result);

    }*/


    @RequestMapping(value = "/newCreate",method = RequestMethod.POST)
    public RestResult<CreateOfflineOrderRep> CreateOfflineOrderV2 (@RequestBody YzChainCreateRequest yzChainCreateRequest) {
        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        PlainResult<CreateOfflineOrderRep> result = createOrderService.CreateOfflineOrderV2(yzChainCreateRequest);
        System.out.println(result.getData());
        return RestResultUtil.build(result);

    }

    @RequestMapping(value = "/upgrade",method = RequestMethod.POST)
    public RestResult<CreateOfflineOrderRep> CreateOfflineOrder (@RequestBody YzChainUpgradeRequest yzChainUpgradeRequest) {
        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        PlainResult<CreateOfflineOrderRep> result = createOrderService.CreateOfflineOrderForUpgrade(yzChainUpgradeRequest);
        System.out.println(result.getData());
        return RestResultUtil.build(result);

    }


    @RequestMapping("/hello")
    public String hello(){
        return "hello";
    }
}
