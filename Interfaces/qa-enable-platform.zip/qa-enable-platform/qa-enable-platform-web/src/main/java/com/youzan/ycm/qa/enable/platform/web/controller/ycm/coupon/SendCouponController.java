package com.youzan.ycm.qa.enable.platform.web.controller.ycm.coupon;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.coupon.SendCouponRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.coupon.SendCouponResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.coupon.SendCouponService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Created by baoyan on 2021-04-13.
 */
@Slf4j
@RestController
@RequestMapping("/coupon")
public class SendCouponController {
    @Resource
    private SendCouponService sendCouponService;

    /**
     * 发放指定优惠券，仅针对旺小店场景，此处写死
     */
    @RequestMapping(value = "/sendCouponForWxd", method = RequestMethod.POST)
    public RestResult<SendCouponResponse> sendCouponForWxd(@RequestBody SendCouponRequest request) {
        PlainResult<SendCouponResponse> result = sendCouponService.sendCouponForWxd(request);
        return RestResultUtil.build(result);

    }

}
