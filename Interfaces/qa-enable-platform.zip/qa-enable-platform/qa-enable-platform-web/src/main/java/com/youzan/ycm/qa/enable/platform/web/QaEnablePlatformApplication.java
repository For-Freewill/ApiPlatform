package com.youzan.ycm.qa.enable.platform.web;

import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import com.youzan.aladdin.AladdinContainer;
import com.youzan.boot.YouZanBootApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication(exclude = {DruidDataSourceAutoConfigure.class}, scanBasePackages = {"com.youzan.ycm.qa.enable.platform"})
@EnableAsync(proxyTargetClass = true)
@ImportResource({"classpath*:spring/applicationContext.xml", "classpath*:qa-*.xml", "classpath*:dubbo-consumer.xml"})
@MapperScan({"com.youzan.ycm.qa.enable.platform.dal.mapper.*"})
public class QaEnablePlatformApplication {
    public static void main(String[] args) {
//        AladdinContainer.run(args);
        YouZanBootApplication.run(QaEnablePlatformApplication.class, args);
    }
}

