package com.youzan.ycm.qa.enable.platform.web.controller.ycm.crmOrder;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmOrder.CreateCrmApprovalNoRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.crmOrder.CrmOrderService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Created by baoyan on 2021-04-26.
 */
@Slf4j
@RestController
@RequestMapping("/crmOrder")
public class CreateCrmApprovalNoController {
    @Resource
    private CrmOrderService crmOrderService;

    /**
     * 生成crm提单审批流
     *
     */
    @RequestMapping(value = "/createCrmApprovalNo", method = RequestMethod.POST)
    public RestResult<String> createCrmApprovalNo(@RequestBody CreateCrmApprovalNoRequest request){
        PlainResult<String> result = crmOrderService.createCrmApprovalNo(request);
        return RestResultUtil.build(result);
    }
}
