package com.youzan.ycm.qa.enable.platform.web.controller.ycm.goods;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.service.ycm.goods.GoodsToolsService;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.Difference;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2021/9/29 17:44
 */
@Slf4j
@RestController
@RequestMapping("/goods")
public class GoodsToolsController {
    @Resource
    private GoodsToolsService goodsToolsService;

    /**
     * 对比原子商品插件-基础QA和SC创建的商品差异
     */
    @RequestMapping(value = "/queryAtomPlugin", method = RequestMethod.GET)
    public RestResult<Map<String, Map>> selectCodeDetail(@RequestParam("appId") Integer appId) {
        PlainResult<Map<String, Map>> result = goodsToolsService.queryAtomPlugin(appId);
        return RestResultUtil.build(result);
    }

    /**
     * 对比原子商品SPU差异
     */
    @RequestMapping(value = "/compareSpuResult", method = RequestMethod.GET)
    public RestResult<List<Difference>> compareSpuResult(@RequestParam("qa_id") Integer qa_id, @RequestParam("sc_id") Integer sc_id) {
        PlainResult<List<Difference>> result = goodsToolsService.compareSpuResult(qa_id, sc_id);
        return RestResultUtil.build(result);
    }

    /**
     * 对比原子商品SKU差异
     */
    @RequestMapping(value = "/compareSkuResult", method = RequestMethod.GET)
    public RestResult<List<Difference>> compareSkuResult(@RequestParam("qa_id") Integer qa_id, @RequestParam("sc_id") Integer sc_id) {
        PlainResult<List<Difference>> result = goodsToolsService.compareSkuResult(qa_id, sc_id);
        return RestResultUtil.build(result);
    }
}
