package com.youzan.ycm.qa.enable.platform.web.controller.ycm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.ShopDeleteRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.ShopService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:05
 **/
@Slf4j
@RestController
@RequestMapping("/pfshop")
public class ShopController {

    @Resource
    private ShopService shopService;

    /**
     * 删除店铺的数据
     */
    @RequestMapping(value = "/deleteDataByKdtId", method = RequestMethod.POST)
    public RestResult<Boolean> deleteDataByKdtId(@RequestBody ShopDeleteRequest shopDeleteRequest){
        PlainResult<Boolean> result = shopService.deleteDataByKdtId(shopDeleteRequest.getKdtId());
        return RestResultUtil.build(result);
    }
}
