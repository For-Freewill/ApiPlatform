package com.youzan.ycm.qa.enable.platform.web.util;

/**
 * @Author wulei
 * @Date 2020/10/27 17:12
 */

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;

import java.util.List;

/**
 * @Author wulei
 * @Date 2020/10/27 17:13
 */
public class RestResultUtil {

    public static <T> RestResult<T> build(PlainResult<T> plainResult) {
        RestResult<T> result = new RestResult<T>();
        if (plainResult == null) {
            result.setCode(999);
            result.setMsg("未知异常");
        } else if (plainResult.isSuccess()) {
            result.setData(plainResult.getData());
        } else {
            result.setCode(plainResult.getCode());
            result.setMsg(plainResult.getMessage());
        }
        return result;
    }

    public static <T> RestResult<T> buildResult(T data) {
        return new RestResult<T>(data);
    }

    public static <T> RestResult<T> buildResult(ResultCode resultCode, T data) {
        return new RestResult<T>(resultCode, data);
    }

    public static <T> RestResult<T> buildResult(ResultCode resultCode) {
        return new RestResult<T>(resultCode);
    }

    public static <T> RestResult<T> buildErrorResult(Integer errorCode, String errorMsg) {
        return new RestResult<T>(errorCode, errorMsg);
    }
    public static <T> ListResult<T> wrapList(List<T> list) {
        ListResult<T> result = new ListResult<>();
        result.setData(list);
        return result;
    }

    public static <T> PlainResult<T> wrapPlain(T b) {
        PlainResult<T> result = new PlainResult<>();
        result.setData(b);
        return result;
    }
}
