package com.youzan.ycm.qa.enable.platform.web.controller.ycm.chain;

import com.youzan.api.common.response.PlainResult;
import com.youzan.shopcenter.shopfront.api.dto.info.workflow.TaskInfo;
import com.youzan.shopcenter.shopfront.api.dto.message.workflow.TaskAckMessageBody;
import com.youzan.shopcenter.shopfront.api.service.unsafe.ShopUpgradeUnsafeService;
import com.youzan.shopcenter.shopfront.api.service.workflow.TaskReadService;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.TaskAckMsgBody;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.SchemeState;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.ShopUpgradeRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.CreateOrderService;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.UpgradeChainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2022/2/9
 **/
@Slf4j
@RestController
@RequestMapping("/upgradeChain")
public class UpgradeChainController {
    @Resource
    CreateOrderService createOrderService;
    @Resource
    UpgradeChainService upgradeChainService;
    @Resource
    ShopUpgradeUnsafeService shopUpgradeUnsafeService;
    @Resource
    TaskReadService taskReadService;


    @RequestMapping(value = "/startUpgrade",method = RequestMethod.POST)
    public PlainResult<ShopUpgradeRep> startUpgrade(@RequestBody YzChainUpgradeRequest yzChainUpgradeRequest){
        PlainResult<ShopUpgradeRep> repPlainResult =new PlainResult<>();
//        PlainResult<CreateOfflineOrderRep> createOfflineOrderRep =  createOrderService.CreateOfflineOrderForUpgrade(yzChainUpgradeRequest);
//        if(createOfflineOrderRep.getData().getFailedKdtIds().size()>0){
//            repPlainResult.setCode(100);
//            repPlainResult.setErrorMessage(100,"创建订单失败啦，不开心");
//            return repPlainResult;
//        }else {
//            repPlainResult = upgradeChainService.startUpgrade(yzChainUpgradeRequest);
//            return repPlainResult;
//        }
        repPlainResult = upgradeChainService.startUpgrade(yzChainUpgradeRequest);
        return repPlainResult;
    }

    @RequestMapping(value = "/queryRunningTasks",method = RequestMethod.GET)
    public PlainResult<List<TaskInfo>> queryRunningTasks(@RequestParam String workflowId ){
        PlainResult<List<TaskInfo>> result = taskReadService.queryRunningTasks(workflowId) ;
        return result;
    }

    @RequestMapping(value = "/queryFinishedTasks",method = RequestMethod.GET)
    public PlainResult<List<TaskInfo>> queryFinishedTasks(@RequestParam String workflowId ){
        PlainResult<List<TaskInfo>> result = taskReadService.queryFinishedTasks(workflowId) ;
        return result;
    }

    @RequestMapping(value = "/sendTaskAckMessage",method = RequestMethod.POST)
    public PlainResult<Boolean> sendTaskAckMessage(@RequestBody TaskAckMsgBody taskAckMsgBody ){
        log.info("taskId----->:"+taskAckMsgBody.getTaskId());
        TaskAckMessageBody taskAckMessageBody = new TaskAckMessageBody();
        taskAckMessageBody.setTaskId(taskAckMsgBody.getTaskId());
        taskAckMessageBody.setWorkflowId("lfy_test");
        taskAckMessageBody.setWorkflowName("lfy_test");
        taskAckMessageBody.setTaskName("lfy_test");
        taskAckMessageBody.setDesc("manual_ack");
        taskAckMessageBody.setPayload("111");
        taskAckMessageBody.setIsSuccess(true);

        PlainResult<Boolean> result = shopUpgradeUnsafeService.sendTaskAckMessage(taskAckMessageBody) ;
        return result;
    }

    @RequestMapping(value = "/schemeState" ,method = RequestMethod.GET)
    public PlainResult<SchemeState> schemeState(@RequestParam String kdtId,String upgradeType ){
        YzChainUpgradeRequest yzChainUpgradeRequest = new YzChainUpgradeRequest();
        yzChainUpgradeRequest.setKdtId(kdtId);
        yzChainUpgradeRequest.setUpgradeType(upgradeType);
        return upgradeChainService.schemeState(yzChainUpgradeRequest);

    }

}
