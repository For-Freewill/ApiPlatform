package com.youzan.ycm.qa.enable.platform.web.controller.ycm.perform;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.MovePfOrderStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.perform.PfOrderStatusService;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.CreateShopService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author wuwu
 * @date 2021/12/7 8:04 PM
 */
@Slf4j
@RestController
@RequestMapping("/perform")
public class PfOrderStatusServiceController {
    @Resource
    private PfOrderStatusService pfOrderStatusService;

    @RequestMapping(value = "/movePfOrderStatus", method = RequestMethod.POST)
    public RestResult<Boolean> createNewShop(@RequestBody MovePfOrderStatusRequest request) {
        PlainResult<Boolean> result = pfOrderStatusService.movePfOrderStatus(request);
        return RestResultUtil.build(result);
    }
}
