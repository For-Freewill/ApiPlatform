package com.youzan.ycm.qa.enable.platform.web.request;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author hezhulin
 * @date 2021-08-30 17:45
 */
@Data
public class ExcuteDetailStatisticsByStaffRequest {

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /**
     * 用例执行时间区间的开始时间
     */
    private Date startDate;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /**
     * 用例执行时间区间的结束时间
     */
    private Date endDate;

    /**
     * 用例归属人
     */
    private String owner;

    /**
     * 查询页
     */
    private int page;

    /**
     * 每页的记录数
     */
    private int pageSize;

}
