package com.youzan.ycm.qa.enable.platform.web.controller.crm.ci;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.Paginator;
import com.youzan.api.common.response.PaginatorResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.*;
import com.youzan.ycm.qa.enable.platform.api.response.ci.*;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.*;
import com.youzan.ycm.qa.enable.platform.biz.jenkins.GitLabService;
import com.youzan.ycm.qa.enable.platform.web.request.ExcuteDetailStatisticsByStaffRequest;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author Jiping.Hu
 * @Description 失败case处理
 * @Date 2021-08-14
 **/
@Slf4j
@RestController
@RequestMapping("/enable/ci")
public class CIHandleController {

    @Resource
    private FailureDetailService failureDetailService;

    @Resource
    private CiJenkinsJobService ciJenkinsJobService;

    @Resource
    private JenkinsReportService jenkinsReportService;

    @Resource
    private CaseDetailService caseDetailService;

    @Resource
    private ExcuteDetailService excuteDetailService;

    @Resource
    private CaseExcuteStatisticsByStaffService caseExcuteStatisticsByStaffService;

    @Resource
    private SuiteListenerService suiteListenerService;

    @Resource
    private GitLabService gitLabService ;


    @ApiOperation("失败case处理列表")
    @RequestMapping(value = "/failure/list", method = RequestMethod.POST)
    public RestResult<PageResult<FailureDetailDTO>> queryByCondition(@RequestBody PageRequest<FailureDetailRequstDTO> pageRequest) {
        PlainResult<PageResult<FailureDetailDTO>> result = failureDetailService.findFailureDetailByCondition(pageRequest);
        return RestResultUtil.build(result);
    }

    @ApiOperation("处理失败case")
    @RequestMapping(value = "/failure/update", method = RequestMethod.POST)
    public RestResult<Boolean> updateFarlure(@RequestBody FailureHandleRequestDTO failureHandleRequestDTO ) {
        PlainResult<Boolean> result = failureDetailService.updateFailureCase(failureHandleRequestDTO.getCaseId(),failureHandleRequestDTO.getFailureCause());
        return RestResultUtil.build(result);
    }

    @ApiOperation("批量处理失败case")
    @RequestMapping(value = "/failure/batchUpdate", method = RequestMethod.POST)
    public RestResult<Boolean> batchUpdate(@RequestBody FailureHandleRequestDTO failureHandleRequestDTO ) {
        PlainResult<Boolean> result = failureDetailService.batchUpdateFailureCase(failureHandleRequestDTO.getCaseIds(),failureHandleRequestDTO.getFailureCause());
        return RestResultUtil.build(result);
    }

    @ApiOperation("失败case重试")
    @RequestMapping(value = "/failure/failureReTry", method = RequestMethod.POST)
    public RestResult<Boolean> failureReTry(@RequestBody FailureRetryRequestDTO failureRetryRequestDTO) {
        PlainResult<Boolean> result = failureDetailService.failureReTry(failureRetryRequestDTO.getJobIds(),failureRetryRequestDTO.getUser());
        return RestResultUtil.build(result);
    }

    @ApiOperation("jenkins job列表")
    @RequestMapping(value = "/jenkis/list", method = RequestMethod.POST)
    public RestResult<PageResult<CiJenkinsJobDTO>> queryJenkinsJobByCondition(@RequestBody PageRequest<CiJenkinsJobRequestDTO> pageRequest ) {
        PlainResult<PageResult<CiJenkinsJobDTO>> result = ciJenkinsJobService.findJenkinsJobByCondition(pageRequest);
        return RestResultUtil.build(result);
    }

    @ApiOperation("获取 jenkins 返回结果")
    @RequestMapping(value = "/jenkinsReport/get", method = RequestMethod.GET)
    public RestResult<JenkinsReportDTO> getJenkinsReport(@RequestParam(required = true) String jobUrl) {
        PlainResult<JenkinsReportDTO> result = jenkinsReportService.getJenkinsReport(jobUrl);
        return RestResultUtil.build(result);
    }

    @ApiOperation("插入用例")
    @RequestMapping(value = "/case/insert", method = RequestMethod.POST)
    public RestResult<Long> insertCase(@RequestBody CaseDetailRequestDTO caseDetailRequestDTO) {
        PlainResult<Long> result = caseDetailService.insert(caseDetailRequestDTO);
        return RestResultUtil.build(result);
    }

    @ApiOperation("删除用例")
    @RequestMapping(value = "/case/delete", method = RequestMethod.GET)
    public RestResult deleteCase(@RequestParam(required = false) long id) {
        return RestResultUtil.build(caseDetailService.delete(id));
    }

    @ApiOperation("查询用例详情")
    @RequestMapping(value = "/case/query", method = RequestMethod.GET)
    public RestResult<ArrayList<CaseDTO>> queryCase(@RequestParam(required = false) String id, @RequestParam(required = false) String caseName, @RequestParam(required = false) String caseBelongClass, @RequestParam(required = false) String caseBelongApp, @RequestParam(required = false) String caseAuthor, @RequestParam(required = false) String caseUrl) {
        return RestResultUtil.build(caseDetailService.query(id, caseName, caseBelongClass, caseBelongApp, caseAuthor, caseUrl));
    }

    @ApiOperation("根据用例ID查询用例详情")
    @RequestMapping(value = "/case/queryById", method = RequestMethod.GET)
    public RestResult<CaseDetailDTO> queryById(@RequestParam(required = true) Long id) {
        return RestResultUtil.build(caseDetailService.queryById(id));
    }

    @ApiOperation("根据执行时间获取各个app的执行详情")
    @RequestMapping(value = "/executeDeatil/date", method = RequestMethod.POST)
    public RestResult<List<ExcuteDetailByDateDTO>> getExcuteDetailByDate(@RequestBody ExcuteDetailByDataRequestDTO excuteDetailByDataRequestDTO) {
        return RestResultUtil.build(excuteDetailService.queryExcuteDetailByDate(excuteDetailByDataRequestDTO));
    }

    @ApiOperation("根据执行时间获取单个应用的执行详情")
    @RequestMapping(value = "/executeDeatil/app", method = RequestMethod.POST)
    public RestResult<List<ExcuteDetailByAppDTO>> getExcuteDetailByApp(@RequestBody PageRequest<ExcuteDetailByAppRequestDTO> excuteDetailByAppRequestDTO) {
        return RestResultUtil.build(excuteDetailService.queryExcuteDetailByApp(excuteDetailByAppRequestDTO));
    }

    @ApiOperation("人维度的用例执行情况汇总列表，限制了要统计的用例执行记录的时间区间范围")
    @RequestMapping(value = "/executeDeatil/statisticsByStaff", method = RequestMethod.POST)
    public PaginatorResult<CaseExcuteSummaryDTO> ExcuteDetailStatisticsByStaff(@RequestBody ExcuteDetailStatisticsByStaffRequest excuteDetailStatisticsByStaffRequest) {
        Paginator paginator = new Paginator(excuteDetailStatisticsByStaffRequest.getPage(),excuteDetailStatisticsByStaffRequest.getPageSize(),0);
        PaginatorResult<CaseExcuteSummaryDTO> result = caseExcuteStatisticsByStaffService.caseExcuteSummary(excuteDetailStatisticsByStaffRequest.getStartDate(),excuteDetailStatisticsByStaffRequest.getEndDate(),paginator);
        return result;
    }

    @ApiOperation("某个人的用例执行平均成功率低于阈值的用例列表，限制了要统计的用例执行记录的时间区间范围")
    @RequestMapping(value = "/executeDeatil/statisticsByStaff/executionSuccessRateLessThan", method = RequestMethod.POST)
    public PaginatorResult<CaseWithExecutionSuccessRate> executionSuccessRateLessThan99PercentCaseList(@RequestBody ExcuteDetailStatisticsByStaffRequest excuteDetailStatisticsByStaffRequest) {
        SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO = new SingleOwnerCaseExcuteRequestDTO();
        singleOwnerCaseExcuteRequestDTO.setStartDate(excuteDetailStatisticsByStaffRequest.getStartDate());
        singleOwnerCaseExcuteRequestDTO.setEndDate(excuteDetailStatisticsByStaffRequest.getEndDate());
        singleOwnerCaseExcuteRequestDTO.setOwner(excuteDetailStatisticsByStaffRequest.getOwner());
        Paginator paginator = new Paginator(excuteDetailStatisticsByStaffRequest.getPage(),excuteDetailStatisticsByStaffRequest.getPageSize(),0);
        singleOwnerCaseExcuteRequestDTO.setPaginator(paginator);
        PaginatorResult<CaseWithExecutionSuccessRate> result = caseExcuteStatisticsByStaffService.executionSuccessRateLessThan99PercentCaseList(singleOwnerCaseExcuteRequestDTO);
        return result;
    }

    @ApiOperation("某个人的用例执行平均时长低于阈值的用例列表，限制了要统计的用例执行记录的时间区间范围")
    @RequestMapping(value = "/executeDeatil/statisticsByStaff/averageExecutionTimeGreaterThan", method = RequestMethod.POST)
    public PaginatorResult<CaseWithAverageExecutionTime>  averageExecutionTimeGreaterThan2SecondCaseList(@RequestBody ExcuteDetailStatisticsByStaffRequest excuteDetailStatisticsByStaffRequest) {
        SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO = new SingleOwnerCaseExcuteRequestDTO();
        singleOwnerCaseExcuteRequestDTO.setStartDate(excuteDetailStatisticsByStaffRequest.getStartDate());
        singleOwnerCaseExcuteRequestDTO.setEndDate(excuteDetailStatisticsByStaffRequest.getEndDate());
        singleOwnerCaseExcuteRequestDTO.setOwner(excuteDetailStatisticsByStaffRequest.getOwner());
        Paginator paginator = new Paginator(excuteDetailStatisticsByStaffRequest.getPage(),excuteDetailStatisticsByStaffRequest.getPageSize(),0);
        singleOwnerCaseExcuteRequestDTO.setPaginator(paginator);
        PaginatorResult<CaseWithAverageExecutionTime>  result = caseExcuteStatisticsByStaffService.averageExecutionTimeGreaterThan2SecondCaseList(singleOwnerCaseExcuteRequestDTO);
        return result;
    }

    @ApiOperation("调试监听器接口suiteStartProcess")
    @RequestMapping(value = "/suiteStartProcess1", method = RequestMethod.POST)
    public RestResult<Boolean>  suiteStartProcessTest(@RequestBody SuiteStartProcessRequestDTO suiteStartProcessRequestDTO) {
        suiteListenerService.suiteStartProcess(suiteStartProcessRequestDTO);
        RestResult<Boolean> result = new RestResult<>();
        result.setData(true);
        return result;
    }

    @ApiOperation("调试监听器接口suiteFinishProcess")
    @RequestMapping(value = "/suiteStartProcess2", method = RequestMethod.POST)
    public RestResult<Boolean>  suiteFinishProcessTest(@RequestBody SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO) {
        suiteListenerService.suiteFinishProcess(suiteFinishProcessRequestDTO);
        RestResult<Boolean> result = new RestResult<>();
        result.setData(true);
        return result;
    }

    @ApiOperation("调试查询class文件作者信息接口")
    @RequestMapping(value = "/getAuthorByClassAndLine", method = RequestMethod.GET)
    public RestResult<String>  getAuthorByClassAndLine(@RequestParam(required = true) String className, @RequestParam(required = true) String line) {
        RestResult<String> result = new RestResult<>();
        result.setData(gitLabService.getAuthorByClassAndLine(className,line));
        return result;
    }

}
