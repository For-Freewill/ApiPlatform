package com.youzan.ycm.qa.enable.platform.web.controller.ycm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.CreateShopService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author wuwu
 * @date 2021/7/20 1:21 PM
 */
@Slf4j
@RestController
@RequestMapping("/shop")
public class CreateShopServiceController {
    @Resource
    private CreateShopService createShopService;

    @RequestMapping(value = "/createShop", method = RequestMethod.POST)
    public RestResult<Long> createNewShop(@RequestBody CreateShopRequest request) {
        PlainResult<Long> result = createShopService.createNewShop(request);
        return RestResultUtil.build(result);
    }
}
