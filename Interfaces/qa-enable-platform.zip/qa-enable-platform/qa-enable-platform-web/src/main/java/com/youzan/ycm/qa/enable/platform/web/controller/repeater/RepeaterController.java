package com.youzan.ycm.qa.enable.platform.web.controller.repeater;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.request.repeater.RecordCovertRequest;
import com.youzan.ycm.qa.enable.platform.biz.service.repeater.RecordConvertService;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.*;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:22
 */
@Slf4j
@RestController
@RequestMapping("/repeater")
public class RepeaterController {
    @Resource
    private RecordConvertService recordConvertService;

    /**
     * 记录转换代码
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/recordToCode", method = RequestMethod.POST)
    public RestResult<String> selectAllByType(@RequestBody RecordCovertRequest request) {
        PlainResult<String> result = recordConvertService.recordToCode(request);
        return RestResultUtil.build(result);
    }

    /**
     * listRecord
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/listRecord", method = RequestMethod.GET)
    public PlainResult<Page<RecordEntity>> listRecord(@RequestParam("appName") String appName, @RequestParam("traceId") String traceId, @RequestParam("pageNum") Integer pageNum, @RequestParam("pageSize") Integer pageSize) {
        return recordConvertService.listRecord(appName, traceId, pageNum, pageSize);
    }

    /**
     * listReplay
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/listReplay", method = RequestMethod.GET)
    public RestResult<ReplayEntity> listReplay(@RequestParam("id") Long id) {
        PlainResult<ReplayEntity> result = recordConvertService.listReplay(id);
        return RestResultUtil.build(result);
    }

    /**配置管理模块
     * listModuleConfig
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/listModuleConfig", method = RequestMethod.GET)
    public PlainResult<Page<ModuleConfigEntity>> listModuleConfig(@RequestParam("appName") String appName,@RequestParam("environment") String environment,
                                                           @RequestParam("page") Integer page,@RequestParam("pageSize") Integer pageSize) {
        return recordConvertService.listModuleConfig(appName,environment,page,pageSize);
    }
    /**
     * 点击进入配置详情
     */
    @ResponseBody
    @RequestMapping(value = "/detailModuleConfig", method = RequestMethod.GET)
    public RestResult<String> detailModuleConfig(@RequestParam("id") Long id) {
        PlainResult<String> result = recordConvertService.detailModuleConfig(id);
        return RestResultUtil.build(result);
    }
    /**
     删除配置
     */
    @ResponseBody
    @RequestMapping(value = "/deleteModuleConfig", method = RequestMethod.GET)
    public RestResult<ModuleConfigEntity> delelteModuleConfig(@RequestParam("id") Long id) {
        PlainResult<ModuleConfigEntity> result = recordConvertService.deleteModuleConfig(id);
        return RestResultUtil.build(result);
    }
    /**
     * 新增配置
     * addModuleConfig
     */
    @ResponseBody
    @RequestMapping(value = "/addOrUpdateModuleConfig", method = RequestMethod.POST)
    public RestResult<ModuleConfigEntity> addModuleConfig(@RequestBody ModuleConfigEntity moduleConfigEntity) {
        PlainResult<ModuleConfigEntity> result = recordConvertService.addOrUpdateModuleConfig(moduleConfigEntity);
        return RestResultUtil.build(result);
    }

    /**
     * listModuleInfo
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/listModuleInfo", method = RequestMethod.GET)
    public RestResult<List<ModuleInfoEntity>> listModuleInfo(@RequestParam("appName") String appName, @RequestParam("ip")  String ip) {
        PlainResult<List<ModuleInfoEntity>> result = recordConvertService.listModuleInfo(appName,ip);
        return RestResultUtil.build(result);
    }

    /**
     * 删除模块信息
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteModuleInfo", method = RequestMethod.GET)
    public PlainResult<Boolean> deleteModuleInfo(@RequestParam("id") Long id) {
        PlainResult<Boolean> result = recordConvertService.deleteModuleInfo(id);
        return result;
    }


}
