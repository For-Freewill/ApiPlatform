package com.youzan.ycm.qa.enable.platform.web.controller.crm.order;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.enable.common.model.rest.PaginationResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.order.OrderProductService;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ListWithTotal;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.CommonModel;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProduct;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductMainInfo;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductSO;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description: 成单关心，服务流转关心与商业化商品关系查询
 * @author: linliying
 * @create: 2021-04-02 17:12
 **/
//@Auth
@Slf4j
@RestController
@RequestMapping(value = "/order/product")
public class CrmOrderProductContorller{
    @Resource
    private OrderProductService orderProductService;


    /**
     查询crm侧的产品类型列表与商业化侧产品类型对应
     */
    @GetMapping(value = "/getList")
    public PaginationResponse<OrderProduct> getList(@RequestParam(required = false)String appType, @RequestParam(required = false)Integer appId, @RequestParam(required = false)String appName, @RequestParam(required = false)Integer itemId, @RequestParam(defaultValue = "1", name = "page")Integer page, @RequestParam(defaultValue = "20", name = "pageSize")Integer pageSize){
        OrderProductSO orderProductSO = new OrderProductSO().setAppType(appType).setAppId(appId).setAppName(appName).setItemId(itemId).setPage(page).setPageSize(pageSize);
        ListWithTotal<OrderProduct> listWithTotal = orderProductService.getList(orderProductSO);
        return new PaginationResponse<>(listWithTotal.getItems(), listWithTotal.getTotal());
    }

    /**
     * 商业化提供支持；可以根据应用名、应用ID、规格ID获取产品信息
     */
    @GetMapping(value = "/searchYopApps")
    public ListResult<OrderProductMainInfo> searchYopApps(@RequestParam(required = false)Integer appId,@RequestParam(required = false)String appName,@RequestParam(required = false)Integer itemId){
        List<OrderProductMainInfo> result = orderProductService.searchYopApps(appId, appName, itemId);
        return RestResultUtil.wrapList(result);
    }

    /**
     * 查询单个crm侧的产品类型
     * @param id
     * @return
     */
    @GetMapping(value = "/getById")
    public PlainResult<OrderProduct> getById(@RequestParam Long id) {
        OrderProduct result = orderProductService.getById(id);
        return RestResultUtil.wrapPlain(result);
    }

    /**
     * 获取产品分类枚举
     */
    @GetMapping(value = "/getAppTypeList")
    @ApiOperation(value = "获取产品分类枚举API", notes = "产品分类枚举列表")
    public ListResult<CommonModel> getAppTypeList() {
        return RestResultUtil.wrapList(orderProductService.getAppTypeList());
    }



}
