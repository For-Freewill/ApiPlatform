package com.youzan.ycm.qa.enable.platform.web.interceptor;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.uic.session.api.model.SessionGetAllResultModel;
import com.youzan.uic.session.api.param.SessionBaseParam;
import com.youzan.uic.session.api.service.UicSessionService;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableURLCounterEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableURLCounterMapper;
import com.youzan.ycm.qa.enable.platform.web.annotation.Auth;
import com.youzan.ycm.qa.enable.platform.web.exception.UnauthorizedException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;

/**
 * @Author qibu
 * @create 2020/11/9 7:07 PM
 */
@Slf4j
@Component("authInterceptor")
public class AuthInterceptor extends HandlerInterceptorAdapter {
    private static final String KDT_SESSION_ID = "KDTSESSIONID";
    private static final String SESSION_STORE_KEY = "loginUser";
    private static final String SESSION_STORE_KEY2 = "userInfo";
    private static final String USER = "user";

    @Resource
    private EnableURLCounterMapper enableURLCounterMapper;

    @Resource
    private UicSessionService uicSessionService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();
        //URL计数器
        uriCounter(request);
        //Auth注解
        if (method.isAnnotationPresent(Auth.class) || method.getDeclaringClass().isAnnotationPresent(Auth.class)) {
            try {
                Cookie c = getCookie(request.getCookies(), KDT_SESSION_ID);
                if (c == null) {
                    throw new UnauthorizedException("Cookie 不存在");
                }
                SessionUser user = getSessionUser(c);
                if (user == null) {
                    throw new EnableException(ResultCode.SESSION_EXPIRED.getCode(), ResultCode.SESSION_EXPIRED.getMessage());
                }
                request.setAttribute(USER, user);
                return true;
            } catch (EnableException | UnauthorizedException e) {
                throw e;
            } catch (Exception e) {
                log.error("鉴权失败，IP: {}, 响应: {}", getIp(request), e.getMessage(), e);
                return false;
            }
        }
        return true;
    }

    /**
     * 统计URL的执行
     */
    @Async
    public void uriCounter(HttpServletRequest request) throws IOException {
        String url = request.getRequestURI();
        log.info("请求的URL=" + url);
        List<EnableURLCounterEntity> list = enableURLCounterMapper.selectList(new QueryWrapper<EnableURLCounterEntity>().lambda().eq(EnableURLCounterEntity::getUrl, url));
        //忽略本请求：/enable/url/count
        if(url.equals("/enable/url/count")){
            return;
        }
        //统计+1
        if (list.size() == 1) {
            EnableURLCounterEntity counterEntity = list.get(0);
            counterEntity.setCount(counterEntity.getCount() + 1);
            enableURLCounterMapper.update(counterEntity, new QueryWrapper<EnableURLCounterEntity>().lambda().eq(EnableURLCounterEntity::getUrl, url));
        }
        //第一次,默认展示
        if (list.size() == 0) {
            EnableURLCounterEntity counterEntity = new EnableURLCounterEntity();
            counterEntity.setExt("");
            counterEntity.setCount(1);
            counterEntity.setUrl(url);
            counterEntity.setAuthor("unknown_"+url);
            counterEntity.setIsShow(Byte.valueOf("1"));
            enableURLCounterMapper.insert(counterEntity);
        }
    }

    private SessionUser getSessionUser(Cookie c) {
        SessionBaseParam param = new SessionBaseParam();
        param.setSessionId(c.getValue());
        PlainResult<SessionGetAllResultModel> result = uicSessionService.getAll(param);
        if (result == null) {
            return null;
        }
        Map<String, Object> values = result.getData().getValues();
        SessionUser user = null;
        if (values.containsKey(SESSION_STORE_KEY2)) {
            //userInfo信息
            JSONObject obj = (JSONObject) values.get(SESSION_STORE_KEY2);
            if (obj != null) {
                user = JSON.parseObject(obj.toJSONString(), SessionUser.class);

            }
        } else if (values.containsKey(SESSION_STORE_KEY)) {
            //loginUser场景，需要设置casId 为loginID
            JSONObject obj = (JSONObject) values.get(SESSION_STORE_KEY);
            if (obj != null) {
                user = JSON.parseObject(obj.toJSONString(), SessionUser.class);
                user.setLoginId(obj.getString("casId"));
            }
        }
        return user;
    }

    private String getIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Real-Ip");
        if (ip == null) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    private Cookie getCookie(Cookie[] cookies, String cookieName) {
        if (cookies == null) {
            return null;
        }
        for (Cookie c : cookies) {
            if (c.getName().equals(cookieName)) {
                return c;
            }
        }
        return null;
    }


}
