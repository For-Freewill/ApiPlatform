package com.youzan.ycm.qa.enable.platform.web.controller;

/**
 * @author leifeiyun
 * @date 2021/8/26
 **/
public class crmForC {
}
