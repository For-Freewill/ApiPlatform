/*
package com.youzan.ycm.qa.enable.platform.web.controller.ycm.shop;

import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.MarketCouponRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.MarketCouponService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

*/
/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:05
 **//*

@Slf4j
@RestController
@RequestMapping("/market")
public class MarketCoupponController {

    @Resource
    private MarketCouponService marketCouponService;

    */
/**
     * 根据ID删除所有相关的券数据
     *//*

    @RequestMapping(value = "/deleteMarketCouponData", method = RequestMethod.POST)
    public RestResult<Void> deleteMarketCouponData(@RequestBody MarketCouponRequest marketCouponRequest) {

        marketCouponService.deleteMarketCouponData(marketCouponRequest.getId());
        return RestResultUtil.buildResult(ResultCode.SUCCESS);
    }
}
*/
