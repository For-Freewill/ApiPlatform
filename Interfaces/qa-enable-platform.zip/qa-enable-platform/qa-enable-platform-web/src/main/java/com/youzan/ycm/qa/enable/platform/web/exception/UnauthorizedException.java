package com.youzan.ycm.qa.enable.platform.web.exception;

/**
 * @Author wulei
 * @Date 2020/10/27 17:13
 */
public class UnauthorizedException extends RuntimeException {

    public UnauthorizedException(String msg) {
        super(msg);
    }
}
