package com.youzan.ycm.qa.enable.platform.web.controller.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:14
 **/
//@Slf4j
//@RestController
//@RequestMapping("/listGfAssetByOwner")
//public class LlistGfAssetByOwnerController {
//    @Resource
//    private GiftAssetRemoteService giftAssetRemoteService;
//
//    /**
//     * 查询礼包
//     */
//    @RequestMapping(value = "/query", method = RequestMethod.POST)
//    public RestResult<GetGiftAssetListGeneralResponse> listGfAssetByOwner(@RequestBody GetGiftAssetListByOwnerRequest request) {
//        PlainResult<GetGiftAssetListGeneralResponse> result = giftAssetRemoteService.listGfAssetByOwner(request);
//        return RestResultUtil.build(result);
//    }
//}
