package com.youzan.ycm.qa.enable.platform.web.controller.ycm.shop;

import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.MarketActivityRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.MarketActivityService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:05
 **/
@Slf4j
@RestController
@RequestMapping("/market")
public class MarketActivityController {

    @Resource
    private MarketActivityService marketActivityService;

    /**
     * 根据ID删除所有相关的活动数据
     */
    @RequestMapping(value = "/deleteMarketActivityData", method = RequestMethod.POST)
    public RestResult<Void> deleteMarketActivityData(@RequestBody MarketActivityRequest marketActivityRequest) {

        marketActivityService.deleteMarketActivityData(marketActivityRequest.getId());
        return RestResultUtil.buildResult(ResultCode.SUCCESS);
    }

}
