package com.youzan.ycm.qa.enable.platform.web.controller.enable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreInsertRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreQueryRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreUpdateRequest;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableProgramScoreService;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableURLCounterEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableURLCounterMapper;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2020/10/27 15:19
 */
@Slf4j
@RestController
@RequestMapping("/enable")
public class EnableURLCounterController {

    @Resource
    private EnableURLCounterMapper enableURLCounterMapper;

    /**
     * 查询TOP10的URL计数器(is_show=1)
     * @return
     */
    @RequestMapping(value = "/url/count", method = RequestMethod.GET)
    public RestResult<Map<String, List>> listURLCounter() {
        Map<String, List> resultData = new HashMap();
        PlainResult result = new PlainResult();
        List<EnableURLCounterEntity> result_add = enableURLCounterMapper.selectList(new QueryWrapper<EnableURLCounterEntity>().lambda().eq(EnableURLCounterEntity::getIsShow,Byte.valueOf("1")).last("order by count desc limit 10"));
        resultData.put("results",result_add);
        result.setData(resultData);
        return RestResultUtil.build(result);
    }
}
