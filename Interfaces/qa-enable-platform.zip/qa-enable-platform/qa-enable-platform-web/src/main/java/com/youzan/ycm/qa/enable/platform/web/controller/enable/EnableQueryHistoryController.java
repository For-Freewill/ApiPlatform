package com.youzan.ycm.qa.enable.platform.web.controller.enable;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import com.youzan.ycm.qa.enable.platform.api.request.enable.AddQueryHistoryResquest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableQueryResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableQueryHistoryService;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableQueryHistoryEntity;
import com.youzan.ycm.qa.enable.platform.web.annotation.Auth;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wulei
 * @date 2020/10/27 15:19
 */
@Auth
@Slf4j
@RestController
@RequestMapping("/enable")
public class EnableQueryHistoryController {

    @Resource
    private EnableQueryHistoryService enableQueryHistoryService;

    /**
     * 新增查询记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public RestResult<Boolean> addQueryHistory(@RequestBody AddQueryHistoryResquest request, @RequestAttribute("user") SessionUser user) {
        request.setOperatorId(user.getLoginId());
        request.setOperatorName(user.getRealname());
        request.setOperatorType(user.getNickname());
        PlainResult<Boolean> result = enableQueryHistoryService.addQueryHistory(request);
        return RestResultUtil.build(result);
    }

    /**
     * 查询记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/query", method = RequestMethod.GET)
    public RestResult<List<EnableQueryHistoryEntity>> queryHistoryByOperatorId(@RequestAttribute("user") SessionUser user) {
        PlainResult<List<EnableQueryHistoryEntity>> result = enableQueryHistoryService.queryHistoryByOperatorId(user.getLoginId());
        return RestResultUtil.build(result);
    }

    /**
     * 查询具体记录
     *
     * @param id
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryById", method = RequestMethod.GET)
    public RestResult<EnableQueryResponse> queryHistoryByOperatorId(@RequestParam(value = "id") Long id) {
        PlainResult<EnableQueryResponse> result = enableQueryHistoryService.queryHistoryById(id);
        return RestResultUtil.build(result);
    }

    /**
     * 逻辑删除查询记录:by id
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteById", method = RequestMethod.GET)
    public RestResult<Boolean> deleteById(@RequestParam(value = "id") Long id) {
        PlainResult<Boolean> result = enableQueryHistoryService.deleteById(id);
        return RestResultUtil.build(result);
    }

    /**
     * 查询全部：分页查询例子，只返回is_delete=0的记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryAll", method = RequestMethod.GET)
    public PlainResult<IPage<EnableQueryHistoryEntity>> getItemList(Page page) {
        return enableQueryHistoryService.queryAll(page);
    }
}
