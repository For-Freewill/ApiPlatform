package com.youzan.ycm.qa.enable.platform.web.controller.enable;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailInsertRequest;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailUpdateRequest;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableTablesDetailService;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableTablesDetailEntity;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:22
 */
@Slf4j
@RestController
@RequestMapping("/demo")
public class EnableTablesDetailController {
    @Resource
    private EnableTablesDetailService enableTablesDetailService;

    /**
     * 查询全部记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/select", method = RequestMethod.GET)
    public RestResult<List<EnableTablesDetailEntity>> listAll() {
        PlainResult<List<EnableTablesDetailEntity>> result = enableTablesDetailService.selectAll();
        return RestResultUtil.build(result);
    }

    /**
     * 新增记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public RestResult<Boolean> insert(@RequestBody EnableTablesDetailInsertRequest request) {
        PlainResult<Boolean> result = enableTablesDetailService.insert(request);
        return RestResultUtil.build(result);
    }


    /**
     * 更新记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateById", method = RequestMethod.POST)
    public RestResult<Boolean> updateByID(@RequestBody EnableTablesDetailUpdateRequest request) {
        PlainResult<Boolean> result = enableTablesDetailService.updateById(request);
        return RestResultUtil.build(result);
    }

    /**
     * 删除记录
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteById", method = RequestMethod.GET)
    public RestResult<Boolean> deleteById(@RequestParam("id") Long id) {
        PlainResult<Boolean> result = enableTablesDetailService.deleteById(id);
        return RestResultUtil.build(result);
    }

    /**
     * Master分支demo接口验证
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String getItemList() {
        return "恭喜你！测试平台启动成功！";
    }
}
