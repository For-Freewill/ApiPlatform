package com.youzan.ycm.qa.enable.platform.web.controller.ycm.onlineTrade;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.onlineTrade.CreateOnlineOrderRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.onlineTrade.OnlineOrderService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Created by baoyan on 12/1/21.
 */
@Slf4j
@RestController
@RequestMapping("/onlineTrade")
public class CreateOnlineOrderController {
    @Resource
    private OnlineOrderService onlineOrderService;

    /**
     * 创建线上订购单
     */
    @RequestMapping(value = "/createOnlineOrder", method = RequestMethod.POST)
    public RestResult<String> createOnlineOrder (@RequestBody CreateOnlineOrderRequest request) {
        PlainResult<String> result = onlineOrderService.createOnlineOrder(request);
        return RestResultUtil.build(result);

    }

}