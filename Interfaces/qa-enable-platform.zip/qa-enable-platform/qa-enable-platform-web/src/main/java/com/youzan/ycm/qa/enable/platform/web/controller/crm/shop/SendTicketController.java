package com.youzan.ycm.qa.enable.platform.web.controller.crm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.shop.SendTicketRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.shop.SendTicketService;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-04-25 21:25
 */
@Slf4j
@RestController
@RequestMapping("/enable/shop/ticket")
public class SendTicketController {
    @Resource
    private SendTicketService sendTicketService;

    @RequestMapping(value = "/sendToShop",method = RequestMethod.POST)
    public RestResult<Boolean> createWxd(@RequestBody SendTicketRequest request){

        PlainResult<Boolean> result = sendTicketService.sendTicketToKdtId(request);
        return RestResultUtil.build(result);
    }
}
