package com.youzan.ycm.qa.enable.platform.web.controller.crm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.web.annotation.Auth;
import com.youzan.ycm.qa.enable.platform.web.response.RestResult;
import com.youzan.ycm.qa.enable.platform.web.util.RestResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import  com.youzan.ycm.qa.enable.platform.api.service.crm.shop.WxdService;
import  com.youzan.ycm.qa.enable.platform.api.request.crm.shop.CreateWxdRequest;

import javax.annotation.Resource;

/**
 * Created by water on 2021/4/15.
 */
//@Auth
@Slf4j
@RestController
@RequestMapping("/enable/shop")

public class CreateWxdController {
    @Resource
    private WxdService wxdService;

    @RequestMapping(value = "/createWxd",method = RequestMethod.POST)
    public RestResult<Long> createWxd(@RequestBody CreateWxdRequest request){
        PlainResult<Long> result = wxdService.createWxd(request);
        return RestResultUtil.build(result);
    }
}
