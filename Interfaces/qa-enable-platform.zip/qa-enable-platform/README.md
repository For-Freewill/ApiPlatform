# 平台简介

![travis](https://travis-ci.org/rhwayfun/spring-boot-learning-examples.svg?branch=develop)
[![codecov](https://codecov.io/gh/rhwayfun/spring-boot-learning-examples/branch/develop/graph/badge.svg)](https://codecov.io/gh/rhwayfun/spring-boot-learning-examples)
[![Gitter](https://img.shields.io/gitter/room/nwjs/nw.js.svg)](https://gitter.im/spring-boot-learning-examples/chat)
[![license](https://img.shields.io/badge/license-EPL%201.0-green.svg)](https://choosealicense.com/licenses/epl-1.0/)

- 简介：https://doc.qima-inc.com/pages/viewpage.action?pageId=289675873

- 后端框架：http://gitlab.qima-inc.com/qa/qa-enable-platform

- 前端框架：http://gitlab.qima-inc.com/qa/qa-enable-web

# 快速启动例子

快速启动demo：https://doc.qima-inc.com/pages/viewpage.action?pageId=308810378

http://localhost:7001/demo/test

返回：恭喜你！测试平台启动成功！

# 需求列表
- 需求列表： https://doc.qima-inc.com/pages/viewpage.action?pageId=304582060

# 参考Links

- [spring-boot](https://github.com/spring-projects/spring-boot)
- [mybatis-plus](https://github.com/baomidou/mybatis-plus)
- [druid](https://github.com/druid-io/druid/)

# 开发者群
企业微信群：商赋测试平台开发群