package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 店铺角色绑定历史表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
@Data
public class FwShoproleBindingHistoryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺角色ID*/
	private Long shopRoleId;

	/**店铺ID*/
	private Long kdtId;

	/**角色类型*/
	private String roleType;

	/**资源池ID*/
	private Long fromPoolId;

	/**资源池类型*/
	private String fromPoolType;

	/**资源池名称*/
	private String fromPoolName;

	/**资源池ID*/
	private Long toPoolId;

	/**资源池类型*/
	private String toPoolType;

	/**资源池名称*/
	private String toPoolName;

	/**绑定时间*/
	private Date boundAt;

	/**绑定原因*/
	private String reason;

	/**规则ID*/
	private Long ruleId;

	/**流转平台规则ID*/
	private Long tpRuleId;

	/**流转平台规则执行ID*/
	private String tpRuleExecutionId;

	/**场景类型*/
	private String sceneType;

	/**场景附加信息*/
	private String scene;

	/**操作人ID*/
	private Long operatorId;

	/**操作人类型*/
	private String operatorType;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
