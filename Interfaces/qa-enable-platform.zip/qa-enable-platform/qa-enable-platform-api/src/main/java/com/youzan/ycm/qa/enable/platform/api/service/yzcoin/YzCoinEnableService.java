package com.youzan.ycm.qa.enable.platform.api.service.yzcoin;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.yzcoin.YzCoinRequest;
import com.youzan.ycm.qa.enable.platform.api.response.yzcoin.YzCoinRep;

/**
 * @author leifeiyun
 * @date 2022/1/6
 **/
public interface YzCoinEnableService {
PlainResult<YzCoinRep> grantYzCoin(YzCoinRequest yzCoinRequest);
PlainResult<YzCoinRep> resetYzCoin(YzCoinRequest yzCoinRequest);
PlainResult<YzCoinRep> getYzCoinBalance(YzCoinRequest yzCoinRequest);
}
