package com.youzan.ycm.qa.enable.platform.api.response.ycm;

import lombok.Data;

import java.util.Map;

/**
 * @Author wulei
 * @Date 2020/11/4 15:04
 */
@Data
public class OrderQueryResponse {
    private static final long serialVersionUID = -5292665560986031575L;

    /**
     * total 返回的记录数
     */
    private Long total;

    /**
     * 返回的表数据信息
     */
    private Map<String, Object> details;
}
