package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;

import java.util.Date;

/**
 * @Author run.xiong
 * @Description 用例请求dto
 * @Date 2021/8/19
 */
@Data
public class ExcuteDetailByAppRequestDTO {
    /**
     * 开始时间
     */
    private Date startDate;

    /**
     * 结束时间
     */
    private Date endDate;

    /**
     * case所属测试类
     */
    private String caseBelongApp;

    /**
     * 每页个数
     */
    @Value("${limit:10}")
    private Integer limit;

    /**
     * 页数
     */
    @Value("${page:1}")
    private Integer page;

}
