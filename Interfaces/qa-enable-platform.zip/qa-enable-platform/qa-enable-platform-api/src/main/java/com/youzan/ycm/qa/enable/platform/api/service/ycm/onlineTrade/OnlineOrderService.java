package com.youzan.ycm.qa.enable.platform.api.service.ycm.onlineTrade;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.onlineTrade.CreateOnlineOrderRequest;
/**
 * Created by baoyan on 11/30/21.
 */
public interface OnlineOrderService {

    /**
     *  创建线上订购，目前仅支持软件
     *
     */
    PlainResult<String> createOnlineOrder(CreateOnlineOrderRequest request);
}
