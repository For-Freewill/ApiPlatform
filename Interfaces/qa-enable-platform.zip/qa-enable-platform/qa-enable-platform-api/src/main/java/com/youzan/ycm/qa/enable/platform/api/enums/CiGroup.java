package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@AllArgsConstructor
@Getter
public enum CiGroup{

    CRM(0, "CRM"),

    YCM(1, "商业化"),

    UNKNOW(-1, "UNKNOW");

    private final Integer code;
    private final String status;

    public static CiGroup of(Integer code) {
        return Arrays.stream(CiGroup.values())
                .filter(taskStatus -> Objects.equals(code, taskStatus.getCode()))
                .findFirst()
                .orElse(null);
    }
}
