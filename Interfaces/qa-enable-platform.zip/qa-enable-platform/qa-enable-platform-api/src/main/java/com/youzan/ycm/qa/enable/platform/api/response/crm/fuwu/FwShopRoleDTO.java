package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 店铺角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:18
 */
@Data
public class FwShopRoleDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**店铺角色ID*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**角色类型*/
	private String roleType;

	/**角色状态*/
	private Integer state;

	/**角色开启时间*/
	private Date startTime;

	/**角色关闭时间*/
	private Date endTime;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
