package com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu.ShopRoleAssignDTO;
import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ResourceTransResponseDTO;

/**
 * @author hezhulin
 * @date 2021-05-18 15:19
 */
public interface ShopRoleOperationService {

    /**
     * 分配店铺的单个店铺角色给指定角色池
     * @param shopRoleAssignDTO
     * @return
     */
    PlainResult<Boolean> assignShopRole(ShopRoleAssignDTO shopRoleAssignDTO);
}
