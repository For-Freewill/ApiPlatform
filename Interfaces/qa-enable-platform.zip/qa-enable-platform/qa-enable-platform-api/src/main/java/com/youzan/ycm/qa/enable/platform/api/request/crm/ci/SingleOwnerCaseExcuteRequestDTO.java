package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import com.youzan.api.common.response.Paginator;
import lombok.Data;

import java.util.Date;

/**
 * @author hezhulin
 * @date 2021-08-30 11:55
 * 人维度用例执行情况查询的入参
 */
@Data
public class SingleOwnerCaseExcuteRequestDTO {

    /**
     * 统计的用例的执行时间不早于该时间
     */
    private Date startDate;

    /**
     * 统计的用例的执行时间不晚于该时间
     */
    private Date endDate;

    /**
     * 用例负责人
     */
    private String owner;

    /**
     * 分页
     */
    private Paginator paginator;

}
