package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 流程角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:50
 */
@Data
public class FwProcRoleDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**流程角色ID*/
	private Long id;

	/**流程实例ID*/
	private Long procInstId;

	/**店铺ID（冗余）*/
	private Long kdtId;

	/**流程模版（冗余）*/
	private String procTemplate;

	/**角色类型*/
	private String roleType;

	/**角色开启时间*/
	private Date startTime;

	/**角色开启时的变量*/
	private String startVariable;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
