package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 店铺属性值
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 11:26:54
 */
@Data
public class ShopAttributeDataDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**店铺属性名称1、label店铺标签*/
	private Integer attrId;

	/**属性值*/
	private String value;

	/**扩展字段*/
	private String expansion;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

	/**删除时间*/
	private Date deletedAt;

}
