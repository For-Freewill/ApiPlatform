package com.youzan.ycm.qa.enable.platform.api.request.ycm.gift;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:18
 **/
@Data
public class GetGiftAssetListByOwnerRequest implements Serializable {
    /**
     * 店铺ktdId
     */
    private String ownerYcmId;

    /**
     * kdt_id:店铺Id
     * default kdt_id
     */
    private String ownerYcmIdType;

    /**
     * 礼包状态（待领取,已领取,已回收,已过期等）
     *
     * @see com.youzan.ycm.gift.constant.GiftAssetStateConstant
     */
    private List<String> stateList;
}
