package com.youzan.ycm.qa.enable.platform.api.service.ycm.inter;

import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.BaseInvokeRequest;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:25
 **/
public interface InterfaceService {

    /**
     * 进行方法调用
     */
    Object doMethodInvoke(BaseInvokeRequest invokeRequest);
}
