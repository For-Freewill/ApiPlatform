package com.youzan.ycm.qa.enable.platform.api.request.crm.kefu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-09 20:48
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransferRecordRequest {
    /**
     * 客户ID
     */
    Long customerId;
    /**
     * 客户所属客服的全名
     */
//    Long fromServantId;
    String fromServantName;
    /**
     * 转接到的客服全名
     */
//    Long toServantId;
    String toServantName;
}
