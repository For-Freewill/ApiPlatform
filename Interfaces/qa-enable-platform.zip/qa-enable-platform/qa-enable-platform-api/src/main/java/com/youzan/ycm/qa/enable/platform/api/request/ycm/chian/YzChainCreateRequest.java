package com.youzan.ycm.qa.enable.platform.api.request.ycm.chian;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2021/5/8
 **/
@Data
public class YzChainCreateRequest implements Serializable {
    /**
     * 产品线类型
     */
    private String prodType;
    private String kdtId;

}
