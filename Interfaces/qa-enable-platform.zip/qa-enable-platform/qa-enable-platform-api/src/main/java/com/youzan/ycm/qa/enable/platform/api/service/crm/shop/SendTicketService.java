package com.youzan.ycm.qa.enable.platform.api.service.crm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.shop.SendTicketRequest;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-04-25 21:29
 */
public interface SendTicketService {

    PlainResult<Boolean> sendTicketToKdtId( SendTicketRequest request);
}
