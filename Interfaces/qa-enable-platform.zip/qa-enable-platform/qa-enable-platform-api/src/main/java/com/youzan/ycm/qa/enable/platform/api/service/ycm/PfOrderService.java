package com.youzan.ycm.qa.enable.platform.api.service.ycm;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.OrderQueryRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.OrderQueryResponse;

/**
 * ycm service
 *
 * @author wulei
 * @date 2020-10-10
 */
public interface PfOrderService {
    /**
     * 根据订单号查询全部表的信息
     *
     * @param request
     * @return
     */
    PlainResult<OrderQueryResponse> queryByTdOrderId(OrderQueryRequest request);

    /**
     * 回收服务期（不进行退款动作）
     *
     * @param pfOrderId
     * @return
     */
    PlainResult<Boolean> recycleForPfOrder(Long pfOrderId);
}
