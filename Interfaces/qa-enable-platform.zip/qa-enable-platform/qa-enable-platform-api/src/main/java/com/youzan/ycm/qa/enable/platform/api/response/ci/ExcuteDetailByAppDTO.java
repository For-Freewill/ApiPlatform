package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Builder;
import lombok.Data;

/**
 * @Author run.xiong
 * @Description 应用执行详情返回结果类
 * @Date 2021/8/23
 */
@Data
@Builder
public class ExcuteDetailByAppDTO {
    /**
     * 执行ID
     */
    private Integer id;
    /**
     * 执行环境
     */
    private String env;
    /**
     * 执行用例数
     */
    private Integer executeCount;
    /**
     * 执行成功用例数
     */
    private Integer executeSuccessCount;
    /**
     * 执行失败用例数
     */
    private Integer executeFailureCount;
    /**
     * 执行跳过用例数
     */
    private Integer executeSkipCount;
    /**
     * 执行链接
     */
    private String reportUrl;
}
