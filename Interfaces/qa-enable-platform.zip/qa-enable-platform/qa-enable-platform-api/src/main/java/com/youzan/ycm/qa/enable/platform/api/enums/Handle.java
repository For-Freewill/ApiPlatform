package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@AllArgsConstructor
@Getter
public enum  Handle {
    UNTREATED(0, "未处理"),

    TREATED(1, "已处理");

    private final Integer code;
    private final String status;

    public static Handle of(Integer code) {
        return Arrays.stream(Handle.values())
                .filter(taskStatus -> Objects.equals(code, taskStatus.getCode()))
                .findFirst()
                .orElse(null);
    }
}
