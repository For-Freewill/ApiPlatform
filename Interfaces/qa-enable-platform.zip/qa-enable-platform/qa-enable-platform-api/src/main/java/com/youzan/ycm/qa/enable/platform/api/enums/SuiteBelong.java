package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author hezhulin
 * @date 2021-08-24 17:25
 */
@Getter
public enum SuiteBelong {

    CRM_ASSIGNABLE("crm-assignable", "crm-assignable", CiGroup.CRM),
    CRM_CORE("crm-core", "crm-core", CiGroup.CRM),
    CRM_CORE_CUSTOMER("crm-core-customer", "crm-core-customer", CiGroup.CRM),
    CRM_CORE_NG("crm-core-ng", "crm-core-ng", CiGroup.CRM),
    ENABLE_TICKET_WEIQUAN("enable-ticket-weiquan", "enable-ticket-weiquan", CiGroup.CRM),
    EP_COMMON_SERVICE("ep-common-service", "ep-common-service", CiGroup.CRM),
    CRM_FUWU("crm-fuwu", "crm-fuwu", CiGroup.CRM),
    ENABLE_CRM_ONLINE_CALL("enable-crm-online-call", "enable-crm-online-call", CiGroup.CRM),
    OPERATION_SERVICE("operation-service", "operation-service", CiGroup.CRM),
    CRM_ORDER_SERVICE("crm-order-service", "crm-order-service", CiGroup.CRM),
    CRM_ORGANIZATION_SERVICE("crm-organization-service", "crm-organization-service", CiGroup.CRM),
    PANAMA_CORE("panama-core", "panama-core", CiGroup.CRM),
    CRM_PROVIDER("crm-provider", "crm-provider", CiGroup.CRM),
    CRM_PROVIDER_SERVICE("crm-provider-service", "crm-provider-service", CiGroup.CRM),
    CRM_QUDAO_WEB("crm-qudao-web", "crm-qudao-web", CiGroup.CRM),
    CRM_SALE_WEB("crm-sales-web", "crm-sales-web", CiGroup.CRM),
    CRM_SALE_SERVICE("crm-sales-service", "crm-sales-service", CiGroup.CRM),
    SERVE_IM("serve-im", "serve-im", CiGroup.CRM),
    CRM_TUOKE_SERVICE("crm-tuoke-service", "crm-tuoke-service", CiGroup.CRM),
    VESTA("vesta", "vesta", CiGroup.CRM),
    CRM_WORKFLOW("crm-workflow", "crm-workflow", CiGroup.CRM),
    CRM_RETRY("crmReRunSuite", "retry", CiGroup.CRM),
    //  商业化相关
    YCM_ALL("all","all",CiGroup.YCM),
    YCM_BASECASE("basecase","baseCase",CiGroup.YCM),
    YCM_GOODS("goods","goods",CiGroup.YCM),
    YCM_DEDUCTION("deduction","deductionAndRefund",CiGroup.YCM),
    YCM_PERIORCOUNT("periodCount","periodCount",CiGroup.YCM),
    YCM_ONLINE_TRADE("onlineTrade","onlineTrade",CiGroup.YCM),
    YCM_OFFLINE_TRADE("offlineTrade","offlineTrade",CiGroup.YCM),
    YCM_MARKET("market","ycm-market",CiGroup.YCM),
    YCM_OPEN("open","ycm-open",CiGroup.YCM),
    YCM_PERFORM("perform","ycm-perform",CiGroup.YCM),
    YCM_TRADE("trade","ycm-trade",CiGroup.YCM),
    BIT_COMMERCE_NEW("bit-commerce-new", "bit-commerce-new", CiGroup.YCM),
    YOP("yop","yop",CiGroup.YCM),
    YCM_RETRY("reRunSuite","ycm-retry",CiGroup.YCM);

    private final String suiteName;
    private final String belongApp;
    private final CiGroup belongGroup;

    SuiteBelong(String suiteName, String belongApp, CiGroup belongGroup) {
        this.suiteName = suiteName;
        this.belongApp = belongApp;
        this.belongGroup = belongGroup;
    }

    public static SuiteBelong of(String suiteName) {
        return Arrays.stream(SuiteBelong.values())
                .filter(suiteBelong -> Objects.equals(suiteName, suiteBelong.getSuiteName()))
                .findFirst()
                .orElse(null);
    }
}
