package com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2022/2/17
 **/
@Data
public class SchemeState implements Serializable {
    String state;
}
