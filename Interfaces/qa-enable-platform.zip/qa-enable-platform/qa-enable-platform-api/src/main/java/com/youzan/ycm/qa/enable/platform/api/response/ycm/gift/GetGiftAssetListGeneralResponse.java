package com.youzan.ycm.qa.enable.platform.api.response.ycm.gift;


/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:19
// **/
//public class GetGiftAssetListGeneralResponse implements Serializable {
//
//    private List<GiftAssetDTO> giftAssetDTOS;
//}
