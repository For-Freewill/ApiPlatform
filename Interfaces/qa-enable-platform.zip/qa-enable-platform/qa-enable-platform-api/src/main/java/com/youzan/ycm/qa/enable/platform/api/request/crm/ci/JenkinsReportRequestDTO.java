package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;


/**
 * @Author run.xiong
 * @Description 获取 jenkins 返回结果 请求入参
 * @Date 2021-08-19
 **/
@Data
public class JenkinsReportRequestDTO {

    /**
     * 对应job的url链接，如 https://cd-qa.qima-inc.com/jenkins-12/job/qa/job/qa-crm-qudao-web/461/
     */
    private String jobUrl;
}
