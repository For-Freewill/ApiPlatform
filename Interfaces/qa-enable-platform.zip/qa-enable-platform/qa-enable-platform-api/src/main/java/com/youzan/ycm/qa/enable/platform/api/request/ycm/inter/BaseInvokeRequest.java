package com.youzan.ycm.qa.enable.platform.api.request.ycm.inter;

import lombok.Data;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:26
 **/
@Data
public class BaseInvokeRequest {

    /**
     * 调用类型  com.youzan.ycm.qa.enable.platform.api.enums.InvokeTypeEnum
     */
    private String invokeType;
}
