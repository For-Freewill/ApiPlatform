package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 激活的服务期历史记录
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
@Data
public class CrmShopProductActiveHistoryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺id*/
	private Long kdtId;

	/**履约单id*/
	private Long orderId;

	/**订单的app_id*/
	private Integer appId;

	/**订单的item_id*/
	private Integer itemId;

	/**订单状态的level*/
	private String level;

	/**订单状态的来源分组*/
	private String groupType;

	/**订单状态的应用类型*/
	private String category;

	/**生效时间*/
	private Date effectTime;

	/**到期时间*/
	private Date expireTime;

	/**商业化履约明细id*/
	private Long pfOrderStatusId;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
