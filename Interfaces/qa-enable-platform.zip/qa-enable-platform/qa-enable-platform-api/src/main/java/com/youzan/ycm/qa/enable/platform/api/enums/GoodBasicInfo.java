package com.youzan.ycm.qa.enable.platform.api.enums;


import com.youzan.ycm.qa.enable.platform.api.exception.IErrorCode;

/**
 * @author leifeiyun
 * @date 2020/12/30
 **/
public enum GoodBasicInfo  {
    RETAIL_CHAIN_FLAGSHIP("零售连锁总部-旗舰版",50666,8414),
    RETAIL_CHAIN_PROFESSIONAL("零售连锁总部-专业版",50555,8200),
    RETAIL_CHAIN_SIGN("有赞连锁-高级版总部L",445247,74247),
    RETAIL_CHAIN_SAME_CITY_STORE("同城网店",445245,74223),
    RETAIL_CHAIN_STORE("零售连锁-门店",50007,8114),
    RETAIL_CHAIN_PARTNER("零售连锁-合伙人",50670,8416),
    RETAIL_CHAIN_NET_STORE("零售连锁-网店",50005,8431),
    YOUZAN_CHAIN_MINIMALIST("零售连锁总部-极简版",50777,8434),
    YOUZAN_CHAIN_MINIMALIST_NET_STORE("微商城连锁-网店",50230,8319),
    YOUZAN_CHAIN_MINIMALIST_PARTNER("微商城连锁-合伙人",50680,8516),
    YOUZAN_CHAIN_CITY_CLOUD_STORE("有赞连锁（同城云店）",51922,76340),
    YOUZAN_CHAIN_REGIONAL_LSTORE("有赞连锁（区域网店)",51923,76342),
    STORE_IN_OUT("门店进出存",445318,100076273),
    EDU_CHAIN_HAED("有赞教育连锁总部",44290,8312),
    EDU_CHAIN_CAMPUS("有赞教育连锁-校区",44291,8314),
    EDU_CHAIN_HEAD_40("教育连锁多校区总部",445281,74372),
    EDU_CHAIN_CAMPUS_40("教育连锁多校区-校区",445282,74373),
    EDU_CHAIN_HEAD_FUSION_40("教育连锁多校区总部-融合版",445281,74413),
    EDU_CHAIN_CAMPUS_FUSION_40("教育连锁多校区-融合版-校区",445282,74415),

    CRM("crm插件",445299,100075879),
    CRM_STORE("crm-门店A",445296,100075875),
    MULTI_STORE("多网点服务",32032,7092),
    MULTI_STORE_NUM("多网点数量",27890,7079);


    private GoodBasicInfo(String name, Integer appId, Integer itemId) {
          this.name = name;
          this.appId = appId;
          this.itemId = itemId;
      }

    private String name;
    private Integer appId;
    private Integer itemId;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }



}
