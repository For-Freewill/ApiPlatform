package com.youzan.ycm.qa.enable.platform.api.service.ycm.cache;

import com.youzan.api.common.response.PlainResult;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:11
 **/
public interface FlushAppStatusService {

    //刷新服务期缓存
    PlainResult<Boolean> flushAppStatusCatch(String kdtId, String appId);
}
