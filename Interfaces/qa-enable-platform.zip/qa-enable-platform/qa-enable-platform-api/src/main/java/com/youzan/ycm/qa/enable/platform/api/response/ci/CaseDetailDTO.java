package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用例详情
 *
 * @author hujiping
 * @email hujiping@youzan.com
 * @date 2021-08-23 11:52:02
 */
@Data
public class CaseDetailDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**主键*/
    private Long id;

    /**case名称*/
    private String caseName;

    /**是否删除（0，未删除；1，删除）*/
    private Integer isDelete;

    /**case所属测试类*/
    private String caseBelongClass;

    /**case所属应用*/
    private String caseBelongApp;

    /**case作者*/
    private String caseAuthor;

    /**case路径*/
    private String caseUrl;

    /**创建时间*/
    private Date createdAt;

    /**更新时间*/
    private Date updatedAt;

}
