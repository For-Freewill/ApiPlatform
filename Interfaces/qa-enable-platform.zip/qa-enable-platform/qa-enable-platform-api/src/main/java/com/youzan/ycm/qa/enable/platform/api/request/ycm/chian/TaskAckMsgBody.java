package com.youzan.ycm.qa.enable.platform.api.request.ycm.chian;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2022/2/16
 **/
@Data
public class TaskAckMsgBody implements Serializable {
    String taskId;
}
