package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-23 20:44
 */
@Data
public class ExcuteDetailDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * jenkinsjob表 id
     */
    private Long jobId;

    /**
     * 关联用例id
     */
    private Long caseId;

    /**
     * 执行结果
     */
    private Integer excuteResult;

    /**
     * 执行耗时
     */
    private String excuteCost;

    /**
     * 执行jenkins
     */
    private String excuteJenkins;

    /**
     * 错误信息
     */
    private String errorDetail;

    /**
     * 执行环境
     */
    private String env;

    /**
     * case所属应用
     */
    private String caseBelongApp;

}
