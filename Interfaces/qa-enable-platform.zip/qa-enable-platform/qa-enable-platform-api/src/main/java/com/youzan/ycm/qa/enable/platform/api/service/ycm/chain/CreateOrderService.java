package com.youzan.ycm.qa.enable.platform.api.service.ycm.chain;


import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;

/**
 * @author leifeiyun
 * @date 2020/12/30
 **/
public interface CreateOrderService  {
    PlainResult<CreateOfflineOrderRep> CreateOfflineOrderV2(YzChainCreateRequest yzChainCreateRequest);

    PlainResult<CreateOfflineOrderRep> CreateOfflineOrderForUpgrade(YzChainUpgradeRequest yzChainCreateRequest);

}
