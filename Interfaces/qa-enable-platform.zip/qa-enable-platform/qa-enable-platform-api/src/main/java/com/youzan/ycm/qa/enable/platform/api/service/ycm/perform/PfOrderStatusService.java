package com.youzan.ycm.qa.enable.platform.api.service.ycm.perform;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.MovePfOrderStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.ResetShopTryTimeRequest;

/**
 * @author wuwu
 * @date 2021/12/6 7:18 PM
 */
public interface PfOrderStatusService {

    /**
     * 插件/软件服务期移动
     * @param request
     * @return
     */
    PlainResult<Boolean> movePfOrderStatus(MovePfOrderStatusRequest request);
}
