package com.youzan.ycm.qa.enable.platform.api.request.crm.shop;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-04-25 21:32
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SendTicketRequest {
    /**
     * 权益名称
     */
    String ticketTaskName;

    /**
     * 发放店铺
     */
    String kdtId;
}
