package com.youzan.ycm.qa.enable.platform.api.service.ycm.yunFee;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.code.NewActivationCodeRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.yunFee.FcFeeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.code.NewActivationCodeResponse;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.yunFee.FcFeeResponse;

/**
 * @Author wulei
 * @Date 2021/01/14 17:30
 */
public interface YunFeeService {
    /**
     * 根据选项，落对应的订单额度订单
     *
     * @param request
     * @return
     */
    PlainResult<NewActivationCodeResponse> createYunFeeOrder(NewActivationCodeRequest request);

    /**
     * 查询计费侧，云服务费相关的4个表
     *
     * @param request
     * @return
     */
    PlainResult<FcFeeResponse> selectFcFee(FcFeeRequest request);
}
