package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Builder;
import lombok.Data;

/**
 * @Author run.xiong
 * @Description 根据执行时间获取各个app的执行详情
 * @Date 2021/8/23
 */
@Data
@Builder
public class ExcuteDetailByDateDTO {
    long id;
    /**
     * case所属应用
     */
    private String caseBelongApp;
    /**
     * case数量
     */
    private Integer caseCount;
    /**
     * 执行次数
     */
    private Integer executeCount;
    /**
     * 平均成功率
     */
    private String averageSuccessRate;
    /**
     * 平均执行时间
     */
    private float averageExecutionTime;
}
