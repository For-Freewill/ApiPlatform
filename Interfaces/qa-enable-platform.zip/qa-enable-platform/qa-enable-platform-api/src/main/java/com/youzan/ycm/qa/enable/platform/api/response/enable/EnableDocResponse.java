package com.youzan.ycm.qa.enable.platform.api.response.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wulei
 * @date 2020/11/19 20:02
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableDocResponse implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * 返回的表数据信息
     */
    private Long id;

    /**
     * 返回的表数据信息
     */
    private String doc_name;

    /**
     * 返回的表数据信息
     */
    private String doc_url;

    /**
     * 返回的表数据信息
     */
    private String doc_ext;

    /**
     * 返回的表数据信息
     */
    private String doc_type;

    /**
     * 返回的表数据信息
     */
    private String doc_author;

    /**
     * 返回的表数据信息
     */
    private Date created_at;
}