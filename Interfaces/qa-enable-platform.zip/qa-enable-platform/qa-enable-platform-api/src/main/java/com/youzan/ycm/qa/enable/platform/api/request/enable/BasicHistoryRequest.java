package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author wulei12
 * @Date 2020/11/5 19:33
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BasicHistoryRequest implements Serializable {
    /**
     * 保存的方案名称
     */
    private String recordName;

    /**
     * biz后台操作人ID
     */
    private String operatorId;
}
