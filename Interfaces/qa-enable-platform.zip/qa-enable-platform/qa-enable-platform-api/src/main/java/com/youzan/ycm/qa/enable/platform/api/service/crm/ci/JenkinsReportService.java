package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.JenkinsReportRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.JenkinsReportDTO;

/**
 * @Author run.xiong
 * @Description 获取Jenkins执行结果业务处理类
 * @Date 2021-08-19
 **/
public interface JenkinsReportService {
    /**
     * 获取Jenkins执行结果
     * @param jobUrl
     * @return
     */
    PlainResult<JenkinsReportDTO> getJenkinsReport(String jobUrl);

    Boolean jobIsFinish(String jobUrl);

}
