package com.youzan.ycm.qa.enable.platform.api.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 请求错误码标记
 *
 * @Author wulei
 * @Date 2020/10/27 17:40
 */
@Data
public class SessionUser implements Serializable {
    private Long id;
    private Long casId;
    private String nickname;
    private String realname;
    private String loginId;
    private Integer sex;
    private Integer status;
    private String casUsername;
    private Long mobile;
    private String email;
    private String avatar;
    private Integer departmentId;
    private Long oaId;
    private String positionName;
    private Boolean isAdmin;
}
