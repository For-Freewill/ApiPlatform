package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author wulei
 * @Date 2020/10/27 17:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddQueryHistoryResquest implements Serializable {
    /**
     * 保存的方案名称qw
     */
    private String recordName;

    /**
     * biz后台操作人ID
     */
    private String operatorId;

    /**
     * 方案涉及的表列表
     */
    private List<String> tables;

    /**
     * biz后台操作人类型
     */
    private String operatorType;

    /**
     * biz后台操作人名称
     */
    private String operatorName;
}
