package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 成单业绩数据表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 11:30:35
 */
@Data
public class OrderBelongingDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**自增id*/
	private Long id;

	/**yop订单号, 来源open_application_order主键*/
	private Long orderId;

	/**员工id*/
	private Long userId;

	/**员工姓名*/
	private String userName;

	/**职业, 1:销售, 2:服务*/
	private Integer profession;

	/**业绩占比，单位(%)，静默时为0*/
	private Integer percentage;

	/**业绩额，单位(分)*/
	private Integer achievement;

	/**额外奖励，单位(分)*/
	private Integer extraBonus;

	/**成单数*/
	private String orderCount;

	/**客户数(暂时不用)*/
	private String customerCount;

	/**是否静默, 0:非静默,1:静默*/
	private Integer isSilent;

	/**归属类型, 1:主归属,0:从归属，主归属只能有一个*/
	private Integer belongType;

	/**调整类型, 原撞单类型, 0:未调整, 具体配置在apollo*/
	private Integer disputeType;

	/**调整类型描述字符串*/
	private String disputeTypeDesc;

	/**调整原因*/
	private String disputeReason;

	/**调整发起人*/
	private String disputeSponsor;

	/**组织类型, 1:有赞, 2:渠道*/
	private Integer orgType;

	/**员工所在部门id*/
	private Long departmentId;

	/**员工所在部门名称*/
	private String departmentName;

	/**员工所属的顶级部门id*/
	private Long topDepartmentId;

	/**员工所属的顶级部门名称*/
	private String topDepartmentName;

	/**祖先部门id列表, 自底向上排序, 逗号分隔*/
	private String ancestorDepartmentIds;

	/**祖先部门名称列表, 自底向上排序, 逗号分隔*/
	private String ancestorDepartmentNames;

	/**渠道商id，org_type=2时有值*/
	private Long providerId;

	/**渠道商名称，org_type=2时有值*/
	private String providerName;

	/**归属标记，0:无标记，1:联合跟进标记，2:销售专属码，3:全民销售，4:跨业务线提报，5:跨地域提报，6:线索提报（归属人），7:线索提报（提报人），8:联合跟进（归属人），9:联合跟进（跟进人），10:商机报备*/
	private Integer belongLabel;

	/**计入考核规则类型,逗号分隔,1：成单量；2：业绩额*/
	private String examineRuleType;

	/**当月最新组织架构id*/
	private String departmentIdsLatestOfMonth;

	/**当月最新组织架构名称*/
	private String departmentNamesLatestOfMonth;

	/**当月最新渠道经理*/
	private Long managerIdLatestOfMonth;

	/**成交周期（销售）单位：秒*/
	private Long salesTransactionCycle;

	/**销售跟进阶段*/
	private String salesFollowStage;

	/**销售跟进阶段名称*/
	private String salesFollowStageName;

	/**流转原因标签*/
	private Integer transferredReasonCode;

	/**是否区域串货, 0:否,1:是*/
	private Integer isCrossRegionSale;

	/**创建时间*/
	private Date createdAt;

	/**修改时间*/
	private Date updatedAt;

}
