package com.youzan.ycm.qa.enable.platform.api.service.ycm.cache;

import com.youzan.api.common.response.PlainResult;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:11
 **/
public interface FlushGoodsAllCatchService {

    /**
     * 清理商品缓存
     */
    PlainResult<Boolean> flushGoodsAllCatch(Integer appId);
}
