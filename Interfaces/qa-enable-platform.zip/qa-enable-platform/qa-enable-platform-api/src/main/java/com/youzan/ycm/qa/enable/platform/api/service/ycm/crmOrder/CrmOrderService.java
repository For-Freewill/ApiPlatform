package com.youzan.ycm.qa.enable.platform.api.service.ycm.crmOrder;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmOrder.CreateCrmApprovalNoRequest;
/**
 * Created by baoyan on 2021-04-25.
 */
public interface CrmOrderService {


    /**
     * 生成crm提单审批流
     *
     */
    PlainResult<String> createCrmApprovalNo(CreateCrmApprovalNoRequest request);
}
