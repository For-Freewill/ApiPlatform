package com.youzan.ycm.qa.enable.platform.api.request.crm.shop;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by water on 2021/4/15.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateWxdRequest {

    private String mobile;
}
