package com.youzan.ycm.qa.enable.platform.api.service.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:00
 **/
//public interface GiftAssetRemoteService {
//
//    /**
//     * 查询礼包
//     */
//    PlainResult<GetGiftAssetListGeneralResponse> listGfAssetByOwner(GetGiftAssetListByOwnerRequest request);
//}
