package com.youzan.ycm.qa.enable.platform.api.response.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wuwu
 * @date 2021/2/19 1:34 PM
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableCreateShopResponse implements Serializable {
    private static final long serialVersionUID = 7718929662682718283L;


    /**
     * 返回店铺ID
     */
    private Long kdtId;

    /**
     * 返回店铺信息
     */
    private String kdtName;

    /**
     * 返回店铺userId
     */
    private String userId;

    private String prodCode;
}
