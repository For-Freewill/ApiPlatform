package com.youzan.ycm.qa.enable.platform.api.service.crm.hotline;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.hotline.CreateHotlineRequest;


public interface HotlineFactoryService {

    PlainResult<Boolean> createHotline(String cookies,CreateHotlineRequest request);

}


