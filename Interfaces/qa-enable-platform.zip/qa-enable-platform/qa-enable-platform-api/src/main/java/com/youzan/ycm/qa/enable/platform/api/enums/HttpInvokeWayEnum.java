package com.youzan.ycm.qa.enable.platform.api.enums;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-24 20:44
 **/
public enum  HttpInvokeWayEnum {
    GET,
    POST
}
