package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author Jiping.Hu
 * @Description 失败处理返回DTO
 * @Date 2021-08-11
 **/
@Data
public class FailureDetailDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * caseId
     */
    Long caseId;

    /**
     * 责任人
     */
    private String owner;

    /**
     * 失败case
     */
    private String caseName;

    /**
     * 所属应用
     */
    private String caseBelongApp;

    /**
     * 所属类
     */
    private String caseBelongClass;

    /**
     * 执行的环境
     */
    private String env;

    /**
     * 执行的时间
     */
    private String excuteTime;

    /**
     * 失败率
     */
    private String failureRate;

    /**
     * 是否处理
     */
    private int hadle;

    private String jobGroup;

}
