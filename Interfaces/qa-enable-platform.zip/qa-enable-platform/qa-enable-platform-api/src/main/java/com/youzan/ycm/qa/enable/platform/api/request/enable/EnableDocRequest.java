package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020/11/19 20:45
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableDocRequest implements Serializable {

    /**
     * 请求信息
     */
    private String docName;

    /**
     * 请求信息
     */
    private String docUrl;

    /**
     * 请求信息
     */
    private String docExt;

    /**
     * 请求信息
     */
    private String docType;

    /**
     * 请求信息
     */
    private String docAuthor;
}
