package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author hezhulin
 * @date 2021-08-24 15:12
 */
@Data
public class SuiteFinishProcessRequestDTO implements Serializable {
    /**
     * job的具体某次执行的url
     */
    private String jobBuildUrl;

    /**
     * 执行的测试套件中配置的suiteName
     */
    private String suiteName;

}
