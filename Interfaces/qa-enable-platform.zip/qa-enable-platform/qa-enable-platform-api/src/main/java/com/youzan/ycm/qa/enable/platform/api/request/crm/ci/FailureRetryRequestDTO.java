package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import lombok.Data;

import java.util.Set;

/**
 * @Author Jiping.Hu
 * @Description  失败重试DTO
 * @Date  2021-08-16
 **/
@Data
public class FailureRetryRequestDTO {
    Set<Long> jobIds;
    SessionUser user;
}
