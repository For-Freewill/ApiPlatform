package com.youzan.ycm.qa.enable.platform.api.response.ycm.code;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * @Author wulei
 * @Date 2021/01/13 15:03
 */
@Data
public class NewActivationCodeResponse implements Serializable {
    private static final long serialVersionUID = -5292665560986031575L;

    /**
     * total 返回的记录数
     */
    private Long total;

    /**
     * 返回的表数据信息
     */
    private Map<String, Object> details;
}
