package com.youzan.ycm.qa.enable.platform.api.request.ycm.perform;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wuwu
 * @date 2021/6/13 6:20 PM
 */
@Data
public class ResetShopTryTimeRequest implements Serializable {
    /**
     * 店铺ID
     */
    private Long kdtId;

    /**
     * 店铺试用期过期时间
     */
    private String endTime;
}
