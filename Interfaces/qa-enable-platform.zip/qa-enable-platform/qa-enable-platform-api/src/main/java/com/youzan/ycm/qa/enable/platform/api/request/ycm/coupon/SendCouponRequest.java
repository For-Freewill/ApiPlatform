package com.youzan.ycm.qa.enable.platform.api.request.ycm.coupon;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Created by baoyan on 2021-04-13.
 */
@Data
public class SendCouponRequest implements Serializable  {

    /**
     * 发放店铺
     */
    private String KdtId;

    /**
     * 总部发券张数，最大值100
     */
    private Integer sendCount;


    /**
     * 优惠券领取方式
     *   发放后自动领:AUTO_RECEIVE ; 发放后手动领: MANUAL_RECEIVE
     */
    private String couponReceiveType;


}
