package com.youzan.ycm.qa.enable.platform.api.service.ycm.chain;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.SchemeState;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.ShopUpgradeRep;

/**
 * @author leifeiyun
 * @date 2022/2/10
 **/
public interface UpgradeChainService {
    /**
     * 执行升级动作
     * @param yzChainUpgradeRequest
     * @return
     */
    PlainResult<ShopUpgradeRep> startUpgrade(YzChainUpgradeRequest yzChainUpgradeRequest);

    /**
     * 验证订单方案已经生成
     * @param yzChainUpgradeRequest
     * @return
     */
    public PlainResult<SchemeState> schemeState(YzChainUpgradeRequest yzChainUpgradeRequest);
}
