package com.youzan.ycm.qa.enable.platform.api.service.ycm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ebiz.common.model.CommonResult;
import com.youzan.shopcenter.shop.entity.LongServiceResult;
import com.youzan.sz.beautystore.shop.model.vo.ShopInfoVO;
import com.youzan.wecom.helper.api.corp.manage.corp.dto.response.CorpCreateRespDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.shop.CreateWxdRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;


/**
 * @author wuwu
 * @date 2021/7/8 11:05 AM
 */
public interface CreateShopService {
    PlainResult<Long> createNewShop(CreateShopRequest createShopRequest);

    LongServiceResult createWscShop(CreateShopRequest createShopRequest);

    LongServiceResult createRetailShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createWscEduShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createRetailHQNewShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createRetailHQWscNewShop(CreateShopRequest createShopRequest);

    PlainResult<ShopInfoVO> createBeautyShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createEduHQNewShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createEdu40HQShop(CreateShopRequest createShopRequest);

    CommonResult<CorpCreateRespDTO> createQiWeiShop(CreateShopRequest createShopRequest);

    PlainResult<Long> createWxd(CreateShopRequest request);


    }
