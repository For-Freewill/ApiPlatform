package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.Getter;

/**
 * @author hezhulin
 * @date 2021-08-27 18:00
 */
@Getter
public enum ExcuteResult {
    PASSED(1, "通过"),
    FAILED(2,"失败"),
    SKIPPED(3, "跳过");

    private final Integer code;
    private final String desc;

    ExcuteResult(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
