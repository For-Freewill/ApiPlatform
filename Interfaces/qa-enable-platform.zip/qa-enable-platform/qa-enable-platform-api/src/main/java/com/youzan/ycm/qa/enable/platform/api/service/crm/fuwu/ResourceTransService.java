package com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ResourceTransResponseDTO;

/**
 * @Author Jiping.Hu
 * @Description 服务资源流转链路 service
 * @Date 2021-04-06
 **/
public interface ResourceTransService {
    /**
     * 根据店铺id和请求环境查询服务资源流转全链路信息
     * @param kdtId
     * @param env
     * @return
     */
    PlainResult<ResourceTransResponseDTO>  queryByTdKdtId(Long kdtId  , String env);
}
