package com.youzan.ycm.qa.enable.platform.api.request.ycm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @Date 2020/10/28 11:19
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PfOrderDetailPageQueryRequest implements Serializable {
    /**
     * pf_order_detail表pf_order_id
     */
    private Long pfOrderId;
}
