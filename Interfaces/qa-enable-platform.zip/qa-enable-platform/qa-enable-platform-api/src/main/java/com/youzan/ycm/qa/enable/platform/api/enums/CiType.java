package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@AllArgsConstructor
@Getter
public enum CiType {

    NORMAL(0, "普通job"),

    RETRY(1, "重试Job");

    private final Integer code;
    private final String status;

    public static CiType of(Integer code) {
        return Arrays.stream(CiType.values())
                .filter(taskStatus -> Objects.equals(code, taskStatus.getCode()))
                .findFirst()
                .orElse(null);
}
}
