package com.youzan.ycm.qa.enable.platform.api.service.ycm.code;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.code.NewActivationCodeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.code.NewActivationCodeResponse;

/**
 * @Author wulei
 * @Date 2021/01/13 15:03
 */
public interface NewActivationCodeService {
    /**
     * 根据code查询新激活码相关的全部新表
     *
     * @param request
     * @return
     */
    PlainResult<NewActivationCodeResponse> selectCodeDetail(NewActivationCodeRequest request);
}
