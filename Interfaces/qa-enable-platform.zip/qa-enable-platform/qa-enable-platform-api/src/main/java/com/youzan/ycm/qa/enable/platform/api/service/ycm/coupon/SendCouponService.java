package com.youzan.ycm.qa.enable.platform.api.service.ycm.coupon;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.coupon.SendCouponRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.coupon.SendCouponResponse;

import javax.annotation.Resource;

/**
 * Created by baoyan on 2021-04-13.
 */
public interface SendCouponService {

    /**
     * 发放指定优惠券，仅针对旺小店场景，此处写死
     *
     */
    PlainResult<SendCouponResponse> sendCouponForWxd(SendCouponRequest request);

}
