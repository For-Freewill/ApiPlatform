package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author Jiping.Hu
 * @Description  失败处理的枚举
 * @Date
 **/
@AllArgsConstructor
@Getter
public enum FailureCause {
    DATA_ERROR(0, "数据异常"),
    UPSTREAM_CALL_FAILED(2,"上游调用失败"),
    MIDDLEWARE_FAILURE(3,"中间件失败"),
    SCRIPT_UNSTABLE(4,"脚本不稳定"),
    CODE_UPDATE(5,"代码改动需适配脚本"),
    DEPENDENT_APPLICATION_UNLAUNCHED(6,"依赖应用未启动成功"),
    CODE_BUG(7,"代码bug"),
    EXTERNAL_CAUSE(1, "其他");

    private final Integer code;
    private final String desc;

    public static FailureCause of(Integer code) {
        return Arrays.stream(FailureCause.values())
                .filter(taskStatus -> Objects.equals(code, taskStatus.getCode()))
                .findFirst()
                .orElse(null);
                        }
}
