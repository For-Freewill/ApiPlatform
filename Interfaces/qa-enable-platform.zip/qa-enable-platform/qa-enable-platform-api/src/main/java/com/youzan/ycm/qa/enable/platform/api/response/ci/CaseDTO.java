package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author run.xiong
 * @Description 用例DTO
 * @Date 2021-08-19
 **/
@Data
public class CaseDTO implements Serializable {
    /**
     * case ID
     */
    private long id;
    /**
     * case名称
     */
    private String caseName;

    /**
     * case所属测试类
     */
    private String caseBelongClass;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * case作者
     */
    private String caseAuthor;

    /**
     * case路径
     */
    private String caseUrl;
}
