package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.CiJenkinsJobRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CiJenkinsJobDTO;

/**
 * @Author Jiping.Hu
 * @Description jenkins job业务处理类
 * @Date 2021-08-16
 **/
public interface CiJenkinsJobService {

    /**
     * 根据条件查询jenkins job
     * @param pageRequest
     * @return
     */
    PlainResult<PageResult<CiJenkinsJobDTO>> findJenkinsJobByCondition(PageRequest<CiJenkinsJobRequestDTO> pageRequest );

    /**
     * 新增
     * @param ciJenkinsJob
     * @return
     */
    Long insert(CiJenkinsJobBO ciJenkinsJob);

    /**
     * 更新
     * @param ciJenkinsJob
     * @return
     */
    Long update(CiJenkinsJobBO ciJenkinsJob);

    CiJenkinsJobBO queryCiJenkinsJobByJobName(String jobName);
}
