package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.FailureDetailBO;
import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.FailureDetailRequstDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.FailureDetailDTO;

import java.util.Set;

/**
 * @Author Jiping.Hu
 * @Description case失败情况处理
 * @Date 2021-08-09
 **/
public interface FailureDetailService {

    /**
     * 失败处理查询列表
     * @param pageRequest
     * @return
     */
    PlainResult<PageResult<FailureDetailDTO>> findFailureDetailByCondition(PageRequest<FailureDetailRequstDTO> pageRequest);

    /**
     * 失败原因处理
     * @param failureCause
     * @return
     */
    PlainResult<Boolean> updateFailureCase(Long id, Integer failureCause);

    /**
     * 批量修改
     * @param ids
     * @param failureCause
     * @return
     */
    PlainResult<Boolean> batchUpdateFailureCase(String ids, Integer failureCause);


    /**
     * 失败case新增
     * @param failureDetailBO
     * @return
     */
    Long insert(FailureDetailBO failureDetailBO);

    /**
     * 失败重试
     * @param ids
     * @return
     */
    PlainResult<Boolean> failureReTry(Set<Long> ids, SessionUser user);
}
