package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author hezhulin
 * @date 2021-08-24 15:12
 */
@Data
public class SuiteStartProcessRequestDTO implements Serializable {

//    /**
//     * job固定名字
//     */
//    private String JobName;

    /**
     * job的具体某次执行的url
     */
    private String jobBuildUrl;

    /**
     * job测试的sc
     */
    private String sc;

    /**
     * 执行的测试套件中配置的suiteName
     */
    private String suiteName;

    /**
     * 是否是重试job
     */
    private Boolean isReferJob;

    /**
     * 重试job的情况下才有意义
     * 触发本次重试job的原jobIds
     */
    private List<Long> sourceJobs;

}
