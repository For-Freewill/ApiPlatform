package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@Data
public class FailureHandleRequestDTO {
    Long caseId;
    Integer failureCause;
    String caseIds;
}
