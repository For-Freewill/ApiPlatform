package com.youzan.ycm.qa.enable.platform.api.response.yzcoin;

import lombok.Data;

/**
 * @author leifeiyun
 * @date 2022/1/12
 **/
@Data
public class YzCoinRep {
    Long yzCoinBalance;
    String message;
}
