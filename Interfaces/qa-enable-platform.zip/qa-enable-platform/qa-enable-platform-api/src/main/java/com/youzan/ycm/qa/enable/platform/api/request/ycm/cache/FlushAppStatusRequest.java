/*
package com.youzan.ycm.qa.enable.platform.api.request.ycm.cache;

import lombok.Data;

import java.io.Serializable;

*/
/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-04-29 14:42
 **//*

@Data
public class FlushAppStatusRequest implements Serializable {

    */
/**
     * 店铺id
     *//*

    private String kdtId;

    */
/**
     * 应用id,  不传则全量清除该商家服务期缓存
     *
     *//*

    private String appId;
}
*/
