package com.youzan.ycm.qa.enable.platform.api.bo.crm.ci;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 用例执行详情
 *
 * @author hujiping
 * @email hujiping@youzan.com
 * @date 2021-08-23 11:52:02
 */
@Data
public class ExcuteDetailBO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**jenkinsjob id*/
	private Long jobId;

	/**关联用例id*/
	private Long caseId;

	/**执行结果*/
	private Integer excuteResult;

	/**执行时间*/
//	private String excuteDate;

	/**执行耗时*/
	private String excuteCost;

	/**执行jenkins*/
	private String excuteJenkins;

	/**错误信息*/
	private String errorDetail;

	/**执行环境*/
	private String env;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
