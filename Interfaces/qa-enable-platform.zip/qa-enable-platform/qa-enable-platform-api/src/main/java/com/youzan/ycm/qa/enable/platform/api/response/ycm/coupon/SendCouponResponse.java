package com.youzan.ycm.qa.enable.platform.api.response.ycm.coupon;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by baoyan on 2021-04-13.
 */
@Data
public class SendCouponResponse implements Serializable {
    private static final long serialVersionUID = -5292665560986031575L;

    /**
     * 发放结果
     */
    private Boolean sendResult;

    /**
     * 发放总数量
     */
    private Long sendCount;

}
