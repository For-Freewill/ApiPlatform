package com.youzan.ycm.qa.enable.platform.api.request.ycm.gift;

import lombok.Data;

import java.io.Serializable;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:23
 **/
@Data
public class QueryCouponAssetRequest implements Serializable {

    /**
     * 店铺id
     */
    private String kdtId;

    /**
     * 优惠券状态
     *     待领取：WAIT_RECEIVE ;  已领取：RECEIVED ;  已使用：USED ;  已回收：RECYCLED ; 已过期：EXPIRED
     */
    private String state;

    /**
     * 页码
     */
    private int page = 1;

    /**
     * 每页大小
     */
    private int pageSize = 10;
}
