package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @Date 2020/10/28 11:19
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnablePageQueryRequest implements Serializable {
    /**
     * 当前页码
     */
    private Integer current;
    /**
     * 每页显示条数
     */
    private Integer size;
    /**
     * 数据总条数
     */
    private Long total;
}
