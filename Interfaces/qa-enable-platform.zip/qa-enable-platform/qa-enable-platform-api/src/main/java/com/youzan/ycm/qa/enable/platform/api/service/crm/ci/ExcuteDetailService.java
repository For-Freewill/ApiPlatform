package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.ExcuteDetailBO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.ExcuteDetailByAppRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.ExcuteDetailByDataRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailByAppDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailByDateDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailDTO;

import java.util.List;

/**
 * @author hezhulin
 * @date 2021-08-17 11:46
 * case执行情况处理
 */
public interface ExcuteDetailService {

    //新增case执行记录（DB数据持久化）
    Long insertExcuteDetail (ExcuteDetailDTO excuteDetailDTO);

    //通过主键查询case执行记录
    ExcuteDetailBO queryExcuteDetailByID (Long id);

    //通过caseId查询case执行记录
    List<ExcuteDetailBO> queryExcuteDetailByCaseId (Long id);

    // 根据时间查找执行结果
    PlainResult<List<ExcuteDetailByDateDTO>> queryExcuteDetailByDate(ExcuteDetailByDataRequestDTO excuteDetailByDataRequestDTO);

    //根据jobid查询关联的所有case执行记录
    List<ExcuteDetailDTO> queryExcuteDetailByJobId (Long jobId);

    // 根据应用查找指定时间内的执行详情
    PlainResult<List<ExcuteDetailByAppDTO>> queryExcuteDetailByApp(PageRequest<ExcuteDetailByAppRequestDTO> excuteDetailByAppRequestDTO);


}
