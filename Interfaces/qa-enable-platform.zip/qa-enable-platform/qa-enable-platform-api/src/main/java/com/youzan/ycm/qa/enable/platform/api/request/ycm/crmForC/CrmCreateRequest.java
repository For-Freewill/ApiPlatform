package com.youzan.ycm.qa.enable.platform.api.request.ycm.crmForC;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2021/8/26
 **/
@Data
public class CrmCreateRequest implements Serializable {
    /**
     * 店铺id
     */
    private String kdtId;
    /**
     * crm商品（crm，crm-门店）
     */
    private String crmGoods;
    /**
     * 门店数量
     */
    private Integer storeCount;
}
