package com.youzan.ycm.qa.enable.platform.api.service.ycm.crmForC;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmForC.CrmCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;

/**
 * @author leifeiyun
 * @date 2021/8/26
 **/

public interface CreateCrmService {

    PlainResult<CreateOfflineOrderRep> CreateOfflineOrderV2(CrmCreateRequest crmCreateRequest);

}
