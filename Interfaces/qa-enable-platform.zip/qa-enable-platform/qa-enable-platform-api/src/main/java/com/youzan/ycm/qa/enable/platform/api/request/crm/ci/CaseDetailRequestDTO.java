package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

/**
 * @Author run.xiong
 * @Description 用例请求dto
 * @Date 2021/8/19
 */
@Data
public class CaseDetailRequestDTO {
    /**
     * case名称
     */
    private String caseName;

    /**
     * case所属测试类
     */
    private String caseBelongClass;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * case作者
     */
    private String caseAuthor;

}
