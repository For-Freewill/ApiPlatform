package com.youzan.ycm.qa.enable.platform.api.request.ycm.yunFee;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author wulei
 * @date 2021/1/20 15:02
 */
@Data
public class FcFeeRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * kdtId
     */
    private String kdtId;

    /**
     * tables
     */
    private List<String> tables;
}