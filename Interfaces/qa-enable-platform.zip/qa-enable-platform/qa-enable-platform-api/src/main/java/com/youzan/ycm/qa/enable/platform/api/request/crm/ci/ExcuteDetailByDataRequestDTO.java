package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

import java.util.Date;

/**
 * @Author run.xiong
 * @Description 根据执行时间获取应用的执行详情 请求体
 * @Date 2021/8/19
 */
@Data
public class ExcuteDetailByDataRequestDTO {
    /**
     * 开始时间
     */
    private Date startDate;

    /**
     * 结束时间
     */
    private Date endDate;

}
