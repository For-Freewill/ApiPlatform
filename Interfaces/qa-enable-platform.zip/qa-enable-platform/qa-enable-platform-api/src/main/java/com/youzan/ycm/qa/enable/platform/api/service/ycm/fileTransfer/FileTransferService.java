package com.youzan.ycm.qa.enable.platform.api.service.ycm.fileTransfer;

import com.youzan.api.common.response.PlainResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * @author leifeiyun
 * @date 2021/9/14
 **/
public  interface FileTransferService {
    Map<String,List> getDiffInterFaceAndMethod(String string1,String string2);
    List<String>  getInterFaceAndMethod(String string);
    public String transferFileToDest(MultipartFile file);

}
