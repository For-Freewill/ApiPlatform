package com.youzan.ycm.qa.enable.platform.api.service.enable;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.enable.BatchCreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableCreateShopResponse;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;

/**
 * @author wuwu
 * @date 2021/2/6 7:34 PM
 */

public interface EnableNewShopPoolService {

    //PlainResult<EnableCreateShopResponse> createAccountPoolNewShop(CreateShopRequest createShopRequest);


    /**
     * 创建微商城单店店铺
     * @param
     * @return
     */
    PlainResult<Boolean> createAccountPoolNewShop(CreateShopRequest createShopRequest);
        /**
         * 获取新店铺
         * @return
         */
    PlainResult<EnableNewKdtIdResponse> getNewKdtId(String prodCode);

    PlainResult<EnableNewKdtIdResponse> concurrentGetNewKdtId(String prodCode);


    void batchCreteWscShop(BatchCreateShopRequest request);

    //Boolean deleteShopData();
}
