package com.youzan.ycm.qa.enable.platform.api.request.crm.hotline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 描述:
 *
 * @author beidou
 * @create 2021-01-21
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateHotlineRequest {

    /**
     * 坐席号
     */
    private String seatNo;

    /**
     * 手机号
     */
    private String mobile;

}
