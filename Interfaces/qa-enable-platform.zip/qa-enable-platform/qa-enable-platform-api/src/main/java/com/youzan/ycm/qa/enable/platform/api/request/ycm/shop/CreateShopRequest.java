package com.youzan.ycm.qa.enable.platform.api.request.ycm.shop;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wuwu
 * @date 2021/7/10 1:18 PM
 */
@Data
public class CreateShopRequest implements Serializable {

    /**
     * 手机号（必传）
     */
    private String phoneNo;

    /**
     * 店铺名称（可不传）
     */
    private String shopName;

    /**
     *
     * @see: com.youzan.ycm.qa.enable.platform.biz.enums.ShopTypeEnums
     */
    private String shopType;

    /**
     * 充值的金额
     */
    private int money;
}
