package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 角色依赖的变量
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
@Data
public class FwRoleDepVarDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**店铺ID*/
	private Long kdtId;

	/**店铺标签*/
	private String tags;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
