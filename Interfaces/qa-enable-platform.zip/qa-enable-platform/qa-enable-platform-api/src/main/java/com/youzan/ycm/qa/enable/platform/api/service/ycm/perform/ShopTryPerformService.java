package com.youzan.ycm.qa.enable.platform.api.service.ycm.perform;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.ResetShopTryTimeRequest;

/**
 * @author wuwu
 * @date 2021/6/13 6:06 PM
 */
public interface ShopTryPerformService {

    /**
     * 重置店铺试用期时间，将试用期的结束时间往前或往后移动，但试用期开始时间不能晚于当前时间
     * @param request
     * @return
     */
    PlainResult<Boolean> resetShopTryTime(ResetShopTryTimeRequest request);
}
