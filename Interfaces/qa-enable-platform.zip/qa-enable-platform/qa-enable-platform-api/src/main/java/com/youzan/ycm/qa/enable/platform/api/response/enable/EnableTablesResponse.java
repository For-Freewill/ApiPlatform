package com.youzan.ycm.qa.enable.platform.api.response.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2020/11/19 20:02
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableTablesResponse implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * 返回的表数据信息
     */
    private List<Map<String, Object>> details;
}