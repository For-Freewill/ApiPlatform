package com.youzan.ycm.qa.enable.platform.api.enums;

import com.youzan.ycm.qa.enable.platform.api.exception.IErrorCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author wulei
 * @Date 2020/10/27 18:13
 */
@AllArgsConstructor
@Getter
public enum EnumCode implements IErrorCode {

    /**
     * 结果码
     */
    SUCCESS(200, "操作成功"),
    FAILURE(500, "后端返回异常"),
    BAD_REQUEST(405, "参数错误"),
    AUTHORIZATION_REQUIRED(401, "未登录"),
    SESSION_EXPIRED(406, "登录信息失效"),
    DELETE_ERROR(50001, "删除失败"),
    SYSTEM_ERROR(999, "后台系统错误");

    /**
     * 信息码
     */
    private Integer code;

    /**
     * 描述信息
     */
    private String message;

    @Override
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String getMsg() {
        return message;
    }

    public void setMsg(String msg) {
        this.message = message;
    }
}
