package com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2022/2/10
 **/
@Data
public class ShopUpgradeRep implements Serializable {
    private static final long serialVersionUID = 4860209885387305389L;

    /**
     * 升级流程id
     */
    private String workflowId;
    private String msg;
}
