package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-17 15:31
 */
@Data
public class CaseWithExecutionSuccessRate {

    /**
     * case名
     */
    private String caseName;

    /**
     * case路径
     */
    private String caseUrl;

    /**
     * case所属应用
     */
    private String caseBelongApp;

    /**
     * 执行成功率
     */
    private double executionSuccessRate;

}
