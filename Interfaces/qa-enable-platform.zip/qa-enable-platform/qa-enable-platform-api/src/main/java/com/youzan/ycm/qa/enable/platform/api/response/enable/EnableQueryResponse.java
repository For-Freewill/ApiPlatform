package com.youzan.ycm.qa.enable.platform.api.response.enable;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/17 10:59
 */
@Data
public class EnableQueryResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 方案ID
     */
    private Long id;

    /**
     * 保存的方案名称
     */
    private String recordName;

    /**
     * 方案涉及的表列表
     */
    private List<String> tableList;

    /**
     * biz后台操作人ID
     */
    private String operatorId;

    /**
     * biz后台操作人类型
     */
    private String operatorType;

    /**
     * biz后台操作人名称
     */
    private String operatorName;
}
