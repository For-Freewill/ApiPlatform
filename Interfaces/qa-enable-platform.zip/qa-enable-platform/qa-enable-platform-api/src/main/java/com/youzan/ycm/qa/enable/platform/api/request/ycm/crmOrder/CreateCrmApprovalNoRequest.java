package com.youzan.ycm.qa.enable.platform.api.request.ycm.crmOrder;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by baoyan on 2021-04-25.
 */
@Data
public class CreateCrmApprovalNoRequest implements Serializable {

    private Long kdtId;

    /**
     * 开通类型 3-立即开通 4-暂不开通
     */
    private Integer openType;

    /**
     * 手机号
     */
    private String mobile;
}
