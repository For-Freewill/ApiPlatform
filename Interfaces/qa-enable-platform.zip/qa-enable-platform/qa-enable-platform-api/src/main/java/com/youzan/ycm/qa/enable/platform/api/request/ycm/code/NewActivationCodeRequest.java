package com.youzan.ycm.qa.enable.platform.api.request.ycm.code;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author wulei
 * @Date 2021/01/13 15:03
 */
@Data
public class NewActivationCodeRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * td_order 表Id：66开头
     */
    private String code;

    /**
     * tables
     */
    private List<String> tables;
}
