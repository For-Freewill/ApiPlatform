package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wuwu
 * @date 2022/2/14 14:45 PM
 */
@Data
public class BatchCreateShopRequest implements Serializable {

    /**
     * 手机号（必传）
     */
    private String phoneNo;

    /**
     * 店铺名称（可不传）
     */
    private String shopName;

    /**
     *
     * @see: com.youzan.ycm.qa.enable.platform.biz.enums.ShopTypeEnums
     */
    private String shopType;

    /**
     * 充值的金额
     */
    private int money;

    /**
     * 批量创建店铺的数量
     */
    private int num;
}
