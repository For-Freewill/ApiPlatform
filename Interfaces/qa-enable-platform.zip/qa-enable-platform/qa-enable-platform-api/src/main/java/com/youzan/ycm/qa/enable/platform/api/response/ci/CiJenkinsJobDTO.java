package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author Jiping.Hu
 * @Description jenkins job列表
 * @Date 2021-08-16
 **/
@Data
public class CiJenkinsJobDTO implements Serializable {

    /**
     * job名称
     */
    private String jobName;

    /**
     * job状态
     */
    private String jobState;

    /**
     * job类型(0：普通job，1：重试job)
     */
    private String jobType;

    /**
     * 重试job
     */
    private Long referJobId;

    /**
     * job执行环境
     */
    private String jobEnv;

    /**
     * 报告地址
     */
    private String reportUrl;

    /**
     * job分组
     */
    private String jobGroup;

    private Long jobId;

    /**
     * job耗时
     */
    private String jobCost;

    /**
     * 总case
     */
    private Integer totalCase;

    /**
     * 失败case
     */
    private Integer failureTotalCase;

    /**
     * 跳过case
     */
    private Integer skipTotalCase;

    /**
     * 成功case
     */
    private Integer successTotalCase;

    /**
     * 处理进度
     */
    private String handleProcess;

    /**
     * 开始时间
     */
    private String createTime;
}
