package com.youzan.ycm.qa.enable.platform.api.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2020/11/19 16:50
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableTablesDetailUpdateRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;
    /**
     * 商业化赋能表名称
     */
    private Long id;
    /**
     * 商业化赋能表名称
     */
    private String tableName;

    /**
     * 商业化赋能表描述
     */
    private String tableDesc;

    /**
     * 商业化赋能表分类
     */
    private String tableType;

    /**
     * 商业化赋能表其他信息
     */
    private String ext;
}
