package com.youzan.ycm.qa.enable.platform.api.request.ycm.onlineTrade;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by baoyan on 11/30/21.
 */
@Data
public class CreateOnlineOrderRequest implements Serializable {

    /**
     * 店铺id
     */
    private Long kdtId;

    /**
     * sku
     */
    private Integer itemId;

    /**
     * 年限
     */
    private Integer quantity;

}
