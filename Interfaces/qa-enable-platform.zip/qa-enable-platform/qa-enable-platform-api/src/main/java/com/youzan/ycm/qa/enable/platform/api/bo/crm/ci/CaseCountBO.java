package com.youzan.ycm.qa.enable.platform.api.bo.crm.ci;

import lombok.Data;

/**
 * @Author run.xiong
 * @Description
 * @Date
 **/
@Data
public class CaseCountBO {
    /**
     * case总数
     */
    int totalCount;
    /**
     * case所属应用
     */
    private String caseBelongApp;
}
