package com.youzan.ycm.qa.enable.platform.api.response.ycm.yunFee;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * @author wulei
 * @date 2021/1/20 15:05
 */
@Data
public class FcFeeResponse implements Serializable {
    private static final long serialVersionUID = -5292665560986031575L;

    /**
     * total 返回的记录数
     */
    private Long total;

    /**
     * 返回的表数据信息
     */
    private Map<String, Object> details;
}