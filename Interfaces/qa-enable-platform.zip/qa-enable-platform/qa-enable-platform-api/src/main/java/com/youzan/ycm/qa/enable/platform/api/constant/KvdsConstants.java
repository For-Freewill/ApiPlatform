package com.youzan.ycm.qa.enable.platform.api.constant;

/**
 * @Description kvds缓存key
 * @Author yanzhiqi
 * @Date 2019/11/12 17:03
 **/
public interface KvdsConstants {

    /*################公共配置################*/
    /**ycm-perform应用的kvds所有的key的前缀*/
    String YCM_PERFORM_KV_NAMESPACE = "youzan:ycm-perform_kvds:";

    /**服务期相关key*/
    /**缓存超时时间*/
    Integer PF_ORDER_STATUS_KEY_TTL = 24 * 60 * 60;
    /**order_status表的key*/
    String PF_ORDER_STATUS_KEY = "youzan:ycm-perform_kvds:pfStatusDetail:applyYcmId:%s:applyYcmType:%s:appId:%s";
    /**店铺有效服务期key*/
    String PF_VALID_STATUS_KEY = "pfStatus:applyKdtId:%s:appId:%s";
    /**履约单和方案id的关系*/
    String PF_SCHEME_ORDER_RELATION_KEY = "relation:pfOrderId:%s";

    /** 库存商品延时任务同步锁 */
    String PF_ORDER_DELAY_ACTIVE_JOB_EXECUTE_LOCK = "delayActiveJobExecute:pfOrderId:%s";

    /** 删除店铺shop_prod_relation缓存，目前只有改了试用期和店铺状态能用到 */
    String SHOP_PROD_RELATION = "youzan:shop-prod_prod_kid2relation:%s";
}
