package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.Paginator;
import com.youzan.api.common.response.PaginatorResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SingleOwnerCaseExcuteRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseExcuteSummaryDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseWithAverageExecutionTime;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseWithExecutionSuccessRate;

import java.util.Date;

/**
 * @author hezhulin
 * @date 2021-08-17 14:49
 * 责任人维度执行情况统计
 */
public interface CaseExcuteStatisticsByStaffService {
    /**
     * 人维度的用例执行情况汇总列表，限制执行时间的区间范围
     * @param startDate 统计的用例的执行时间不早于该时间
     * @param endDate 统计的用例的执行时间不晚于该时间
     * @return
     */
    PaginatorResult<CaseExcuteSummaryDTO> caseExcuteSummary(Date startDate, Date endDate, Paginator paginator);

    /**
     * 执行成功率<99%的用例列表 99%的成功率代码里变量配置
     * @param singleOwnerCaseExcuteRequestDTO
     * @return
     */
    PaginatorResult<CaseWithExecutionSuccessRate> executionSuccessRateLessThan99PercentCaseList(SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO);

    /**
     * 平均每次执行时长>2s的用例列表 2s的平均执行时间代码里变量配置
     * @param singleOwnerCaseExcuteRequestDTO
     * @return
     */
    PaginatorResult<CaseWithAverageExecutionTime> averageExecutionTimeGreaterThan2SecondCaseList(SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO);

}
