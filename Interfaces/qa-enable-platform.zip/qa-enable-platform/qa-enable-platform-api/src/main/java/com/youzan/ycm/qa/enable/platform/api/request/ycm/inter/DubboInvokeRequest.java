package com.youzan.ycm.qa.enable.platform.api.request.ycm.inter;

import lombok.Data;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-24 20:29
 **/
@Data
public class DubboInvokeRequest extends BaseInvokeRequest{

    /**
     * 接口名
     */
    private String interfaceName;

    /**
     * 方法名
     */
    private String methodName;

    /**
     * 版本号
     */
    private String version;

    /**
     * 参数类型
     */
    private List<String> parameterTypes;

    /**
     * 参数
     */
    private List<Object> arguments;
}
