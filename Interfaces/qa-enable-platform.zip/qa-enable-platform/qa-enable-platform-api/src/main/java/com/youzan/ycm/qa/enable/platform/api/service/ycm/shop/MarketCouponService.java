/*
package com.youzan.ycm.qa.enable.platform.api.service.ycm.shop;

*/
/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:11
 **//*

public interface MarketCouponService {
    */
/**
     * 清理某笔订单下所有的营销券数据，根据活动ID来操作
     *//*

    public void deleteMarketCouponData(Long id);
}
*/
