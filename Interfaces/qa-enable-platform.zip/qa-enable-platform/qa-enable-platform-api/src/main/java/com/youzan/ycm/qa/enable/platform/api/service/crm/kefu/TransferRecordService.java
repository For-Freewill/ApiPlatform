package com.youzan.ycm.qa.enable.platform.api.service.crm.kefu;

import com.youzan.api.common.response.PlainBoolResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.kefu.TransferRecordRequest;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-09 21:03
 */
public interface TransferRecordService {
    PlainResult<Boolean> transferRecordToServant(TransferRecordRequest transferRecordRequest);
}
