package com.youzan.ycm.qa.enable.platform.api.service.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:21
 **/
//public interface CouponAssetRemoteService {
//
//    /**
//     * 查询券
//     */
//    PlainResult<PageResponse<CouponAssetDTO>> queryCouponAssetListByKdtId(QueryCouponAssetRequest request);
//
//}
