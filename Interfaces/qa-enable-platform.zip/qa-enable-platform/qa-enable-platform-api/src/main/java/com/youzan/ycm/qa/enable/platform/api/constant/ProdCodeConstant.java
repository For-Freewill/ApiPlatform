package com.youzan.ycm.qa.enable.platform.api.constant;

/**
 * @author wuwu
 * @date 2021/6/13 10:41 PM
 */
public interface ProdCodeConstant {
    /**
     * 微商城
     */
    String SHOP_PROD_WSC = "wsc";

    /**
     * 微商城连锁总部
     */
    String WSC_CHAIN_SUB_SHOP_PROD = "wsc_chain_sub_shop_prod";

    /**
     * 教育连锁总部
     */
    String EDU_CHAIN_SUB_SHOP_PROD = "edu_chain_sub_shop_prod";

    /**
     * 微商城连锁总部
     */
    String WSC_CHAIN_HQ_PROD = "wsc_chain_hq_prod";

    /**
     * 教育连锁
     */
    String EDU_CHAIN_HQ_PROD = "edu_chain_hq_prod";

    /**
     * 零售
     */
    String SHOP_PROD_RETAIL = "retail";

    /**
     * 零售相关
     */
    String RETAIL_CHAIN_HQ_PROD= "retail_chain_hq_prod";

    String  RETAIL_CHAIN_OFFLINE_PROD= "retail_chain_offline_prod";

    String  STOCK_PROD= "stock_prod";

    String  RETAIL_CHAIN_PARTNER_PROD = "retail_chain_partner_prod";

    String  RETAIL_CHAIN_FENXIAO_SUPPLIER_PROD= "retail_chain_fenxiao_supplier_prod";

    /**
     * 美业
     */
    String SHOP_PROD_BEAUTY = "beauty";

    /**
     * 试用期
     */
    String SHOP_PROD_LIFE_CYCLE_TRY = "try";

    /**
     * 企业微信助手
     */
    String ENTERPRISE_WECHAT_ASSISTANT = "wecom_helper_prod";
}
