package com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-05-18 14:23
 */
@Data
public class ShopRoleAssignDTO {

    private Long kdtId;

    /**
     * 店铺角色名称
     */
    private String shopRole;

    /**
     * 目标角色池类型 TERRITORY:公海, PROVIDER:渠道商, USER:员工
     */
    private String srcPoolType;

    /**
     * 角色池名称 目标角色池类型=TERRITORY:公海 的时候生效
     */
    private String poolName;

    /**
     * 渠道商id 目标角色池类型=PROVIDER:渠道商 的时候生效
     */
    private Long providerId;

    /**
     * 人员的userId 目标角色池类型=USER:员工 的时候生效
     */
    private Long userId;

}
