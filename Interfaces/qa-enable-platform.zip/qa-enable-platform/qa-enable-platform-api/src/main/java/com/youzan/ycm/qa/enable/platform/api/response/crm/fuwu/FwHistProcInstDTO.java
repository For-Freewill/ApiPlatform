package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 * 历史服务流程实例
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:50
 */
@Data
public class FwHistProcInstDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**流程实例ID*/
	private Long procInstId;

	/**店铺ID*/
	private Long kdtId;

	/**流程模版*/
	private String procTemplate;

	/**流程状态*/
	private Integer state;

	/**流程开启时间*/
	private Date startTime;

	/**流程关闭时间*/
	private Date endTime;

	/**流程开启时的变量*/
	private String startVariable;

	/**流程关闭时的变量*/
	private String endVariable;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
