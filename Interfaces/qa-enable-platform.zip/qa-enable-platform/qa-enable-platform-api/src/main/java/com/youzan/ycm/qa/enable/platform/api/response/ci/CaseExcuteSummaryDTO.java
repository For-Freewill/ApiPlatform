package com.youzan.ycm.qa.enable.platform.api.response.ci;

import lombok.Data;

/**
 * @author hezhulin
 * @date 2021-08-17 15:14
 */
@Data
public class CaseExcuteSummaryDTO {
    /**
     * 责任人
     */
    private String owner;

    /**
     * 总case
     */
    private Integer totalCase;

    /**
     * 执行成功率<99%的用例个数
     */
    private Integer executionSuccessRateLessThan99PercentTotalCase;

    /**
     * 平均执行时长>2s的用例个数
     */
    private Integer averageExecutionTimeGreaterThan2SecondTotalCase;

}
