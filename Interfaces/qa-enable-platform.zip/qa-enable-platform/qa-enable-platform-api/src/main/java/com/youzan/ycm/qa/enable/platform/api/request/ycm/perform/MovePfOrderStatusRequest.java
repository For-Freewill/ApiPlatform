package com.youzan.ycm.qa.enable.platform.api.request.ycm.perform;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wuwu
 * @date 2021/12/6 7:20 PM
 */
@Data
public class MovePfOrderStatusRequest implements Serializable {
    /**
     * 店铺ID
     */
    private Long kdtId;

    /**
     * 需要移动服务期的插件/软件的appId
     */
    private Long appId;

    /**
     * 插件过期时间
     */
    private Date expireTime;

    /**
     * sc
     */
    private String serviceChain;


}
