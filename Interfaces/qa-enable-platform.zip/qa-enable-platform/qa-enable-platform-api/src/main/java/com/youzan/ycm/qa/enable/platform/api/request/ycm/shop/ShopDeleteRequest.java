package com.youzan.ycm.qa.enable.platform.api.request.ycm.shop;

import lombok.Data;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:06
 **/
@Data
public class ShopDeleteRequest {

    /**
     * 店铺ID
     */
    private Long kdtId;
}
