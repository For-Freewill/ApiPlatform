package com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu;

import lombok.Data;

/**
 * @Author Jiping.Hu
 * @Description 根据店铺查询服务信息  DTO
 * @Date
 **/
@Data
public class ResourceTransDTO {

    private Long kdtId;

    private String env;

}

