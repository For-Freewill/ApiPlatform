package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResourceTransResponseDTO {
    List<ShopDTO> shopDTOList;
    List<ShopAttributeDataDTO> shopAttributeDataDTOList;
    List<OrderBelongingDTO> orderBelongingDTOList;
    List<FwShopRoleStateHistDTO> fwShopRoleStateHistDTOList;
    List<FwShopRolePropertyDTO> fwShopRolePropertyDTOList;
    List<FwShopRoleDTO> fwShopRoleDTOList;
    List<FwShoproleBindingDTO>  fwShoproleBindingDTOList;
    List<FwShoproleBindingHistoryDTO> fwShoproleBindingHistoryDTOList;
    List<FwShopProductAckDTO> fwShopProductAckDTOList;
    List<FwRoleDepVarDTO> fwRoleDepVarDTOList;
    List<FwProcRoleDTO> fwProcRoleDTOList;
    List<FwProcInstDTO> fwProcInstDTOList;
    List<FwHistProcInstDTO> fwHistProcInstDTOList;
    List<FwHistProcRoleDTO> fwHistProcRoleDTOList;
    List<FwProcDepVarDTO> fwProcDepVarDTOList;
    List<FwProcDepVarSnapshotDTO> fwProcDepVarSnapshotDTOList;
    List<FwFuwuBelongAssignDTO> fwFuwuBelongAssignDTOList;
    List<CrmShopProductKdtIndexDTO>  crmShopProductKdtIndexDTOList;
    List<CrmShopProductActiveDTO>  crmShopProductActiveDTOList;
    List<CrmShopProductServiceTimeDTO> crmShopProductServiceTimeDTOList;
    List<CrmShopProductActiveHistoryDTO> crmShopProductActiveHistoryDTOList;
}
