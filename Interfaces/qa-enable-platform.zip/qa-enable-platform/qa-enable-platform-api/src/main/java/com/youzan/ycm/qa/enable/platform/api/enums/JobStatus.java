package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author Jiping.Hu
 * @Description
 * @Date
 **/
@AllArgsConstructor
@Getter
public enum JobStatus {
    START(0, "执行中"),
    SUCCESS(1, "执行成功"),
    FAILURE(2, "执行失败");

    private final Integer code;
    private final String desc;

    public static JobStatus of(Integer code) {
        return Arrays.stream(JobStatus.values())
                .filter(taskStatus -> Objects.equals(code, taskStatus.getCode()))
                .findFirst()
                .orElse(null);
    }
}
