package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

import java.util.List;

/**
 * @Author Jiping.Hu
 * @Description 失败处理列表查询请求dto
 * @Date
 **/
@Data
public class FailureDetailRequstDTO {
    /**
     * 责任人
     */
    private String owner;

    /**
     * 所属应用
     */
    private String application;

    /**
     * 执行环境
     */
    private String env;

    /**
     * 执行的job
     */
    private List<Long> jobIds;

    /**
     * job 分组
     */
    private Integer jobGroup;

}
