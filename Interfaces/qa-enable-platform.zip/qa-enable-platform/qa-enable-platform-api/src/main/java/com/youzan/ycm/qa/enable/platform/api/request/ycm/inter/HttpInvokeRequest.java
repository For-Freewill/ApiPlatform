package com.youzan.ycm.qa.enable.platform.api.request.ycm.inter;

import com.youzan.ycm.qa.enable.platform.api.enums.HttpInvokeWayEnum;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-24 20:29
 **/
@Data
public class HttpInvokeRequest extends BaseInvokeRequest{

    /**
     * 请求方式
     */
    private HttpInvokeWayEnum httpInvokeWayEnum;

    /**
     * 请求地址
     */
    private String url;

    /**
     * 请求参数
     */
    private Map<String, String> parameters;






}
