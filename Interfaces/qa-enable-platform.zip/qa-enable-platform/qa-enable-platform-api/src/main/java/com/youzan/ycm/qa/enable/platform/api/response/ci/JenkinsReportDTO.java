package com.youzan.ycm.qa.enable.platform.api.response.ci;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author run.xiong
 * @Description 获取jenlins执行结果DTO
 * @Date 2021-08-19
 **/
@Data
public class JenkinsReportDTO {
    /**
     * 运行总时长
     */
    private float duration;
    /**
     * 总用例数
     */
    private long count;
    /**
     * 失败用例数
     */
    private long failCount;
    /**
     * 成功用例数
     */
    private long passCount;
    /**
     * 跳过用例数
     */
    private long skipCount;
    /**
     * 执行结果，true成功 false失败
     */
    private boolean status;
    /**
     * 执行结果详情
     */
    private ArrayList<Suites> suites;

    @Data
    public static class Suites implements Serializable {
        /**
         * 类名
         */
        private String className;
        /**
         * 执行时长
         */
        private float duration;
        /**
         * 执行日志
         */
        private String log;
        /**
         * 方法名，用例名
         */
        private String name;
        /**
         * 状态，PASSED成功，SKIPPED跳过，REGRESSION与FIXED为失败
         * --更新
         * PASSED 成功（和上一次构建时相同用例比较，上次是成功的，这次也是成功的），
         * SKIPPED 忽略（场景：失败自动重试的情况，因为失败被重试的case状态就是SKIPPED，可以当成成功？），//todo 待确定
         * FIXED 成功（和上一次构建时相同用例比较，上次是失败的，这次是成功的），
         * REGRESSION 失败（和上一次构建时相同用例比较，上次是成功的，这次是失败的），
         * FAILED 失败（和上一次构建时相同用例比较，上次是失败的，这次也是失败的）
         */
        private String status;
        /**
         * 执行链接
         */
        private String url;
    }



}
