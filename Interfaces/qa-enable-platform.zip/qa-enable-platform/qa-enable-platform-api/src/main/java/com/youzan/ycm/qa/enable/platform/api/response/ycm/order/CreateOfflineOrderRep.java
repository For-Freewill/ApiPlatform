package com.youzan.ycm.qa.enable.platform.api.response.ycm.order;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2021/4/26
 **/
@Data
public class CreateOfflineOrderRep implements Serializable {
    /**
     * 下单失败店铺
     */
    private List<Long> failedKdtIds;
    private String createContent;

}
