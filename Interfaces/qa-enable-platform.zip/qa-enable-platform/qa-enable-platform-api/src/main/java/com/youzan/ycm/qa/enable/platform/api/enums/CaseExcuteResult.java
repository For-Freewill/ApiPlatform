package com.youzan.ycm.qa.enable.platform.api.enums;

import lombok.Data;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author hezhulin
 * @date 2021-08-25 15:00
 */
@Getter
public enum CaseExcuteResult {
    PASSED(1, "通过"),
    FIXED(1,"通过"),
    SKIPPED(1, "跳过"),//todo 待确定
    REGRESSION(2,"失败"),
    FAILED(2,"失败");

    private final Integer code;
    private final String desc;

    CaseExcuteResult (Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
