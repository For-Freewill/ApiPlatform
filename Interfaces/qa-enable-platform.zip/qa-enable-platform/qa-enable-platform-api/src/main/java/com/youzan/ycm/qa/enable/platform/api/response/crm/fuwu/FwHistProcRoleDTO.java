package com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 历史流程角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:18
 */
@Data
public class FwHistProcRoleDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**主键*/
	private Long id;

	/**流程角色ID*/
	private Long procRoleId;

	/**流程实例ID*/
	private Long procInstId;

	/**店铺ID（冗余）*/
	private Long kdtId;

	/**流程模版（冗余）*/
	private String procTemplate;

	/**角色类型*/
	private String roleType;

	/**角色状态*/
	private Integer state;

	/**角色开启时间*/
	private Date startTime;

	/**角色关闭时间*/
	private Date endTime;

	/**角色开启时的变量*/
	private String startVariable;

	/**角色关闭时的变量*/
	private String endVariable;

	/**创建时间*/
	private Date createdAt;

	/**更新时间*/
	private Date updatedAt;

}
