package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CaseCountBO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.CaseDetailRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDetailDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author run.xiong
 * @Description 用例详情业务处理类
 * @Date 2021/8/19
 */
public interface CaseDetailService {
    /**
     * 插入用例
     * @return
     */
    PlainResult<Long> insert(CaseDetailRequestDTO caseDetailRequestDTO);

    /**
     * 删除用例
     */
    PlainResult delete(long id);

    /**
     * 查询
     */
    PlainResult<ArrayList<CaseDTO>> query(String id, String caseName, String caseBelongClass, String caseBelongApp, String caseAuthor, String caseUrl);

    /**
     * 根据id查询用例消息
     */
    PlainResult<CaseDetailDTO> queryById(Long id);

    /**
     * 获取每个应用的用例总数
     */
    PlainResult<List<CaseCountBO>> getCountByApp();

}
