package com.youzan.ycm.qa.enable.platform.api.service.crm.ci;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteFinishProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteStartProcessRequestDTO;

/**
 * @author hezhulin
 * @date 2021-08-24 14:12
 * 测试套件监听后的业务处理逻辑
 */
public interface SuiteListenerService {

    PlainResult<Boolean> suiteStartProcess(SuiteStartProcessRequestDTO suiteStartProcessRequestDTO);

    PlainResult<Boolean>  suiteFinishProcess(SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO);
}
