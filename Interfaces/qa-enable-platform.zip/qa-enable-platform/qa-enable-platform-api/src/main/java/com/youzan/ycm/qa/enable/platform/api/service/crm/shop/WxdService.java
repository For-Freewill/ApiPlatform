package com.youzan.ycm.qa.enable.platform.api.service.crm.shop;
import com.youzan.api.common.response.PlainResult;
import  com.youzan.ycm.qa.enable.platform.api.request.crm.shop.CreateWxdRequest;


/**
 * Created by water on 2021/4/15.
 */
public interface WxdService {

    PlainResult<Long> createWxd(CreateWxdRequest request);

}
