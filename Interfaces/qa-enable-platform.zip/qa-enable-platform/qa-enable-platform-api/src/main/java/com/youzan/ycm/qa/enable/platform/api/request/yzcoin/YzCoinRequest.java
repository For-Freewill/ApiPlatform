package com.youzan.ycm.qa.enable.platform.api.request.yzcoin;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leifeiyun
 * @date 2022/1/12
 **/
@Data
public class YzCoinRequest implements Serializable {
    Long kdtId;
    Long yzCoin=0L;
}
