package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

import java.util.Date;

/**
 * @Author Jiping.Hu
 * @Description jenkins job列表请求入参
 * @Date 2021-08-13
 **/
@Data
public class CiJenkinsJobRequestDTO {
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 执行环境
     */
    private String env;
    /**
     * 分组（商业化/crm）
     */
    private Integer job_group;

    /**
     * 执行状态
     */
    private Integer jobState;
}
