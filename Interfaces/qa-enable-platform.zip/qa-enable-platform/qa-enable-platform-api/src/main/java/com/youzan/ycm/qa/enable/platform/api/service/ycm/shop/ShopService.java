package com.youzan.ycm.qa.enable.platform.api.service.ycm.shop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.coupon.SendCouponResponse;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:11
 **/
public interface ShopService {

    /**
     * 清理店铺下所有数据，kdtid维度，暴力删除
     */
    PlainResult<Boolean> deleteDataByKdtId(Long kdtId);
}
