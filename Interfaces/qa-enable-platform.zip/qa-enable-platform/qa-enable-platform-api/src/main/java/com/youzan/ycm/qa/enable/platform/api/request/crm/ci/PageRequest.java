package com.youzan.ycm.qa.enable.platform.api.request.crm.ci;

import lombok.Data;

@Data
public class PageRequest<T> {

    private T       dto;
    private Integer pageNum = 1;
    private Integer pageSize = 15;


}
