package com.youzan.ycm.qa.enable.platform.api.enums;

import com.youzan.ycm.qa.enable.platform.api.exception.IErrorCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author wulei
 * @Date 2020/10/27 18:13
 */
@AllArgsConstructor
@Getter
public enum ResultCode implements IErrorCode {

    /**
     * 结果码
     */
    SUCCESS(200, "操作成功"),
    FAILURE(500, "后端返回异常"),
    BAD_REQUEST(405, "参数错误"),
    AUTHORIZATION_REQUIRED(401, "未登录"),
    SESSION_EXPIRED(406, "登录信息失效"),
    DELETE_ERROR(50001, "删除失败"),
    CREATED_ERROR(701,"发券单创建失败"),
    SEND_ERROR(702,"优惠券发放失败"),
    SYSTEM_ERROR(999, "后台系统错误"),
    //SAVE_SHOP_ERROR(998,"保存店铺信息错误");
    TICKET_NOEXIST(99,"权益券不存在"),
    TICKET_NOTENOUGH(101,"权益券不足"),
    SHOPROLEPOOL_NOEXIST(601,"角色池不存在"),
    SHOPROLEASSIGN_ERROR(602,"调用底层店铺角色绑定接口绑定失败"),
    CREATE_APPROVALNO_ERROR(703,"审批流创建失败"),
    SAVE_SHOP_ERROR(998,"保存店铺信息错误"),
    CREATE_SHOP_ERROR(1001,"创建店铺失败"),
    NO_PERFORM_ORDER(1002,"没有可移动的服务期"),
    MOVER_ERROR(1003,"移动服务期失败"),
    CONCURRENT_ERROR(1004,"刷新缓存或同步服务期失败"),
    RECHARGE_ERROR(2000,"充值失败"),
    CREATE_ONLINEORDER_ERROR(2001,"创建订单失败"),
    PREPAY_ERROR(2002,"预支付失败"),
    PAY_ERROR(2003,"收银台扣款失败");






    /**
     * 信息码
     */
    private Integer code;

    /**
     * 描述信息
     */
    private String message;

    @Override
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String getMsg() {
        return message;
    }

    public void setMsg(String msg) {
        this.message = message;
    }
}
