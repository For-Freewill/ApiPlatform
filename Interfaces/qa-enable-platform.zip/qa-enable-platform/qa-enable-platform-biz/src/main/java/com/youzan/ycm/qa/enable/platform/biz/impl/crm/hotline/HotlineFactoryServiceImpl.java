package com.youzan.ycm.qa.enable.platform.biz.impl.crm.hotline;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.hotline.CreateHotlineRequest;
import com.youzan.ycm.qa.enable.platform.dependency.crm.hotline.HotlineClient;

import com.youzan.ycm.qa.enable.platform.api.service.crm.hotline.HotlineFactoryService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

/**
 * 描述:
 *
 * @author beidou
 * @create 2021-01-21
 */
@Slf4j
@Service(value = "HotlineFactoryService")
public class HotlineFactoryServiceImpl implements HotlineFactoryService {

    @Resource
    HotlineClient hotlineClient;

    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Override
    public PlainResult<Boolean> createHotline(String cookies, CreateHotlineRequest request) {
        REQUEST_LOGGER.info("crete hotline request = " + request);

        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getSeatNo(), "坐席号不能为空");
        AssertUtil.isAllNotNone(request.getMobile(), "手机号不能为空");

        String timestamp = Long.toString(System.currentTimeMillis()) ;

        hotlineClient.onRinging(cookies,request.getSeatNo(),request.getMobile(),timestamp);

        hotlineClient.onEstablished(cookies,request.getSeatNo(),request.getMobile(),timestamp);

        return plainResult;



    }
}
