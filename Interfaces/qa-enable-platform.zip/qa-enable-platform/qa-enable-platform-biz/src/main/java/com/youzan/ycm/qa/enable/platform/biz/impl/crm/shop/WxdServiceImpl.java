package com.youzan.ycm.qa.enable.platform.biz.impl.crm.shop;
import com.youzan.api.common.response.PlainResult;
import com.youzan.shopcenter.common.vo.MixedPhoneNumberVO;
import com.youzan.shopcenter.common.vo.MobileNumberVO;
import com.youzan.shopcenter.outer.entity.common.Address;
import com.youzan.shopcenter.outer.entity.request.ShopCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.shop.WxdService;
import com.youzan.shopcenter.outer.service.shop.ShopCreateOuterService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import  com.youzan.ycm.qa.enable.platform.api.request.crm.shop.CreateWxdRequest;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * Created by water on 2021/4/15.
 */
@Slf4j
@Service(value = "WxdService")
public class WxdServiceImpl implements WxdService{

    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private ShopCreateOuterService shopCreateOuterService;

    @Override
    public PlainResult<Long> createWxd(CreateWxdRequest request){

        REQUEST_LOGGER.info("指定手机号码创建旺小店店铺:" + request  );

        ShopCreateRequest shopCreateRequest = new ShopCreateRequest();
        shopCreateRequest.setShopType(19);
        shopCreateRequest.setShopTopic(0);
        shopCreateRequest.setShopRole(0);
        shopCreateRequest.setManagerName("ceshi");
        MobileNumberVO mobileNumberVO = new MobileNumberVO();
        mobileNumberVO.setCountryCode("+86");
        mobileNumberVO.setMobileNumber(request.getMobile());
        shopCreateRequest.setManagerMobileNumber(mobileNumberVO);
        MixedPhoneNumberVO mixedPhoneNumberVO = new MixedPhoneNumberVO();
        mixedPhoneNumberVO.setAreaCode("0357");
        mixedPhoneNumberVO.setPhoneNumber(request.getMobile());
        shopCreateRequest.setCustomerServicePhoneNumber(mixedPhoneNumberVO);
        shopCreateRequest.setShopName("qa" + request.getMobile());
        Address address = new Address();
        address.setCountry("CN");
        address.setProvince("浙江省");
        address.setCounty("西湖区");
        address.setCity("杭州市");
        address.setCountyId(330106);
        address.setAddress("良渚街道梁家塘");
        address.setLat("30.340652575725237");
        address.setLng("120.02679300430407");
        shopCreateRequest.setAddress(address);
        shopCreateRequest.setFromTerminal(4);
        shopCreateRequest.setFromBiz(15);
        shopCreateRequest.setOperatorType(1);
        shopCreateRequest.setOperatorId(8157600614L);
        shopCreateRequest.setAppName("shop-front");
        shopCreateRequest.setIpAddress("172.18.208.45");
        PlainResult<Long> shop = shopCreateOuterService.createShop(shopCreateRequest);
        return shop;
    }

}
