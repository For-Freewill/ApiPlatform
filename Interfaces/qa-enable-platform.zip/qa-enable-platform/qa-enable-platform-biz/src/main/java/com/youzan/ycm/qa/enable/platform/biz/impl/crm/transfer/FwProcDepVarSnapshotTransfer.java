package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwProcDepVarSnapshotDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwProcDepVarSnapshotDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 流程依赖的变量快照表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwProcDepVarSnapshotTransfer {

	public static FwProcDepVarSnapshotDTO toBO(FwProcDepVarSnapshotDO d) {

		if (d == null) {

			return null;
		}

		FwProcDepVarSnapshotDTO fwProcDepVarSnapshotBO = new FwProcDepVarSnapshotDTO();
		fwProcDepVarSnapshotBO.setId(d.getId());
		fwProcDepVarSnapshotBO.setKdtId(d.getKdtId());
		fwProcDepVarSnapshotBO.setOrderId(d.getOrderId());
		fwProcDepVarSnapshotBO.setAppId(d.getAppId());
		fwProcDepVarSnapshotBO.setItemId(d.getItemId());
		fwProcDepVarSnapshotBO.setProductTypeAlias(d.getProductTypeAlias());
		fwProcDepVarSnapshotBO.setLevel(d.getLevel());
		fwProcDepVarSnapshotBO.setIncludeKaPlugin(d.getIncludeKaPlugin());
		fwProcDepVarSnapshotBO.setExpireTime(d.getExpireTime());
		fwProcDepVarSnapshotBO.setBelongDepartmentIds(d.getBelongDepartmentIds());
		fwProcDepVarSnapshotBO.setBelongProviderId(d.getBelongProviderId());
		fwProcDepVarSnapshotBO.setFuwuBelongTeam(d.getFuwuBelongTeam());
		fwProcDepVarSnapshotBO.setFuwuBelongId(d.getFuwuBelongId());
		fwProcDepVarSnapshotBO.setInnerFlag(d.getInnerFlag());
		fwProcDepVarSnapshotBO.setVersion(d.getVersion());
		fwProcDepVarSnapshotBO.setCreatedAt(d.getCreatedAt());
		fwProcDepVarSnapshotBO.setUpdatedAt(d.getUpdatedAt());

		return fwProcDepVarSnapshotBO;
	}

	public static FwProcDepVarSnapshotDO toDO(FwProcDepVarSnapshotDTO bo) {

        if (bo == null) {

			return null;
		}

		FwProcDepVarSnapshotDO fwProcDepVarSnapshotDO = new FwProcDepVarSnapshotDO();
		fwProcDepVarSnapshotDO.setId(bo.getId());
		fwProcDepVarSnapshotDO.setKdtId(bo.getKdtId());
		fwProcDepVarSnapshotDO.setOrderId(bo.getOrderId());
		fwProcDepVarSnapshotDO.setAppId(bo.getAppId());
		fwProcDepVarSnapshotDO.setItemId(bo.getItemId());
		fwProcDepVarSnapshotDO.setProductTypeAlias(bo.getProductTypeAlias());
		fwProcDepVarSnapshotDO.setLevel(bo.getLevel());
		fwProcDepVarSnapshotDO.setIncludeKaPlugin(bo.getIncludeKaPlugin());
		fwProcDepVarSnapshotDO.setExpireTime(bo.getExpireTime());
		fwProcDepVarSnapshotDO.setBelongDepartmentIds(bo.getBelongDepartmentIds());
		fwProcDepVarSnapshotDO.setBelongProviderId(bo.getBelongProviderId());
		fwProcDepVarSnapshotDO.setFuwuBelongTeam(bo.getFuwuBelongTeam());
		fwProcDepVarSnapshotDO.setFuwuBelongId(bo.getFuwuBelongId());
		fwProcDepVarSnapshotDO.setInnerFlag(bo.getInnerFlag());
		fwProcDepVarSnapshotDO.setVersion(bo.getVersion());
		fwProcDepVarSnapshotDO.setCreatedAt(bo.getCreatedAt());
		fwProcDepVarSnapshotDO.setUpdatedAt(bo.getUpdatedAt());

		return fwProcDepVarSnapshotDO;
	}

	public static List<FwProcDepVarSnapshotDTO> toBOList(List<FwProcDepVarSnapshotDO> doList) {

		if (doList == null) {

			return new ArrayList<FwProcDepVarSnapshotDTO>();
		}

		List<FwProcDepVarSnapshotDTO> boList = new ArrayList<FwProcDepVarSnapshotDTO>();
		for (FwProcDepVarSnapshotDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwProcDepVarSnapshotDO> toDOList(List<FwProcDepVarSnapshotDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwProcDepVarSnapshotDO>();
		}

		List<FwProcDepVarSnapshotDO> doList = new ArrayList<FwProcDepVarSnapshotDO>();

		for (FwProcDepVarSnapshotDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
