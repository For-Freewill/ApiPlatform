package com.youzan.ycm.qa.enable.platform.biz.service.order;

import com.youzan.yop.api.entity.OpenApplicationBasicApi;
import com.youzan.yop.api.entity.item.AppDetailwithItemApi;
import com.youzan.yop.api.entity.item.ItemApi;

import java.util.List;


public interface MarketDependService {
    ItemApi getItemByItemId(Integer itemId);

    OpenApplicationBasicApi getApplicationBasicById(Integer appId);

    /**
     * 根据appId、appName查询产品类型信息
     * 查询条件 or 的关系，不者都为空代表会返回所有的item
     *
     * @param appId
     * @param appName
     * @return
     */
    List<AppDetailwithItemApi> getAllAppDetail(Integer appId, String appName);
}
