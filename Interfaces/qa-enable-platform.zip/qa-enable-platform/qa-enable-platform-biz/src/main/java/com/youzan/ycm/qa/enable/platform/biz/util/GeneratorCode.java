package com.youzan.ycm.qa.enable.platform.biz.util;

import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;

import java.util.Scanner;

/**
 * @Author Jiping.Hu
 * @Description 代码自动生成类
 * @Date 20210621
 **/
public class GeneratorCode {

    /**
     * 表名输入
     * @param tip
     * @return
     */
      public static String scanner(String tip) {
            Scanner scanner = new Scanner(System.in);
            StringBuilder help = new StringBuilder();
            help.append("请输入" + tip + "：");
            System.out.println(help.toString());
            if (scanner.hasNext()) {
                String ipt = scanner.next();
                if (StringUtils.isNotBlank(ipt)) {
                    return ipt;
                }
            }
            throw new MybatisPlusException("请输入正确的" + tip + "！");
        }

    /**
     * 初始化数据源
     * @param name
     * @return
     */
    public static DataSourceConfig initDataSource(String name){
            DataSourceConfig dsc = new DataSourceConfig();
           switch (name){
               case "1":
                   dsc.setUrl("jdbc:mysql://10.9.51.13:3008/dzt_crm?characterEncoding=UTF-8&useSSL=false");
                   dsc.setDriverName("com.mysql.jdbc.Driver");
                   dsc.setUsername("user_dztcrm");
                   dsc.setPassword("tNmwT6LLX5mppmAbEqQg");
                   break;
               case "2":
                   dsc.setUrl("jdbc:mysql://10.9.123.228:3306/ycm_qa?characterEncoding=utf8");
                   dsc.setDriverName("com.mysql.jdbc.Driver");
                   dsc.setUsername("user_ycmqa");
                   dsc.setPassword("dX64KMrvj2lL2SOgia1M");
                   break;
               case "3":
                   dsc.setUrl("jdbc:mysql://10.9.123.228:3306/yz_commerce?characterEncoding=utf8");
                   dsc.setDriverName("com.mysql.jdbc.Driver");
                   dsc.setUsername("u1_yz_commerce");
                   dsc.setPassword("j7sbapubG3yanbNK");
                   break;
               case "4":
                   dsc.setUrl("jdbc:mysql://10.9.123.228:3306/yz_finance_fee?characterEncoding=utf8");
                   dsc.setDriverName("com.mysql.jdbc.Driver");
                   dsc.setUsername("user_yzfinafee");
                   dsc.setPassword("Bsa8aZjNGqFoYpMMsM2s");
                    break;
           }
           return dsc;
        }

        public static void main(String[] args) {
            /****代码生成器**/
            AutoGenerator mpg = new AutoGenerator();
            /***设置代码生成引擎*/
            mpg.setTemplateEngine( new FreemarkerTemplateEngine());

            /***全局配置**/
            GlobalConfig gc = new GlobalConfig();
            String projectPath = System.getProperty("user.dir");
            gc.setOutputDir(projectPath + "/template")
                    .setAuthor(scanner("请输入作者的名称："))
                    .setFileOverride(true)
                    .setOpen(false)
                    .setEntityName("%sEntity")
                    .setServiceName("%sService");

            mpg.setGlobalConfig(gc);

            /***数据源配置**/
            String dataSourceName = scanner("请输入数据源（dzt_crm：1 ，ycmqa：2 ，ycm：3 ，fcfee：4）");
            mpg.setDataSource(initDataSource(dataSourceName));

            /***策略配置**/
            StrategyConfig strategyConfig = new StrategyConfig();
            strategyConfig.setCapitalMode(true)//开启全局大写命名
                    .setEntityLombokModel(true)
                    .setNaming(NamingStrategy.underline_to_camel)//数据表映射到实体的命名策略
                    .setInclude(scanner("表名，多个英文逗号分割").split(","))
                    .setColumnNaming(NamingStrategy.underline_to_camel)
                    .setTablePrefix();
            mpg.setStrategy(strategyConfig);

            /***包配置**/
            PackageConfig pc = new PackageConfig();
            pc.setParent("com.youzan.enable")
                    .setMapper("mapper")
                    .setService("Service")
                    .setEntity("entity");

            mpg.setPackageInfo(pc);

            /***配置模板，设置不生成的类**/
            TemplateConfig templateConfig = new TemplateConfig();
            templateConfig.setController("")
                    .setService("")
                    .setServiceImpl("");

            mpg.setTemplate(templateConfig);
           /* // 自定义配置
            InjectionConfig cfg = new InjectionConfig() {
                @Override
                public void initMap() {
                    // v
                }
            };

            // 如果模板引擎是 freemarker
            String templatePath = "/" +
                    "templates/mapper.xml.ftl";
            // 如果模板引擎是 velocity
            // String templatePath = "/templates/mapper.xml.vm";

            // 自定义输出配置
            List<FileOutConfig> focList = new ArrayList<>();
            // 自定义配置会被优先输出
            focList.add(new FileOutConfig(templatePath) {
                @Override
                public String outputFile(TableInfo tableInfo) {
                    // 自定义输出文件名 ， 如果你 Entity 设置了前后缀、此处注意 xml 的名称会跟着发生变化！！
                    return projectPath + "/src/main/resources/mapper/" + pc.getModuleName()
                            + "/" + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;
                }
            });

            cfg.setFileOutConfigList(focList);
            mpg.setCfg(cfg);*/

            // 配置模板
            //TemplateConfig templateConfig = new TemplateConfig();

            // 配置自定义输出模板
            //指定自定义模板路径，注意不要带上.ftl/.vm, 会根据使用的模板引擎自动识别
            // templateConfig.setEntity("templates/entity2.java");
            // templateConfig.setService();
            // templateConfig.setController();

            //templateConfig.setXml(null);
            //mpg.setTemplate(templateConfig);

            mpg.setTemplateEngine(new FreemarkerTemplateEngine());
            mpg.execute();
        }

}
