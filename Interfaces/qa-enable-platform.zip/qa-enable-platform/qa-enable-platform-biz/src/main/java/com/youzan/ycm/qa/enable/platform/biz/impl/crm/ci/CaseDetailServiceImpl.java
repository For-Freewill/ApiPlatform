package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CaseCountBO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.CaseDetailRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CaseDetailService;
import com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer.CaseDetailTransfer;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CaseDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.po.CaseCountEntityPo;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CaseDetailMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author run.xiong
 * @Description 获取Jenkins执行结果处理业务类
 * @Date 2021/8/19
 */
@Slf4j
@Service(value = "CaseDetailService")
public class CaseDetailServiceImpl implements CaseDetailService {

    @Resource
    CaseDetailMapper caseDetailMapper;

    public void updateCase(CaseDetailEntity caseDetailEntity, CaseDetailRequestDTO caseDetailRequestDTO, String caseUrl){
        caseDetailEntity.setCaseName(caseDetailRequestDTO.getCaseName());
        caseDetailEntity.setCaseBelongClass(caseDetailRequestDTO.getCaseBelongClass());
        caseDetailEntity.setCaseBelongApp(caseDetailRequestDTO.getCaseBelongApp());
        caseDetailEntity.setCaseAuthor(caseDetailRequestDTO.getCaseAuthor());
        caseDetailEntity.setCaseUrl(caseUrl);
        caseDetailEntity.setDelete(false);
    }

    @Override
    public PlainResult<Long> insert(CaseDetailRequestDTO caseDetailRequestDTO) {
        String caseUrl = caseDetailRequestDTO.getCaseBelongClass()+"."+caseDetailRequestDTO.getCaseName();

        QueryWrapper<CaseDetailEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("case_url", caseUrl);
        queryWrapper.eq("case_belong_app", caseDetailRequestDTO.getCaseBelongApp());
        // 判断用例是否存在,根据app与路径进行判断
        List<CaseDetailEntity> caseDetailEntityList =  caseDetailMapper.selectList(queryWrapper);

        PlainResult plainResult =  new PlainResult();
        if(caseDetailEntityList.size()>0){
            if(!caseDetailEntityList.get(0).isDelete()){
                CaseDetailEntity caseDetailEntity = caseDetailEntityList.get(0);
                updateCase(caseDetailEntity, caseDetailRequestDTO, caseUrl);
                plainResult.setData(caseDetailEntity.getId());
            } else{
                plainResult.setErrorMessage(400, "用例已存在，请勿重复添加");
            }
        } else{
            CaseDetailEntity caseDetailEntity = new CaseDetailEntity();
            updateCase(caseDetailEntity, caseDetailRequestDTO, caseUrl);
            caseDetailMapper.insert(caseDetailEntity);
            long id = caseDetailEntity.getId();
            plainResult.setData(id);
        }
        return plainResult;
    }

    @Override
    public PlainResult delete(long id) {
        QueryWrapper<CaseDetailEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", id);
        queryWrapper.eq("is_delete", false);
        if(caseDetailMapper.selectList(queryWrapper).size()==0){
            PlainResult plainResult = new PlainResult();
            plainResult.setErrorMessage(400, "用例不存在");
            return plainResult;
        }
        CaseDetailEntity caseDetailEntity = new CaseDetailEntity();
        caseDetailEntity.setId(id);
        caseDetailEntity.setDelete(true);
        caseDetailMapper.updateById(caseDetailEntity);
        PlainResult plainResult =  new PlainResult();
        return plainResult;
    }

    @Override
    public PlainResult<CaseDetailDTO> queryById(Long id){
        CaseDetailEntity result = caseDetailMapper.findById(id);

        PlainResult plainResult =  new PlainResult();
        plainResult.setData(CaseDetailTransfer.toDTO(result));
        return plainResult;
    }

    @Override
    public PlainResult<List<CaseCountBO>> getCountByApp(){
        List<CaseCountEntityPo> appCaseCount = caseDetailMapper.getAppCaseCount();

        PlainResult plainResult =  new PlainResult();
        plainResult.setData(appCaseCount);
        return plainResult;
    }


    @Override
    public PlainResult<ArrayList<CaseDTO>> query(String id, String caseName, String caseBelongClass, String caseBelongApp, String caseAuthor, String caseUrl) {
        QueryWrapper<CaseDetailEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_delete", false);
        if(id != null){
            queryWrapper.eq("id", id);
        }
        if(caseName != null){
            queryWrapper.eq("case_name", caseName);
        }
        if(caseBelongClass != null){
            queryWrapper.eq("case_belong_class", caseBelongClass);
        }
        if(caseBelongApp != null){
            queryWrapper.eq("case_belong_app", caseBelongApp);
        }
        if(caseAuthor != null){
            queryWrapper.eq("case_author", caseAuthor);
        }
        if(caseUrl != null){
            queryWrapper.eq("case_url", caseUrl);
        }

        List<CaseDetailEntity> findResult = caseDetailMapper.selectList(queryWrapper);
        List<CaseDTO> result = new LinkedList<>();
        for (CaseDetailEntity i:findResult) {
            CaseDTO caseDto = new CaseDTO();
            caseDto.setCaseAuthor(i.getCaseAuthor());
            caseDto.setCaseName(i.getCaseName());
            caseDto.setCaseBelongApp(i.getCaseBelongApp());
            caseDto.setCaseBelongClass(i.getCaseBelongClass());
            caseDto.setId(i.getId());
            caseDto.setCaseUrl(i.getCaseUrl());
            result.add(caseDto);
        }
        System.out.println(result);
        PlainResult plainResult =  new PlainResult();
        plainResult.setData(result);
        return plainResult;
    }
}
