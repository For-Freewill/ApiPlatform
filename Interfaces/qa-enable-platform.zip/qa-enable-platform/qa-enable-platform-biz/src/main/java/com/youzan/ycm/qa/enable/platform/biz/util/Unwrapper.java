package com.youzan.ycm.qa.enable.platform.biz.util;

import com.google.common.base.Preconditions;
import com.youzan.api.common.response.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ListWithTotal;

import java.util.List;
import java.util.Map;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-15 18:55
 **/
public class Unwrapper {
    public static <T> List<T> unwrap(ListResult<T> result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "%s", result.getMessage());
        return result.getData();
    }

    public static <T> ListWithTotal<T> unwrapWithCount(ListResult<T> result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "%s", result.getMessage());
        return new ListWithTotal<>(result.getData(), result.getCount());
    }

    public static <T> T unwrap(PlainResult<T> result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "%s", result.getMessage());
        return result.getData();
    }

    public static void unwrapPlainResult(PlainResult result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "%s", result.getMessage());
    }

    public static Boolean unwrap(PlainBoolResult result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "%s", result.getMessage());
        return result.getData().get("isSuccess");
    }

    public static <T> ListWithTotal<T> unwrap(PaginatorResult<T> result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "调用依赖失败，errorMsg：%s", result.getMessage());
        return new ListWithTotal<>(result.getData().getItems(), result.getData().getPaginator().getTotalCount());
    }

    public static <K, V> Map<K, V> unwrap(MapResult<K, V> result) {
        Preconditions.checkState(result != null, "调用依赖结果为null");
        Preconditions.checkState(result.isSuccess(), "调用依赖失败，errorMsg：%s", result.getMessage());
        return result.getData();
    }
}
