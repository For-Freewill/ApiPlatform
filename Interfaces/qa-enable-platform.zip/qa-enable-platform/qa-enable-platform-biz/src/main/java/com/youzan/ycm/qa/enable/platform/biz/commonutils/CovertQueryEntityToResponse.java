package com.youzan.ycm.qa.enable.platform.biz.commonutils;

import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableQueryResponse;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableQueryHistoryEntity;
import org.springframework.beans.BeanUtils;

import java.util.List;


/**
 * @author wulei
 * @date 2020/11/17 10:58
 */
public class CovertQueryEntityToResponse {

    /**
     * 转换EnableQueryHistoryEntity ==>EnableQueryResponse
     *
     * @param enableQueryHistoryEntity
     * @return
     */
    public static EnableQueryResponse queryEntityToRes(EnableQueryHistoryEntity enableQueryHistoryEntity) {
        EnableQueryResponse enableQueryResponse = new EnableQueryResponse();
        BeanUtils.copyProperties(enableQueryHistoryEntity, enableQueryResponse);
        List<String> tableList = StringToList.strToList(enableQueryHistoryEntity.getTables(), ",");
        enableQueryResponse.setTableList(tableList);
        return enableQueryResponse;
    }
}
