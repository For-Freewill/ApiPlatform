package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.perform;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.framework.redis.RedisClient;
import com.youzan.platform.bootstrap.exception.BusinessException;
import com.youzan.shopcenter.shopconfig.api.dto.request.OperatorDTO;
import com.youzan.shopcenter.shopconfig.api.dto.request.ShopConfigSetRequest;
import com.youzan.shopcenter.shopconfig.api.service.ShopConfigWriteService;
import com.youzan.shopcenter.shopprod.api.entity.ShopProd;
import com.youzan.shopcenter.shopprod.api.service.prod.ProdReadService;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.ResetShopTryTimeRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.perform.ShopTryPerformService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.shop.ShopProdRelationEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.shop.ShopProdVersionRelationEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.shop.ShopProdRelationMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.shop.ShopProdVersionRelationMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import com.youzan.ycm.qa.enable.platform.api.constant.KvdsConstants;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author wuwu
 * @date 2021/6/13 6:11 PM
 */
@Slf4j
@Service("shopTryPerformService")
public class ShopTryPerformServiceImpl implements ShopTryPerformService {
    @Resource
    private ShopProdVersionRelationMapper shopProdVersionRelationMapper;

    @Resource
    private ShopProdRelationMapper shopProdRelationMapper;

    @Resource
    private ShopConfigWriteService shopConfigWriteService;

    @Resource
    private ProdReadService prodReadService;

    @Resource
    private RedisClient redisClient;

    @Override
    public PlainResult<Boolean> resetShopTryTime(ResetShopTryTimeRequest request) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        log.info( "重置试用期店铺时间："+ request);

        //参数校验
        AssertUtil.isAllNotNone(request.getKdtId(), "店铺不能为空!");
        AssertUtil.isAllNotNone(request.getEndTime(), "过期时间不能为空!");

        Date nowTime = new Date();
        Date endTime = null;
        Calendar calendar = Calendar.getInstance();//日历对象
        Date beginTime = calendar.getTime();
        try {
            endTime = sdf.parse(request.getEndTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        calendar.setTime(endTime);
//        calendar.add(Calendar.DATE,-7);
//        Date beginTime = calendar.getTime();
        int compareTo = nowTime.compareTo(beginTime);

        if(compareTo < 0) {
            throw new IllegalArgumentException("试用期开始时间不能大于当前时间");

        }

        String status = "try";
        /**更新店铺 shop_prod_version_relation 表
         * lifecycle_status = 'try';
         * lifecycle_begin_time = endTime-7;
         * lifecycle_end_time =endTime
         */

        //获取店铺prodCode
        String shopProdCode = queryShopProds(request.getKdtId());
        log.info("当前店铺的prodCode："+shopProdCode);

        //获取shop_prod_version_relation 表数据
        ShopProdVersionRelationEntity shopProdVersionRelation = shopProdVersionRelationMapper.selectOne(new QueryWrapper<ShopProdVersionRelationEntity>()
                .eq("kdt_id",request.getKdtId())
                .eq("prod_code",shopProdCode)
                .last("limit 1"));
        if(null == shopProdVersionRelation) {
            log.error( "shop_prod_version_relation 表未查询到数据");
            throw new RuntimeException("shop_prod_version_relation 未查询到数据");
        }
        shopProdVersionRelation.setLifecycleBeginTime(beginTime);
        shopProdVersionRelation.setLifecycleEndTime(endTime);
        shopProdVersionRelation.setLifecycleStatus(status);
        shopProdVersionRelationMapper.updateById(shopProdVersionRelation);

        /**更新店铺 shop_prod_version_relation 表
         * lifecycle_status = 'try';
         * lifecycle_begin_time = endTime-7;
         * lifecycle_end_time =endTime
         */
        //获取shop_prod_relation 表数据
        ShopProdRelationEntity shopProdRelation = shopProdRelationMapper.selectOne(new QueryWrapper<ShopProdRelationEntity>()
                .eq("kdt_id",request.getKdtId())
                .eq("prod_code",shopProdCode)
                .last("limit 1"));
        if(null == shopProdRelation) {
            log.error( "shop_prod_relation 表未查询到数据");
            throw new RuntimeException("shop_prod_relation 未查询到数据");
        }
        shopProdRelation.setBeginTime(beginTime);
        shopProdRelation.setEndTime(endTime);
        shopProdRelation.setLifecycleStatus(status);
        shopProdRelationMapper.updateById(shopProdRelation);
        //设置team_close状态为0
        setShopTeamCloseConfig(request.getKdtId(),"0");

        //清两个数据表的缓存
        String key = String.format(KvdsConstants.SHOP_PROD_RELATION,request.getKdtId());
        redisClient.opsForKey().del(key);

        PlainResult result = new PlainResult();
        result.setMessage("更新试用期时间成功");
        return result;
    }


    /**
     * 设置店铺的team_close value为0，即：店铺不为打烊状态
     * @param kdtId
     */
    public void setShopTeamCloseConfig(Long kdtId,String value) {
        ShopConfigSetRequest shopConfigSetRequest = new ShopConfigSetRequest();

        shopConfigSetRequest.setKdtId(kdtId);
        shopConfigSetRequest.setKey("team_close");
        shopConfigSetRequest.setValue(value);
        OperatorDTO operatorDTO  = new OperatorDTO();
        operatorDTO.setFromApp("CI_TEST");
        operatorDTO.setId(111L);
        operatorDTO.setName("SHANGYEHUA");
        operatorDTO.setType(1);
        shopConfigSetRequest.setOperator(operatorDTO);

        PlainResult<Boolean> setShopConfigResult = shopConfigWriteService.setShopConfig(shopConfigSetRequest);

        if (!setShopConfigResult.isSuccess()) {
            log.error("设置team_close失败");
            throw new BusinessException("设置team_close失败" + JSON.toJSONString(setShopConfigResult));
        }
    }

    public String queryShopProds(Long kdtId) {
        PlainResult<ShopProd> result = prodReadService.queryShopProd(kdtId);
        if(!result.isSuccess()) {
            log.error("查询店铺prodCode失败");
            throw new BusinessException("查询店铺prodCode失败" + JSON.toJSONString(result));
        }
        return result.getData().getProdCode();
    }
}
