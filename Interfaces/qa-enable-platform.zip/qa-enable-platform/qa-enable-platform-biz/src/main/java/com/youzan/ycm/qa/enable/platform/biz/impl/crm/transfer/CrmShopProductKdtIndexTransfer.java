package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.CrmShopProductKdtIndexDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.CrmShopProductKdtIndexDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺最近一次软件状态
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
public class CrmShopProductKdtIndexTransfer {

	public static CrmShopProductKdtIndexDTO toBO(CrmShopProductKdtIndexDO d) {

		if (d == null) {

			return null;
		}

        CrmShopProductKdtIndexDTO crmShopProductKdtIndexBO = new CrmShopProductKdtIndexDTO();
		crmShopProductKdtIndexBO.setId(d.getId());
		crmShopProductKdtIndexBO.setKdtId(d.getKdtId());
		crmShopProductKdtIndexBO.setStatus(d.getStatus());
		crmShopProductKdtIndexBO.setCreatedAt(d.getCreatedAt());
		crmShopProductKdtIndexBO.setUpdatedAt(d.getUpdatedAt());

		return crmShopProductKdtIndexBO;
	}

	public static CrmShopProductKdtIndexDO toDO(CrmShopProductKdtIndexDTO bo) {

        if (bo == null) {

			return null;
		}

		CrmShopProductKdtIndexDO crmShopProductKdtIndexDO = new CrmShopProductKdtIndexDO();
		crmShopProductKdtIndexDO.setId(bo.getId());
		crmShopProductKdtIndexDO.setKdtId(bo.getKdtId());
		crmShopProductKdtIndexDO.setStatus(bo.getStatus());
		crmShopProductKdtIndexDO.setCreatedAt(bo.getCreatedAt());
		crmShopProductKdtIndexDO.setUpdatedAt(bo.getUpdatedAt());

		return crmShopProductKdtIndexDO;
	}

	public static List<CrmShopProductKdtIndexDTO> toBOList(List<CrmShopProductKdtIndexDO> doList) {

		if (doList == null) {

			return new ArrayList<CrmShopProductKdtIndexDTO>();
		}

		List<CrmShopProductKdtIndexDTO> boList = new ArrayList<CrmShopProductKdtIndexDTO>();
		for (CrmShopProductKdtIndexDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<CrmShopProductKdtIndexDO> toDOList(List<CrmShopProductKdtIndexDTO> boList) {

		if (boList == null) {

			return new ArrayList<CrmShopProductKdtIndexDO>();
		}

		List<CrmShopProductKdtIndexDO> doList = new ArrayList<CrmShopProductKdtIndexDO>();

		for (CrmShopProductKdtIndexDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
