package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.chain;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.GoodBasicInfo;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.CreateOrderService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.YcmRefactorRemoteService;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.entity.RefactorRouterResponse;
import com.youzan.yop.api.form.order.OrderItemFormV2;
import com.youzan.yop.api.request.RefactorRouterRequest;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2020/12/30
 **/
@Slf4j
@Service("createOrderService")
public class CreateOrderServiceImpl implements CreateOrderService {
    @Resource
    MarketRemoteService marketRemoteService;
    @Resource
    YcmRefactorRemoteService ycmRefactorRemoteService;


    @Override
    public PlainResult<CreateOfflineOrderRep> CreateOfflineOrderV2(YzChainCreateRequest yzChainCreateRequest) {

        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();
        offlineOrderFormV2.setDiscountAmount(0L);
        offlineOrderFormV2.setNeedAdminSign((byte) 0);
        offlineOrderFormV2.setNeedInvoice(true);
        offlineOrderFormV2.setUserId(2135L);
        offlineOrderFormV2.setRealPrice(1);
        offlineOrderFormV2.setOriginPrice(1L);
        List<OrderItemFormV2> itemFormV2List = new ArrayList<>();
        String prodType=yzChainCreateRequest.getProdType();
        String kdtId = yzChainCreateRequest.getKdtId();

        AssertUtil.isAllNotNone(prodType,"prodType 不能为空！");
        AssertUtil.isAllNotNone(kdtId,"kdtId 不能为空！");


        CreateOfflineOrderRep createOfflineOrderRep = new CreateOfflineOrderRep();
        RefactorRouterRequest refactorRouterRequest = new RefactorRouterRequest();
        refactorRouterRequest.setKdtIdList(Arrays.asList(Long.valueOf(kdtId)));
        PlainResult<RefactorRouterResponse> kdtOldCheck = ycmRefactorRemoteService.getRefactorRouterByKdtIdList(refactorRouterRequest);
        PlainResult<CreateOfflineOrderRep> result = new PlainResult<>();
        if(kdtOldCheck.getData().getYopKdtIdList().size()>0){
            createOfflineOrderRep.setFailedKdtIds(kdtOldCheck.getData().getYopKdtIdList());
            createOfflineOrderRep.setCreateContent("yop老系统店铺，暂不支持订购！请联系商业化测试处理");
            result.setData(createOfflineOrderRep);
            return result;
        }
        switch (prodType){
            //有赞连锁4.0L旗舰版系列订购方案
            case "yzChain40LFlagShip":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_FLAGSHIP.getItemId(), (byte) 1,kdtId,false,1));
                for (int count =0;count<5;count++){
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_NET_STORE.getItemId(), (byte) 1,null,false,1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_STORE.getItemId(), (byte) 1,null,false,1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_PARTNER.getItemId(),(byte)1,null,false,1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L旗舰版总部，5个门店，5个网店，7个合伙人】！");
                break;
            //有赞连锁4.0L专业版系列订购方案
            case "yzChain40LProfessional":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_PROFESSIONAL.getItemId(), (byte) 1, kdtId, false, 1));
                for (int count = 0; count < 5; count++) {
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_NET_STORE.getItemId(), (byte) 1, null, false, 1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_STORE.getItemId(), (byte) 1, null, false, 1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L专业版总部，5个门店，5个网店】！");

                break;
            //有赞连锁4.0L高级版系列订购方案
            case "yzChain40LSign":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_SIGN.getItemId(), (byte) 1,kdtId,false,1));
                for (int count =0;count<5;count++){
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_SAME_CITY_STORE.getItemId(), (byte) 1,null,false,1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L高级版总部，5个同城网店】！");
                break;

            //有赞连锁4.0D旗舰版系列订购方案
            case "yzChain40DProfessional":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_MINIMALIST.getItemId(), (byte) 1, kdtId, false, 1));
                for (int count = 0; count < 5; count++) {
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_MINIMALIST_NET_STORE.getItemId(), (byte) 1, null, false, 1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_MINIMALIST_PARTNER.getItemId(), (byte) 1, null, false, 1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0D旗舰版总部，5个网店，7个合伙人】！");
                break;
            case "eduChain":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_HAED.getItemId(), (byte) 1, kdtId, false, 1));
                for (int count = 0; count < 5; count++) {
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_CAMPUS.getItemId(), (byte) 1, null, false, 1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【有赞教育连锁总部，5个校区】！");
                break;
            case "yzChainCityCloudStore":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_CITY_CLOUD_STORE.getItemId(), (byte) 1, kdtId, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁（同城云店)总部，5个同城云店】！");
                break;
            case "cityCloudStore":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_SAME_CITY_STORE.getItemId(), (byte) 1, null, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购【1个同城云店】！");
                break;
            case "yzChainRegionalStore":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_REGIONAL_LSTORE.getItemId(), (byte) 1, kdtId, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁（区域网店)总部，1个区域网店，5个门店收银】！");
                break;
            case "regionalStore":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_NET_STORE.getItemId(), (byte) 1, null, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购【1个区域网店】！");
                break;
            case "storePos":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_STORE.getItemId(), (byte) 1, null, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购【1个门店收银】！");
                break;
            default:
                break;
        }
        offlineOrderFormV2.setItems(itemFormV2List);
        offlineOrderFormV2.setKdtId(kdtId);
        offlineOrderFormV2.setKdtName("");
        PlainResult<CreateOfflineOrderResponse> createResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);

        List<Long> failedKdtIds = createResult.getData().getFailedKdtIds();
        createOfflineOrderRep.setFailedKdtIds(failedKdtIds);
        if(failedKdtIds.size()>0){
            createOfflineOrderRep.setCreateContent("暂无订购任何产品！");
        }
        result.setData(createOfflineOrderRep);
        return result;
    }

    @Override
    public PlainResult<CreateOfflineOrderRep> CreateOfflineOrderForUpgrade(YzChainUpgradeRequest yzChainCreateRequest) {
        //因为是方便一键订购的初衷，所以能写死的参数都写死，仅保证简单订购，非商业化业务方不需要复杂的订购
        OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();
        offlineOrderFormV2.setDiscountAmount(0L);
        offlineOrderFormV2.setNeedAdminSign((byte) 0);
        offlineOrderFormV2.setNeedInvoice(true);
        offlineOrderFormV2.setUserId(2135L);
        offlineOrderFormV2.setRealPrice(1);
        offlineOrderFormV2.setOriginPrice(1L);
        List<OrderItemFormV2> itemFormV2List = new ArrayList<>();
        String upgradeType=yzChainCreateRequest.getUpgradeType();
        String kdtId = yzChainCreateRequest.getKdtId();

        AssertUtil.isAllNotNone(upgradeType,"upgradeType 不能为空！");
        AssertUtil.isAllNotNone(kdtId,"kdtId 不能为空！");

        CreateOfflineOrderRep createOfflineOrderRep = new CreateOfflineOrderRep();
        RefactorRouterRequest refactorRouterRequest = new RefactorRouterRequest();
        refactorRouterRequest.setKdtIdList(Arrays.asList(Long.valueOf(kdtId)));
        PlainResult<RefactorRouterResponse> kdtOldCheck = ycmRefactorRemoteService.getRefactorRouterByKdtIdList(refactorRouterRequest);
        PlainResult<CreateOfflineOrderRep> result = new PlainResult<>();
        if(kdtOldCheck.getData().getYopKdtIdList().size()>0){
            createOfflineOrderRep.setFailedKdtIds(kdtOldCheck.getData().getYopKdtIdList());
            createOfflineOrderRep.setCreateContent("yop老系统店铺，暂不支持订购！请联系商业化测试处理");
            result.setData(createOfflineOrderRep);
            return result;
        }
        switch (upgradeType){
            //零售单店升级有赞连锁L-专业版
            case "retail-yzChain40LProfessional":
                //微商城单店升级有赞连锁L-专业版系列订购方案
            case "wsc-yzChain40LProfessional":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_PROFESSIONAL.getItemId(), (byte) 1, kdtId, true, 1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_NET_STORE.getItemId(), (byte) 1, null, true, 1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_STORE.getItemId(), (byte) 1, null, true, 1));
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L专业版总部，1个门店，1个网店】！点击跳转shop-console升级");
                break;

            //零售单店升级有赞连锁L-旗舰版
            case "retail-yzChain40LFlagShip":
            //微商城单店升级有赞连锁L-旗舰版系列订购方案
            case "wsc-yzChain40LFlagShip":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_FLAGSHIP.getItemId(), (byte) 1,kdtId,true,1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_NET_STORE.getItemId(), (byte) 1,null,true,1));
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_STORE.getItemId(), (byte) 1,null,true,1));

                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L旗舰版总部，1个门店，1个网店】！点击跳转shop-console升级");
                break;
            case "yzChain40LSign":
                //高级版总部，同城网店
               /* itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.MULTI_STORE.getItemId(), (byte) 1,kdtId,false,1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.MULTI_STORE_NUM.getItemId(), (byte) 1,kdtId,false,1));
*/
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_SIGN.getItemId(), (byte) 1,kdtId,true,1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.RETAIL_CHAIN_SAME_CITY_STORE.getItemId(), (byte) 1,null,true,1));
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0L高级版总部，1个同城网店】！点击跳转shop-console升级");
                break;

                //教育单店升级教育连锁4.0(多校区2.0)
            case "edu-eduChain40":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_HEAD_40.getItemId(),(byte)1,kdtId,true,1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_CAMPUS_40.getItemId(), (byte) 1, null, true, 1));
                createOfflineOrderRep.setCreateContent("成功订购【教育连锁多校区总部，1个校区】！点击跳转shop-console升级");
                break;
                //教育单店升级教育连锁4.0(多校区2.0)-融合版
            case "edu-eduChain40_fusion":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_HEAD_FUSION_40.getItemId(),(byte)1,kdtId,true,1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.EDU_CHAIN_CAMPUS_FUSION_40.getItemId(), (byte) 1, null, true, 1));
                createOfflineOrderRep.setCreateContent("成功订购【教育连锁多校区总部-融合版，1个融合版校区】！点击跳转shop-console升级");
                break;
            //微商城单店升级有赞连锁D-旗舰版系列订购方案
            case "wsc-yzChain40DProfessional":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_MINIMALIST.getItemId(), (byte) 1, kdtId, true, 1));
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.YOUZAN_CHAIN_MINIMALIST_NET_STORE.getItemId(), (byte) 1, null, true, 1));
                createOfflineOrderRep.setCreateContent("成功订购【有赞连锁4.0D旗舰版总部，1个网店】！点击跳转shop-console升级");
                break;
            case "wscMultiStore-LSign":
                //不落单
                break;
            case "wsc-retail":
                break;
            case "wsc-edu":
                break;

            case "eduChain20-eduChain40":
                //不落单
                break;
            case "wscChain40D-retailChain40L":
                break;
            default:
                break;

        }
        if(itemFormV2List.size()>0){
            offlineOrderFormV2.setItems(itemFormV2List);
            offlineOrderFormV2.setKdtId(kdtId);
            offlineOrderFormV2.setKdtName("");
            PlainResult<CreateOfflineOrderResponse> createResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
            result = new PlainResult<>();
            List<Long> failedKdtIds = createResult.getData().getFailedKdtIds();
            createOfflineOrderRep.setFailedKdtIds(failedKdtIds);
            if(failedKdtIds.size()>0){
                createOfflineOrderRep.setCreateContent("暂无订购任何产品！");
            }
            result.setData(createOfflineOrderRep);
            return result;
        }else {
            result = new PlainResult<>();
            createOfflineOrderRep.setFailedKdtIds(new ArrayList<>());
            createOfflineOrderRep.setCreateContent("无需额外订购产品！");
            result.setData(createOfflineOrderRep);
            return result;

        }

    }

    public OrderItemFormV2 getOrderItemFormV2(Integer itemId,Byte buyType,String applyKdtId,Boolean newMigration,Integer quantity){
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setApplyKdtId(applyKdtId);
        orderItemFormV2.setItemId(itemId);
        orderItemFormV2.setBuyType(buyType);
        orderItemFormV2.setNewMigration(newMigration);
        orderItemFormV2.setQuantity(quantity);
        return orderItemFormV2;
    }

}
