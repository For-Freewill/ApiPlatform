package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ShopAttributeDataDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.ShopAttributeDataDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺属性值
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 11:26:54
 */
public class ShopAttributeDataTransfer {

	public static ShopAttributeDataDTO toBO(ShopAttributeDataDO d) {

        if (d == null) {

			return null;
		}

		ShopAttributeDataDTO shopAttributeDataBO = new ShopAttributeDataDTO();
		shopAttributeDataBO.setId(d.getId());
		shopAttributeDataBO.setKdtId(d.getKdtId());
		shopAttributeDataBO.setAttrId(d.getAttrId());
		shopAttributeDataBO.setValue(d.getValue());
		shopAttributeDataBO.setExpansion(d.getExpansion());
		shopAttributeDataBO.setCreatedAt(d.getCreatedAt());
		shopAttributeDataBO.setUpdatedAt(d.getUpdatedAt());
		shopAttributeDataBO.setDeletedAt(d.getDeletedAt());

		return shopAttributeDataBO;
	}

	public static ShopAttributeDataDTO toDTO(ShopAttributeDataDTO bo) {

        if (bo == null) {

			return null;
		}

		ShopAttributeDataDTO shopAttributeDataDTO = new ShopAttributeDataDTO();
		shopAttributeDataDTO.setId(bo.getId());
		shopAttributeDataDTO.setKdtId(bo.getKdtId());
		shopAttributeDataDTO.setAttrId(bo.getAttrId());
		shopAttributeDataDTO.setValue(bo.getValue());
		shopAttributeDataDTO.setExpansion(bo.getExpansion());
		shopAttributeDataDTO.setCreatedAt(bo.getCreatedAt());
		shopAttributeDataDTO.setUpdatedAt(bo.getUpdatedAt());
		shopAttributeDataDTO.setDeletedAt(bo.getDeletedAt());

		return shopAttributeDataDTO;
	}

	public static List<ShopAttributeDataDTO> toBOList(List<ShopAttributeDataDO> doList) {

		if (doList == null) {

			return new ArrayList<ShopAttributeDataDTO>();
		}

		List<ShopAttributeDataDTO> boList = new ArrayList<ShopAttributeDataDTO>();
		for (ShopAttributeDataDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<ShopAttributeDataDTO> toDTOList(List<ShopAttributeDataDTO> boList) {

		if (boList == null) {

			return new ArrayList<ShopAttributeDataDTO>();
		}

		List<ShopAttributeDataDTO> doList = new ArrayList<ShopAttributeDataDTO>();
		for (ShopAttributeDataDTO bo : boList) {

			if (bo != null) {

				doList.add(toDTO(bo));
			}
		}

		return doList;
	}

}
