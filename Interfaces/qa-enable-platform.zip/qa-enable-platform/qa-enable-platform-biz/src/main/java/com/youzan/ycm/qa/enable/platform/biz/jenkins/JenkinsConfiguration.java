package com.youzan.ycm.qa.enable.platform.biz.jenkins;

import com.offbytwo.jenkins.JenkinsServer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @Author qibu
 * @create 2021/8/25 11:35 AM
 */
@Configuration
public class JenkinsConfiguration {

    @Value("${jenkins.serverUri}")
    private String serverUri;
    @Value("${jenkins.username}")
    private String username;
    @Value("${jenkins.password}")
    private String password;

    /*注入jenkinsServer对象*/
    @Bean(name = "jenkinsServer")
    @Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public JenkinsServer getJenkinsServer() {
        try {
            return new JenkinsServer(new URI(serverUri), username, password);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return null;
    }

}
