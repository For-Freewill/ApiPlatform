package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.CrmShopProductActiveDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.CrmShopProductActiveDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 当前激活的服务期
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
public class CrmShopProductActiveTransfer {

	public static CrmShopProductActiveDTO toBO(CrmShopProductActiveDO d) {

		if (d == null) {

			return null;
		}

		CrmShopProductActiveDTO crmShopProductActiveBO = new CrmShopProductActiveDTO();
		crmShopProductActiveBO.setId(d.getId());
		crmShopProductActiveBO.setKdtId(d.getKdtId());
		crmShopProductActiveBO.setOrderId(d.getOrderId());
		crmShopProductActiveBO.setAppId(d.getAppId());
		crmShopProductActiveBO.setItemId(d.getItemId());
		crmShopProductActiveBO.setLevel(d.getLevel());
		crmShopProductActiveBO.setGroupType(d.getGroupType());
		crmShopProductActiveBO.setCategory(d.getCategory());
		crmShopProductActiveBO.setEffectTime(d.getEffectTime());
		crmShopProductActiveBO.setExpireTime(d.getExpireTime());
		crmShopProductActiveBO.setPfOrderStatusId(d.getPfOrderStatusId());
		crmShopProductActiveBO.setCreatedAt(d.getCreatedAt());
		crmShopProductActiveBO.setUpdatedAt(d.getUpdatedAt());

		return crmShopProductActiveBO;
	}

	public static CrmShopProductActiveDO toDO(CrmShopProductActiveDTO bo) {

        if (bo == null) {

			return null;
		}

		CrmShopProductActiveDO crmShopProductActiveDO = new CrmShopProductActiveDO();
		crmShopProductActiveDO.setId(bo.getId());
		crmShopProductActiveDO.setKdtId(bo.getKdtId());
		crmShopProductActiveDO.setOrderId(bo.getOrderId());
		crmShopProductActiveDO.setAppId(bo.getAppId());
		crmShopProductActiveDO.setItemId(bo.getItemId());
		crmShopProductActiveDO.setLevel(bo.getLevel());
		crmShopProductActiveDO.setGroupType(bo.getGroupType());
		crmShopProductActiveDO.setCategory(bo.getCategory());
		crmShopProductActiveDO.setEffectTime(bo.getEffectTime());
		crmShopProductActiveDO.setExpireTime(bo.getExpireTime());
		crmShopProductActiveDO.setPfOrderStatusId(bo.getPfOrderStatusId());
		crmShopProductActiveDO.setCreatedAt(bo.getCreatedAt());
		crmShopProductActiveDO.setUpdatedAt(bo.getUpdatedAt());

		return crmShopProductActiveDO;
	}

	public static List<CrmShopProductActiveDTO> toBOList(List<CrmShopProductActiveDO> doList) {

		if (doList == null) {

			return new ArrayList<CrmShopProductActiveDTO>();
		}

		List<CrmShopProductActiveDTO> boList = new ArrayList<CrmShopProductActiveDTO>();
		for (CrmShopProductActiveDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<CrmShopProductActiveDO> toDOList(List<CrmShopProductActiveDTO> boList) {

		if (boList == null) {

			return new ArrayList<CrmShopProductActiveDO>();
		}

		List<CrmShopProductActiveDO> doList = new ArrayList<CrmShopProductActiveDO>();

		for (CrmShopProductActiveDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
