package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.inter;

import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.rpc.service.GenericService;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.BaseInvokeRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.DubboInvokeRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.inter.InterfaceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 14:37
 **/
@Service("Dubbo_interfaceService")
public class DubboInterfaceServiceImpl implements InterfaceService {

    /**
     * 进行方法调用
     */
    @Override
    public Object doMethodInvoke(BaseInvokeRequest invokeRequest) {
        DubboInvokeRequest dubboInvokeRequest = (DubboInvokeRequest) invokeRequest;
        // 引用远程服务
        // 该实例很重量，里面封装了所有与注册中心及服务提供方连接，请缓存
        ReferenceConfig<GenericService> reference = new ReferenceConfig<GenericService>();
        // 弱类型接口名
        reference.setInterface(dubboInvokeRequest.getInterfaceName());
        if (StringUtils.isNotEmpty(dubboInvokeRequest.getVersion())) {
            reference.setVersion(dubboInvokeRequest.getVersion());
        } else {
            reference.setVersion("1.0.0");
        }
        // 声明为泛化接口
        reference.setGeneric(true);

        // 用com.alibaba.dubbo.rpc.service.GenericService可以替代所有接口引用
        GenericService genericService = reference.get();

        // 基本类型以及Date,List,Map等不需要转换，直接调用
        String[] paramTypes = dubboInvokeRequest.getParameterTypes().toArray(new String[0]);
        Object[] params = dubboInvokeRequest.getArguments().toArray(new Object[0]);
        return genericService.$invoke(dubboInvokeRequest.getMethodName(), paramTypes, params);

    }
}
