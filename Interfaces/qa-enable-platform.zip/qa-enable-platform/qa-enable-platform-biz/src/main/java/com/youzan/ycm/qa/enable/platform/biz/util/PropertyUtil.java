package com.youzan.ycm.qa.enable.platform.biz.util;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

import java.util.Properties;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-15 10:58
 */
public class PropertyUtil {
    private static Properties properties;

    static {
        properties = getProperties("application.yml");
    }

    public static Properties getProperties() {
        return properties;
    }

    public static Properties getProperties(String fileName) {
        PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource(fileName));//class路径引入
        configurer.setProperties(yaml.getObject());
        return yaml.getObject();
    }

    public static String get(String key){
        return properties.getProperty(key);
    }

}
