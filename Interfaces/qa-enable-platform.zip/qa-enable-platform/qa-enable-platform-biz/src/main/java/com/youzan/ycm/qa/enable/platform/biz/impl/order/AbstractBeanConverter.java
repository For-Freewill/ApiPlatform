package com.youzan.ycm.qa.enable.platform.biz.impl.order;

import com.youzan.enable.crm.meta.api.dto.product.ProductExtendDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProduct;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductMainInfo;
import com.youzan.yop.api.entity.item.ItemApi;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.converter.BidirectionalConverter;
import ma.glasnost.orika.converter.builtin.DateAndTimeConverters;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import ma.glasnost.orika.metadata.Type;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 16:05
 **/
@Component
public  class AbstractBeanConverter {
    protected MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

    private MapperFacade mapperFacade = null;

    public AbstractBeanConverter() {
        mapperFactory.getConverterFactory().registerConverter("timestamp2date", new DateAndTimeConverters.LongToDateConverter());
        mapperFactory.getConverterFactory().registerConverter(new BidirectionalConverter<List<String>, String>() {
            @Override
            public String convertTo(List<String> source, Type<String> destinationType, MappingContext mappingContext) {
                return CollectionUtils.isEmpty(source) ? "" : source.get(0);
            }

            @Override
            public List<String> convertFrom(String source, Type<List<String>> destinationType, MappingContext mappingContext) {
                return StringUtils.isBlank(source) ? Collections.emptyList() : Collections.singletonList(source);
            }
        });
        initMap();
        mapperFacade = mapperFactory.getMapperFacade();
    }

    protected  void initMap(){
        mapperFactory.classMap(ItemApi.class, OrderProductMainInfo.class)
                .field("appid", "appId")
                .field("appName", "appName")
                .field("id", "itemId")
                .field("name", "itemName")
                .byDefault()
                .register();

        mapperFactory.classMap(ProductExtendDTO.class, OrderProduct.class)
                .field("productType.productTypeAlias", "appType")
                .field("productType.productTypeName", "appTypeName")
                .byDefault()
                .register();
    };

    public <V, P> P convert(V base, Class<P> target) {
        return mapperFacade.map(base, target);
    }

    public <V, P> void convert(V base, P target) {
        mapperFacade.map(base, target);
    }

    public <V, P> List<P> convertList(List<V> baseList, Class<P> target) {
        return baseList == null ? new LinkedList<>() : mapperFacade.mapAsList(baseList, target);
    }
}
