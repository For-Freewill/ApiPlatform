package com.youzan.ycm.qa.enable.platform.biz.impl.order;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.youzan.api.common.response.ListResult;
import com.youzan.enable.crm.meta.api.dto.product.ProductConditionDTO;
import com.youzan.enable.crm.meta.api.dto.product.ProductExtendDTO;
import com.youzan.enable.crm.meta.api.dto.product.ProductTypeDTO;
import com.youzan.ycm.qa.enable.platform.biz.service.order.MarketDependService;
import com.youzan.ycm.qa.enable.platform.biz.service.order.OrderProductService;
import com.youzan.ycm.qa.enable.platform.biz.service.order.ProductDependService;
import com.youzan.ycm.qa.enable.platform.biz.service.order.ProductTypeDependService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ListWithTotal;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.CommonModel;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductMainInfo;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProduct;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductSO;
import com.youzan.yop.api.entity.item.AppDetailwithItemApi;
import com.youzan.yop.api.entity.item.ItemApi;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 15:33
 **/
@Service
@Slf4j
public class OrderProductServiceImpl implements OrderProductService {
    @Resource
    private AbstractBeanConverter abstractBeanConverter;

    @Resource
    private MarketDependService marketDependService;

    @Resource
    private ProductDependService productDependService;

    @Resource
    private ProductTypeDependService productTypeDependService;



    @Override
    public ListWithTotal<OrderProduct> getList(OrderProductSO orderProductSO) {
        Preconditions.checkNotNull(orderProductSO, "参数不能为空！");
        Preconditions.checkArgument(orderProductSO.getPage() != null && orderProductSO.getPage() > 0, "页码大小不合法！");
        Preconditions.checkArgument(orderProductSO.getPageSize() != null && orderProductSO.getPageSize() > 0, "每页数量不合法！");
        Preconditions.checkArgument(orderProductSO.getPageSize() != null && orderProductSO.getPageSize() <= 200, "每页数量不超过200条！");
        ProductConditionDTO condition = abstractBeanConverter.convert(orderProductSO, ProductConditionDTO.class);
        if (StringUtils.isNotEmpty(orderProductSO.getAppType())) {
            ProductTypeDTO productTypeDTO = productTypeDependService.getByAlias(orderProductSO.getAppType());
            if (productTypeDTO != null) {
                condition.setProductTypeId(productTypeDTO.getProductTypeId());
            }
        }
        condition.setIncludingNonActive(true).setSortKey("created_at").setSortOrder("desc");

        ListResult<ProductExtendDTO> result = productDependService.queryProduct(condition);
        return new ListWithTotal<>(abstractBeanConverter.convertList(result.getData(), OrderProduct.class), result.getCount());
    }

    /**
     * 商业化提供支持；可以根据应用名、应用ID、规格ID获取产品信息
     *  @param appId
     * @param appName
     * @param itemId
     * @return
     */
    @Override
    public List<OrderProductMainInfo> searchYopApps(Integer appId, String appName, Integer itemId) {
        if (AssertUtil.notNullOrDefault(appId) || StringUtils.isNotEmpty(appName)) {
            List<AppDetailwithItemApi> serviceAllAppDetail = marketDependService.getAllAppDetail(appId, appName);
            if (CollectionUtils.isEmpty(serviceAllAppDetail)) {
                return Collections.emptyList();
            }

            List<OrderProductMainInfo> orderProductMainInfoList = new ArrayList<>();
            serviceAllAppDetail.forEach(appDetailwithItemApi -> {
                List<OrderProductMainInfo> orderProductMainInfos = abstractBeanConverter.convertList(appDetailwithItemApi.getItemApis(), OrderProductMainInfo.class);
                orderProductMainInfos.forEach(orderProductMainInfo -> orderProductMainInfo.setAppName(appDetailwithItemApi.getName()));
                orderProductMainInfoList.addAll(orderProductMainInfos);
            });

            if (AssertUtil.nullOrDefault(itemId)) {
                return orderProductMainInfoList;
            }

            OrderProductMainInfo orderProductMainInfo = orderProductMainInfoList.stream()
                    .filter(o -> o.getItemId().equals(itemId))
                    .findFirst().orElse(null);
            return orderProductMainInfo == null ? Collections.emptyList() : Lists.newArrayList(orderProductMainInfo);
        }

        if (AssertUtil.notNullOrDefault(itemId)) {
            ItemApi itemApi = marketDependService.getItemByItemId(itemId);
            return itemApi == null ? Collections.emptyList() : Lists.newArrayList(abstractBeanConverter.convert(itemApi, OrderProductMainInfo.class));
        }

        return Collections.emptyList();
    }

    /**
     * 查询单个crm侧的产品类型
     *
     * @param id
     * @return
     */
    @Override
    public OrderProduct getById(Long id) {
        Preconditions.checkNotNull(id, "id不能为空！");
        ProductExtendDTO result = productDependService.getById(id);
        return abstractBeanConverter.convert(result, OrderProduct.class);
    }

    @Override
    public List<CommonModel> getAppTypeList() {
        List<CommonModel> commonModels = new ArrayList<>();
        List<ProductTypeDTO> allProductType = productTypeDependService.getAllProductType();
        allProductType.forEach(element -> commonModels.add(new CommonModel<>(element.getProductTypeAlias(), element.getProductTypeName())));
        return commonModels;
    }

}
