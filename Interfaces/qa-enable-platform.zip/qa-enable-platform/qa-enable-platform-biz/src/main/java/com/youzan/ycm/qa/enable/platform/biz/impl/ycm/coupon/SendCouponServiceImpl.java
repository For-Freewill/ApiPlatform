package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.coupon;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.market.api.CouponSendRemoteService;
import com.youzan.ycm.market.dto.couponsend.CouponSendRuleDTO;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.couponsend.SendCouponAssetRequest;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.coupon.SendCouponRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.coupon.SendCouponResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.coupon.SendCouponService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;

/**
 * Created by baoyan on 2021-04-13.
 */
@Slf4j
@Service("sendCouponService")
public class SendCouponServiceImpl implements SendCouponService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private CouponSendRemoteService couponSendRemoteService;
    @Override
    public PlainResult<SendCouponResponse> sendCouponForWxd(SendCouponRequest request){
        REQUEST_LOGGER.info("发放旺小店满减券:" + request);

        AssertUtil.isAllNotNone(request.getKdtId(), "发放店铺不能为空！");
        AssertUtil.isAllNotNone(request.getSendCount(), "发放数量不能为空！");
        AssertUtil.isAllNotNone(request.getCouponReceiveType(), "领取方式不能为空！");

        //组装发券单
        SaveSendCouponRequest saveSendCouponRequest  = new SaveSendCouponRequest() ;
        CouponSendRuleDTO couponSendRuleDTO = new CouponSendRuleDTO();
        couponSendRuleDTO.setCouponSendRecordId("");
        couponSendRuleDTO.setCouponId("13060");
        couponSendRuleDTO.setCouponName("旺小店满减至0.01");
        if (request.getKdtId()!= null) {
            couponSendRuleDTO.setKdtIdList(Arrays.asList(request.getKdtId()));
        }
        if (request.getCouponReceiveType()!= null) {
            couponSendRuleDTO.setCouponReceiveType(request.getCouponReceiveType());
        }
        couponSendRuleDTO.setCouponSendChannel("BIZ_OPERATION");
        couponSendRuleDTO.setCouponUseType("PERIOD_EFFECT");
        couponSendRuleDTO.setPeriodDays("100");
        couponSendRuleDTO.setManualReceiveDays("100");
        couponSendRuleDTO.setRemark("qa-test");
        if (request.getSendCount()!= null){
            couponSendRuleDTO.setTotalSendCount(request.getSendCount());
        }
        couponSendRuleDTO.setNotify(false);
        saveSendCouponRequest.setCouponSendRuleDTO(couponSendRuleDTO);
        PlainResult<SaveCouponSendRecordResponse> couponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);

        //发放优惠券券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        PlainResult<com.youzan.ycm.market.response.couponsend.SendCouponResponse> sendResult = new PlainResult<com.youzan.ycm.market.response.couponsend.SendCouponResponse>();
        if(couponSendRecord.getCode() != 200) {
            log.error("创建发券单失败!"+couponSendRecord.toString());
            throw new EnableException(ResultCode.CREATED_ERROR.getCode(), ResultCode.CREATED_ERROR.getMsg());
        }
        sendCouponAssetRequest.setCouponSendRecordId(couponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId());
        sendCouponAssetRequest.setSendOperator("qa平台");
        sendResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        if(sendResult.getCode()!= 200){
            log.error("发放优惠券失败!"+sendResult.toString());
            throw new EnableException(ResultCode.SEND_ERROR.getCode(), ResultCode.SEND_ERROR.getMsg());
        }
        // 3-封装结果
        PlainResult<SendCouponResponse> result = new PlainResult<>();
        return  result;
    }

}
