package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.ExcuteDetailBO;
import com.youzan.ycm.qa.enable.platform.api.enums.CaseExcuteResult;
import com.youzan.ycm.qa.enable.platform.api.enums.JobStatus;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.ExcuteDetailByAppRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.ExcuteDetailByDataRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailByAppDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailByDateDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CaseDetailService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.ExcuteDetailService;
import com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer.ExcuteDetailTransfer;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CiJenkinsJobEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.ExcuteDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.po.CaseCountEntityPo;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.po.ExcuteByJobIdPO;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CaseDetailMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CiJenkinsJobMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.ExcuteDetailMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author run.xiong
 * @Description 执行详情逻辑实现类
 * @Date 2021/8/23
 */
@Slf4j
@Service(value = "excuteDetailService")
public class ExcuteDetailServiceImpl implements ExcuteDetailService {

    @Resource
    ExcuteDetailMapper excuteDetailMapper;

    @Resource
    CaseDetailMapper caseDetailMapper;

    @Resource
    CaseDetailService caseDetailService;

    @Resource
    CiJenkinsJobMapper ciJenkinsJobMapper;

    @Override
    public Long insertExcuteDetail(ExcuteDetailDTO excuteDetailDTO) {
        int isSuccess = 0;
        ExcuteDetailEntity excuteDetailEntity = null;
        try{
            excuteDetailEntity = ExcuteDetailTransfer.toEntity(excuteDetailDTO);
            isSuccess = excuteDetailMapper.insert(excuteDetailEntity);
        }catch (Exception e){
            log.info(e.toString());
        }
        if(isSuccess>0)
            return excuteDetailEntity.getId();
        else {
            throw new RuntimeException("ExcuteDetail表数据插入异常");
        }
    }

    @Override
    public ExcuteDetailBO queryExcuteDetailByID(Long id) {

        ExcuteDetailEntity excuteDetailEntity = excuteDetailMapper.selectById(id);
        if (null == excuteDetailEntity)
            return null;
        else{
            return ExcuteDetailTransfer.toB0(excuteDetailEntity);
        }
    }

    @Override
    public List<ExcuteDetailBO> queryExcuteDetailByCaseId(Long id) {
        Wrapper<ExcuteDetailEntity> queryWrapper = new QueryWrapper<ExcuteDetailEntity>().lambda().eq(ExcuteDetailEntity::getCaseId,id);
        List<ExcuteDetailEntity> excuteDetailEntityList = excuteDetailMapper.selectList(queryWrapper);
        if (null == excuteDetailEntityList || excuteDetailEntityList.size() == 0)
            return null;
        else{
            List<ExcuteDetailBO> excuteDetailBOList = new ArrayList<ExcuteDetailBO>();
            excuteDetailEntityList.forEach(excuteDetailEntity -> excuteDetailBOList.add(ExcuteDetailTransfer.toB0(excuteDetailEntity)));
            return excuteDetailBOList;
        }
    }

    @Override
    public PlainResult<List<ExcuteDetailByAppDTO>> queryExcuteDetailByApp(PageRequest<ExcuteDetailByAppRequestDTO> excuteDetailByAppRequestDTO){
        List<ExcuteDetailByAppDTO> result = new LinkedList<>();

        PageInfo<ExcuteByJobIdPO> excuteByJobIdPOSList = PageHelper.startPage(excuteDetailByAppRequestDTO.getPageNum(), excuteDetailByAppRequestDTO.getPageSize()).doSelectPageInfo(
                () -> excuteDetailMapper.executeByJobId(excuteDetailByAppRequestDTO.getDto().getCaseBelongApp(),excuteDetailByAppRequestDTO.getDto().getStartDate(),excuteDetailByAppRequestDTO.getDto().getEndDate()));

        for (ExcuteByJobIdPO excuteByJobIdPO : excuteByJobIdPOSList.getList()){
            int failurecount = excuteDetailMapper.findByexcuteResult(excuteByJobIdPO.getJobId(), CaseExcuteResult.FAILED.getCode()).getTotalCount();
            //int regressionCount  = excuteDetailMapper.findByexcuteResult(excuteByJobIdPO.getJobId(), CaseExcuteResult.REGRESSION.getCode()).getTotalCount();
            int successCount = excuteDetailMapper.findByexcuteResult(excuteByJobIdPO.getJobId(),CaseExcuteResult.PASSED.getCode()).getTotalCount();
            //int fixCount = excuteDetailMapper.findByexcuteResult(excuteByJobIdPO.getJobId(),CaseExcuteResult.FIXED.getCode()).getTotalCount();
            //int skipCount = excuteDetailMapper.findByexcuteResult(excuteByJobIdPO.getJobId(),CaseExcuteResult.SKIPPED.getCode()).getTotalCount();
            ExcuteDetailByAppDTO excuteDetailByAppDTO = ExcuteDetailByAppDTO.builder()
                    .env(excuteByJobIdPO.getEnv())
                    .executeCount(excuteByJobIdPO.getExcuteCaseCount())
                    .executeSkipCount(0)
                    .executeFailureCount(failurecount)
                    .executeSuccessCount(successCount)
                    .id(excuteByJobIdPO.getJobId())
                    .reportUrl(excuteByJobIdPO.getExcuteJenkins())
                    .build();
            result.add(excuteDetailByAppDTO);
        }
        PageResult<ExcuteDetailByAppDTO> pageResult = new PageResult<>();
        pageResult.setTotalNum((int)excuteByJobIdPOSList.getTotal());
        pageResult.setList(result);

        PlainResult plainResult =  new PlainResult();
        plainResult.setData(pageResult);
        return plainResult;
    }

    /**
     * 根据时间查询每个应用的执行情况
     * @param excuteDetailByDataRequestDTO
     * @return
     */
    @Override
    public PlainResult<List<ExcuteDetailByDateDTO>> queryExcuteDetailByDate(ExcuteDetailByDataRequestDTO excuteDetailByDataRequestDTO) {
        Date startDate = excuteDetailByDataRequestDTO.getStartDate();
        Date endDate = excuteDetailByDataRequestDTO.getEndDate();
        /**返回结果对象*/
        List<ExcuteDetailByDateDTO> excuteDetailByDateDTOS = new ArrayList<>();
        /**
         * 获取应用对应的case统计
         */
        List<CaseCountEntityPo> appCaseCountList = caseDetailMapper.getAppCaseCount();
        for (CaseCountEntityPo caseCountEntityPo : appCaseCountList){
            /**根据case_belong_app 查询执行的次数和耗费的时间*/
            List<ExcuteByJobIdPO> excuteByJobIdPOSList = excuteDetailMapper.executeByJobId(caseCountEntityPo.getCaseBelongApp(),startDate,endDate);
            /**查询应用执行的平均成功率**/
            List<CiJenkinsJobEntity> ciJenkinsJobEntityList  = ciJenkinsJobMapper.findByApp(caseCountEntityPo.getCaseBelongApp(),startDate,endDate);
            String successRate = "-";
            long successCount = ciJenkinsJobEntityList.stream().filter(ciJenkinsJobEntity -> ciJenkinsJobEntity.getJobState()== JobStatus.SUCCESS.getCode()).count();
            NumberFormat nfmt = NumberFormat.getInstance();
            nfmt.setMinimumIntegerDigits(2);

            successRate = successCount== 0?"0%":nfmt.format((double)successCount/ciJenkinsJobEntityList.size() * 100) +"%";
            float avgTime =  0 ;
            if (null != excuteByJobIdPOSList && excuteByJobIdPOSList.size() !=0){
                double cost  = excuteByJobIdPOSList.stream().mapToDouble(ExcuteByJobIdPO::getExcuteCost).sum();
                int   count = excuteByJobIdPOSList.size();
                avgTime = (float) cost/count;
            }

            ExcuteDetailByDateDTO excuteDetailByDateDTO = ExcuteDetailByDateDTO.builder()
                    .caseBelongApp(caseCountEntityPo.getCaseBelongApp())
                    .caseCount(caseCountEntityPo.getTotalCount())
                    .executeCount(null == excuteByJobIdPOSList || excuteByJobIdPOSList.size() ==0?0:excuteByJobIdPOSList.size())
                    .averageExecutionTime(avgTime)
                    .averageSuccessRate(successRate)
                    .build();
            excuteDetailByDateDTOS.add(excuteDetailByDateDTO);
        }

        PlainResult plainResult =  new PlainResult();
        plainResult.setData(excuteDetailByDateDTOS);
        return plainResult;
    }

    @Override
    public List<ExcuteDetailDTO> queryExcuteDetailByJobId(Long jobId) {
        Wrapper<ExcuteDetailEntity> queryWrapper = new QueryWrapper<ExcuteDetailEntity>().lambda().eq(ExcuteDetailEntity::getJobId,jobId);
        List<ExcuteDetailEntity> excuteDetailEntityList = excuteDetailMapper.selectList(queryWrapper);
        if (null==excuteDetailEntityList || excuteDetailEntityList.size()<1)
            return null;
        else {
            List<ExcuteDetailDTO> excuteDetailDTOList = new ArrayList<ExcuteDetailDTO>();
            excuteDetailEntityList.forEach(excuteDetailEntity->{
                excuteDetailDTOList.add(ExcuteDetailTransfer.toDTO(excuteDetailEntity));
            });
            return excuteDetailDTOList;
        }
    }
}
