package com.youzan.ycm.qa.enable.platform.biz.commonutils;

/**
 * @author wulei
 * @date 2021/11/16 19:16
 * dubbo请求响应转Java代码
 */
public class JavaCodeSegmentDefinition {
    // 新的Java文件
    public static final String NEW_JAVA = "import com.alibaba.fastjson.JSONObject;\n" +
            "import com.alibaba.fastjson.JSON;\n"+
            "import #REQUESTIMPORT#;\n" +
            "import #RESPIMPORT#;\n" +
            "import #SERVICEIMPORT#;\n" +
            "import lombok.extern.slf4j.Slf4j;\n" +
            "import com.youzan.api.common.response.PlainResult;\n" +
            "import org.testng.Assert;\n" +
            "import org.testng.annotations.Test;\n" +
            "import com.youzan.test.quickstart.annotation.Dubbo;\n" +
            "\n" +
            "@Slf4j\n" +
            "public class #ServiceName#Test extends BaseTest {\n" +
            "#DUBBOANNOTATION#" +
            "\n" +
            "    #TEST#\n" +
            "}";

    // @Test
    public static final String TEST = "@Test()\n" +
            "    public void #MethodName#Test(){\n" +
            "        String requestData=\"#REQUEST_DATA#\";\n" +
            "        #REQUESTS#\n" +
            "        #INVOKE#\n" +
            "        log.info(\"result = \" + result.toString());\n" +
            "        #RESPONSE_ASSERT#\n" +
            "    }\n";

    // DUBBOANNOTATION
    public static final String DUBBOANNOTATION = "\t@Dubbo\n" +
            "\tprivate #ServiceName# service;\n";

    // REQUESTS
    public static final String REQUESTS = "#REQUEST# request = JSON.parseObject(requestData, #REQUEST#.class);";

    // INVOKE Dubbo调用
    public static final String INVOKE = "PlainResult<String> result = service.#MethodName#(request);";

    // response拼接
    public static final String RESPONSE_ASSERT = "if (result!=null){\n" +
            "\t\t\tAssert.assertEquals(result.getCode(),\"#respCode#\");\n" +
            "\t\t\tAssert.assertEquals(result.getData(),\"#respData#\");\n" +
            "\t\t\tAssert.assertEquals(result.getMessage(),\"#respMsg#\");\n" +
            "\t\t}";

    // @Test_MUL
    public static final String TEST_MUL = "@Test()\n" +
            "    public void #MethodName#Test(){\n" +
            "#REQUESTS#\n" +
            "        #INVOKE#\n" +
            "        log.info(\"result = \" + result.toString());\n" +
            "        #RESPONSE_ASSERT#\n" +
            "    }\n";

    // REQUESTS_MUL
    public static final String REQUESTS_MUL = "\t\t#REQUEST# request_#loop# = JSON.parseObject('#REQ_DATA#', #REQUEST#.class);\n";

    // INVOKE Dubbo_MUL
    public static final String INVOKE_MUL = "PlainResult<String> result = service.#MethodName#(#REQUESTS_MUL_LIST#);";
}
