package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ebiz.common.model.CommonResult;
import com.youzan.shopcenter.outer.entity.common.Address;
import com.youzan.shopcenter.outer.entity.common.OptSource;
import com.youzan.shopcenter.outer.entity.request.BeautyShopCreateRequest;
import com.youzan.shopcenter.outer.entity.request.WscEduShopCreateRequest;
import com.youzan.shopcenter.outer.entity.request.chain.RetailHqCreateRequest;
import com.youzan.shopcenter.outer.service.chain.RetailChainCreateOuterService;
import com.youzan.shopcenter.outer.service.shop.ShopCreateOuterService;
import com.youzan.shopcenter.shop.entity.LongServiceResult;
import com.youzan.shopcenter.shop.entity.request.RetailShopCreateRequest;
import com.youzan.shopcenter.shop.entity.request.WscCreateRequest;
import com.youzan.shopcenter.shop.service.ShopCreateService;
import com.youzan.sz.beautystore.shop.model.vo.ShopInfoVO;
import com.youzan.uic.api.user.model.MobileUserInfoModel;
import com.youzan.uic.api.user.param.UserInfoQueryParam;
import com.youzan.uic.api.user.service.UserInfoService;
import com.youzan.wecom.helper.api.corp.manage.corp.dto.response.CorpCreateRespDTO;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.enable.BatchCreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableCreateShopResponse;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;
import com.youzan.ycm.qa.enable.platform.api.service.enable.EnableNewShopPoolService;
import com.youzan.ycm.qa.enable.platform.biz.enums.ShopTypeEnums;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableAccountPoolEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableAccountPoolMapper;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.CreateShopService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.RetryException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalTime;
import java.util.Objects;

/**
 * @author wuwu
 * @date 2021/2/7 1:27 PM
 */
@Slf4j
@Service("enableNewShopPoolService")
public class EnableNewShopPoolServiceImpl extends ServiceImpl<EnableAccountPoolMapper, EnableAccountPoolEntity> implements EnableNewShopPoolService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private EnableAccountPoolMapper enableAccountPoolMapper;

    @Autowired
    private CreateShopService createShopService;



    @Override
    public PlainResult<Boolean> createAccountPoolNewShop(CreateShopRequest createShopRequest) {
        PlainResult<Boolean> plainResult = new PlainResult<>();
        EnableAccountPoolEntity enableAccountPoolEntity = new EnableAccountPoolEntity();

        if(createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("qa" + System.currentTimeMillis());
        }
        PlainResult<Long> createShopResult = createShopService.createNewShop(createShopRequest);

        if (createShopResult.isSuccess() && createShopResult.getData() != null) {
            enableAccountPoolEntity.setKdtId(createShopResult.getData().toString());
            enableAccountPoolEntity.setKdtName(createShopRequest.getShopName());
            enableAccountPoolEntity.setUserId(createShopRequest.getPhoneNo());
            enableAccountPoolEntity.setProdCode(createShopRequest.getShopType());

            int isSave = enableAccountPoolMapper.insert(enableAccountPoolEntity);

            if (isSave > 0) {
                plainResult.setData(Boolean.TRUE);
            } else {
                throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
            }

            return plainResult;
        } else {
            plainResult.setCode(createShopResult.getCode());
            plainResult.setMessage(createShopResult.getMessage());
            return plainResult;
        }
    }



    @Override
    @Transactional
    public PlainResult<EnableNewKdtIdResponse> getNewKdtId(String prodCode) {
        int isApplied = 0;
        int isNew = 1;

        PlainResult<EnableNewKdtIdResponse> plainResult = new PlainResult<>();
        EnableNewKdtIdResponse enableNewKdtIdResponse = new EnableNewKdtIdResponse();

        //选中要更新的kdtid
        EnableAccountPoolEntity result = enableAccountPoolMapper.selectOne(new QueryWrapper<EnableAccountPoolEntity>()
                .lambda()
                .eq(EnableAccountPoolEntity::getIsApplied, isApplied)
                .eq(EnableAccountPoolEntity::getIsNew, isNew)
                .eq(EnableAccountPoolEntity::getProdCode,prodCode)
                .groupBy(EnableAccountPoolEntity::getUserId)
                .orderByDesc(EnableAccountPoolEntity::getCreatedAt).last("limit 1"));

        //如果kdtid被其他人修改过了就失败
        if (result != null) {
            result.setIsApplied(1);
            result.setIsNew(0);
            int updateNum = enableAccountPoolMapper.updateById(result);
            if (updateNum > 0) {
                log.info("更新成功");
                enableNewKdtIdResponse.setKdtId(Long.valueOf(result.getKdtId()));
                enableNewKdtIdResponse.setKdtName(result.getKdtName());
                enableNewKdtIdResponse.setUserId(result.getUserId());
                plainResult.setData(enableNewKdtIdResponse);
                plainResult.setCode(200);
                plainResult.setSuccess(true);
                plainResult.setMessage("占用店铺成功");
            } else {
                log.info("更新失败，该记录已被其他人修改！");
                plainResult.setData(null);
                plainResult.setMessage("更新店铺信息失败");
                plainResult.setSuccess(false);
                //throw new RetryException("获取店铺失败");
            }
        } else {
            log.info("没有可用的新店铺");
            plainResult.setData(null);
            plainResult.setMessage("没有可用的新店铺");
            plainResult.setSuccess(false);
        }
        return plainResult;
    }

    @Override
    @Retryable(value = RetryException.class, maxAttempts = 3, backoff = @Backoff(delay = 2000, multiplier = 1.5))
    public PlainResult<EnableNewKdtIdResponse> concurrentGetNewKdtId(String prodCode) {
        PlainResult<EnableNewKdtIdResponse> result = getNewKdtId(prodCode);
        if (!result.isSuccess()) {
            log.info("获取店铺失败");
            throw new RetryException("获取店铺失败");
        } else {
            log.info("获取店铺成功");
            return result;
        }
    }

    @Recover
    public void recover(RetryException e) {
        log.warn("获取店铺失败！！！" + LocalTime.now());
    }


    @Override
    public void batchCreteWscShop(BatchCreateShopRequest request) {
        CreateShopRequest createShopRequest = new CreateShopRequest();
        createShopRequest.setPhoneNo(request.getPhoneNo());
        createShopRequest.setShopName(request.getShopName());
        createShopRequest.setShopType(request.getShopType());

        for (int i = 0; i < request.getNum(); i++) {
            createShopRequest.setShopName("qa" + System.currentTimeMillis());

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            PlainResult<Boolean> result = createAccountPoolNewShop(createShopRequest);
            if(!result.isSuccess() ||result.getData() == null) {
                throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),result.getMessage());
            }
        }

    }






}
