package com.youzan.ycm.qa.enable.platform.biz.util;

import java.io.Serializable;

public class PageInfo implements Serializable {

    // 页码
    private static final int PAGE_NUMBER = 1;

    // 页面大小
    private static final int PAGE_SIZE = 15;

    /**
     * 页码
     */
    private Integer pageNum;

    /**
     * 分页大小
     */
    private Integer pageSize;

    private String orderBy;

	/**
	 * 是否需要查询count总数
	 */
	private Boolean isCount = false;

    /**
     * 记录总数
     */
    private Integer total;

    public PageInfo() {
        this.pageNum = PAGE_NUMBER;
        this.pageSize = PAGE_SIZE;
    }

    public PageInfo(Integer pageNum, Integer pageSize, Integer total){
        this.pageSize = pageSize;
        this.pageNum = pageNum;
        this.total = total;
    }

    public void setPageInfo(Integer pageNum, Integer pageSize){
        this.pageSize = pageSize;
        this.pageNum = pageNum;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }


    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(final String orderBy) {
        this.orderBy = orderBy;
    }

	public Boolean getCount() {
		return isCount;
	}

	public void setCount(Boolean count) {
		isCount = count;
	}

	@Override
    public String toString() {
        return "PageInfo{" +
                   "pageNum=" + pageNum +
                   ", pageSize=" + pageSize +
                   ", total=" + total +
                   '}';
    }
}
