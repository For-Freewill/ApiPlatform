package com.youzan.ycm.qa.enable.platform.biz.impl.order;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.service.order.MarketDependService;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.entity.OpenApplicationBasicApi;
import com.youzan.yop.api.entity.item.AppDetailwithItemApi;
import com.youzan.yop.api.entity.item.ItemApi;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-15 20:07
 **/
@Service
public class MarketDependServiceImpl implements MarketDependService {
    @Resource
    private MarketRemoteService marketRemoteService;


    @Override
    public ItemApi getItemByItemId(Integer itemId) {

        PlainResult<ItemApi> itemApiPlainResult = marketRemoteService.getItemByItemId(itemId);

        return itemApiPlainResult.isSuccess() ? itemApiPlainResult.getData() : null;
    }

    @Override
    public OpenApplicationBasicApi getApplicationBasicById(Integer appId) {
        PlainResult<OpenApplicationBasicApi> openApplicationBasicApiPlainResult = marketRemoteService.getApplicationBasicById(appId);
        return openApplicationBasicApiPlainResult.isSuccess() ? openApplicationBasicApiPlainResult.getData() : null;
    }

    /**
     * 根据appId、appName查询产品类型信息
     * 查询条件 or 的关系，不者都为空代表会返回所有的item
     *
     * @param appId
     * @param appName
     * @return
     */
    @Override
    public List<AppDetailwithItemApi> getAllAppDetail(Integer appId, String appName) {
        AppDetailwithItemApi appDetailwithItemApi = new AppDetailwithItemApi();
        appDetailwithItemApi.setAppid(appId);
        appDetailwithItemApi.setName(appName);

        PlainResult<List<AppDetailwithItemApi>> result = marketRemoteService.getAllAppDetail(appDetailwithItemApi);
        return result.isSuccess() ? result.getData() : Collections.emptyList();
    }
}
