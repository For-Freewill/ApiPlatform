package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.CrmShopProductActiveHistoryDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.CrmShopProductActiveHistoryDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 激活的服务期历史记录
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
public class CrmShopProductActiveHistoryTransfer {

	public static CrmShopProductActiveHistoryDTO toDTO(CrmShopProductActiveHistoryDO d) {

		if (d == null) {

			return null;
		}

		CrmShopProductActiveHistoryDTO crmShopProductActiveHistoryDTO = new CrmShopProductActiveHistoryDTO();
		crmShopProductActiveHistoryDTO.setId(d.getId());
		crmShopProductActiveHistoryDTO.setKdtId(d.getKdtId());
		crmShopProductActiveHistoryDTO.setOrderId(d.getOrderId());
		crmShopProductActiveHistoryDTO.setAppId(d.getAppId());
		crmShopProductActiveHistoryDTO.setItemId(d.getItemId());
		crmShopProductActiveHistoryDTO.setLevel(d.getLevel());
		crmShopProductActiveHistoryDTO.setGroupType(d.getGroupType());
		crmShopProductActiveHistoryDTO.setCategory(d.getCategory());
		crmShopProductActiveHistoryDTO.setEffectTime(d.getEffectTime());
		crmShopProductActiveHistoryDTO.setExpireTime(d.getExpireTime());
		crmShopProductActiveHistoryDTO.setPfOrderStatusId(d.getPfOrderStatusId());
		crmShopProductActiveHistoryDTO.setCreatedAt(d.getCreatedAt());
		crmShopProductActiveHistoryDTO.setUpdatedAt(d.getUpdatedAt());

		return crmShopProductActiveHistoryDTO;
	}

	public static CrmShopProductActiveHistoryDO toDO(CrmShopProductActiveHistoryDTO bo) {

        if (bo == null) {

			return null;
		}

		CrmShopProductActiveHistoryDO crmShopProductActiveHistoryDO = new CrmShopProductActiveHistoryDO();
		crmShopProductActiveHistoryDO.setId(bo.getId());
		crmShopProductActiveHistoryDO.setKdtId(bo.getKdtId());
		crmShopProductActiveHistoryDO.setOrderId(bo.getOrderId());
		crmShopProductActiveHistoryDO.setAppId(bo.getAppId());
		crmShopProductActiveHistoryDO.setItemId(bo.getItemId());
		crmShopProductActiveHistoryDO.setLevel(bo.getLevel());
		crmShopProductActiveHistoryDO.setGroupType(bo.getGroupType());
		crmShopProductActiveHistoryDO.setCategory(bo.getCategory());
		crmShopProductActiveHistoryDO.setEffectTime(bo.getEffectTime());
		crmShopProductActiveHistoryDO.setExpireTime(bo.getExpireTime());
		crmShopProductActiveHistoryDO.setPfOrderStatusId(bo.getPfOrderStatusId());
		crmShopProductActiveHistoryDO.setCreatedAt(bo.getCreatedAt());
		crmShopProductActiveHistoryDO.setUpdatedAt(bo.getUpdatedAt());

		return crmShopProductActiveHistoryDO;
	}

	public static List<CrmShopProductActiveHistoryDTO> toBOList(List<CrmShopProductActiveHistoryDO> doList) {

		if (doList == null) {

			return new ArrayList<CrmShopProductActiveHistoryDTO>();
		}

		List<CrmShopProductActiveHistoryDTO> boList = new ArrayList<CrmShopProductActiveHistoryDTO>();
		for (CrmShopProductActiveHistoryDO d : doList) {

			if (d != null) {

				boList.add(toDTO(d));
			}
		}
		return boList;
	}

}
