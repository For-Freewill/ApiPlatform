package com.youzan.ycm.qa.enable.platform.biz.impl.ycm;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.perform.api.AdvanceRemoteService;
import com.youzan.ycm.perform.api.PfRefundRemoteService;
import com.youzan.ycm.perform.dto.YcmIdDTO;
import com.youzan.ycm.perform.request.advance.CanAdvanceOrderQuotaRequest;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.OrderQueryRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.OrderQueryResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.PfOrderService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.LegalTables;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift.GfAssetEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.MKCapitalAccountRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.MKRedeemCodeJoinRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.MkBizRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.MkJoinRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.open.OpenAppBizIdMappingEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.open.OpenAppOrderIdMappingEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.gift.GfAssetMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.MKCapitalAccountRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.MKRedeemCodeJoinRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.MkBizRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.MkJoinRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.open.OpenAppBizIdMappingMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.open.OpenAppOrderIdMappingMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.perform.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.trade.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 订单查询
 *
 * @author wulei
 * @date 2020-10-10
 */
@Slf4j
@Service("pfOrderService")
public class PfOrderServiceImpl extends ServiceImpl<PfOrderMapper, PfOrderEntity> implements PfOrderService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private AdvanceRemoteService advanceRemoteService;
    // td_*
    @Resource
    private TdBatchRefundOrderMapper tdBatchRefundOrderMapper;
    @Resource
    private TdDctResultDetailMapper tdDctResultDetailMapper;
    @Resource
    private TdItemRefundRecordMapper tdItemRefundRecordMapper;
    @Resource
    private TdOrderItemMapper tdOrderItemMapper;
    @Resource
    private TdOrderItemRefundOrderMapper tdOrderItemRefundOrderMapper;
    @Resource
    private TdOrderMapper tdOrderMapper;
    @Resource
    private TdPayOrderMapper tdPayOrderMapper;
    @Resource
    private TdPayRefundOrderMapper tdPayRefundOrderMapper;
    @Resource
    private TdPmtResultDetailMapper tdPmtResultDetailMapper;
    @Resource
    private TdPstMapper tdPstMapper;
    @Resource
    private TdSettleOrderMapper tdSettleOrderMapper;
    @Resource
    private TdYzbGrantOrderMapper tdYzbGrantOrderMapper;
    // pf_*
    @Resource
    private PfAssetMapper pfAssetMapper;
    @Resource
    private PfCouponRecordMapper pfCouponRecordMapper;
    @Resource
    private PfDebtRepayRecordMapper pfDebtRepayRecordMapper;
    @Resource
    private PfOrderDetailActiveRecordMapper pfOrderDetailActiveRecordMapper;
    @Resource
    private PfOrderDetailAdvanceRecordMapper pfOrderDetailAdvanceRecordMapper;
    @Resource
    private PfOrderDetailDebtRecordMapper pfOrderDetailDebtRecordMapper;
    @Resource
    private PfOrderDetailMapper pfOrderDetailMapper;
    @Resource
    private PfOrderItemBizMapper pfOrderItemBizMapper;
    @Resource
    private PfOrderMapper pfOrderMapper;
    @Resource
    private PfOrderStatusMapper pfOrderStatusMapper;
    @Resource
    private PfOrderStockMapper pfOrderStockMapper;
    @Resource
    private PfRightsStatusMapper pfRightsStatusMapper;
    @Resource
    private PfSchemeOrderRelationMapper pfSchemeOrderRelationMapper;
    @Resource
    private PfStatusLogMapper pfStatusLogMapper;
    @Resource
    private PfStockLogMapper pfStockLogMapper;
    @Resource
    private PfOrderSplitDetailMapper pfOrderSplitDetailMapper;
    @Resource
    private PfOrderPreAcceptOrderMapper pfOrderPreAcceptOrderMapper;
    //mk_*
    @Resource
    private MkBizRecordMapper mkBizRecordMapper;
    @Resource
    private MKCapitalAccountRecordMapper mkCapitalAccountRecordMapper;
    @Resource
    private MkJoinRecordMapper mkJoinRecordMapper;
    @Resource
    private MKRedeemCodeJoinRecordMapper mkRedeemCodeJoinRecordMapper;
    //open_*
    @Resource
    private OpenAppBizIdMappingMapper openAppBizIdMappingMapper;
    @Resource
    private OpenAppOrderIdMappingMapper openAppOrderIdMappingMapper;
    //gift_*
    @Resource
    private GfAssetMapper gfAssetMapper;
    @Resource
    private PfRefundRemoteService pfRefundRemoteService;

    /**
     * 根据订单号查询全部表的信息
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<OrderQueryResponse> queryByTdOrderId(OrderQueryRequest request) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getTables(), "tables 不能为空！");
        AssertUtil.isAllNotNone(request.getTdOrderId(), "td_order id不能为空！");
        REQUEST_LOGGER.info("query request = " + request);
        // 2-执行查询
        OrderQueryResponse orderQueryResponse = new OrderQueryResponse();
        Map<String, Object> resultMaps = resultMap(request);
        // 3-封装结果
        orderQueryResponse.setTotal(Long.valueOf(resultMaps.size()));
        orderQueryResponse.setDetails(resultMaps);
        PlainResult<OrderQueryResponse> plainResult = new PlainResult<>();
        plainResult.setData(orderQueryResponse);
        plainResult.setSuccess(true);
        return plainResult;
    }

    /**
     * 查询YOP的级别-dubbo调用例子
     *
     * @param id
     * @return
     */
    public PlainResult<CanAdvanceOrderQuotaResponse> queryYopLevel(String id) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(id, "id 不能为空！");
        // 2-构造入参
        CanAdvanceOrderQuotaRequest canAdvanceOrderQuotaRequest = new CanAdvanceOrderQuotaRequest();
        YcmIdDTO ycmIdDTO = new YcmIdDTO();
        ycmIdDTO.setId(id);
        ycmIdDTO.setType("KDT_ID");
        canAdvanceOrderQuotaRequest.setYcmIdDTO(ycmIdDTO);
        return advanceRemoteService.canAdvanceOrderQuota(canAdvanceOrderQuotaRequest);
    }

    /**
     * 回收服务期（不进行退款动作）
     *
     * @param pfOrderId
     * @return
     */
    @Override
    public PlainResult<Boolean> recycleForPfOrder(Long pfOrderId) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(pfOrderId, "pfOrderId 不能为空！");
        return pfRefundRemoteService.recycleForPfOrder(pfOrderId);
    }

    /**
     * 表名校验
     *
     * @return
     */
    private List<String> verifyTables(OrderQueryRequest request) {
        // 1-请求列表去重
        List<String> queryTables = request.getTables().stream().distinct().collect(Collectors.toList());
        // 2-合法表名
        List<String> tables = LegalTables.legalTables();
        // 3-判断是否有不在合法表内的数据
        List<String> bad = queryTables.stream().filter(tb -> !tables.contains(tb)).collect(Collectors.toList());
        if (bad.size() > 0) {
            log.info("请求的tables名称不存在" + bad.toString());
            throw new EnableException(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMsg());
        }
        return queryTables;
    }

    /**
     * 查询结果数据
     *
     * @param request
     * @return
     */
    private Map<String, Object> resultMap(OrderQueryRequest request) {
        Map<String, Object> resultMap = new LinkedHashMap<>();

        //1-校验入参的表格
        List<String> queryTables = verifyTables(request);

        //2-获取td_no
        List<TdOrderEntity> res = tdOrderMapper.selectList(new QueryWrapper<TdOrderEntity>().lambda().eq(TdOrderEntity::getId, request.getTdOrderId()));
        //
        if (res.size() == 0) {
            return resultMap;
        }
        String td_no = res.get(0).getTdNo();
        //3-td_* 表数据获取
        if (td_no != null) {
            //3-td_* 表数据获取
            if (queryTables.contains("td_order") && tdOrderMapper.selectList(new QueryWrapper<TdOrderEntity>().eq("id", request.getTdOrderId())).size() != 0) {
                resultMap.put("td_order", tdOrderMapper.selectList(new QueryWrapper<TdOrderEntity>().eq("id", request.getTdOrderId())));
            }
            if (queryTables.contains("td_order_item") && tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItemEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_order_item", tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItemEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_pay_order") && tdPayOrderMapper.selectList(new QueryWrapper<TdPayOrderEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_pay_order", tdPayOrderMapper.selectList(new QueryWrapper<TdPayOrderEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_pay_refund_order") && tdPayRefundOrderMapper.selectList(new QueryWrapper<TdPayRefundOrderEntity>().eq("pay_trade_no", td_no)).size() != 0) {
                resultMap.put("td_pay_refund_order", tdPayRefundOrderMapper.selectList(new QueryWrapper<TdPayRefundOrderEntity>().eq("pay_trade_no", td_no)));
            }
            if (queryTables.contains("td_pmt_result_detail") && tdPmtResultDetailMapper.selectList(new QueryWrapper<TdPmtResultDetailEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_pmt_result_detail", tdPmtResultDetailMapper.selectList(new QueryWrapper<TdPmtResultDetailEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_pst") && tdPstMapper.selectList(new QueryWrapper<TdPstEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_pst", tdPstMapper.selectList(new QueryWrapper<TdPstEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_settle_order") && tdSettleOrderMapper.selectList(new QueryWrapper<TdSettleOrderEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_settle_order", tdSettleOrderMapper.selectList(new QueryWrapper<TdSettleOrderEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_yzb_grant_order") && tdYzbGrantOrderMapper.selectList(new QueryWrapper<TdYzbGrantOrderEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_yzb_grant_order", tdYzbGrantOrderMapper.selectList(new QueryWrapper<TdYzbGrantOrderEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_batch_refund_order") && tdBatchRefundOrderMapper.selectList(new QueryWrapper<TdBatchRefundOrderEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_batch_refund_order", tdBatchRefundOrderMapper.selectList(new QueryWrapper<TdBatchRefundOrderEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_dct_result_detail") && tdDctResultDetailMapper.selectList(new QueryWrapper<TdDctResultDetailEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_dct_result_detail", tdDctResultDetailMapper.selectList(new QueryWrapper<TdDctResultDetailEntity>().eq("td_no", td_no)));
            }
            if (queryTables.contains("td_order_item_refund_order") && tdOrderItemRefundOrderMapper.selectList(new QueryWrapper<TdOrderItemRefundOrderEntity>().eq("td_no", td_no)).size() != 0) {
                resultMap.put("td_order_item_refund_order", tdOrderItemRefundOrderMapper.selectList(new QueryWrapper<TdOrderItemRefundOrderEntity>().eq("td_no", td_no)));
            }

            //4-获取 pf_order id :td_order 一对多 pf_order
            List<Long> pf_order_ids = pfOrderMapper.selectList(new QueryWrapper<PfOrderEntity>().eq("biz_order_id", td_no)).stream().map(PfOrderEntity::getId).collect(Collectors.toList());
            if (pf_order_ids.size() > 0) {
                if (queryTables.contains("pf_order") && pfOrderMapper.selectList(new QueryWrapper<PfOrderEntity>().eq("biz_order_id", td_no)).size() != 0) {
                    resultMap.put("pf_order", pfOrderMapper.selectList(new QueryWrapper<PfOrderEntity>().eq("biz_order_id", td_no)));
                }
                if (queryTables.contains("pf_order_detail") && pfOrderDetailMapper.selectList(new QueryWrapper<PfOrderDetailEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_detail", pfOrderDetailMapper.selectList(new QueryWrapper<PfOrderDetailEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_status") && pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatusEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_status", pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatusEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_stock") && pfOrderStockMapper.selectList(new QueryWrapper<PfOrderStockEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_stock", pfOrderStockMapper.selectList(new QueryWrapper<PfOrderStockEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_detail_active_record") && pfOrderDetailActiveRecordMapper.selectList(new QueryWrapper<PfOrderDetailActiveRecordEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_detail_active_record", pfOrderDetailActiveRecordMapper.selectList(new QueryWrapper<PfOrderDetailActiveRecordEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_detail_advance_record") && pfOrderDetailAdvanceRecordMapper.selectList(new QueryWrapper<PfOrderDetailAdvanceRecordEntity>().in("advance_pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_detail_advance_record", pfOrderDetailAdvanceRecordMapper.selectList(new QueryWrapper<PfOrderDetailAdvanceRecordEntity>().in("advance_pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_detail_debt_record") && pfOrderDetailDebtRecordMapper.selectList(new QueryWrapper<PfOrderDetailDebtRecordEntity>().in("owe_pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_detail_debt_record", pfOrderDetailDebtRecordMapper.selectList(new QueryWrapper<PfOrderDetailDebtRecordEntity>().in("owe_pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_item_biz") && pfOrderItemBizMapper.selectList(new QueryWrapper<PfOrderItemBizEntity>().in("pf_order_id_to_append", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_order_item_biz", pfOrderItemBizMapper.selectList(new QueryWrapper<PfOrderItemBizEntity>().in("pf_order_id_to_append", pf_order_ids)));
                }
                if (queryTables.contains("pf_coupon_record") && pfCouponRecordMapper.selectList(new QueryWrapper<PfCouponRecordEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_coupon_record", pfCouponRecordMapper.selectList(new QueryWrapper<PfCouponRecordEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_debt_repay_record") && pfDebtRepayRecordMapper.selectList(new QueryWrapper<PfDebtRepayRecordEntity>().in("repay_pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_debt_repay_record", pfDebtRepayRecordMapper.selectList(new QueryWrapper<PfDebtRepayRecordEntity>().in("repay_pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_rights_status") && pfRightsStatusMapper.selectList(new QueryWrapper<PfRightsStatusEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_rights_status", pfRightsStatusMapper.selectList(new QueryWrapper<PfRightsStatusEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_scheme_order_relation") && pfSchemeOrderRelationMapper.selectList(new QueryWrapper<PfSchemeOrderRelationEntity>().in("order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_scheme_order_relation", pfSchemeOrderRelationMapper.selectList(new QueryWrapper<PfSchemeOrderRelationEntity>().in("order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_status_log") && pfStatusLogMapper.selectList(new QueryWrapper<PfStatusLogEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_status_log", pfStatusLogMapper.selectList(new QueryWrapper<PfStatusLogEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_stock_log") && pfStockLogMapper.selectList(new QueryWrapper<PfStockLogEntity>().in("biz_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_stock_log", pfStockLogMapper.selectList(new QueryWrapper<PfStockLogEntity>().in("biz_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_asset") && pfAssetMapper.selectList(new QueryWrapper<PfAssetEntity>().in("pf_order_id", pf_order_ids)).size() != 0) {
                    resultMap.put("pf_asset", pfAssetMapper.selectList(new QueryWrapper<PfAssetEntity>().in("pf_order_id", pf_order_ids)));
                }
                if (queryTables.contains("pf_order_pre_accept_order") && pfOrderPreAcceptOrderMapper.selectList(new QueryWrapper<PfOrderPreAcceptOrderEntity>().in("biz_id", td_no)).size() != 0) {
                    resultMap.put("pf_order_pre_accept_order", pfOrderPreAcceptOrderMapper.selectList(new QueryWrapper<PfOrderPreAcceptOrderEntity>().in("biz_id", td_no)));
                }
                if (queryTables.contains("pf_order_split_detail") && pfOrderSplitDetailMapper.selectList(new QueryWrapper<PfOrderSplitDetailEntity>().in("biz_id", td_no)).size() != 0) {
                    resultMap.put("pf_order_split_detail", pfOrderSplitDetailMapper.selectList(new QueryWrapper<PfOrderSplitDetailEntity>().in("biz_id", td_no)));
                }

            }
            //6-mk_* 表数据
            if (queryTables.contains("mk_biz_record") && mkBizRecordMapper.selectList(new QueryWrapper<MkBizRecordEntity>().in("biz_order_id", td_no)).size() != 0) {
                resultMap.put("mk_biz_record", mkBizRecordMapper.selectList(new QueryWrapper<MkBizRecordEntity>().in("biz_order_id", td_no)));
            }
            if (queryTables.contains("mk_capital_account_record") && mkCapitalAccountRecordMapper.selectList(new QueryWrapper<MKCapitalAccountRecordEntity>().in("td_order_id", request.getTdOrderId())).size() != 0) {
                resultMap.put("mk_capital_account_record", mkCapitalAccountRecordMapper.selectList(new QueryWrapper<MKCapitalAccountRecordEntity>().in("td_order_id", request.getTdOrderId())));
            }
            if (queryTables.contains("mk_join_record") && mkJoinRecordMapper.selectList(new QueryWrapper<MkJoinRecordEntity>().in("biz_order_id", td_no)).size() != 0) {
                resultMap.put("mk_join_record", mkJoinRecordMapper.selectList(new QueryWrapper<MkJoinRecordEntity>().in("biz_order_id", td_no)));
            }
            if (queryTables.contains("mk_redeem_code_join_record") && mkRedeemCodeJoinRecordMapper.selectList(new QueryWrapper<MKRedeemCodeJoinRecordEntity>().in("biz_id", td_no)).size() != 0) {
                resultMap.put("mk_redeem_code_join_record", mkRedeemCodeJoinRecordMapper.selectList(new QueryWrapper<MKRedeemCodeJoinRecordEntity>().in("biz_id", td_no)));
            }
            //7-open_* 表数据
            if (queryTables.contains("open_app_biz_id_mapping") && openAppBizIdMappingMapper.selectList(new QueryWrapper<OpenAppBizIdMappingEntity>().in("ycm_biz_id", td_no)).size() != 0) {
                resultMap.put("open_app_biz_id_mapping", openAppBizIdMappingMapper.selectList(new QueryWrapper<OpenAppBizIdMappingEntity>().in("ycm_biz_id", td_no)));
            }
            if (queryTables.contains("open_app_order_id_mapping") && openAppOrderIdMappingMapper.selectList(new QueryWrapper<OpenAppOrderIdMappingEntity>().in("ycm_td_order_id", td_no)).size() != 0) {
                resultMap.put("open_app_order_id_mapping", openAppOrderIdMappingMapper.selectList(new QueryWrapper<OpenAppOrderIdMappingEntity>().in("ycm_td_order_id", td_no)));
            }
            //8-gf 表数据
            if (queryTables.contains("gf_asset") && gfAssetMapper.selectList(new QueryWrapper<GfAssetEntity>().in("biz_id", td_no)).size() != 0) {
                resultMap.put("gf_asset", gfAssetMapper.selectList(new QueryWrapper<GfAssetEntity>().in("biz_id", td_no)));
            }

        } else {
            return resultMap;
        }
        return resultMap;
    }
}