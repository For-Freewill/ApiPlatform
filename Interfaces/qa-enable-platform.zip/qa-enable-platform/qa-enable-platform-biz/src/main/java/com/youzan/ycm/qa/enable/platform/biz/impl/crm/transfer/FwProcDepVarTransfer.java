package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwProcDepVarDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwProcDepVarDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 流程依赖的变量
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwProcDepVarTransfer {

	public static FwProcDepVarDTO toBO(FwProcDepVarDO d) {

		if (d == null) {

			return null;
		}

		FwProcDepVarDTO fwProcDepVarBO = new FwProcDepVarDTO();
		fwProcDepVarBO.setId(d.getId());
		fwProcDepVarBO.setKdtId(d.getKdtId());
		fwProcDepVarBO.setOrderId(d.getOrderId());
		fwProcDepVarBO.setAppId(d.getAppId());
		fwProcDepVarBO.setItemId(d.getItemId());
		fwProcDepVarBO.setProductTypeAlias(d.getProductTypeAlias());
		fwProcDepVarBO.setLevel(d.getLevel());
		fwProcDepVarBO.setIncludeKaPlugin(d.getIncludeKaPlugin());
		fwProcDepVarBO.setExpireTime(d.getExpireTime());
		fwProcDepVarBO.setBelongDepartmentIds(d.getBelongDepartmentIds());
		fwProcDepVarBO.setBelongProviderId(d.getBelongProviderId());
		fwProcDepVarBO.setFuwuBelongTeam(d.getFuwuBelongTeam());
		fwProcDepVarBO.setFuwuBelongId(d.getFuwuBelongId());
		fwProcDepVarBO.setInnerFlag(d.getInnerFlag());
		fwProcDepVarBO.setVersion(d.getVersion());
		fwProcDepVarBO.setCreatedAt(d.getCreatedAt());
		fwProcDepVarBO.setUpdatedAt(d.getUpdatedAt());

		return fwProcDepVarBO;
	}

	public static FwProcDepVarDO toDO(FwProcDepVarDTO bo) {

        if (bo == null) {

			return null;
		}

		FwProcDepVarDO fwProcDepVarDO = new FwProcDepVarDO();
		fwProcDepVarDO.setId(bo.getId());
		fwProcDepVarDO.setKdtId(bo.getKdtId());
		fwProcDepVarDO.setOrderId(bo.getOrderId());
		fwProcDepVarDO.setAppId(bo.getAppId());
		fwProcDepVarDO.setItemId(bo.getItemId());
		fwProcDepVarDO.setProductTypeAlias(bo.getProductTypeAlias());
		fwProcDepVarDO.setLevel(bo.getLevel());
		fwProcDepVarDO.setIncludeKaPlugin(bo.getIncludeKaPlugin());
		fwProcDepVarDO.setExpireTime(bo.getExpireTime());
		fwProcDepVarDO.setBelongDepartmentIds(bo.getBelongDepartmentIds());
		fwProcDepVarDO.setBelongProviderId(bo.getBelongProviderId());
		fwProcDepVarDO.setFuwuBelongTeam(bo.getFuwuBelongTeam());
		fwProcDepVarDO.setFuwuBelongId(bo.getFuwuBelongId());
		fwProcDepVarDO.setInnerFlag(bo.getInnerFlag());
		fwProcDepVarDO.setVersion(bo.getVersion());
		fwProcDepVarDO.setCreatedAt(bo.getCreatedAt());
		fwProcDepVarDO.setUpdatedAt(bo.getUpdatedAt());

		return fwProcDepVarDO;
	}

	public static List<FwProcDepVarDTO> toBOList(List<FwProcDepVarDO> doList) {

		if (doList == null) {

			return new ArrayList<FwProcDepVarDTO>();
		}

		List<FwProcDepVarDTO> boList = new ArrayList<FwProcDepVarDTO>();
		for (FwProcDepVarDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwProcDepVarDO> toDOList(List<FwProcDepVarDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwProcDepVarDO>();
		}

		List<FwProcDepVarDO> doList = new ArrayList<FwProcDepVarDO>();

		for (FwProcDepVarDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
