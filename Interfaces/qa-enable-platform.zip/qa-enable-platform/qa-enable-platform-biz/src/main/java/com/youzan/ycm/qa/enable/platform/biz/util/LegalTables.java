package com.youzan.ycm.qa.enable.platform.biz.util;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author wulei
 * @Date 2020/11/11 16:57
 */
public class LegalTables {
    /**
     * 订单查询合法列表
     *
     * @return
     */
    public static List<String> legalTables() {
        return Stream.of("td_order", "td_order_item", "td_pay_order", "td_pay_refund_order", "td_pmt_result_detail", "td_pst", "td_settle_order", "td_yzb_grant_order",
                "td_batch_refund_order", "td_dct_result_detail", "td_order_item_refund_order", "pf_order", "pf_order_detail", "pf_order_status", "pf_order_stock", "pf_order_detail_active_record",
                "pf_order_detail_advance_record", "pf_order_detail_debt_record", "pf_order_item_biz", "pf_coupon_record", "pf_debt_repay_record", "pf_rights_status", "pf_scheme_order_relation",
                "pf_status_log", "pf_stock_log", "pf_asset", "pf_order_pre_accept_order", "pf_order_split_detail", "mk_biz_record", "mk_capital_account_record", "mk_join_record", "mk_redeem_code_join_record", "open_app_biz_id_mapping", "open_app_order_id_mapping",
                "gf_asset").collect(Collectors.toList());
    }

    /**
     * 新激活码关联表
     *
     * @return
     */
    public static List<String> newActivationCodeLegalTables() {
        return Stream.of("cd_redeem_code", "cd_redeem_code_batch", "cd_redeem_code_apply_record", "cd_redeem_code_apply_mutex", "cd_redeem_code_distribute_record", "td_activation_code", "td_activation_code_goods_item", "td_activation_code_apply_record").collect(Collectors.toList());
    }


    /**
     * 云服务费计费侧表
     *
     * @return
     */
    public static List<String> yunFeeFcFeeLegalTables() {
        return Stream.of("fc_fee_resource_package", "fc_fee_yop_protocol", "fc_fee_resource_package_log", "fc_fee_yop_protocol_log").collect(Collectors.toList());
    }
}
