package com.youzan.ycm.qa.enable.platform.biz.impl.crm.fuwu;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.CrmShopProductActiveDTO;
import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ResourceTransResponseDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu.ResourceTransService;
import com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.ShopDO;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.fuwu.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.List;

/**
 * @Author Jiping.Hu
 * @Description 根据店铺id查询服务资源流转链路信息
 * @Date
 **/
@Slf4j
@Service(value = "resourceTransService")
public class ResourceTransServiceImpl implements ResourceTransService {

    @Resource
    private ShopMapper shopMapper;
    @Resource
    private CrmShopProductActiveMapper shopProActiveMapper;
    @Resource
    private CrmShopProductKdtIndexMapper  shopProKdtIndexMapper;
    @Resource
    private CrmShopProductServiceTimeMapper shopServiceTimeMapper;
    @Resource
    private  CrmShopProductActiveHistoryMapper crmShopProductActiveHistoryMapper;
    @Resource
    private OrderBelongingMapper orderBelongingMapper;
    @Resource
    private FwProcInstMapper fwProcInstMapper;
    @Resource
    private FwHistProcInstMapper fwHistProcInstMapper;
    @Resource
    private FwProcRoleMapper fwProcRoleMapper;
    @Resource
    private FwHistProcRoleMapper fwHistProcRoleMapper;
    @Resource
    private FwProcDepVarMapper fwProcDepVarMapper;
    @Resource
    private FwProcDepVarSnapshotMapper fwProcDepVarSnapshotMapper;
    @Resource
    private FwRoleDepVarMapper fwRoleDepVarMapper;
    @Resource
    private FwShopRoleMapper  fwShopRoleMapper;
    @Resource
    private ShopAttributeDataMapper shopAttributeMapper;
    @Resource
    private FwFuwuBelongAssignMapper fwFuwuBelongAssignMapper;
    @Resource
    private  FwShoproleBindingHistoryMapper fwShoproleBindingHistoryMapper;
    @Resource
    private FwShoproleBindingMapper  fwShoproleBindingMapper;
    @Resource
    private FwShopRolePropertyMapper fwShopRolePropertyMapper;
    @Resource
    private FwShopRoleStateHistMapper fwShopRoleStateHistMapper;

    public ResourceTransServiceImpl() {
    }

    @Override
    public PlainResult<ResourceTransResponseDTO> queryByTdKdtId(Long kdtId, String env) {

        if (null == kdtId ){
            throw new EnableException(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMsg());
        }

        List<ShopDO> shopDOList = shopMapper.findByIds(new HashSet<Long>(){{ add(kdtId); }});

        List<CrmShopProductActiveDTO> crmShopProductActiveDTO = CrmShopProductActiveTransfer.toBOList(shopProActiveMapper.findByIds(new HashSet<Long>(){{ add(kdtId); }}));

        ResourceTransResponseDTO resourceTransResponseDTO = ResourceTransResponseDTO.builder()
                .shopDTOList(ShopTransfer.toBOList(shopDOList))
                .crmShopProductActiveDTOList(crmShopProductActiveDTO)
                .crmShopProductServiceTimeDTOList(CrmShopProductServiceTimeTransfer.toBOList(shopServiceTimeMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .crmShopProductKdtIndexDTOList(CrmShopProductKdtIndexTransfer.toBOList(shopProKdtIndexMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .orderBelongingDTOList(OrderBelongingTransfer.toBOList(orderBelongingMapper.findByIds(new HashSet<Long>(){{
                    add(crmShopProductActiveDTO.size() ==  0?null:crmShopProductActiveDTO.get(0).getOrderId()); }})))
                .fwFuwuBelongAssignDTOList(FwFuwuBelongAssignTransfer.toBOList(fwFuwuBelongAssignMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwProcInstDTOList(FwProcInstTransfer.toBOList(fwProcInstMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwHistProcInstDTOList(FwHistProcInstTransfer.toBOList(fwHistProcInstMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwProcRoleDTOList(FwProcRoleTransfer.toBOList(fwProcRoleMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwHistProcRoleDTOList(FwHistProcRoleTransfer.toBOList(fwHistProcRoleMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwRoleDepVarDTOList(FwRoleDepVarTransfer.toBOList(fwRoleDepVarMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwProcDepVarDTOList(FwProcDepVarTransfer.toBOList(fwProcDepVarMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwProcDepVarSnapshotDTOList(FwProcDepVarSnapshotTransfer.toBOList(fwProcDepVarSnapshotMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwShopRoleDTOList(FwShopRoleTransfer.toBOList(fwShopRoleMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .shopAttributeDataDTOList(ShopAttributeDataTransfer.toBOList(shopAttributeMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwShoproleBindingDTOList(FwShoproleBindingTransfer.toBOList(fwShoproleBindingMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwShoproleBindingHistoryDTOList(FwShoproleBindingHistoryTransfer.toBOList(fwShoproleBindingHistoryMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwShopRolePropertyDTOList(FwShopRolePropertyTransfer.toBOList(fwShopRolePropertyMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .fwShopRoleStateHistDTOList(FwShopRoleStateHistTransfer.toBOList(fwShopRoleStateHistMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))
                .crmShopProductActiveHistoryDTOList(CrmShopProductActiveHistoryTransfer.toBOList(crmShopProductActiveHistoryMapper.findByIds(new HashSet<Long>(){{
                    add(kdtId); }})))

                .build();

        PlainResult<ResourceTransResponseDTO> plainResult = new PlainResult<>();
        plainResult.setData(resourceTransResponseDTO);
        return plainResult;
    }
}
