package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreInsertRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreQueryRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreUpdateRequest;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableProgramScoreService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.DateUtils;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScorePO;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreQAPO;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableProgramScoreMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @author wulei
 * @date 2021-5-21
 */
@Slf4j
@Service(value = "enableProgramScoreService")
public class EnableProgramScoreServiceImpl extends ServiceImpl<EnableProgramScoreMapper, EnableProgramScoreEntity> implements EnableProgramScoreService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private EnableProgramScoreService enableProgramScoreService;


    @Resource
    private EnableProgramScoreMapper enableProgramScoreMapper;

    /**
     * 新增质量分记录
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<Boolean> insert(EnableProgramScoreInsertRequest request) {
        PlainResult<Boolean> plainResult = new PlainResult<>();
        //入参校验
        checkRequest(request);

        // 插入记录
        Boolean isSave = null;

        isSave = enableProgramScoreService.save(transfer(request));
        if (isSave) {
            plainResult.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }
        return plainResult;
    }

    /**
     * 入参数校验
     */
    private void checkRequest(EnableProgramScoreInsertRequest request) {
        // 校验入参数
        AssertUtil.isAllNotNone(request, "request不能为空");
        AssertUtil.isAllNotNone(request.getProgramName(), "项目名称不能为空");
        AssertUtil.isAllNotNone(request.getProgramQa(), "项目测试不能为空");
        AssertUtil.isAllNotNone(request.getProgramDev(), "项目开发不能为空");
        AssertUtil.isAllNotNone(request.getProgramOnlineTime(), "上线时间不能为空");

        AssertUtil.isAllNotNone(request.getXiaolvUrl(), "效率地址不能为空");
        AssertUtil.isAllNotNone(request.getReportUrl(), "报告地址不能为空");
        AssertUtil.isAllNotNone(request.getTestCase(), "测试分析地址不能为空");
        AssertUtil.isAllNotNone(request.getTeam(), "team不能为空");
    }

    /**
     * BO 转换
     */
    private EnableProgramScoreEntity transfer(EnableProgramScoreInsertRequest request) {
        EnableProgramScoreEntity enableProgramScoreEntity = new EnableProgramScoreEntity();
        BeanUtils.copyProperties(request, enableProgramScoreEntity);

        if (request.getScoreTotal() == null) {
            enableProgramScoreEntity.setScoreTotal(Double.valueOf(0));
        }
        if (request.getScorePrd() == null) {
            enableProgramScoreEntity.setScorePrd(Double.valueOf(0));
        }
        if (request.getScoreDev() == null) {
            enableProgramScoreEntity.setScoreDev(Double.valueOf(0));
        }
        if (request.getScoreQa() == null) {
            enableProgramScoreEntity.setScoreQa(Double.valueOf(0));
        }
        if (request.getScoreOnline() == null) {
            enableProgramScoreEntity.setScoreOnline(Double.valueOf(0));
        }
        if (request.getScorePm() == null) {
            enableProgramScoreEntity.setScorePm(Double.valueOf(0));
        }

        enableProgramScoreEntity.setProgramOnlineTime(DateUtils.parseDate(request.getProgramOnlineTime()));
        return enableProgramScoreEntity;
    }

    /**
     * 参数查询
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<Map<String, List>> selectByParam(EnableProgramScoreQueryRequest request) {
        Map<String, List> resultData = new HashMap();
        PlainResult<Map<String, List>> plainResult = new PlainResult<>();
        AssertUtil.isAllNotNone(request, "参数异常");
        List<EnableProgramScoreEntity> result = enableProgramScoreMapper.selectList(requestWrapper(request));
        Double scoreTotal = result.stream().mapToDouble(x -> x.getScoreTotal()).sum();
        Double scoreDev = result.stream().mapToDouble(x -> x.getScoreDev()).sum();
        Double scoreOnline = result.stream().mapToDouble(x -> x.getScoreOnline()).sum();
        Double scorePrd = result.stream().mapToDouble(x -> x.getScorePrd()).sum();
        Double scoreQa = result.stream().mapToDouble(x -> x.getScoreQa()).sum();
        Double scorePm = result.stream().mapToDouble(x -> x.getScorePm()).sum();
        List<Map<String, String>> analytics = new ArrayList<>();
        Map<String, String> anaMap = new HashMap<>();
        DecimalFormat df = new DecimalFormat("0.00");
        Double reduceSum = scoreDev + scoreOnline + scorePrd + scoreQa;
        Double scoreDevPercentage = scoreDev / reduceSum * 100;
        Double scoreOnlinePercentage = scoreOnline / reduceSum * 100;
        Double scorePrdPercentage = scorePrd / reduceSum * 100;
        Double scoreQaPercentage = scoreQa / reduceSum * 100;
        Double scorePmPercentage = scorePm / reduceSum * 100;

        anaMap.put("proCount", String.valueOf(result.size()));
        anaMap.put("scoreTotal", df.format(scoreTotal));
        anaMap.put("scoreDev", df.format(scoreDev));
        anaMap.put("scoreDevPercentage", df.format(scoreDevPercentage) + "%");

        anaMap.put("scoreOnline", df.format(scoreOnline));
        anaMap.put("scoreOnlinePercentage", df.format(scoreOnlinePercentage) + "%");

        anaMap.put("scorePrd", df.format(scorePrd));
        anaMap.put("scorePrdPercentage", df.format(scorePrdPercentage) + "%");

        anaMap.put("scoreQa", df.format(scoreQa));
        anaMap.put("scoreQaPercentage", df.format(scoreQaPercentage) + "%");

        anaMap.put("scorePm", df.format(scorePm));
        anaMap.put("scorePmPercentage", df.format(scorePmPercentage) + "%");

        anaMap.put("reduceSum", df.format(reduceSum));
        analytics.add(0, anaMap);

        resultData.put("results", result);
        resultData.put("analytics", analytics);
        plainResult.setData(resultData);
        return plainResult;
    }

    /**
     * 项目统计：按月统计，按人员统计，5星统计
     *
     * @param request
     * @return
     */

    @Override
    public PlainResult<Map<String, List>> analyticByParam(EnableProgramScoreQueryRequest request) {
        Map<String, List> resultData = new HashMap();
        PlainResult<Map<String, List>> plainResult = new PlainResult<>();
        //项目：按照月份汇总
        List<EnableProgramScorePO> monthResult = enableProgramScoreMapper.monthAnalytics(request.getTeam());
        resultData.put("monthTotal", monthResult);
        //项目：按照测试人员汇总并排行
        List<EnableProgramScoreQAPO> qaResult = enableProgramScoreMapper.qaAnalytics(request.getTeam());
        resultData.put("qaTotal", qaResult);
        //项目：5星比例
        DecimalFormat df = new DecimalFormat("0.00");
        Double totalCount = Double.valueOf(enableProgramScoreMapper.selectList(new QueryWrapper<EnableProgramScoreEntity>().lambda().eq(EnableProgramScoreEntity::getTeam, request.getTeam()).ge(EnableProgramScoreEntity::getProgramOnlineTime, 20220101)).size());
        Double fiveStarCount = Double.valueOf(enableProgramScoreMapper.selectList(new QueryWrapper<EnableProgramScoreEntity>().lambda().eq(EnableProgramScoreEntity::getTeam, request.getTeam()).ge(EnableProgramScoreEntity::getScoreTotal, 4.5).ge(EnableProgramScoreEntity::getProgramOnlineTime, 20220101)).size());
        resultData.put("fiveStarTotal", Arrays.asList(df.format(fiveStarCount / totalCount * 100)));
        resultData.put("H2Total", Arrays.asList(totalCount));

        plainResult.setData(resultData);
        return plainResult;
    }

    /**
     * 入参数判断
     */
    private QueryWrapper<EnableProgramScoreEntity> requestWrapper(EnableProgramScoreQueryRequest request) {
        QueryWrapper<EnableProgramScoreEntity> wrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(request.getTeam())) {
            wrapper.lambda().eq(EnableProgramScoreEntity::getTeam, request.getTeam());
        }
        if (StringUtils.isNotEmpty(request.getProgramName())) {
            wrapper.lambda().like(EnableProgramScoreEntity::getProgramName, request.getProgramName());
        }
        if (StringUtils.isNotEmpty(request.getProgramQa())) {
            wrapper.lambda().eq(EnableProgramScoreEntity::getProgramQa, request.getProgramQa());
        }
        if (StringUtils.isNotEmpty(request.getScoreTotal())) {
            wrapper.lambda().ge(EnableProgramScoreEntity::getScoreTotal, Double.valueOf(request.getScoreTotal()));
        }
        if (StringUtils.isNotEmpty(request.getBeginOnlineTime()) && StringUtils.isNotEmpty(request.getEndOnlineTime())) {
            wrapper.lambda().between(EnableProgramScoreEntity::getProgramOnlineTime, request.getBeginOnlineTime(), request.getEndOnlineTime());
        }
        wrapper.lambda().orderByDesc(EnableProgramScoreEntity::getProgramOnlineTime);
        return wrapper;
    }

    /**
     * 分页查询全部
     *
     * @param team
     * @param page
     * @return
     */
    @Override
    public PlainResult<IPage<EnableProgramScoreEntity>> selectAll(String team, IPage page) {
        QueryWrapper<EnableProgramScoreEntity> wrapper = new QueryWrapper<>();
        PlainResult<IPage<EnableProgramScoreEntity>> plainResult = new PlainResult<>();

        // 校验入参数
        AssertUtil.isAllNotNone(team, "team不能为空");
        if (team.equals("商业化") || team.equals("CRM")) {
            wrapper.lambda().eq(EnableProgramScoreEntity::getTeam, team);
            IPage<EnableProgramScoreEntity> result = enableProgramScoreMapper.selectPage(page, wrapper);
            REQUEST_LOGGER.info("分页查询team=" + team);
            plainResult.setData(result);
            plainResult.setSuccess(true);
            plainResult.setCode(200);
            return plainResult;
        } else {
            plainResult.setSuccess(false);
            plainResult.setMessage("team设置错误");
            return plainResult;
        }
    }


    /**
     * 更新记录
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<Boolean> updateById(EnableProgramScoreUpdateRequest request) {
        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 校验入参数
        AssertUtil.isAllNotNone(request.getId(), "id不能为空");
        EnableProgramScoreEntity enableProgramScoreEntity = new EnableProgramScoreEntity();
        BeanUtils.copyProperties(request, enableProgramScoreEntity);
        //
        int result = enableProgramScoreMapper.updateById(enableProgramScoreEntity);

        if (result >= 1) {
            plainResult.setMessage("更新成功");
            return plainResult;
        } else {
            plainResult.setCode(500);
            plainResult.setData(false);
            plainResult.setSuccess(false);
            plainResult.setMessage("更新失败");
            return plainResult;
        }
    }

    /**
     * 逻辑删除by id
     *
     * @param id
     * @return
     */
    @Override
    public PlainResult<Boolean> deleteById(Long id) {
        PlainResult<Boolean> plainResult = new PlainResult<>();
        // 校验入参数
        AssertUtil.isAllNotNone(id, "id不能为空");
        if (id >= 1) {
            int result = enableProgramScoreMapper.deleteById(id);
            if (result >= 1) {
                plainResult.setMessage("删除成功");
                return plainResult;
            } else {
                plainResult.setCode(500);
                plainResult.setData(false);
                plainResult.setSuccess(false);
                plainResult.setMessage("删除失败");
                return plainResult;
            }
        }
        return plainResult;
    }

    /**
     * 根据ID查询详情
     *
     * @param id
     * @return
     */
    @Override
    public PlainResult<EnableProgramScoreEntity> selectById(Long id) {
        PlainResult<EnableProgramScoreEntity> plainResult = new PlainResult<>();
        // 校验入参数
        AssertUtil.isAllNotNone(id, "id不能为空");
        if (id >= 1) {
            EnableProgramScoreEntity result = enableProgramScoreMapper.selectById(id);
            plainResult.setData(result);
            return plainResult;
        }
        return plainResult;
    }
}