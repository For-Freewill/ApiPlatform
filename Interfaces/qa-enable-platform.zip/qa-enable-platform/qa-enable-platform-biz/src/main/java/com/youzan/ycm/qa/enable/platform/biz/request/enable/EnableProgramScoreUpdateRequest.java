package com.youzan.ycm.qa.enable.platform.biz.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2020/11/19 16:50
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableProgramScoreUpdateRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;
    /**
     * 项目名称
     */
    private Long id;

    /**
     * 项目名称
     */
    private String programName;

    /**
     * 项目测试
     */
    private String programQa;

    /**
     * 项目开发
     */
    private String programDev;

    /**
     * 上线时间
     */
    private String programOnlineTime;

    /**
     * 总分-满5分
     */
    private Double scoreTotal;

    /**
     * 需求扣分
     */
    private Double scorePrd;

    /**
     * 研发扣分
     */
    private Double scoreDev;

    /**
     * 测试扣分
     */
    private Double scoreQa;

    /**
     * 上线扣分
     */
    private Double scoreOnline;

    /**
     * 项目管理
     */
    private Double scorePm;

    /**
     * 效率地址
     */
    private String xiaolvUrl;

    /**
     * 报告地址
     */
    private String reportUrl;

    /**
     * 测试分析
     */
    private String testCase;

    /**
     * 小组
     */
    private String team;

    /**
     * 说明
     */
    private String ext;

    /**
     * tags
     */
    private String tags;
}
