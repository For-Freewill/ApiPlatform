package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.cache;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.cache.FlushGoodsAllCatchService;
import com.youzan.yop.api.GoodsToolsRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-04 20:26
 **/
@Slf4j
@Service("flushGoodsAllCatchService")
public class FlushGoodsAllCatchServiceImpl implements FlushGoodsAllCatchService {

    @Resource
    private GoodsToolsRemoteService goodsToolsRemoteService;

    /**
     * 清理商品缓存
     */
    @Override
    public PlainResult<Boolean> flushGoodsAllCatch(Integer yopAppId) {
        PlainResult<Boolean> result = goodsToolsRemoteService.flushGoodsAllCatch(yopAppId);
        result.setData(Boolean.TRUE);
        return result;
    }
}
