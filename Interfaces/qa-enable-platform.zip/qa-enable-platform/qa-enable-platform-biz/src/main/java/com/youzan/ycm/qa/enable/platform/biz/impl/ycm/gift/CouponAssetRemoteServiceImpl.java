package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:26
 **/
//@Service
//public class CouponAssetRemoteServiceImpl implements CouponAssetRemoteService {
//
//    @Resource
//    private CouponAssetRemoteService couponAssetRemoteService;
//
//    /**
//     * 查询券
//     */
//
//    @Override
//    public PlainResult<PageResponse<CouponAssetDTO>> queryCouponAssetListByKdtId(QueryCouponAssetRequest request) {
//
//        PlainResult<PageResponse<CouponAssetDTO>> result = couponAssetRemoteService.queryCouponAssetListByKdtId(request);
//        return result;
//    }
//}
