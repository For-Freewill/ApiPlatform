package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.inter;

import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.BaseInvokeRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.inter.HttpInvokeRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.inter.InterfaceService;
import com.youzan.ycm.qa.enable.platform.biz.util.HttpClientUtil;
import org.springframework.stereotype.Service;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-24 20:38
 **/

@Service("Http_interfaceService")
public class HttpInterfaceServiceImpl implements InterfaceService {
    @Override
    public Object doMethodInvoke(BaseInvokeRequest invokeRequest) {
        HttpInvokeRequest httpInvokeRequest = (HttpInvokeRequest) invokeRequest;
        switch (httpInvokeRequest.getHttpInvokeWayEnum()){
            case GET:
                return HttpClientUtil.sendGet(httpInvokeRequest.getUrl(),httpInvokeRequest.getParameters());
            case POST:
                return HttpClientUtil.sendPost(httpInvokeRequest.getUrl(),httpInvokeRequest.getParameters());
        }
        return null;
    }
}

