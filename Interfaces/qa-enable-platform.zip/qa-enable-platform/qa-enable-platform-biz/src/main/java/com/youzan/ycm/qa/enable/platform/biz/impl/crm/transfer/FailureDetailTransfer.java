package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;


import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.FailureDetailBO;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.FailureDetailEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 失败处理
 *
 * @author hujiping
 * @email hujiping@youzan.com
 * @date 2021-08-23 11:52:02
 */
public class FailureDetailTransfer {

    public static FailureDetailBO toBO(FailureDetailEntity d) {

        if (d == null) {

            return null;
        }

        FailureDetailBO failureDetailBO = new FailureDetailBO();
        failureDetailBO.setId(d.getId());
        failureDetailBO.setCaseId(d.getCaseId());
        failureDetailBO.setFailureCause(d.getFailureCause());
        failureDetailBO.setHandle(d.getHandle());
        failureDetailBO.setCreatedAt(d.getCreatedAt());
        failureDetailBO.setUpdatedAt(d.getUpdatedAt());

        return failureDetailBO;
    }

    public static FailureDetailEntity toDO(FailureDetailBO bo) {

        if (bo == null) {

            return null;
        }

        FailureDetailEntity failureDetailDO = new FailureDetailEntity();
        failureDetailDO.setId(bo.getId());
        failureDetailDO.setExcuteId(bo.getExcuteId());
        failureDetailDO.setJobId(bo.getJobId());
        failureDetailDO.setCaseId(bo.getCaseId());
        failureDetailDO.setFailureCause(bo.getFailureCause());
        failureDetailDO.setHandle(bo.getHandle());
        if (null==bo.getCreatedAt())
            failureDetailDO.setCreatedAt(new Date());
        else
            failureDetailDO.setCreatedAt(bo.getCreatedAt());
        if (null==bo.getUpdatedAt())
            failureDetailDO.setUpdatedAt(new Date());
        else
            failureDetailDO.setUpdatedAt(bo.getUpdatedAt());

        return failureDetailDO;
    }

    public static List<FailureDetailBO> toBOList(List<FailureDetailEntity> doList) {

        if (doList == null) {

            return new ArrayList<FailureDetailBO>();
        }

        List<FailureDetailBO> boList = new ArrayList<FailureDetailBO>();
        for (FailureDetailEntity d : doList) {

            if (d != null) {

                boList.add(toBO(d));
            }
        }
        return boList;
    }

    public static List<FailureDetailEntity> toDOList(List<FailureDetailBO> boList) {

        if (boList == null) {

            return new ArrayList<FailureDetailEntity>();
        }

        List<FailureDetailEntity> doList = new ArrayList<FailureDetailEntity>();

        for (FailureDetailBO bo : boList) {

            if (bo != null) {

                doList.add(toDO(bo));
            }
        }

        return doList;
    }

}

