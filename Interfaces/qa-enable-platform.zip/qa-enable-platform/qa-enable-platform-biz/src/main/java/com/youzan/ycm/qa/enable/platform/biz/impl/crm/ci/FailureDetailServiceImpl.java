package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.FailureDetailBO;
import com.youzan.ycm.qa.enable.platform.api.enums.CiGroup;
import com.youzan.ycm.qa.enable.platform.api.enums.FailureCause;
import com.youzan.ycm.qa.enable.platform.api.enums.Handle;
import com.youzan.ycm.qa.enable.platform.api.enums.SuiteBelong;
import com.youzan.ycm.qa.enable.platform.api.model.SessionUser;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.FailureDetailRequstDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.FailureDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.FailureDetailService;
import com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer.FailureDetailTransfer;
import com.youzan.ycm.qa.enable.platform.biz.jenkins.JenkinJobEnum;
import com.youzan.ycm.qa.enable.platform.biz.jenkins.JenkinsService;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.po.FailureDetailPo;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CaseDetailMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CiJenkinsJobMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.ExcuteDetailMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.FailureDetailMapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Author Jiping.Hu
 * @Description 失败处理业务类
 * @Date
 **/
@Slf4j
@Service(value = "FailureDetailService")
public class FailureDetailServiceImpl implements FailureDetailService {

    @Resource
    FailureDetailMapper failureDetailMapper;
    @Resource
    CaseDetailMapper  caseDetailMapper;
    @Resource
    ExcuteDetailMapper excuteDetailMapper;
    @Resource
    CiJenkinsJobMapper ciJenkinsJobMapper;
    @Resource
    JenkinsService jenkinsService;

    @Override
    public PlainResult<PageResult<FailureDetailDTO>> findFailureDetailByCondition(PageRequest<FailureDetailRequstDTO> pageRequest) {
        FailureDetailPo failureDetailPo = new FailureDetailPo();
        FailureDetailRequstDTO failureDetailRequstDTO  = pageRequest.getDto();

        if (null != failureDetailRequstDTO ){
            failureDetailPo.setJob_id(failureDetailRequstDTO.getJobIds());
            failureDetailPo.setOwner(null == failureDetailRequstDTO.getOwner()?"":failureDetailRequstDTO.getOwner());
            failureDetailPo.setBelongApp(null == failureDetailRequstDTO.getApplication()?"":failureDetailRequstDTO.getApplication());
            failureDetailPo.setEnv(null == failureDetailRequstDTO.getEnv()?"":failureDetailRequstDTO.getEnv());
            failureDetailPo.setJobGroup(null == failureDetailRequstDTO.getJobGroup()?-1:failureDetailRequstDTO.getJobGroup());
        }
        failureDetailPo.setHandle(0);
        List<FailureDetailByConditionEntity> failureDetailEntityList = failureDetailMapper.findByCondition(failureDetailPo);

        int totalNum = failureDetailEntityList.size();
        int limit = pageRequest.getPageSize();
        int from = (pageRequest.getPageNum()-1)*limit;
        int to   = limit * pageRequest.getPageNum();

        if (to > totalNum) {
            to = totalNum;
        }

        PageResult<FailureDetailDTO> pageResult = new PageResult<>();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        /**查询结果设置**/
        if (totalNum == 0){
            pageResult.setTotalNum(0);
            pageResult.setList(new ArrayList<>());
        } else {
            List<FailureDetailDTO> failureDetailDTOList = new ArrayList<>();

            failureDetailEntityList = failureDetailEntityList.subList(from>totalNum?0:from,to);
            failureDetailEntityList.forEach(result->{
                CaseDetailEntity caseDetailEntity = caseDetailMapper.selectById(result.getCaseId());
                if (null == caseDetailEntity){
                    return;
                }
                FailureDetailDTO failureDetailDTO =  new FailureDetailDTO();
                failureDetailDTO.setJobGroup(CiGroup.of(result.getJobGroup()).getStatus());
                /***组装case信息*/
                failureDetailDTO.setOwner(caseDetailEntity.getCaseAuthor());
                failureDetailDTO.setCaseBelongApp(caseDetailEntity.getCaseBelongApp());
                failureDetailDTO.setCaseBelongClass(caseDetailEntity.getCaseBelongClass());
                failureDetailDTO.setCaseName(caseDetailEntity.getCaseName());
                failureDetailDTO.setCaseId(result.getId());//这里是失败列表的主键id，不是caseid
                /***组装执行信息*/
                ExcuteDetailEntity excuteDetailEntity  = excuteDetailMapper.selectById(result.getExcuteId());
                failureDetailDTO.setEnv(excuteDetailEntity.getEnv());
                failureDetailDTO.setFailureRate(failureRate(result.getCaseId()));
                failureDetailDTO.setExcuteTime(formatter.format(excuteDetailEntity.getCreatedAt()));
                failureDetailDTOList.add(failureDetailDTO);
            });
            pageResult.setTotalNum(totalNum);
            pageResult.setList(failureDetailDTOList);
        }

        PlainResult<PageResult<FailureDetailDTO>> result = new PlainResult<>();
        result.setData(pageResult);
        return result;
    }

    /**
     * 失败率计算
     * @param caseId
     * @return
     */
    private String failureRate(Long  caseId){
        int total = excuteDetailMapper.excuteTotalByCase(caseId).getTotalCount();
        int failureTotal = excuteDetailMapper.excuteFailureByCase(caseId).getFailureTotal();
        String failureRate = "-";
        /***创建一个数值格式化对象 **/
        NumberFormat nfmt = NumberFormat.getInstance();
        nfmt.setMinimumIntegerDigits(2);
        failureRate = nfmt.format((double)failureTotal/total * 100) +"%";
        return failureRate;
    }

    /**
     * 失败原因修改
     * @param caseId 失败case主键
     * @param failureCause
     * @return
     */
    @Override
    public PlainResult<Boolean> updateFailureCase(Long caseId, Integer failureCause) {
        Preconditions.checkArgument(null != caseId ,"id不能为空");
        Preconditions.checkArgument(null != failureCause ,"错误原因不能为空");
        FailureDetailEntity failureDetailEntity_old = failureDetailMapper.selectById(caseId);
        Preconditions.checkArgument(null!= failureDetailEntity_old,"数据不存在");
        failureDetailEntity_old.setFailureCause(FailureCause.of(failureCause).getCode());
        failureDetailEntity_old.setHandle(Handle.TREATED.getCode());
        failureDetailMapper.update(failureDetailEntity_old);
        PlainResult<Boolean> result = new PlainResult<>();
        result.setData(true);
        return result;
    }

    /**
     * 批量修改
     * @param ids
     * @param failureCause
     * @return
     */
    @Override
    public PlainResult<Boolean> batchUpdateFailureCase(String ids, Integer failureCause) {
        PlainResult<Boolean> result = new PlainResult<>();
        log.info("批量处理失败case，ids="+ids);
        String[] splitIds = ids.split(",");
       if (null != ids && splitIds.length != 0){
           for (String id : splitIds){
               updateFailureCase(Long.valueOf(id),failureCause);
           }
       }
        result.setData(false);
        result.setMessage("你还未选中任何失败case");
        return result;

    }

    @Override
    public Long insert(FailureDetailBO failureDetailBO) {
        return failureDetailMapper.add(FailureDetailTransfer.toDO(failureDetailBO));
    }


    /**
     * 失败case重试
     * 不支持批量重试的场景：jobid不属于同一个分组的不支持批量重试；失败case所属的环境不属于同一个环境也不支持
     * 失败重试前，将对应job的id置为-1，防止同一个job重复重试
     * @param ids
     * @return
     */
    @Override
    public PlainResult<Boolean> failureReTry(Set<Long> ids, SessionUser user) {
        PlainResult<Boolean> plainpResult  = new PlainResult<>();
        String env ;
        String application = "";
        List<CiJenkinsJobEntity> ciJenkinsJobEntity = ciJenkinsJobMapper.findByIds(ids);

        int group_count = ciJenkinsJobEntity
                .stream().map(result->result.getJobGroup()).distinct()
                .collect(Collectors.toSet()).size();
        if (group_count != 1){
            plainpResult.setMessage("你选择的失败case不属于同一个分组，请重新选择");
            plainpResult.setData(false);
            return plainpResult;
        }
        int env_count = ciJenkinsJobEntity
                .stream()
                .map(result->result.getJobEnv())
                .distinct()
                .collect(Collectors.toList()).size();
        if (env_count != 1){
            plainpResult.setMessage("你要重试的失败case的环境不一致");
            plainpResult.setData(false);
            return plainpResult;
        }


        env = ciJenkinsJobEntity.get(0).getJobEnv();

        /**
         * 失败重试前，修改对应重试job的referId = -1
         */
        Set<Long> jobSet = ciJenkinsJobEntity.stream().map(ci->ci.getId()).collect(Collectors.toSet());
        for (CiJenkinsJobEntity entity:ciJenkinsJobEntity){
            if (entity.getReferJobId() == 0){
                entity.setReferJobId(-1l);
                ciJenkinsJobMapper.update(entity);
            }
        }

        /**
         * 根据caseID, 过滤重复的失败case
         */
        List<FailureDetailEntity> failureDetailEntityList =  failureDetailMapper.findByJobIds(jobSet);
        failureDetailEntityList.stream().map(
                failureDetailEntity -> failureDetailEntity.getCaseId())
                .distinct()
                .collect(Collectors.toList());

        /**
         * JenkinJobEnum.valueOf(suiteBelong.getBelongGroup().name()).getLine()
         */
        String line = "" ;

        JSONArray jsonArray = new JSONArray();
        for (FailureDetailEntity failureDetailEntity : failureDetailEntityList){
            CaseDetailEntity caseDetailEntity = caseDetailMapper.findById(failureDetailEntity.getCaseId());
            jsonArray.add(caseDetailEntity.getCaseBelongClass()+"."+caseDetailEntity.getCaseName());
            if (!application.contains(caseDetailEntity.getCaseBelongApp())){
                application = application+caseDetailEntity.getCaseBelongApp();
            }
            if (StringUtils.isEmpty(line)){
                line = JenkinJobEnum.valueOf(SuiteBelong.of(caseDetailEntity.getCaseBelongApp()).getBelongGroup().name()).getLine();
            }
        }
        PlainResult<Boolean>  plainResult_jenkins = jenkinsService.runCase(line,jsonArray,env, JSONObject.toJSONString(jobSet),application,UserMapper.findByUserName(user.getRealname()).getName());
        plainpResult.setSuccess(plainResult_jenkins.isSuccess());
        plainpResult.setCode(plainResult_jenkins.getCode());
        plainpResult.setMessage(plainResult_jenkins.getMessage());
        return plainpResult;
    }

    @AllArgsConstructor
    @Getter
    private enum UserMapper {
        HUJIPING("hujiping", "胡吉平"),
        QINQIAO("qinqiao", "覃俏"),
        HEZHULIN("hezhulin", "何珠琳"),
        WANGHUIFANG("wanghuifang", "王会芳"),
        CHENGSUSU("chengsusu", "程素素"),
        XUSUXING("xusuxing", "徐苏醒");

        /**
         * 重试job
         */
        private String name;

        /**
         * gitLab projectId
         */
        private String user_id;

        public static UserMapper findByUserName(String name) {
            for (UserMapper value : values()) {
                if (Objects.equals(name, value.user_id)) {
                    return value;
                }
            }
            return null;
        }
    }
}
