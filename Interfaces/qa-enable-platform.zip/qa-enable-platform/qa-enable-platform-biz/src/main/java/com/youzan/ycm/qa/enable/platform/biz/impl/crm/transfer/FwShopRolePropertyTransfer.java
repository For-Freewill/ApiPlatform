package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShopRolePropertyDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShopRolePropertyDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺角色属性
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
public class FwShopRolePropertyTransfer {

	public static FwShopRolePropertyDTO toBO(FwShopRolePropertyDO d) {

		if (d == null) {

			return null;
		}

		FwShopRolePropertyDTO fwShopRolePropertyBO = new FwShopRolePropertyDTO();
		fwShopRolePropertyBO.setId(d.getId());
		fwShopRolePropertyBO.setShopRoleId(d.getShopRoleId());
		fwShopRolePropertyBO.setKdtId(d.getKdtId());
		fwShopRolePropertyBO.setRoleType(d.getRoleType());
		fwShopRolePropertyBO.setLastVisitTime(d.getLastVisitTime());
		fwShopRolePropertyBO.setLastEffectiveVisitTime(d.getLastEffectiveVisitTime());
		fwShopRolePropertyBO.setTouch(d.getTouch());
		fwShopRolePropertyBO.setCreatedAt(d.getCreatedAt());
		fwShopRolePropertyBO.setUpdatedAt(d.getUpdatedAt());

		return fwShopRolePropertyBO;
	}

	public static FwShopRolePropertyDO toDO(FwShopRolePropertyDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShopRolePropertyDO fwShopRolePropertyDO = new FwShopRolePropertyDO();
		fwShopRolePropertyDO.setId(bo.getId());
		fwShopRolePropertyDO.setShopRoleId(bo.getShopRoleId());
		fwShopRolePropertyDO.setKdtId(bo.getKdtId());
		fwShopRolePropertyDO.setRoleType(bo.getRoleType());
		fwShopRolePropertyDO.setLastVisitTime(bo.getLastVisitTime());
		fwShopRolePropertyDO.setLastEffectiveVisitTime(bo.getLastEffectiveVisitTime());
		fwShopRolePropertyDO.setTouch(bo.getTouch());
		fwShopRolePropertyDO.setCreatedAt(bo.getCreatedAt());
		fwShopRolePropertyDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShopRolePropertyDO;
	}

	public static List<FwShopRolePropertyDTO> toBOList(List<FwShopRolePropertyDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShopRolePropertyDTO>();
		}

		List<FwShopRolePropertyDTO> boList = new ArrayList<FwShopRolePropertyDTO>();
		for (FwShopRolePropertyDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShopRolePropertyDO> toDOList(List<FwShopRolePropertyDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShopRolePropertyDO>();
		}

		List<FwShopRolePropertyDO> doList = new ArrayList<FwShopRolePropertyDO>();

		for (FwShopRolePropertyDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
