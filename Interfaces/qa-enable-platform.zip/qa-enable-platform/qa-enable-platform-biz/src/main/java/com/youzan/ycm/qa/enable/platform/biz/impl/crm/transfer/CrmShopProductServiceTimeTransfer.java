package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.CrmShopProductServiceTimeDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.CrmShopProductServiceTimeDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 商业化同步过来的CRM服务期片段
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:29
 */
public class CrmShopProductServiceTimeTransfer {

	public static CrmShopProductServiceTimeDTO toBO(CrmShopProductServiceTimeDO d) {

		if (d == null) {

			return null;
		}

		CrmShopProductServiceTimeDTO crmShopProductServiceTimeBO = new CrmShopProductServiceTimeDTO();
		crmShopProductServiceTimeBO.setId(d.getId());
		crmShopProductServiceTimeBO.setKdtId(d.getKdtId());
		crmShopProductServiceTimeBO.setOrderId(d.getOrderId());
		crmShopProductServiceTimeBO.setAppId(d.getAppId());
		crmShopProductServiceTimeBO.setOrderStatusAppId(d.getOrderStatusAppId());
		crmShopProductServiceTimeBO.setItemId(d.getItemId());
		crmShopProductServiceTimeBO.setLevel(d.getLevel());
		crmShopProductServiceTimeBO.setGroupType(d.getGroupType());
		crmShopProductServiceTimeBO.setCategory(d.getCategory());
		crmShopProductServiceTimeBO.setEffectTime(d.getEffectTime());
		crmShopProductServiceTimeBO.setExpireTime(d.getExpireTime());
		crmShopProductServiceTimeBO.setPfOrderStatusId(d.getPfOrderStatusId());
		crmShopProductServiceTimeBO.setCreatedAt(d.getCreatedAt());
		crmShopProductServiceTimeBO.setUpdatedAt(d.getUpdatedAt());

		return crmShopProductServiceTimeBO;
	}

	public static CrmShopProductServiceTimeDO toDO(CrmShopProductServiceTimeDTO bo) {

        if (bo == null) {

			return null;
		}

		CrmShopProductServiceTimeDO crmShopProductServiceTimeDO = new CrmShopProductServiceTimeDO();
		crmShopProductServiceTimeDO.setId(bo.getId());
		crmShopProductServiceTimeDO.setKdtId(bo.getKdtId());
		crmShopProductServiceTimeDO.setOrderId(bo.getOrderId());
		crmShopProductServiceTimeDO.setAppId(bo.getAppId());
		crmShopProductServiceTimeDO.setOrderStatusAppId(bo.getOrderStatusAppId());
		crmShopProductServiceTimeDO.setItemId(bo.getItemId());
		crmShopProductServiceTimeDO.setLevel(bo.getLevel());
		crmShopProductServiceTimeDO.setGroupType(bo.getGroupType());
		crmShopProductServiceTimeDO.setCategory(bo.getCategory());
		crmShopProductServiceTimeDO.setEffectTime(bo.getEffectTime());
		crmShopProductServiceTimeDO.setExpireTime(bo.getExpireTime());
		crmShopProductServiceTimeDO.setPfOrderStatusId(bo.getPfOrderStatusId());
		crmShopProductServiceTimeDO.setCreatedAt(bo.getCreatedAt());
		crmShopProductServiceTimeDO.setUpdatedAt(bo.getUpdatedAt());

		return crmShopProductServiceTimeDO;
	}

	public static List<CrmShopProductServiceTimeDTO> toBOList(List<CrmShopProductServiceTimeDO> doList) {

		if (doList == null) {

			return new ArrayList<CrmShopProductServiceTimeDTO>();
		}

		List<CrmShopProductServiceTimeDTO> boList = new ArrayList<CrmShopProductServiceTimeDTO>();
		for (CrmShopProductServiceTimeDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<CrmShopProductServiceTimeDO> toDOList(List<CrmShopProductServiceTimeDTO> boList) {

		if (boList == null) {

			return new ArrayList<CrmShopProductServiceTimeDO>();
		}

		List<CrmShopProductServiceTimeDO> doList = new ArrayList<CrmShopProductServiceTimeDO>();

		for (CrmShopProductServiceTimeDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
