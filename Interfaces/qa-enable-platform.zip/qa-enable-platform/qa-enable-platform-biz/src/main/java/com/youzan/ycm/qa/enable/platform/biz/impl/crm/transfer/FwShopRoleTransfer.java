package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShopRoleDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShopRoleDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 店铺角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:18
 */
public class FwShopRoleTransfer {

	public static FwShopRoleDTO toBO(FwShopRoleDO d) {

		if (d == null) {

			return null;
		}

		FwShopRoleDTO fwShopRoleBO = new FwShopRoleDTO();
		fwShopRoleBO.setId(d.getId());
		fwShopRoleBO.setKdtId(d.getKdtId());
		fwShopRoleBO.setRoleType(d.getRoleType());
		fwShopRoleBO.setState(d.getState());
		fwShopRoleBO.setStartTime(d.getStartTime());
		fwShopRoleBO.setEndTime(d.getEndTime());
		fwShopRoleBO.setCreatedAt(d.getCreatedAt());
		fwShopRoleBO.setUpdatedAt(d.getUpdatedAt());

		return fwShopRoleBO;
	}

	public static FwShopRoleDO toDO(FwShopRoleDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShopRoleDO fwShopRoleDO = new FwShopRoleDO();
		fwShopRoleDO.setId(bo.getId());
		fwShopRoleDO.setKdtId(bo.getKdtId());
		fwShopRoleDO.setRoleType(bo.getRoleType());
		fwShopRoleDO.setState(bo.getState());
		fwShopRoleDO.setStartTime(bo.getStartTime());
		fwShopRoleDO.setEndTime(bo.getEndTime());
		fwShopRoleDO.setCreatedAt(bo.getCreatedAt());
		fwShopRoleDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShopRoleDO;
	}

	public static List<FwShopRoleDTO> toBOList(List<FwShopRoleDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShopRoleDTO>();
		}

		List<FwShopRoleDTO> boList = new ArrayList<FwShopRoleDTO>();
		for (FwShopRoleDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShopRoleDO> toDOList(List<FwShopRoleDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShopRoleDO>();
		}

		List<FwShopRoleDO> doList = new ArrayList<FwShopRoleDO>();

		for (FwShopRoleDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
