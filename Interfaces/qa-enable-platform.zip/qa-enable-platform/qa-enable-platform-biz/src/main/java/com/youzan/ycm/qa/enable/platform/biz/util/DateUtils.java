package com.youzan.ycm.qa.enable.platform.biz.util;


import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * @author wulei
 * @Date 2021/05/31
 */
@Slf4j
public class DateUtils {


    public final static String[] DATE_PATTERNS = {"yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyyMMdd", "yyyyMMddHHmmss", "yyyy/MM/dd"};

    public final static String DATE_TIME = "yyyy-MM-dd HH:mm:ss";

    public final static String DATE = "yyyy-MM-dd";
    public final static String START_TIME = "1970-01-01 08:00:00";
    /**
     * 2000-01-01
     */
    private final static long BASIC_TIME = 946656000000L;

    /**
     * 解析格式化的日期
     *
     * @param dateText
     * @return
     */
    public static Date parseDate(Object dateText) {
        if (dateText == null) {
            return null;
        } else if (dateText instanceof Date) {
            return (Date) dateText;
        } else {
            return parseDate(dateText, DATE_PATTERNS);
        }
    }

    /**
     * 解析格式化的日期
     *
     * @param dateText
     * @param patterns
     * @return
     */
    public static Date parseDate(Object dateText, String... patterns) {
        if (dateText == null) {
            return null;
        } else {
            try {
                return org.apache.commons.lang3.time.DateUtils.parseDate((String) dateText, patterns);
            } catch (Exception e) {
                log.warn("date convert error meet dateText=[{}]", dateText);
                return null;
            }
        }
    }


    /**
     * 格式化日期
     *
     * @param dateText
     * @return
     */
    public static String formatDateTime(Date dateText) {
        return formatDate(dateText, DATE_TIME);
    }

    /**
     * 格式化日期
     *
     * @param dateText
     * @return
     */
    public static String formatDate(Date dateText, String pattern) {
        if (dateText == null) {
            return null;
        } else if (dateText.getTime() <= BASIC_TIME) {
            return null;
        }
        try {
            return DateFormatUtils.format(dateText, pattern);
        } catch (Exception e) {
            return null;
        }
    }


    /**
     * 要求格式化日期
     *
     * @param dateText
     * @return
     */
    public static String requiredFormatDate(Date dateText, String pattern) {
        try {
            return DateFormatUtils.format(dateText, pattern);
        } catch (Exception e) {
            log.warn("error format Date[{}]", dateText);
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }
    }


    /**
     * 获取当前时间
     */
    public static Date getCurrentTime() {
        return new Date();
    }

    /**
     * @param date
     * @param amount
     * @return
     */
    public static Date addDays(Date date, int amount) {
        return org.apache.commons.lang3.time.DateUtils.addDays(date, amount);
    }


    /**
     * 判断时间是否在时间段内
     *
     * @param checkTime 需要判断的时间
     * @param startTime 开始时间
     * @param endTime   结束时间
     */
    public static boolean isTimeBetween(Date checkTime, Date startTime, Date endTime) {
        if (Objects.isNull(checkTime) || Objects.isNull(startTime) || Objects.isNull(endTime)) {
            return false;
        }
        return checkTime.after(startTime) && checkTime.before(endTime);

    }

    /**
     * 适配默认时间
     *
     * @param date
     * @return
     */
    public static Date adaptDefaultTimeForBiz(Date date) {

        if (date.getTime() <= BASIC_TIME) {
            return null;
        }

        return date;
    }

    public static int differentDays(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        int day1 = cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);

        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if (year1 != year2) {
            //不同年
            int timeDistance = 0;
            for (int i = year1; i < year2; i++) {
                if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
                    //闰年
                    timeDistance += 366;
                } else {
                    //不是闰年
                    timeDistance += 365;
                }
            }

            return timeDistance + (day2 - day1);
        } else {
            //同一年
            return day2 - day1;
        }
    }
}
