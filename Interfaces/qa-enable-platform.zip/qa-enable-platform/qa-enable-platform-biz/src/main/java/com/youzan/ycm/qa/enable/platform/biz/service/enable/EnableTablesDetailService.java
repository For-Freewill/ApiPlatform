package com.youzan.ycm.qa.enable.platform.biz.service.enable;

import com.baomidou.mybatisplus.extension.service.IService;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailInsertRequest;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailUpdateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableTablesResponse;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableTablesDetailEntity;

import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:05
 */
public interface EnableTablesDetailService extends IService<EnableTablesDetailEntity> {
    /**
     * 查询全部表 for 前端
     *
     * @return
     */
    PlainResult<EnableTablesResponse> select();

    /**
     * 查询全部表
     * @return
     */
    PlainResult<List<EnableTablesDetailEntity>> selectAll();

    /**
     * 新增记录
     *
     * @return
     */
    PlainResult<Boolean> insert(EnableTablesDetailInsertRequest request);

    /**
     * 逻辑删除记录
     *
     * @return
     */
    PlainResult<Boolean> updateById(EnableTablesDetailUpdateRequest request);

    /**
     * 逻辑删除记录
     *
     * @return
     */
    PlainResult<Boolean> deleteById(Long id);
}
