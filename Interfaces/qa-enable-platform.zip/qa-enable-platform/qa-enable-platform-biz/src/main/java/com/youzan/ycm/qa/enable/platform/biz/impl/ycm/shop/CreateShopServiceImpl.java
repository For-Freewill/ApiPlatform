package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.shop;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ebiz.common.model.CommonResult;
import com.youzan.pay.acctrans.api.acctrans.AcctransRechargeService;
import com.youzan.pay.acctrans.api.acctrans.dto.AcctransAccountingDTO;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransRechargeRequest;
import com.youzan.pay.acctrans.common.model.enums.AccountType;
import com.youzan.pay.acctrans.common.model.enums.SubTransCodeEnum;
import com.youzan.pay.acctrans.common.model.enums.TransCodeEnum;
import com.youzan.pay.acctrans.common.model.model.AccountInfo;
import com.youzan.pay.core.api.model.response.DataResult;
import com.youzan.pay.core.common.model.enums.CurrencyCode;
import com.youzan.pay.core.common.model.enums.bizcode.ChannelType;
import com.youzan.pay.core.utils.KeyUtils;
import com.youzan.platform.bootstrap.exception.BusinessException;
import com.youzan.retail.shop.api.hq.param.HQCreateRequest;
import com.youzan.retail.shop.api.hq.service.HQManageService;
import com.youzan.shopcenter.common.vo.MixedPhoneNumberVO;
import com.youzan.shopcenter.common.vo.MobileNumberVO;
import com.youzan.shopcenter.outer.entity.common.Address;
import com.youzan.shopcenter.outer.entity.common.OptSource;
import com.youzan.shopcenter.outer.entity.request.BeautySubShopCreateRequest;
import com.youzan.shopcenter.outer.entity.request.ShopCreateRequest;
import com.youzan.shopcenter.outer.entity.request.WscEduShopCreateRequest;
import com.youzan.shopcenter.outer.entity.request.chain.EduHqCreateRequest;
import com.youzan.shopcenter.outer.entity.request.chain.RetailHqCreateRequest;
import com.youzan.shopcenter.outer.service.chain.EduChainCreateOuterService;
import com.youzan.shopcenter.outer.service.chain.RetailChainCreateOuterService;
import com.youzan.shopcenter.outer.service.shop.ShopCreateOuterService;
import com.youzan.shopcenter.shop.entity.LongServiceResult;
import com.youzan.shopcenter.shop.entity.request.RetailShopCreateRequest;
import com.youzan.shopcenter.shop.entity.request.WscCreateRequest;
import com.youzan.shopcenter.shop.service.ShopCreateService;
import com.youzan.sz.beautystore.shop.model.dto.ShopAddressDTO;
import com.youzan.sz.beautystore.shop.model.dto.ShopInfoDTO;
import com.youzan.sz.beautystore.shop.model.vo.ShopInfoVO;
import com.youzan.sz.beautystore.shop.service.BeautyShopService;
import com.youzan.uic.api.user.model.MobileUserInfoModel;
import com.youzan.uic.api.user.param.UserInfoQueryParam;
import com.youzan.uic.api.user.param.UserRegisterPasswordParam;
import com.youzan.uic.api.user.service.UserInfoService;
import com.youzan.uic.api.user.service.UserRegisterService;
import com.youzan.wecom.helper.api.common.dto.Operator;
import com.youzan.wecom.helper.api.corp.manage.corp.CorpManageService;
import com.youzan.wecom.helper.api.corp.manage.corp.dto.request.CorpCreateReqDTO;
import com.youzan.wecom.helper.api.corp.manage.corp.dto.response.CorpCreateRespDTO;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.shop.CreateShopRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.CreateShopService;
import com.youzan.ycm.qa.enable.platform.biz.enums.ShopTypeEnums;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.AsyncExecutor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * @author wuwu
 * @date 2021/7/8 11:06 AM
 */
@Slf4j
@Service("createShopService")
public class CreateShopServiceImpl implements CreateShopService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private UserInfoService userInfoService;

    @Resource
    private com.youzan.pay.customer.api.ops.UserInfoService payUserInfoService;

    @Resource
    private ShopCreateService shopCreateService;

    @Resource
    private ShopCreateOuterService shopCreateOuterService;

    @Resource
    private RetailChainCreateOuterService retailChainCreateOuterService;

    @Resource
    private UserRegisterService userRegisterService;

    @Resource
    private AcctransRechargeService acctransRechargeService;

    @Resource
    private BeautyShopService beautyShopService;

    @Resource
    private EduChainCreateOuterService eduChainCreateOuterService;

    @Resource
    private HQManageService hqManageService;

    @Resource
    private CorpManageService corpManageService;
//
//
//    @Resource
//    private BeautyShopManager beautyShopManager;

    @Override
    public PlainResult<Long> createNewShop(CreateShopRequest createShopRequest) {
        log.info("创建店铺的参数："+JSON.toJSONString(createShopRequest));
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        AssertUtil .isAllNotNone(createShopRequest.getShopType(), "店铺类型不能为空");
        PlainResult<Long> result = new PlainResult<>();
        Long kdtId = 0L;

        ShopTypeEnums shopTypeEnum = ShopTypeEnums.findShopTypeEnum(createShopRequest.getShopType());
        if (Objects.isNull(shopTypeEnum)) {
            throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"请选择正确的店铺类型");
        }
        try {
            switch (shopTypeEnum) {
                case BEAUTY_BASE:
                case BEAUTY_PRO:
                    PlainResult<ShopInfoVO> beautyBaseResult = createBeautyShop(createShopRequest);
                    if(!beautyBaseResult.isSuccess() || beautyBaseResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+beautyBaseResult.getMessage());
                    }
                    kdtId = beautyBaseResult.getData().getKdtId();
                    break;
                case WSC:
                    LongServiceResult wscResult = createWscShop(createShopRequest);
                    if(!wscResult.isIsSuccess() || wscResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+wscResult.getErrorDesc());
                    }
                    kdtId = wscResult.getData();

                    break;
                case WSC_CHAIN:
                    PlainResult<Long> wscChainResult = createRetailHQWscNewShop(createShopRequest);
                    if(!wscChainResult.isSuccess() || wscChainResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+wscChainResult.getMessage());
                    }
                    kdtId = wscChainResult.getData();
                    break;
                case RETAIL:
                    LongServiceResult retailResult = createRetailShop(createShopRequest);
                    if(!retailResult.isIsSuccess() || retailResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+retailResult.getErrorDesc());
                    }
                    kdtId = retailResult.getData();
                    break;
                case RETAIL_CHAIN:
                case RETAIL_ADVANCED_VERSION:
                    PlainResult<Long> retailChainResult = createRetailHQNewShop(createShopRequest);
                    if(!retailChainResult.isSuccess() || retailChainResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+retailChainResult.getMessage());
                    }
                    kdtId = retailChainResult.getData();
                    break;
                case EDU:
                    PlainResult<Long> eduResult = createWscEduShop(createShopRequest);
                    if(!eduResult.isSuccess() || eduResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+eduResult.getMessage());
                    }
                    kdtId = eduResult.getData();
                    break;
                case EDU_CHAIN:
                    PlainResult<Long> eduChainResult = createEduHQNewShop(createShopRequest);
                    if(!eduChainResult.isSuccess() || eduChainResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+eduChainResult.getMessage());
                    }
                    kdtId = eduChainResult.getData();
                    break;

                case EDU_CHAIN_40:
                    PlainResult<Long> eduChain40Result = createEdu40HQShop(createShopRequest);
                    if(!eduChain40Result.isSuccess() || eduChain40Result.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+eduChain40Result.getMessage());
                    }
                    kdtId = eduChain40Result.getData();
                    break;


                case ENTERPRISE_WECHAT_ASSISTANT:
                    CommonResult<CorpCreateRespDTO> qiWeiResult = createQiWeiShop(createShopRequest);
                    if(!qiWeiResult.isSuccess() || qiWeiResult.getData() == null){
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+qiWeiResult.getMessage());
                    }
                    kdtId = qiWeiResult.getData().getYzKdtId();
                    break;


                case WXD:
                    PlainResult<Long> wxdResult = createWxd(createShopRequest);
                    if(!wxdResult.isSuccess() || wxdResult.getData() == null) {
                        throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建店铺失败："+wxdResult.getMessage());
                    }
                    kdtId = wxdResult.getData();
                    break;
            }
        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage(e.getMessage());
            result.setCode(10001);
            return result;
        }

        //异步执行充值方法
        Long finalKdtId = kdtId;
        result.setData(kdtId);
        if (createShopRequest.getMoney() > 0) {
            AsyncExecutor.execute(() -> rechargeShopBalance(String.valueOf(finalKdtId),createShopRequest.getMoney()));
        }

        return result;
    }

    @Override
    public LongServiceResult createWscShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }
        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        WscCreateRequest request = new WscCreateRequest();
        request.setShopName(createShopRequest.getShopName());
        request.setBusiness(35);
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("西湖区");
        request.setAddress("文三路黄龙万科中心");
        request.setCountyId(310000);
        request.setLat("30.238908");
        request.setLng("120.1641");
        request.setAccountId(accountId);
        LongServiceResult result = shopCreateService.createWscShop(request);
        return result;
    }

    @Override
    public LongServiceResult createRetailShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }
        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        RetailShopCreateRequest request = new RetailShopCreateRequest();
        request.setShopName(createShopRequest.getShopName());
        request.setBusiness(35);
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("西湖区");
        request.setAddress("文三路黄龙万科中心");
        request.setCountyId(310000);
        request.setAccountId(accountId);
        request.setIpAddress("10.215.44.22");
        LongServiceResult result = shopCreateService.createRetailShop(request);
        return result;
    }


    @Override
    public PlainResult<Long> createWscEduShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        String sequence = DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.now());
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("教育单店-" + sequence);
        }
        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        WscEduShopCreateRequest request = new WscEduShopCreateRequest();
        Address address = new Address();
        address.setAddress("西溪路788号5幢");
        address.setCountyId(310000);
        address.setCounty("西湖区");
        address.setProvince("浙江省");
        address.setCity("杭州市");
        address.setProvince("浙江省");
        request.setAddress(address);
        request.setShopName(createShopRequest.getShopName());
        request.setBusinessId(95);
        request.setAppName("wsc-pc-vis");
        request.setEntryAppName("wsc-pc-vis");
        request.setOperatorId(accountId);
        request.setOperatorType(1);
        request.setIpAddress("10.215.44.22");
        PlainResult<Long> result = shopCreateOuterService.createWscEduShop(request);
        return result;

    }


    @Override
    public PlainResult<Long> createRetailHQNewShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());

        }
        Integer saasSolution = 2;
        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        RetailHqCreateRequest request = new RetailHqCreateRequest();
        request.setShopName(createShopRequest.getShopName());
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("西湖区");
        request.setAddress("文三路黄龙万科中心");
        request.setCountyId(310000);
        request.setAccountId(accountId);
        request.setSaasSolution(saasSolution);//零售连锁的saasSolution = 2
        OptSource optSource = new OptSource();
        optSource.setAppName("retail-shop");
        optSource.setIpAddress("10.215.44.22");
        optSource.setOperatorId(accountId);
        request.setOptSource(optSource);
        request.setOnlineMode(2);
        request.setBusinessId(36);
        request.setLat("30.238908");
        request.setLng("120.1641");
        if(createShopRequest.getShopType().equals("retail_advanced_version")){
            request.setVersionCode("advanced_version");
        }
        PlainResult<Long> result = retailChainCreateOuterService.createRetailHQ(request);
        return result;
    }


    @Override
    public PlainResult<Long> createRetailHQWscNewShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }
        Integer saasSolution = 7003;

        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        RetailHqCreateRequest request = new RetailHqCreateRequest();
        request.setShopName(createShopRequest.getShopName());
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("西湖区");
        request.setAddress("文三路黄龙万科中心");
        request.setCountyId(310000);
        request.setAccountId(accountId);
        request.setSaasSolution(saasSolution);//微商城连锁的saasSolution = 7003
        OptSource optSource = new OptSource();
        optSource.setAppName("retail-shop");
        optSource.setIpAddress("10.215.44.22");
        optSource.setOperatorId(accountId);
        request.setOptSource(optSource);
        request.setBusinessId(36);
        request.setOnlineMode(2);
        request.setLat("30.238908");
        request.setLng("120.1641");
        PlainResult<Long> result = retailChainCreateOuterService.createRetailHQ(request);
        return result;
    }

    @Override
    public PlainResult<Long> createEduHQNewShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }

        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        EduHqCreateRequest request = new EduHqCreateRequest();
        Address address = new Address();
        address.setAddress("西溪路788号5幢");
        address.setCountyId(310000);
        address.setCounty("西湖区");
        address.setProvince("浙江省");
        address.setCity("杭州市");
        address.setProvince("浙江省");
        request.setAddress(address);
        request.setShopName(createShopRequest.getShopName());
        request.setBusinessId(95);
        request.setAppName("wsc-pc-vis");
        request.setEntryAppName("wsc-pc-vis");
        request.setOperatorId(accountId);
        request.setOperatorType(1);
        request.setIpAddress("10.215.44.22");
        PlainResult<Long> result = eduChainCreateOuterService.createEduHQ(request);
        return result;
    }

    @Override
    public PlainResult<Long> createEdu40HQShop(CreateShopRequest createShopRequest) {
        HQCreateRequest request = new HQCreateRequest();
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }

        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        request.setShopName(createShopRequest.getShopName());
        request.setAdminId(accountId);
        request.setBusinessId(95);
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("西溪路788号5幢");
        request.setAddress("西溪路788号5幢");
        request.setCountyId(310000);
        request.setFromBiz(1);
        request.setFromTerminal(0);
        request.setRetailSource("WEB-RETAIL-AJAX");
        request.setSaasSolution(7003);
        request.setOnlineMode(1);
        request.setShopTopic(1);
        request.setLat("30.238908");
        request.setLng("120.1641");

        return hqManageService.create(request);
    }

    @Override
    public CommonResult<CorpCreateRespDTO> createQiWeiShop(CreateShopRequest createShopRequest){
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }

        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        CorpCreateReqDTO request = new CorpCreateReqDTO();
        request.setWecomAuthRedirectUrl("企业微信授权重定向地址");
        Operator operator = new Operator();
        operator.setMobile(Long.valueOf(createShopRequest.getPhoneNo()));
        operator.setYzUserId(accountId);
        operator.setNickname(createShopRequest.getPhoneNo());
        operator.setAppName("商赋测试平台");
        operator.setClientIp("10.215.44.22");
        request.setOperator(operator);

        CommonResult<CorpCreateRespDTO> result = corpManageService.create(request);

        return result;
    }

    @Override
    public PlainResult<ShopInfoVO> createBeautyShop(CreateShopRequest createShopRequest) {
        AssertUtil.isAllNotNone(createShopRequest.getPhoneNo(), "手机号不能为空");
        if (createShopRequest.getShopName() == null) {
            createShopRequest.setShopName("auto-" + System.currentTimeMillis());
        }
        Long accountId = getAccountId(createShopRequest.getPhoneNo());

        ShopInfoDTO shopInfoDTO = new ShopInfoDTO();
        ShopAddressDTO shopAddressDTO = new ShopAddressDTO();
        shopInfoDTO.setName(createShopRequest.getShopName());
        shopAddressDTO.setProvince("浙江省");
        shopAddressDTO.setCity("杭州市");
        shopAddressDTO.setArea("西湖区");
        shopAddressDTO.setAddressDetail("文三路黄龙万科中心");
        shopAddressDTO.setAreaCode("330102");
        shopAddressDTO.setLng("120.1641");
        shopAddressDTO.setLat("30.238908");

        shopInfoDTO.setAdminId(accountId);
        shopInfoDTO.setCateId(5);
        if(createShopRequest.getShopType().equals("beauty_base")) {
            shopInfoDTO.setVersion(10);
        } else if (createShopRequest.getShopType().equals("beauty_pro")) {
            shopInfoDTO.setVersion(20);
        }
        shopInfoDTO.setLogo("http://img.yzcdn.cn/upload_files/2017/04/06/FkzPke7UiK-QgqA0_KFby82u6KV7.png");
        shopInfoDTO.setShopAddress(shopAddressDTO);
        shopInfoDTO.setFromSource(0);
        shopInfoDTO.setIp("24.160.225.194");


        PlainResult<ShopInfoVO> result = beautyShopService.createV2(shopInfoDTO);


//        BeautyShopCreateRequest request = new BeautyShopCreateRequest();
//        request.setShopName(createShopRequest.getShopName());
//        request.setCountry("CN");
//        request.setProvince("浙江省");
//        request.setCity("杭州市");
//        request.setArea("西湖区");
//        request.setAddress("文三路黄龙万科中心");
//        request.setCountyId(310000);
//        request.setAccountId(accountId);
//        request.setBusiness(5);
//        request.setContactName(createShopRequest.getPhoneNo());
//        request.setContactCountryCode("+86");
//        request.setContactMobile(createShopRequest.getPhoneNo());
//        request.setIpAddress("24.160.225.194");
//        if(createShopRequest.getShopType().equals("beauty_base")) {
//            request.setVersion("base_version");
//        }else if (createShopRequest.getShopType().equals("beauty_pro")) {
//            request.setVersion("profession_version");
//        }
//        request.setFromTerminal(0);
//        request.setFromBiz(0);
//        request.setLogo("http://img.yzcdn.cn/upload_files/2017/04/06/FkzPke7UiK-QgqA0_KFby82u6KV7.png");
//        PlainResult<Long> result = shopCreateOuterService.createBeautyShop(request);
//        if (result.getData() !=null) {
//            AsyncExecutor.execute(() -> createBeautySubShop(createShopRequest.getPhoneNo(),result.getData(),accountId));
//        }

        return result;

    }

    public void createBeautySubShop(String phoneNo,Long parentKdtId,Long accountId) {
        BeautySubShopCreateRequest beautySubShopCreateRequest = new BeautySubShopCreateRequest();
        beautySubShopCreateRequest.setParentKdtId(parentKdtId);
        beautySubShopCreateRequest.setAccountId(accountId);
        beautySubShopCreateRequest.setAddress("文三路黄龙万科中心");
        beautySubShopCreateRequest.setCity("杭州市");
        beautySubShopCreateRequest.setBusinessId(5);
        beautySubShopCreateRequest.setCountry("CN");
        beautySubShopCreateRequest.setCounty("西湖区");
        beautySubShopCreateRequest.setCountyId(330102);
        beautySubShopCreateRequest.setShopName("auto-" + System.currentTimeMillis());
        beautySubShopCreateRequest.setIpAddress("24.160.225.194");
        beautySubShopCreateRequest.setManagerCountryCode("+86");
        beautySubShopCreateRequest.setLogo("http://img.yzcdn.cn/upload_files/2017/04/06/FkzPke7UiK-QgqA0_KFby82u6KV7.png");
        beautySubShopCreateRequest.setManagerMobileNumber(phoneNo);
        beautySubShopCreateRequest.setManagerName(phoneNo);
        beautySubShopCreateRequest.setProvince("浙江省");

        PlainResult<Long> result = shopCreateOuterService.createBeautySubShop(beautySubShopCreateRequest);

        if(!result.isSuccess()) {
            log.info("创建子店铺失败");
            throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建子店铺失败："+result.getMessage());
        }
    }


    @Override
    public PlainResult<Long> createWxd(CreateShopRequest request){

        REQUEST_LOGGER.info("指定手机号码创建旺小店店铺:" + request  );
        if (request.getShopName() == null) {
            request.setShopName("w"+System.currentTimeMillis());
        }

        Long accountId = getAccountId(request.getPhoneNo());


        ShopCreateRequest shopCreateRequest = new ShopCreateRequest();
        shopCreateRequest.setShopType(19);
        shopCreateRequest.setShopTopic(0);
        shopCreateRequest.setShopRole(0);
        shopCreateRequest.setManagerName("ceshi");
        MobileNumberVO mobileNumberVO = new MobileNumberVO();
        mobileNumberVO.setCountryCode("+86");
        mobileNumberVO.setMobileNumber(request.getPhoneNo());
        shopCreateRequest.setManagerMobileNumber(mobileNumberVO);
        MixedPhoneNumberVO mixedPhoneNumberVO = new MixedPhoneNumberVO();
        mixedPhoneNumberVO.setAreaCode("0357");
        mixedPhoneNumberVO.setPhoneNumber(request.getPhoneNo());
        shopCreateRequest.setCustomerServicePhoneNumber(mixedPhoneNumberVO);
        shopCreateRequest.setShopName(request.getShopName());
        Address address = new Address();
        address.setCountry("CN");
        address.setProvince("浙江省");
        address.setCounty("西湖区");
        address.setCity("杭州市");
        address.setCountyId(330106);
        address.setAddress("良渚街道梁家塘");
        address.setLat("30.340652575725237");
        address.setLng("120.02679300430407");
        shopCreateRequest.setAddress(address);
        shopCreateRequest.setFromTerminal(4);
        shopCreateRequest.setFromBiz(15);
        shopCreateRequest.setOperatorType(1);
        shopCreateRequest.setOperatorId(accountId);
        shopCreateRequest.setAppName("shop-front");
        shopCreateRequest.setIpAddress("172.18.208.45");
        PlainResult<Long> shop = shopCreateOuterService.createShop(shopCreateRequest);
        return shop;
    }




    public PlainResult<Long> createMobileAccount(String phoneNo) {
        try {
            UserRegisterPasswordParam userRegisterPasswordParam = new UserRegisterPasswordParam();
            userRegisterPasswordParam.setCountryCode("+86");
            userRegisterPasswordParam.setMobile(phoneNo);
            userRegisterPasswordParam.setPassword("123456");
            userRegisterPasswordParam.setGroupId(1L);

            PlainResult<Long> result = userRegisterService.registerByPassword(userRegisterPasswordParam);
            return result;
        } catch (Exception e) {
            throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),e.getMessage());
        }

    }


    /**
     * 获取手机号信息
     * @param phoneNo
     * @return
     */
    public Long getUserAccountInfo(String phoneNo) {
        try {
            UserInfoQueryParam userInfoQueryParam = new UserInfoQueryParam();
            userInfoQueryParam.setMobile(phoneNo);
            userInfoQueryParam.setWithPassword(true);
            userInfoQueryParam.setAppName("shangyehua-CI");
            PlainResult<MobileUserInfoModel> userResult = userInfoService.getMobileInfo(userInfoQueryParam);

            if(userResult.getData() != null && userResult.getData().getUserId() != null) {
                return userResult.getData().getUserId();
            }else{
                log.info("手机号"+phoneNo+"下未找到对应的账号");
                return null;
            }
        } catch (Exception e) {
            throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),e.getMessage());
        }

    }


    /**
     * 获取手机号的accountId
     * @param phoneNo
     * @return
     */
    public Long getAccountId(String phoneNo) {
        Long accountId = getUserAccountInfo(phoneNo);
        if (accountId == null) {
            PlainResult<Long> result = createMobileAccount(phoneNo);
            if (result.isSuccess() && result.getData() !=null) {
                return result.getData();
            }else {
                log.info("创建账号失败");
                throw new EnableException(ResultCode.CREATE_SHOP_ERROR.getCode(),"创建账号失败"+result.getMessage());
            }
        }

        return accountId;
    }

    /**
     * 店铺余额充值，单位（元）
     *
     * @param kdtId
     * @param money
     */
    public void rechargeShopBalance(String kdtId, int money) {
        String userNo = kdtId;
        money = money * 100;
        int inputType = 0;
        //根据kdtId 获取userNo
        PlainResult<String> result = new PlainResult<>();
        try {
            result = payUserInfoService.queryUserNoByKdtId(Integer.parseInt(kdtId));
            if (!result.isSuccess() || result.getData() == null) {
                log.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
                throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
            }
        } catch (Exception e) {
            log.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
        }
        userNo = result.getData();

        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        AcctransRechargeRequest rechargeRequest = new AcctransRechargeRequest();
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setUserNo(String.valueOf(userNo));
        accountInfo.setAccountType(AccountType.BASE_ACCT.getType());
        rechargeRequest.setAccountInfo(accountInfo);
        rechargeRequest.setAppName("biz-commerce");
        rechargeRequest.setClientId(waterNo);
        rechargeRequest.setAcquireNo(waterNo);
        rechargeRequest.setAmount(money);
        rechargeRequest.setChannelCode(ChannelType.BALANCE.getCode());
        rechargeRequest.setCurrencyCode(CurrencyCode.CNY.getNum());
        rechargeRequest.setOperator("qa-syh-test");
        rechargeRequest.setOrderNo(waterNo);
        rechargeRequest.setParternerBizType("301001");
        rechargeRequest.setParternerId("301001");
        rechargeRequest.setRemark("接口测试调用");
        rechargeRequest.setSubTransCode(SubTransCodeEnum.RECHARGE_RECHARGESETTLE.getCode());
        rechargeRequest.setTransCode(TransCodeEnum.RECHARGE.getCode());
        rechargeRequest.setRequestTime("test");
        DataResult<AcctransAccountingDTO> rechargeResult = acctransRechargeService.recharge(rechargeRequest);

        if (!rechargeResult.isSuccess()) {
            log.error("AcctransService 充值接口调用失败,waterNo=" + rechargeResult.getRequestId() + "! ");
            throw new BusinessException("AcctransService 充值接口调用失败！返回结果为：" + JSON.toJSONString(rechargeResult));
        }
    }

//    public static void main(String[] args) {
//        CreateShopRequest createShopRequest =  new CreateShopRequest();
//        createShopRequest.setShopType("beauty_base");
//        if(createShopRequest.getShopType().equals("beauty_base")) {
//            System.out.println(true);
//        }else {
//            System.out.println(false);
//        }
//    }
}
