package com.youzan.ycm.qa.enable.platform.biz.response.goods;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: wulei
 * @Date: 7/19/21 5:33 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GdSpuSnapshotDTO {
    private Long id;

    private String spuId;

    private Long snapshotNo;

    private String goodsType;

    private Integer appId;

    private String spuName;

    private String icon;

    private String category;

    private String orderDeclare;

    private String descInfo;

    private String content;

    private Byte isSupportYzb;

    private Byte isFree;

    private String performType;

    private String mainSpuId;

    private String pageId;

    private String wscUrl;

    private String storeUrl;

    private String ownerId;

    private String ownerType;

    private String bizExt;

    private String shelfState;
}