package com.youzan.ycm.qa.enable.platform.biz.response.repeater;

import lombok.Data;


@Data
public class RestResult {
    /**
     * 返回值code
     */
    private Integer code;

    /**
     * 返回值message
     */
    private String msg;

    /**
     * 返回值data
     */
    private String data;

    /**
     * 返回值message
     */
    private String message;
}
