package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.youzan.api.common.response.PlainResult;
import com.youzan.hawk.common.utils.HttpUtils;
import com.youzan.ycm.qa.enable.platform.api.response.ci.JenkinsReportDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.JenkinsReportService;
import jdk.nashorn.internal.parser.JSONParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;


/**
 * @Author run.xiong
 * @Description 获取Jenkins执行结果处理业务类
 * @Date 2021-08-19
 **/
@Slf4j
@Service(value = "JenkinsReportServiceImpl")
public class JenkinsReportServiceImpl implements JenkinsReportService {

    @Override
    public PlainResult<JenkinsReportDTO> getJenkinsReport(String jobUrl) {
        // http://shangyehua-jenkins.cd-qa.qima-inc.com/job/crm-sales-web-base/771/api/json
        if( ! jobUrl.endsWith("/")) {
            jobUrl += "/";
        }

        jobUrl += "testReport/";

        // 请求Jenkins的api获取执行结果
        HttpUtils.Response response = HttpUtils.get(jobUrl+"api/json?pretty=true");
        log.debug(response.getContent());
        JSONObject jsonObject = JSON.parseObject(response.getContent());
        JenkinsReportDTO jenkinsReportDTO = new JenkinsReportDTO();
        jenkinsReportDTO.setSkipCount(jsonObject.getLong("skipCount"));
        jenkinsReportDTO.setPassCount(jsonObject.getLong("passCount"));
        jenkinsReportDTO.setFailCount(jsonObject.getLong("failCount"));
        jenkinsReportDTO.setCount(jenkinsReportDTO.getSkipCount() + jenkinsReportDTO.getFailCount() +
                            jenkinsReportDTO.getPassCount());
        jenkinsReportDTO.setDuration(jsonObject.getFloat("duration"));

//        if(jsonObject.getLong("failCount") >0 || jsonObject.getLong("skipCount") > 0){
//            jenkinsReportDTO.setStatus(false);
//        }else {
//            jenkinsReportDTO.setStatus(true);
//        }

        if(jsonObject.getLong("failCount") >0){
            jenkinsReportDTO.setStatus(false);
        }else {
            jenkinsReportDTO.setStatus(true);
        }

        ArrayList<JenkinsReportDTO.Suites> suites1 = new ArrayList();


        JSONObject resultList = new JSONObject();

        for (int i = 0; i < jsonObject.getJSONArray("suites").size(); i++) {
            JSONObject suite = (JSONObject) jsonObject.getJSONArray("suites").get(i);
            for (int j = 0; j < suite.getJSONArray("cases").size(); j++) {

                JSONObject cases = (JSONObject) suite.getJSONArray("cases").get(j);

                // 拼接日志，errorStackTrace字段加stdout字段
                String logStr = "";
                if(cases.get("errorStackTrace") != null){
                    logStr += cases.get("errorStackTrace");
                }
                if(cases.get("stdout") != null){
                    logStr += cases.get("stdout");
                }

                // 拼接用例的执行详情的链接
                String url = jobUrl;
                int length = cases.getString("className").lastIndexOf(".");
                url += cases.getString("className").substring(0, length);
                url += "/" + cases.getString("className").substring(length+1);
                url += "/" + cases.getString("name");


                String path = cases.getString("className") + "." + cases.getString("name");

                if(resultList.containsKey(path)){
                    BigDecimal duration1= new BigDecimal(Float.toString(resultList.getJSONObject(path).getFloat("duration")));
                    BigDecimal duration2= new BigDecimal(Float.toString(cases.getFloat("duration")));
                    resultList.getJSONObject(path).put("duration", duration1.add(duration2).floatValue());
                    // dataprover的数据url为_个数
//                    String new_url = url;
                    String new_url=url.substring(0,url.lastIndexOf("/"));
//                    new_url += "_" +resultList.getJSONObject(path).getInteger("num").toString();

                    // 数据驱动的情况下，当有多条用例，其中一条用例执行结果为非成功，则结果显示为失败
//                    if(!cases.getString("status").equals("PASSED")){
//                        resultList.getJSONObject(path).put("status", "REGRESSION");
//                    }
                    if(cases.getString("status").equals("REGRESSION") || cases.getString("status").equals("FAILED")){
                        resultList.getJSONObject(path).put("status", cases.getString("status"));
                    }

                    // 日志累加
                    resultList.getJSONObject(path).put("log", resultList.getJSONObject(path).getString("log")+logStr);

                    // 链接累加
                    //getJSONObject("url")里面存的格式是
                    // {"https://cd-qa.qima-inc.com/jenkins-18/job/crm-core-customer/job/qaBit-bit-enable/11/testReport/com.youzan.test.fuwu.shopproduct/GetActiveSoftwareTest/getActiveSoftware_effective14":"PASSED",
                    // "https://cd-qa.qima-inc.com/jenkins-18/job/crm-core-customer/job/qaBit-bit-enable/11/testReport/com.youzan.test.fuwu.shopproduct/GetActiveSoftwareTest/getActiveSoftware_effective14_2":"PASSED"}
//                    resultList.getJSONObject(path).getJSONObject("url").put(new_url, cases.getString("status"));
                    resultList.getJSONObject(path).put("url",new_url);
//                    resultList.getJSONObject(path).put("num", resultList.getJSONObject(path).getInteger("num")+1);
                }else {
                    JSONObject tmp = new JSONObject();
                    tmp.put("duration", cases.getFloat("duration"));
                    tmp.put("name", cases.getString("name"));
                    tmp.put("log", logStr);
                    tmp.put("status", cases.getString("status"));
                    tmp.put("className", cases.getString("className"));
//                    tmp.put("num", 2);
//                    JSONObject _url  = new JSONObject();
                    //url某条具体用例执行的结果链接 https://cd-qa.qima-inc.com/jenkins-18/job/crm-core-customer/job/qaBit-bit-enable/11/testReport/com.youzan.test.fuwu.shopproduct/GetActiveSoftwareTest/getActiveSoftware_effective14
//                    _url.put(url, cases.getString("status"));
                    tmp.put("url", url);
                    resultList.put(path, tmp);
                }
            }
        }

        resultList.forEach((path, val) -> {
            // 过滤已存在的用例
            JenkinsReportDTO.Suites suites = new JenkinsReportDTO.Suites();
            JSONObject cases = (JSONObject)val;
            suites.setDuration(cases.getFloat("duration"));
            suites.setName(cases.getString("name"));
            suites.setStatus(cases.getString("status"));
            suites.setClassName(cases.getString("className"));
            suites.setLog(cases.getString("log"));
            suites.setUrl(cases.getString("url"));
            // 添加其中一条用例的
            suites1.add(suites);
        });

        jenkinsReportDTO.setSuites(suites1);

        PlainResult plainResult =  new PlainResult();
        plainResult.setData(jenkinsReportDTO);
        return plainResult;
    }

    @Override
    public Boolean jobIsFinish(String jobUrl) {

        if( ! jobUrl.endsWith("/")) {
            jobUrl += "/";
        }

        // 请求Jenkins的api获取执行情况
        HttpUtils.Response response = HttpUtils.get(jobUrl+"api/json?pretty=true");
        if (null == response.getContent() || response.getContent().isEmpty()){
            log.error("请求Jenkins的api获取执行情况异常");
            return false;
        }
        JSONObject jsonObject = JSON.parseObject(response.getContent());
        if (!jsonObject.getBoolean("building") && null != jsonObject.getString("result") && !jsonObject.getString("result").isEmpty())
            return true;
        return false;

    }
}
