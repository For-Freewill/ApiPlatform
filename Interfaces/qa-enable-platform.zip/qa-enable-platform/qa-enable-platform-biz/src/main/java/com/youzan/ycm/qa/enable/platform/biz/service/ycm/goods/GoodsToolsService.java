package com.youzan.ycm.qa.enable.platform.biz.service.ycm.goods;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.Difference;

import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2021/9/29 17:34
 */
public interface GoodsToolsService {
    /**
     * 查询原子商品详情
     *
     * @param atom_plugin_app_id_qa
     * @return
     */
    PlainResult<Map<String, Map>> queryAtomPlugin(Integer atom_plugin_app_id_qa);

    /**
     * 对比原子商品插件-基础QA和SC创建的商品SPU差异
     *
     * @param atom_plugin_app_id_qa
     * @param atom_plugin_app_id_sc
     * @return
     */
    PlainResult<List<Difference>> compareSpuResult(Integer atom_plugin_app_id_qa, Integer atom_plugin_app_id_sc);

    /**
     * 对比原子商品插件-基础QA和SC创建的商品SKU差异
     *
     * @param atom_plugin_app_id_qa
     * @param atom_plugin_app_id_sc
     * @return
     */
    PlainResult<List<Difference>> compareSkuResult(Integer atom_plugin_app_id_qa, Integer atom_plugin_app_id_sc);


}
