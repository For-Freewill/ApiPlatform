package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwRoleDepVarDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwRoleDepVarDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 角色依赖的变量
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwRoleDepVarTransfer {

	public static FwRoleDepVarDTO toBO(FwRoleDepVarDO d) {

		if (d == null) {

			return null;
		}

		FwRoleDepVarDTO fwRoleDepVarBO = new FwRoleDepVarDTO();
		fwRoleDepVarBO.setId(d.getId());
		fwRoleDepVarBO.setKdtId(d.getKdtId());
		fwRoleDepVarBO.setTags(d.getTags());
		fwRoleDepVarBO.setCreatedAt(d.getCreatedAt());
		fwRoleDepVarBO.setUpdatedAt(d.getUpdatedAt());

		return fwRoleDepVarBO;
	}

	public static FwRoleDepVarDO toDO(FwRoleDepVarDTO bo) {

        if (bo == null) {

			return null;
		}

		FwRoleDepVarDO fwRoleDepVarDO = new FwRoleDepVarDO();
		fwRoleDepVarDO.setId(bo.getId());
		fwRoleDepVarDO.setKdtId(bo.getKdtId());
		fwRoleDepVarDO.setTags(bo.getTags());
		fwRoleDepVarDO.setCreatedAt(bo.getCreatedAt());
		fwRoleDepVarDO.setUpdatedAt(bo.getUpdatedAt());

		return fwRoleDepVarDO;
	}

	public static List<FwRoleDepVarDTO> toBOList(List<FwRoleDepVarDO> doList) {

		if (doList == null) {

			return new ArrayList<FwRoleDepVarDTO>();
		}

		List<FwRoleDepVarDTO> boList = new ArrayList<FwRoleDepVarDTO>();
		for (FwRoleDepVarDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwRoleDepVarDO> toDOList(List<FwRoleDepVarDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwRoleDepVarDO>();
		}

		List<FwRoleDepVarDO> doList = new ArrayList<FwRoleDepVarDO>();

		for (FwRoleDepVarDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
