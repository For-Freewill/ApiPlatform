package com.youzan.ycm.qa.enable.platform.biz.jenkins;

import org.gitlab4j.api.GitLabApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


/**
 * @Author qibu
 * @create 2021/8/25 11:35 AM
 */
@Configuration
public class GitLabConfiguration {

    @Value("${gitLab.serverUri}")
    private String serverUri;
    @Value("${gitLab.token}")
    private String token;

    /*注入gitLabApi对象*/
    @Bean(name = "gitLabApi")
    @Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public GitLabApi getGitLabApi() {
        return new GitLabApi(serverUri, token);
    }

}
