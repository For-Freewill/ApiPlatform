/*
package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.shop;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.MarketCouponService;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

*/
/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:11
 **//*

@Service
public class MarketCouponServiceImpl implements MarketCouponService {

    @Autowired(required = false)
    public MkCouponMapper mkCouponMapper;

    @Autowired(required = false)
    public MkCouponRuleMapper mkCouponRuleMapper;

    @Autowired(required = false)
    public MkCouponAssetMapper mkCouponAssetMapper;

    @Autowired(required = false)
    public MkCouponSnapshotMapper mkCouponSnapshotMapper;

    @Autowired(required = false)
    public MkCouponSendRecordMapper mkCouponSendRecordMapper;

    @Autowired(required = false)
    public MkCouponSendRecordDetailMapper mkCouponSendRecordDetailMapper;

    */
/**
     * 清理某笔订单下所有的营销券数据,根据活动ID来操作
     *//*

    public void deleteMarketCouponData(Long id) {

        List<MkCouponEntity> mkCouponEntityList =
                mkCouponMapper.selectList(
                        new QueryWrapper<MkCouponEntity>().lambda().eq(MkCouponEntity::getId, id));

        mkCouponEntityList.forEach(item -> {
            List<MkCouponSendRecordEntity> mkCouponSendRecordEntityList =
                    mkCouponSendRecordMapper.selectList(
                            new QueryWrapper<MkCouponSendRecordEntity>().lambda().eq(MkCouponSendRecordEntity::getCouponId, item.getId()));
            mkCouponSendRecordEntityList.forEach(mkCouponEntityItem -> {

                mkCouponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetailEntity>().lambda().eq(MkCouponSendRecordDetailEntity::getSendRecordId, mkCouponEntityItem.getId()));
                mkCouponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecordEntity>().lambda().eq(MkCouponSendRecordEntity::getCouponId, mkCouponEntityItem.getId()));
            });
            mkCouponRuleMapper.delete(new QueryWrapper<MkCouponRuleEntity>().lambda().eq(MkCouponRuleEntity::getCouponId, item.getId()));
            mkCouponAssetMapper.delete(new QueryWrapper<MkCouponAssetEntity>().lambda().eq(MkCouponAssetEntity::getCouponId, item.getId()));
            mkCouponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshotEntity>().lambda().eq(MkCouponSnapshotEntity::getCouponId, item.getId()));
            mkCouponMapper.delete(new QueryWrapper<MkCouponEntity>().lambda().eq(MkCouponEntity::getId, item.getId()));
        });
    }
}
*/
