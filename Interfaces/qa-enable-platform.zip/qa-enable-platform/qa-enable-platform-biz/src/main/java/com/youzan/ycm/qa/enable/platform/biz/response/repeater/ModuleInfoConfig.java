package com.youzan.ycm.qa.enable.platform.biz.response.repeater;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author wulei
 * @date 2021/12/7 10:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ModuleInfoConfig {
    /**
     * 是否开启ttl线程上下文切换
     * <p>
     * 开启之后，才能将并发线程中发生的子调用记录下来，否则无法录制到并发子线程的子调用信息
     * <p>
     * 原理是将住线程的threadLocal拷贝到子线程，执行任务完成后恢复
     *
     * @see com.alibaba.ttl.TransmittableThreadLocal
     */
    private boolean useTtl;

    /**
     * 是否执行录制降级策略
     * <p>
     * 开启之后，不进行录制，只处理回放请求
     */
    private boolean degrade;

    /**
     * 异常发生阈值；默认1000
     * 当{@code ExceptionAware} 感知到异常次数超过阈值后，会降级模块
     */
    private Integer exceptionThreshold = 1000;

    /**
     * 采样率；最小力度万分之一
     * 10000 代表 100%
     */
    private Integer sampleRate = 10000;

    /**
     * 插件地址
     */
    private String pluginsPath;

    /**
     * 由于HTTP接口的量太大（前后端未分离的情况可能还有静态资源）因此必须走白名单匹配模式才录制
     */
    private List<String> httpEntrancePatterns = Lists.newArrayList();

    /**
     * java入口插件动态增强的行为
     */
    private List<Behavior> javaEntranceBehaviors = Lists.newArrayList();

    /**
     * java子调用插件动态增强的行为
     */
    private List<Behavior> javaSubInvokeBehaviors = Lists.newArrayList();

    /**
     * 需要启动的插件
     */
    private List<String> pluginIdentities = Lists.newArrayList();

    /**
     * 回放器插件
     */
    private List<String> repeatIdentities = Lists.newArrayList();
}
