package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShopProductAckDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShopProductAckDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺产品ACK
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
public class FwShopProductAckTransfer {

	public static FwShopProductAckDTO toBO(FwShopProductAckDO d) {

		if (d == null) {

			return null;
		}

		FwShopProductAckDTO fwShopProductAckBO = new FwShopProductAckDTO();
		fwShopProductAckBO.setId(d.getId());
		fwShopProductAckBO.setKdtId(d.getKdtId());
		fwShopProductAckBO.setOrderId(d.getOrderId());
		fwShopProductAckBO.setAcked(d.getAcked());
		fwShopProductAckBO.setCreatedAt(d.getCreatedAt());
		fwShopProductAckBO.setUpdatedAt(d.getUpdatedAt());

		return fwShopProductAckBO;
	}

	public static FwShopProductAckDO toDO(FwShopProductAckDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShopProductAckDO fwShopProductAckDO = new FwShopProductAckDO();
		fwShopProductAckDO.setId(bo.getId());
		fwShopProductAckDO.setKdtId(bo.getKdtId());
		fwShopProductAckDO.setOrderId(bo.getOrderId());
		fwShopProductAckDO.setAcked(bo.getAcked());
		fwShopProductAckDO.setCreatedAt(bo.getCreatedAt());
		fwShopProductAckDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShopProductAckDO;
	}

	public static List<FwShopProductAckDTO> toBOList(List<FwShopProductAckDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShopProductAckDTO>();
		}

		List<FwShopProductAckDTO> boList = new ArrayList<FwShopProductAckDTO>();
		for (FwShopProductAckDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShopProductAckDO> toDOList(List<FwShopProductAckDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShopProductAckDO>();
		}

		List<FwShopProductAckDO> doList = new ArrayList<FwShopProductAckDO>();

		for (FwShopProductAckDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
