package com.youzan.ycm.qa.enable.platform.biz.commonutils;

/**
 * @author wulei
 * @date 2021/11/12 11:46
 */
public class Test {
}
