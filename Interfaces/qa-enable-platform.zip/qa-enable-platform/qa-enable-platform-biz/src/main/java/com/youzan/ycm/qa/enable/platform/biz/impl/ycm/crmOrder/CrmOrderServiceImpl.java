package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.crmOrder;

import com.youzan.api.common.response.PlainResult;
import com.youzan.crm.support.api.dto.orderproposal.*;
import com.youzan.crm.support.api.enums.reduce.BuyType;
import com.youzan.crm.support.api.service.orderproposal.OrderProposalInstanceRemoteService;
import com.youzan.enable.common.model.entity.UserIdentifier;
import com.youzan.enable.crm.shop.api.dto.ShopBasicDTO;
import com.youzan.enable.crm.shop.api.service.ShopBasicRemoteService;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmOrder.CreateCrmApprovalNoRequest;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import  com.youzan.ycm.qa.enable.platform.api.service.ycm.crmOrder.CrmOrderService;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.youzan.enable.common.model.enums.organization.OrgTypeEnum.QIMA;

/**
 * Created by baoyan on 2021-04-25.
 */
@Slf4j
@Service("crmOrderService")

public class CrmOrderServiceImpl implements CrmOrderService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private OrderProposalInstanceRemoteService orderProposalInstanceRemoteService;
    @Resource
    private ShopBasicRemoteService shopBasicRemoteService;
    @Override
    public PlainResult<String>createCrmApprovalNo(CreateCrmApprovalNoRequest request){
        REQUEST_LOGGER.info("生成审批流:" + request);

        PlainResult<ShopBasicDTO> queryResult = new  PlainResult<ShopBasicDTO>();

        AssertUtil.isAllNotNone(request.getKdtId(), "店铺id不能为空！");
        AssertUtil.isAllNotNone(request.getOpenType(), "请选择开通方式！");
        AssertUtil.isAllNotNone(request.getMobile(), "手机号不能为空！");

        //  参数组装
        SubmitOrderDTO submitOrderDTO = new SubmitOrderDTO();
        SubmitOrderCustomerInfoDTO customerInfo = new SubmitOrderCustomerInfoDTO();

        if(request.getKdtId()!= null){
            customerInfo.setKdtId(request.getKdtId());
            queryResult = shopBasicRemoteService.getByKdtId(request.getKdtId());
        }
        if(request.getOpenType()!= null){
            customerInfo.setOpenType(request.getOpenType());
        }
        if(request.getMobile()!= null&&request.getMobile().equals(queryResult.getData().getMobile())){
            customerInfo.setMobile(request.getMobile());
        }else{
            log.error("创建审批流失败:"+"手机号输入错误！");
            throw new EnableException(ResultCode.CREATE_APPROVALNO_ERROR.getCode(), "创建审批流失败:"+"手机号输入错误！");
        }
        customerInfo.setBuyType(BuyType.NEW);
        customerInfo.setCompanyName("湖南哩哩啦啦科技有限公司");
        customerInfo.setOrderType("KA");
        customerInfo.setProductType("WSC_CHAIN_KA");
        customerInfo.setOpportunityId(729975L);
        customerInfo.setServiceFormKey("");
        submitOrderDTO.setCustomerInfo(customerInfo);

        UserIdentifier applicant = new UserIdentifier();
        applicant.setUserId(5176L);
        applicant.setType(QIMA);
        submitOrderDTO.setApplicant(applicant);

        submitOrderDTO.setContractInfo("[{\"uid\":\"fun-upload-1618887207274-8\",\"filename\":\"国王.jpg\",\"type\":\"image/jpeg\",\"url\":\"https://file-pr-test.yzcdn.cn/upload_files/yz-test-private-file/2021/04/20/Fhx-ytTIR0WsVONHwhLY53HZt9AF.jpg?e=1618902900&token=pNRZT0KqE-4QuBa6MxYRg-Uc-FTJ8vw_TDVMOYK0:5ugldAx175IA-IV7S1tBGALQQ5Y=\"}]");
        OrderInfoDTO orderInfo = new OrderInfoDTO();
        orderInfo.setAmount("1");
        orderInfo.setItemId(8296);
        orderInfo.setNumber(1);
        submitOrderDTO.setOrderInfos(Arrays.asList(orderInfo));

        PayInfoDTO payInfo = new PayInfoDTO();
        payInfo.setPayCertificate("[{\"uid\":\"fun-upload-1618887207274-7\",\"filename\":\"国王.jpg\",\"type\":\"image/jpeg\",\"url\":\"https://file-pr-test.yzcdn.cn/upload_files/yz-test-private-file/2021/04/20/Fhx-ytTIR0WsVONHwhLY53HZt9AF.jpg?e=1618902896&token=pNRZT0KqE-4QuBa6MxYRg-Uc-FTJ8vw_TDVMOYK0:YrN82QoDrGK6rVv5nb1WiK9oBI0=\"}]");

        PayRecordDTO payRecordDTO = new PayRecordDTO();
        payRecordDTO.setAmount("1");
        payRecordDTO.setPayAccount("1");
        Date payAt = new Date(2021,1,1);
        payRecordDTO.setPayAt(payAt);
        payInfo.setPayRecords(Arrays.asList(payRecordDTO));
        submitOrderDTO.setPayInfo(payInfo);
        submitOrderDTO.setRemark("");

        PlainResult<String> submitOrderResult = orderProposalInstanceRemoteService.submitOrder(submitOrderDTO);
        if(submitOrderResult.getCode()!= 200){
            log.error("创建审批流异常:"+submitOrderResult.toString());
            throw new EnableException(ResultCode.CREATE_APPROVALNO_ERROR.getCode(),ResultCode.CREATE_APPROVALNO_ERROR.getMsg());
        }

        // 3-封装结果
        PlainResult<String> result = new PlainResult<>();
        result.setData(submitOrderResult.getData());
        return  result;
    }
}
