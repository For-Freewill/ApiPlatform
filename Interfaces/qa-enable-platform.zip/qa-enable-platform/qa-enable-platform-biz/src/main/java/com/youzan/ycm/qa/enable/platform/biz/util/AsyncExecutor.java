package com.youzan.ycm.qa.enable.platform.biz.util;

import java.util.concurrent.*;

/**
 * @author wuwu
 * @date 2021/7/18 4:50 PM
 */
public class AsyncExecutor {

    private final static ExecutorService executorService = Executors.newFixedThreadPool(5);


    public static void execute(Runnable runnable) {
        executorService.submit(runnable);
    }
}
