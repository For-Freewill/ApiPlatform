package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwHistProcInstDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwHistProcInstDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 历史服务流程实例
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:50
 */
public class FwHistProcInstTransfer {

	public static FwHistProcInstDTO toBO(FwHistProcInstDO d) {

		if (d == null) {

			return null;
		}

		FwHistProcInstDTO fwHistProcInstBO = new FwHistProcInstDTO();
		fwHistProcInstBO.setId(d.getId());
		fwHistProcInstBO.setProcInstId(d.getProcInstId());
		fwHistProcInstBO.setKdtId(d.getKdtId());
		fwHistProcInstBO.setProcTemplate(d.getProcTemplate());
		fwHistProcInstBO.setState(d.getState());
		fwHistProcInstBO.setStartTime(d.getStartTime());
		fwHistProcInstBO.setEndTime(d.getEndTime());
		fwHistProcInstBO.setStartVariable(d.getStartVariable());
		fwHistProcInstBO.setEndVariable(d.getEndVariable());
		fwHistProcInstBO.setCreatedAt(d.getCreatedAt());
		fwHistProcInstBO.setUpdatedAt(d.getUpdatedAt());

		return fwHistProcInstBO;
	}

	public static FwHistProcInstDO toDO(FwHistProcInstDTO bo) {

        if (bo == null) {

			return null;
		}

		FwHistProcInstDO fwHistProcInstDO = new FwHistProcInstDO();
		fwHistProcInstDO.setId(bo.getId());
		fwHistProcInstDO.setProcInstId(bo.getProcInstId());
		fwHistProcInstDO.setKdtId(bo.getKdtId());
		fwHistProcInstDO.setProcTemplate(bo.getProcTemplate());
		fwHistProcInstDO.setState(bo.getState());
		fwHistProcInstDO.setStartTime(bo.getStartTime());
		fwHistProcInstDO.setEndTime(bo.getEndTime());
		fwHistProcInstDO.setStartVariable(bo.getStartVariable());
		fwHistProcInstDO.setEndVariable(bo.getEndVariable());
		fwHistProcInstDO.setCreatedAt(bo.getCreatedAt());
		fwHistProcInstDO.setUpdatedAt(bo.getUpdatedAt());

		return fwHistProcInstDO;
	}

	public static List<FwHistProcInstDTO> toBOList(List<FwHistProcInstDO> doList) {

		if (doList == null) {

			return new ArrayList<FwHistProcInstDTO>();
		}

		List<FwHistProcInstDTO> boList = new ArrayList<FwHistProcInstDTO>();
		for (FwHistProcInstDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwHistProcInstDO> toDOList(List<FwHistProcInstDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwHistProcInstDO>();
		}

		List<FwHistProcInstDO> doList = new ArrayList<FwHistProcInstDO>();

		for (FwHistProcInstDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
