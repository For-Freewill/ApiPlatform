package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShoproleBindingDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShoproleBindingDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺角色绑定关系表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:51
 */
public class FwShoproleBindingTransfer {

	public static FwShoproleBindingDTO toBO(FwShoproleBindingDO d) {

		if (d == null) {

			return null;
		}

        FwShoproleBindingDTO fwShoproleBindingBO = new FwShoproleBindingDTO();
		fwShoproleBindingBO.setId(d.getId());
		fwShoproleBindingBO.setShopRoleId(d.getShopRoleId());
		fwShoproleBindingBO.setKdtId(d.getKdtId());
		fwShoproleBindingBO.setRoleType(d.getRoleType());
		fwShoproleBindingBO.setPoolId(d.getPoolId());
		fwShoproleBindingBO.setPoolType(d.getPoolType());
		fwShoproleBindingBO.setPoolName(d.getPoolName());
		fwShoproleBindingBO.setBoundAt(d.getBoundAt());
		fwShoproleBindingBO.setReason(d.getReason());
		fwShoproleBindingBO.setCreatedAt(d.getCreatedAt());
		fwShoproleBindingBO.setUpdatedAt(d.getUpdatedAt());

		return fwShoproleBindingBO;
	}

	public static FwShoproleBindingDO toDO(FwShoproleBindingDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShoproleBindingDO fwShoproleBindingDO = new FwShoproleBindingDO();
		fwShoproleBindingDO.setId(bo.getId());
		fwShoproleBindingDO.setShopRoleId(bo.getShopRoleId());
		fwShoproleBindingDO.setKdtId(bo.getKdtId());
		fwShoproleBindingDO.setRoleType(bo.getRoleType());
		fwShoproleBindingDO.setPoolId(bo.getPoolId());
		fwShoproleBindingDO.setPoolType(bo.getPoolType());
		fwShoproleBindingDO.setPoolName(bo.getPoolName());
		fwShoproleBindingDO.setBoundAt(bo.getBoundAt());
		fwShoproleBindingDO.setReason(bo.getReason());
		fwShoproleBindingDO.setCreatedAt(bo.getCreatedAt());
		fwShoproleBindingDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShoproleBindingDO;
	}

	public static List<FwShoproleBindingDTO> toBOList(List<FwShoproleBindingDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShoproleBindingDTO>();
		}

		List<FwShoproleBindingDTO> boList = new ArrayList<FwShoproleBindingDTO>();
		for (FwShoproleBindingDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShoproleBindingDO> toDOList(List<FwShoproleBindingDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShoproleBindingDO>();
		}

		List<FwShoproleBindingDO> doList = new ArrayList<FwShoproleBindingDO>();

		for (FwShoproleBindingDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
