package com.youzan.ycm.qa.enable.platform.biz.impl.order;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.enable.crm.meta.api.dto.product.*;
import com.youzan.enable.crm.meta.api.service.product.ProductRemoteService;
import com.youzan.ycm.qa.enable.platform.biz.service.order.ProductDependService;
import com.youzan.ycm.qa.enable.platform.biz.util.Unwrapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-15 18:50
 **/
@Service
public class ProductDependServiceImpl implements ProductDependService {
    @Resource
    private ProductRemoteService productRemoteService;

    @Override
    public Boolean insert(ProductCreateDTO createDTO) {
        PlainResult<Boolean> result = productRemoteService.insert(createDTO);
        return Unwrapper.unwrap(result);
    }

    @Override
    public Boolean updateById(ProductUpdateDTO updateDTO) {
        PlainResult<Boolean> result = productRemoteService.updateById(updateDTO);
        return Unwrapper.unwrap(result);
    }

    @Override
    public ProductExtendDTO getByItemId(Integer itemId) {
        PlainResult<ProductExtendDTO> result = productRemoteService.getByItemId(itemId);
        return Unwrapper.unwrap(result);
    }

    @Override
    public ProductExtendDTO getById(Long id) {
        PlainResult<ProductExtendDTO> result = productRemoteService.getById(id);
        return Unwrapper.unwrap(result);
    }

    @Override
    public ListResult<ProductExtendDTO> queryProduct(ProductConditionDTO condition) {
        return productRemoteService.queryProduct(condition);
    }

    @Override
    public List<ProductTypeAggregationDTO> queryAllProduct() {
        return Unwrapper.unwrap(productRemoteService.getAllProduct());
    }
}
