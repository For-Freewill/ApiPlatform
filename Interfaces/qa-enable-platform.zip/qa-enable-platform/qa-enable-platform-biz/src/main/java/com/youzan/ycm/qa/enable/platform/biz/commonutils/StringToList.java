package com.youzan.ycm.qa.enable.platform.biz.commonutils;


import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/17 11:02
 */
public class StringToList {

    /**
     * str ==> List<String>
     *
     * @param inputStr
     * @param delimeter
     * @return
     */
    public static List<String> strToList(String inputStr, String delimeter) {
        List<String> outputList = new ArrayList<>();
        String str1 = StringUtils.remove(inputStr, '[');
        String str2 = StringUtils.remove(str1, ']');
        String str = StringUtils.deleteWhitespace(str2);
        if (StringUtils.isNotEmpty(inputStr) && StringUtils.isNotEmpty(delimeter)) {
            for (String s : str.split(delimeter)) {
                outputList.add(s);
            }
        }
        return outputList;
    }

}
