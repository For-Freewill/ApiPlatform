package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.yunFee;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.code.NewActivationCodeRequest;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.yunFee.FcFeeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.code.NewActivationCodeResponse;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.yunFee.FcFeeResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.yunFee.YunFeeService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.LegalTables;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeResourcePackageEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeResourcePackageLogEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeYopProtocolEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeYopProtocolLogEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeResourcePackageLogMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeResourcePackageMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeYopProtocolLogMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeYopProtocolMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wulei
 * @date 2021/1/20 15:14
 */
@Slf4j
@Service("yunFeeService")
public class YunFeeServiceImpl implements YunFeeService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private FcFeeYopProtocolMapper fcFeeYopProtocolMapper;
    @Resource
    private FcFeeYopProtocolLogMapper fcFeeYopProtocolLogMapper;
    @Resource
    private FcFeeResourcePackageMapper fcFeeResourcePackageMapper;
    @Resource
    private FcFeeResourcePackageLogMapper fcFeeResourcePackageLogMapper;

    /**
     * 根据选项，落对应的订单额度订单
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<NewActivationCodeResponse> createYunFeeOrder(NewActivationCodeRequest request) {
        return null;
    }

    /**
     * 查询计费侧，云服务费相关的4个表
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<FcFeeResponse> selectFcFee(FcFeeRequest request) {
        REQUEST_LOGGER.info("计费侧查询:" + request);

        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getTables(), "tables 不能为空！");
        AssertUtil.isAllNotNone(request.getKdtId(), "kdtId 不能为空！");
        // 2-执行查询
        FcFeeResponse fcFeeResponse = new FcFeeResponse();
        Map<String, Object> resultMaps = resultMap(request);
        // 3-封装结果
        fcFeeResponse.setTotal(Long.valueOf(resultMaps.size()));
        fcFeeResponse.setDetails(resultMaps);
        PlainResult<FcFeeResponse> plainResult = new PlainResult<>();
        plainResult.setData(fcFeeResponse);
        return plainResult;
    }

    /**
     * 表名校验
     *
     * @return
     */
    private List<String> verifyTables(FcFeeRequest request) {
        // 1-请求列表去重
        List<String> queryTables = request.getTables().stream().distinct().collect(Collectors.toList());
        // 2-合法表名
        List<String> tables = LegalTables.yunFeeFcFeeLegalTables();
        // 3-判断是否有不在合法表内的数据
        List<String> bad = queryTables.stream().filter(tb -> !tables.contains(tb)).collect(Collectors.toList());
        if (bad.size() > 0) {
            log.info("请求的tables名称不存在" + bad.toString());
            throw new EnableException(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMsg());
        }
        return queryTables;
    }

    /**
     * 查询结果数据
     *
     * @param request
     * @return
     */
    private Map<String, Object> resultMap(FcFeeRequest request) {
        Map<String, Object> resultMap = new LinkedHashMap<>();

        //1-校验入参的表格
        List<String> queryTables = verifyTables(request);

        //2-查询code是否存在
        List<FcFeeResourcePackageEntity> res = fcFeeResourcePackageMapper.selectList(new QueryWrapper<FcFeeResourcePackageEntity>().lambda().eq(FcFeeResourcePackageEntity::getKdtId, request.getKdtId()));
        //
        if (res.size() == 0) {
            return resultMap;
        } else {
            //fc_fee_resource_package
            if (queryTables.contains("fc_fee_resource_package") && fcFeeResourcePackageMapper.selectList(new QueryWrapper<FcFeeResourcePackageEntity>().lambda().eq(FcFeeResourcePackageEntity::getKdtId, request.getKdtId())).size() != 0) {
                resultMap.put("fc_fee_resource_package", fcFeeResourcePackageMapper.selectList(new QueryWrapper<FcFeeResourcePackageEntity>().lambda().eq(FcFeeResourcePackageEntity::getKdtId, Long.valueOf(request.getKdtId())).last("limit 500")));
            }

            //fc_fee_yop_protocol
            if (queryTables.contains("fc_fee_yop_protocol") && fcFeeYopProtocolMapper.selectList(new QueryWrapper<FcFeeYopProtocolEntity>().lambda().eq(FcFeeYopProtocolEntity::getKdtId, request.getKdtId())).size() != 0) {
                resultMap.put("fc_fee_yop_protocol", fcFeeYopProtocolMapper.selectList(new QueryWrapper<FcFeeYopProtocolEntity>().lambda().eq(FcFeeYopProtocolEntity::getKdtId, Long.valueOf(request.getKdtId())).last("limit 500")));
            }

            //fc_fee_resource_package_log
            if (queryTables.contains("fc_fee_resource_package_log") && fcFeeResourcePackageLogMapper.selectList(new QueryWrapper<FcFeeResourcePackageLogEntity>().lambda().eq(FcFeeResourcePackageLogEntity::getKdtId, request.getKdtId())).size() != 0) {
                resultMap.put("fc_fee_resource_package_log", fcFeeResourcePackageLogMapper.selectList(new QueryWrapper<FcFeeResourcePackageLogEntity>().lambda().eq(FcFeeResourcePackageLogEntity::getKdtId, Long.valueOf(request.getKdtId())).last("limit 500")));
            }

            //fc_fee_yop_protocol_log
            if (queryTables.contains("fc_fee_yop_protocol_log") && fcFeeYopProtocolLogMapper.selectList(new QueryWrapper<FcFeeYopProtocolLogEntity>().lambda().eq(FcFeeYopProtocolLogEntity::getKdtId, request.getKdtId())).size() != 0) {
                resultMap.put("fc_fee_yop_protocol_log", fcFeeYopProtocolLogMapper.selectList(new QueryWrapper<FcFeeYopProtocolLogEntity>().lambda().eq(FcFeeYopProtocolLogEntity::getKdtId, Long.valueOf(request.getKdtId())).last("limit 500")));
            }
        }
        return resultMap;
    }
}
