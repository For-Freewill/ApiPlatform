package com.youzan.ycm.qa.enable.platform.biz.impl.ycm;

import com.youzan.api.common.response.PlainResult;
import com.youzan.shopcenter.shop.service.ShopBaseReadService;
import com.youzan.ycm.qa.enable.platform.api.request.yzcoin.YzCoinRequest;
import com.youzan.ycm.qa.enable.platform.api.response.yzcoin.YzCoinRep;
import com.youzan.ycm.qa.enable.platform.api.service.yzcoin.YzCoinEnableService;
import com.youzan.yop.yzcoin.api.AccountService;
import com.youzan.yop.yzcoin.api.YzCoinService;
import com.youzan.yop.yzcoin.api.dto.AccountBalanceInfoDTO;
import com.youzan.yop.yzcoin.api.dto.YzCoinGrantDTO;
import com.youzan.yop.yzcoin.api.param.YzCoinGrantOrRecycleParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author leifeiyun
 * @date 2022/1/6
 **/
@Slf4j
@Service("yzCoinEnableService")
public class YzCoinEnableServiceImpl implements YzCoinEnableService {

    @Autowired(required = false)
    YzCoinService yzCoinService;
    @Autowired(required = false)
    ShopBaseReadService shopBaseReadService;
    @Autowired(required = false)
    AccountService accountService;

    @Override
    public PlainResult<YzCoinRep> grantYzCoin(YzCoinRequest yzCoinRequest) {
        YzCoinRep yzCoinRep = new YzCoinRep();
        Long kdtId=yzCoinRequest.getKdtId();
        Boolean isKdtIdExit = shopBaseReadService.isKdtIdExisted(yzCoinRequest.getKdtId()).isData();
        if(isKdtIdExit){
            Long yzCoin=yzCoinRequest.getYzCoin()*100;
            String waterNo = "qaEnableGrant" + System.currentTimeMillis() + kdtId + (int) Math.random() * 100000;
            //入参封装
            YzCoinGrantOrRecycleParam yzCoinParam=new YzCoinGrantOrRecycleParam();
            yzCoinParam.setKdtId(kdtId);
            yzCoinParam.setInfo("qaEnable充值");
            yzCoinParam.setMoney(yzCoin);
            yzCoinParam.setOutWaterNo(waterNo);
            yzCoinParam.setType("grant");
            yzCoinParam.setSourceTag("qaEnable");

            PlainResult<YzCoinGrantDTO> result = yzCoinService.grant(yzCoinParam);
            if(result!=null){
                yzCoinRep.setYzCoinBalance(accountService.getBalanceByKdtId(kdtId).getData().getBalance()/100);
                yzCoinRep.setMessage("成功充值有赞币！");

            }else {
                yzCoinRep.setMessage("充值失败,如需紧急充值，请联系雷飞云");
            }
        }else {
            yzCoinRep.setMessage("店铺不存在!!，你看看你是不是环境搞错了咩~~~");
        }
        PlainResult<YzCoinRep> plainResult = new PlainResult<>();
        plainResult.setData(yzCoinRep);
        return plainResult;
    }

    @Override
    public PlainResult<YzCoinRep> resetYzCoin(YzCoinRequest yzCoinRequest) {
        YzCoinRep yzCoinRep = new YzCoinRep();
        Long kdtId = yzCoinRequest.getKdtId();
        Boolean isKdtIdExit = shopBaseReadService.isKdtIdExisted(kdtId).isData();
        if(isKdtIdExit){
            //先回收有赞币
            String recycleWaterNo = "qaEnableReset" + System.currentTimeMillis() + kdtId + (int) Math.random() * 100000;
            YzCoinGrantOrRecycleParam yzCoinRecycleParam = new YzCoinGrantOrRecycleParam();
            yzCoinRecycleParam.setKdtId(kdtId);
            yzCoinRecycleParam.setInfo("qaEnable回收");
            yzCoinRecycleParam.setMoney(accountService.getBalanceByKdtId(kdtId).getData().getBalance());
            yzCoinRecycleParam.setOutWaterNo(recycleWaterNo);
            yzCoinRecycleParam.setType("recycle");
            yzCoinRecycleParam.setSourceTag("qaEnable");
            PlainResult<Long> result = yzCoinService.recycle(yzCoinRecycleParam);

            if(result!=null){
                yzCoinRep.setYzCoinBalance(accountService.getBalanceByKdtId(kdtId).getData().getBalance()/100);
                yzCoinRep.setMessage("重置成功");
            }else {
                yzCoinRep.setMessage("重置数额失败,如需紧急充值，请联系雷飞云");
            }
        }else {
            yzCoinRep.setMessage("店铺不存在!!，你看看你是不是环境搞错了咩~~~");
        }
        PlainResult<YzCoinRep> plainResult = new PlainResult<>();
        plainResult.setData(yzCoinRep);
        return plainResult;
    }

    @Override
    public PlainResult<YzCoinRep> getYzCoinBalance(YzCoinRequest yzCoinRequest) {
        Long kdtId = yzCoinRequest.getKdtId();
        YzCoinRep yzCoinRep = new YzCoinRep();
        Boolean isKdtIdExit = shopBaseReadService.isKdtIdExisted(kdtId).isData();
        if(isKdtIdExit){

            PlainResult<AccountBalanceInfoDTO> result = accountService.getBalanceByKdtId(kdtId);
            Long money  = result.getData().getBalance();
            if(result!=null){
                yzCoinRep.setYzCoinBalance(money/100);
            }else {
                yzCoinRep.setMessage("查询失败");
            }
        }else {
            yzCoinRep.setMessage("店铺不存在!!，你看看你是不是环境搞错了咩~~~");
        }
        PlainResult<YzCoinRep> plainResult = new PlainResult<>();
        plainResult.setData(yzCoinRep);
        return plainResult;
    }
}
