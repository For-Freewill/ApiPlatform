package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwHistProcRoleDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwHistProcRoleDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 历史流程角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:18
 */
public class FwHistProcRoleTransfer {

	public static FwHistProcRoleDTO toBO(FwHistProcRoleDO d) {

		if (d == null) {

			return null;
		}

        FwHistProcRoleDTO fwHistProcRoleBO = new FwHistProcRoleDTO();
		fwHistProcRoleBO.setId(d.getId());
		fwHistProcRoleBO.setProcRoleId(d.getProcRoleId());
		fwHistProcRoleBO.setProcInstId(d.getProcInstId());
		fwHistProcRoleBO.setKdtId(d.getKdtId());
		fwHistProcRoleBO.setProcTemplate(d.getProcTemplate());
		fwHistProcRoleBO.setRoleType(d.getRoleType());
		fwHistProcRoleBO.setState(d.getState());
		fwHistProcRoleBO.setStartTime(d.getStartTime());
		fwHistProcRoleBO.setEndTime(d.getEndTime());
		fwHistProcRoleBO.setStartVariable(d.getStartVariable());
		fwHistProcRoleBO.setEndVariable(d.getEndVariable());
		fwHistProcRoleBO.setCreatedAt(d.getCreatedAt());
		fwHistProcRoleBO.setUpdatedAt(d.getUpdatedAt());

		return fwHistProcRoleBO;
	}

	public static FwHistProcRoleDO toDO(FwHistProcRoleDTO bo) {

        if (bo == null) {

			return null;
		}

		FwHistProcRoleDO fwHistProcRoleDO = new FwHistProcRoleDO();
		fwHistProcRoleDO.setId(bo.getId());
		fwHistProcRoleDO.setProcRoleId(bo.getProcRoleId());
		fwHistProcRoleDO.setProcInstId(bo.getProcInstId());
		fwHistProcRoleDO.setKdtId(bo.getKdtId());
		fwHistProcRoleDO.setProcTemplate(bo.getProcTemplate());
		fwHistProcRoleDO.setRoleType(bo.getRoleType());
		fwHistProcRoleDO.setState(bo.getState());
		fwHistProcRoleDO.setStartTime(bo.getStartTime());
		fwHistProcRoleDO.setEndTime(bo.getEndTime());
		fwHistProcRoleDO.setStartVariable(bo.getStartVariable());
		fwHistProcRoleDO.setEndVariable(bo.getEndVariable());
		fwHistProcRoleDO.setCreatedAt(bo.getCreatedAt());
		fwHistProcRoleDO.setUpdatedAt(bo.getUpdatedAt());

		return fwHistProcRoleDO;
	}

	public static List<FwHistProcRoleDTO> toBOList(List<FwHistProcRoleDO> doList) {

		if (doList == null) {

			return new ArrayList<FwHistProcRoleDTO>();
		}

		List<FwHistProcRoleDTO> boList = new ArrayList<FwHistProcRoleDTO>();
		for (FwHistProcRoleDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwHistProcRoleDO> toDOList(List<FwHistProcRoleDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwHistProcRoleDO>();
		}

		List<FwHistProcRoleDO> doList = new ArrayList<FwHistProcRoleDO>();

		for (FwHistProcRoleDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
