package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.Paginator;
import com.youzan.api.common.response.PaginatorResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.api.common.vo.ListWithPaginatorVO;
import com.youzan.ycm.qa.enable.platform.api.enums.ExcuteResult;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SingleOwnerCaseExcuteRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseExcuteSummaryDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseWithAverageExecutionTime;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseWithExecutionSuccessRate;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CaseDetailService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CaseExcuteStatisticsByStaffService;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CountByOwnerEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.SingleOwnerCaseExcuteDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.SingleOwnerCaseExcuteDetailEntityV2;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CaseDetailMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.ExcuteDetailMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * @author hezhulin
 * @date 2021-08-17 15:59
 */
@Service(value = "caseExcuteStatisticsByStaffService")
public class CaseExcuteStatisticsByStaffServiceImpl implements CaseExcuteStatisticsByStaffService {

    //用例的成功率标准值
    public static final BigDecimal caseExecutionSuccessRate = new BigDecimal("0.950");
    //用例的执行时长标准值
    public static final BigDecimal caseAverageExecutionTime = new BigDecimal("2.00");;

    @Resource
    public ExcuteDetailMapper excuteDetailMapper;

    @Resource
    public CaseDetailMapper caseDetailMapper;

    /**
     * 人维度的用例执行情况汇总列表，限制执行时间的区间范围
     * @param startDate 统计的用例的执行时间不早于该时间
     * @param endDate 统计的用例的执行时间不晚于该时间
     * @return
     */
    @Override
    public PaginatorResult<CaseExcuteSummaryDTO> caseExcuteSummary(Date startDate, Date endDate, Paginator paginator) {

        List<CountByOwnerEntity> caseCountByOwner = caseDetailMapper.getOwnerCount();
        if (null == caseCountByOwner || caseCountByOwner.size() == 0){
            Paginator paginator1 = new Paginator(0);
            ListWithPaginatorVO<CaseExcuteSummaryDTO> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator1,null);
            PaginatorResult<CaseExcuteSummaryDTO> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }

        int pageSize= paginator.getPageSize();
        int pageStart = (paginator.getPage()-1)*pageSize;

        if (pageStart+1>caseCountByOwner.size()){
            Paginator paginator1 = new Paginator(caseCountByOwner.size());
            ListWithPaginatorVO<CaseExcuteSummaryDTO> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator1,null);
            PaginatorResult<CaseExcuteSummaryDTO> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }else {
            int total = caseCountByOwner.size();
            List<CaseExcuteSummaryDTO> caseExcuteSummaryDTOS = new ArrayList<>();
            List<CountByOwnerEntity> caseCountByOwner_curret = new ArrayList<>();
            if (pageStart+pageSize < caseCountByOwner.size()){
                caseCountByOwner_curret=caseCountByOwner.subList(pageStart,pageStart+pageSize);
            }
            else{
                caseCountByOwner_curret=caseCountByOwner.subList(pageStart,caseCountByOwner.size()-1);
                caseCountByOwner_curret.add(caseCountByOwner.get(caseCountByOwner.size()-1));
            }

            caseCountByOwner_curret.stream().forEach(entity->{
                int totalCase1 = excuteDetailMapper.querySingleOwnerCaseExcuteCountByExcuteCost(startDate, endDate, entity.getOwner(), caseAverageExecutionTime);
                int totalCase2 = excuteDetailMapper.querySingleOwnerCaseExcuteCountBySuccessRate(startDate,endDate,entity.getOwner(),caseExecutionSuccessRate);
                CaseExcuteSummaryDTO caseExcuteSummaryDTO = new CaseExcuteSummaryDTO();
                caseExcuteSummaryDTO.setOwner(entity.getOwner());
                caseExcuteSummaryDTO.setTotalCase(entity.getTotalCount());
                caseExcuteSummaryDTO.setAverageExecutionTimeGreaterThan2SecondTotalCase(totalCase1);
                caseExcuteSummaryDTO.setExecutionSuccessRateLessThan99PercentTotalCase(totalCase2);
                caseExcuteSummaryDTOS.add(caseExcuteSummaryDTO);
            });

            Paginator paginator1 = new Paginator(paginator.getPage(),pageSize,total);
            ListWithPaginatorVO<CaseExcuteSummaryDTO> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator1,caseExcuteSummaryDTOS);
            PaginatorResult<CaseExcuteSummaryDTO> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;

        }

    }

    /**
     * 执行成功率<99%的用例列表 99%的成功率代码里变量配置
     * @return
     */
    @Override
    public PaginatorResult<CaseWithExecutionSuccessRate> executionSuccessRateLessThan99PercentCaseList(SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO) {

        int count = excuteDetailMapper.querySingleOwnerCaseExcuteCountBySuccessRate(singleOwnerCaseExcuteRequestDTO.getStartDate(),singleOwnerCaseExcuteRequestDTO.getEndDate()
                ,singleOwnerCaseExcuteRequestDTO.getOwner(),caseExecutionSuccessRate);
        if (count==0){
            Paginator paginator = new Paginator(0);
            ListWithPaginatorVO<CaseWithExecutionSuccessRate> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,null);
            PaginatorResult<CaseWithExecutionSuccessRate> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }

        int pageSize= singleOwnerCaseExcuteRequestDTO.getPaginator().getPageSize();
        int pageStart = (singleOwnerCaseExcuteRequestDTO.getPaginator().getPage()-1)*pageSize;

        if (pageStart+1>count){
            Paginator paginator = new Paginator(count);
            ListWithPaginatorVO<CaseWithExecutionSuccessRate> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,null);
            PaginatorResult<CaseWithExecutionSuccessRate> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }else {
            List<SingleOwnerCaseExcuteDetailEntity> singleOwnerCaseExcuteDetailEntityList = excuteDetailMapper.querySingleOwnerCaseExcuteBySuccessRate(
                    singleOwnerCaseExcuteRequestDTO.getStartDate(),singleOwnerCaseExcuteRequestDTO.getEndDate(),
                    singleOwnerCaseExcuteRequestDTO.getOwner(),caseExecutionSuccessRate,
                    pageStart,pageSize);
            if (null==singleOwnerCaseExcuteDetailEntityList || singleOwnerCaseExcuteDetailEntityList.size()==0)
                throw new RuntimeException("数据统计异常，不应该走到这个逻辑");
            Paginator paginator = new Paginator(singleOwnerCaseExcuteRequestDTO.getPaginator().getPage(),pageSize,count);
            List<CaseWithExecutionSuccessRate> items = new ArrayList<>();
            singleOwnerCaseExcuteDetailEntityList.stream().forEach(it->{
                CaseWithExecutionSuccessRate caseWithExecutionSuccessRate = new CaseWithExecutionSuccessRate();
                caseWithExecutionSuccessRate.setCaseName(it.getCaseName());
                caseWithExecutionSuccessRate.setCaseUrl(it.getCaseUrl());
                caseWithExecutionSuccessRate.setCaseBelongApp(it.getCaseBelongApp());
                caseWithExecutionSuccessRate.setExecutionSuccessRate(it.getSuccessRate());
                items.add(caseWithExecutionSuccessRate);
            });
            ListWithPaginatorVO<CaseWithExecutionSuccessRate> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,items);
            PaginatorResult<CaseWithExecutionSuccessRate> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }
    }

    /**
     * 平均每次执行时长>2s的用例列表 2s的平均执行时间代码里变量配置
     * @param singleOwnerCaseExcuteRequestDTO
     * @return
     */
    @Override
    public PaginatorResult<CaseWithAverageExecutionTime> averageExecutionTimeGreaterThan2SecondCaseList(SingleOwnerCaseExcuteRequestDTO singleOwnerCaseExcuteRequestDTO) {

        int count = excuteDetailMapper.querySingleOwnerCaseExcuteCountByExcuteCost(singleOwnerCaseExcuteRequestDTO.getStartDate(),singleOwnerCaseExcuteRequestDTO.getEndDate()
                ,singleOwnerCaseExcuteRequestDTO.getOwner(),caseAverageExecutionTime);
        if (count==0){
            Paginator paginator = new Paginator(0);
            ListWithPaginatorVO<CaseWithAverageExecutionTime> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,null);
            PaginatorResult<CaseWithAverageExecutionTime> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }

        int pageSize= singleOwnerCaseExcuteRequestDTO.getPaginator().getPageSize();
        int pageStart = (singleOwnerCaseExcuteRequestDTO.getPaginator().getPage()-1)*pageSize;

        if (pageStart+1>count){
            Paginator paginator = new Paginator(count);
            ListWithPaginatorVO<CaseWithAverageExecutionTime> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,null);
            PaginatorResult<CaseWithAverageExecutionTime> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }else {
            List<SingleOwnerCaseExcuteDetailEntityV2> singleOwnerCaseExcuteDetailEntityList = excuteDetailMapper.querySingleOwnerCaseExcuteByExcuteCost(
                    singleOwnerCaseExcuteRequestDTO.getStartDate(),singleOwnerCaseExcuteRequestDTO.getEndDate(),
                    singleOwnerCaseExcuteRequestDTO.getOwner(),caseAverageExecutionTime,
                    pageStart,pageSize);
            if (null==singleOwnerCaseExcuteDetailEntityList || singleOwnerCaseExcuteDetailEntityList.size()==0)
                throw new RuntimeException("数据统计异常，不应该走到这个逻辑");
            Paginator paginator = new Paginator(singleOwnerCaseExcuteRequestDTO.getPaginator().getPage(),pageSize,count);
            List<CaseWithAverageExecutionTime> items = new ArrayList<>();
            singleOwnerCaseExcuteDetailEntityList.stream().forEach(it->{
                CaseWithAverageExecutionTime caseWithAverageExecutionTime = new CaseWithAverageExecutionTime();
                caseWithAverageExecutionTime.setCaseName(it.getCaseName());
                caseWithAverageExecutionTime.setCaseUrl(it.getCaseUrl());
                caseWithAverageExecutionTime.setCaseBelongApp(it.getCaseBelongApp());
                caseWithAverageExecutionTime.setAverageExecutionTime(it.getAverageExcuteCost());
                items.add(caseWithAverageExecutionTime);
            });
            ListWithPaginatorVO<CaseWithAverageExecutionTime> listWithPaginatorVO = new ListWithPaginatorVO<>(paginator,items);
            PaginatorResult<CaseWithAverageExecutionTime> result = new PaginatorResult<>();
            result.setData(listWithPaginatorVO);
            return result;
        }
    }

//    private Map<Long, Double> filtercaseExecutionSuccessRate(Date startDate,Date endDate,String owner){
//
//        List<SingleOwnerCaseExcuteDetailEntity> singleOwnerCaseExcuteDetails = excuteDetailMapper.querySingleOwnerCaseExcuteDetail(
//                startDate, endDate, owner);
//        if (null == singleOwnerCaseExcuteDetails || singleOwnerCaseExcuteDetails.size() == 0)
//            return null;
//        Map<Long,Integer> pass = new HashMap<>();
//        Map<Long,Integer> skipp = new HashMap<>();
//        Map<Long,Integer> fail = new HashMap<>();
//        singleOwnerCaseExcuteDetails.forEach(singleOwnerCaseExcuteDetailEntity -> {
//            if (singleOwnerCaseExcuteDetailEntity.getExcuteResult().intValue()==(ExcuteResult.PASSED).getCode().intValue()){
//                pass.put(singleOwnerCaseExcuteDetailEntity.getCaseId(),singleOwnerCaseExcuteDetailEntity.getTotal());
//            }
//            if (singleOwnerCaseExcuteDetailEntity.getExcuteResult().intValue()==(ExcuteResult.FAILED).getCode().intValue()){
//                fail.put(singleOwnerCaseExcuteDetailEntity.getCaseId(),singleOwnerCaseExcuteDetailEntity.getTotal());
//                if (!pass.containsKey(singleOwnerCaseExcuteDetailEntity.getCaseId()))
//                    pass.put(singleOwnerCaseExcuteDetailEntity.getCaseId(),Integer.valueOf(0));
//            }
//            if (singleOwnerCaseExcuteDetailEntity.getExcuteResult().intValue()==(ExcuteResult.SKIPPED).getCode().intValue()){
//                skipp.put(singleOwnerCaseExcuteDetailEntity.getCaseId(),singleOwnerCaseExcuteDetailEntity.getTotal());
//                if (!pass.containsKey(singleOwnerCaseExcuteDetailEntity.getCaseId()))
//                    pass.put(singleOwnerCaseExcuteDetailEntity.getCaseId(),Integer.valueOf(0));
//            }
//        });
//        Map<Long, Double> caseExecutionSuccessRates = new HashMap<>();
//        for (Map.Entry<Long,Integer> entry : pass.entrySet()){
//            Integer totalPass=entry.getValue();
//            Integer totalFail=0;
//            Integer totalSkipp=0;
//            if (fail.containsKey(entry.getKey()))
//                totalFail=fail.get(entry.getKey());
//            if (skipp.containsKey(entry.getKey()))
//                totalSkipp=skipp.get(entry.getKey());
//            BigDecimal totalPass2 = new BigDecimal(totalPass.toString());
//            BigDecimal totalFail2 = new BigDecimal(totalFail.toString());
//            BigDecimal totalSkipp2 = new BigDecimal(totalSkipp.toString());
//            BigDecimal total = totalPass2.add(totalFail2).add(totalSkipp2);
//            BigDecimal executionSuccessRate = totalPass2.divide(total,2,BigDecimal.ROUND_HALF_UP);
//            if (executionSuccessRate.compareTo(caseExecutionSuccessRate)==-1)
//                caseExecutionSuccessRates.put(entry.getKey(),Double.valueOf(executionSuccessRate.doubleValue()));
//        }
//        return caseExecutionSuccessRates;
//
//    }
}
