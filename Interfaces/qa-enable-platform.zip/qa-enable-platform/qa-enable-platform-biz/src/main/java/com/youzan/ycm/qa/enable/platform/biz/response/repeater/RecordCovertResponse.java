package com.youzan.ycm.qa.enable.platform.biz.response.repeater;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecordCovertResponse implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * request URL
     */
    private String requestURL;

    /**
     * request 方法
     */
    private String requestMethod;

    /**
     * request SC
     */
    private String sc;

    /**
     * response code
     */
    private String responseCode;

    /**
     * response data
     */
    private String responseData;

}
