package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailInsertRequest;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailUpdateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableTablesResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableTablesDetailService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableTablesDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableTablesDetailMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:07
 */
@Slf4j
@Service(value = "enableTablesDetailService")
public class EnableTablesDetailServiceImpl extends ServiceImpl<EnableTablesDetailMapper, EnableTablesDetailEntity> implements EnableTablesDetailService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private EnableTablesDetailService enableTablesDetailService;


    @Resource
    private EnableTablesDetailMapper enableTablesDetailMapper;

    /**
     * 查询全部
     *
     * @return
     */
    @Override
    public PlainResult<EnableTablesResponse> select() {
        return null;
    }

    /**
     * 查询全部表信息
     *
     * @return
     */
    @Override
    public PlainResult<List<EnableTablesDetailEntity>> selectAll() {
        PlainResult<List<EnableTablesDetailEntity>> plainResult = new PlainResult<>();
        List<EnableTablesDetailEntity> result = enableTablesDetailService.list();
        plainResult.setData(result);

        return plainResult;
    }

    /**
     * 插入记录
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<Boolean> insert(EnableTablesDetailInsertRequest request) {
        REQUEST_LOGGER.info("insert request = " + request);

        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getTableName(), "表名不能为空");
        AssertUtil.isAllNotNone(request.getTableDesc(), "表描述不能为空");
        AssertUtil.isAllNotNone(request.getTableType(), "表类型不能为空");
        // 2-属性复制
        EnableTablesDetailEntity enableTablesDetailEntity = new EnableTablesDetailEntity();
        BeanUtils.copyProperties(request, enableTablesDetailEntity);
        // 3-插入记录
        Boolean isSave = null;

        isSave = enableTablesDetailService.save(enableTablesDetailEntity);
        if (isSave) {
            plainResult.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }
        return plainResult;
    }

    /**
     * 更新记录byID
     *
     * @param request
     * @return
     */
    @Override
    public PlainResult<Boolean> updateById(EnableTablesDetailUpdateRequest request) {
        REQUEST_LOGGER.info("update request = " + request);

        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 1-校验入参数
        AssertUtil.isNotNull(request.getId(), "id不能为空");
        // 2-属性复制
        EnableTablesDetailEntity enableTablesDetailEntity = new EnableTablesDetailEntity();
        BeanUtils.copyProperties(request, enableTablesDetailEntity);
        // 3-更新记录
        Boolean isSave = null;

        isSave = enableTablesDetailService.update(new UpdateWrapper<EnableTablesDetailEntity>().lambda().
                set(EnableTablesDetailEntity::getTableName, request.getTableName()).
                set(EnableTablesDetailEntity::getTableDesc, request.getTableDesc()).
                set(EnableTablesDetailEntity::getTableType, request.getTableType()).
                set(EnableTablesDetailEntity::getExt, request.getExt()).
                eq(EnableTablesDetailEntity::getId, request.getId()));

        if (isSave) {
            plainResult.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }

        return plainResult;
    }

    /**
     * 逻辑删除byId
     *
     * @param id
     * @return
     */
    @Override
    public PlainResult<Boolean> deleteById(Long id) {
        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 1-校验入参数
        AssertUtil.isAllNotNone(id, "id不能为空");

        // 2-删除记录
        Boolean isSave = null;
        isSave = enableTablesDetailService.removeById(id);
        plainResult.setData(isSave);

        if (isSave) {
            plainResult.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }
        return plainResult;
    }
}