package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.OrderBelongingDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.OrderBelongingDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 成单业绩数据表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 11:30:35
 */
public class OrderBelongingTransfer {

	public static OrderBelongingDTO toBO(OrderBelongingDO d) {

		if (d == null) {

			return null;
		}

        OrderBelongingDTO orderBelongingBO = new OrderBelongingDTO();
		orderBelongingBO.setId(d.getId());
		orderBelongingBO.setOrderId(d.getOrderId());
		orderBelongingBO.setUserId(d.getUserId());
		orderBelongingBO.setUserName(d.getUserName());
		orderBelongingBO.setProfession(d.getProfession());
		orderBelongingBO.setPercentage(d.getPercentage());
		orderBelongingBO.setAchievement(d.getAchievement());
		orderBelongingBO.setExtraBonus(d.getExtraBonus());
		orderBelongingBO.setOrderCount(d.getOrderCount());
		orderBelongingBO.setCustomerCount(d.getCustomerCount());
		orderBelongingBO.setIsSilent(d.getIsSilent());
		orderBelongingBO.setBelongType(d.getBelongType());
		orderBelongingBO.setDisputeType(d.getDisputeType());
		orderBelongingBO.setDisputeTypeDesc(d.getDisputeTypeDesc());
		orderBelongingBO.setDisputeReason(d.getDisputeReason());
		orderBelongingBO.setDisputeSponsor(d.getDisputeSponsor());
		orderBelongingBO.setOrgType(d.getOrgType());
		orderBelongingBO.setDepartmentId(d.getDepartmentId());
		orderBelongingBO.setDepartmentName(d.getDepartmentName());
		orderBelongingBO.setTopDepartmentId(d.getTopDepartmentId());
		orderBelongingBO.setTopDepartmentName(d.getTopDepartmentName());
		orderBelongingBO.setAncestorDepartmentIds(d.getAncestorDepartmentIds());
		orderBelongingBO.setAncestorDepartmentNames(d.getAncestorDepartmentNames());
		orderBelongingBO.setProviderId(d.getProviderId());
		orderBelongingBO.setProviderName(d.getProviderName());
		orderBelongingBO.setBelongLabel(d.getBelongLabel());
		orderBelongingBO.setExamineRuleType(d.getExamineRuleType());
		orderBelongingBO.setDepartmentIdsLatestOfMonth(d.getDepartmentIdsLatestOfMonth());
		orderBelongingBO.setDepartmentNamesLatestOfMonth(d.getDepartmentNamesLatestOfMonth());
		orderBelongingBO.setManagerIdLatestOfMonth(d.getManagerIdLatestOfMonth());
		orderBelongingBO.setSalesTransactionCycle(d.getSalesTransactionCycle());
		orderBelongingBO.setSalesFollowStage(d.getSalesFollowStage());
		orderBelongingBO.setSalesFollowStageName(d.getSalesFollowStageName());
		orderBelongingBO.setTransferredReasonCode(d.getTransferredReasonCode());
		orderBelongingBO.setIsCrossRegionSale(d.getIsCrossRegionSale());
		orderBelongingBO.setCreatedAt(d.getCreatedAt());
		orderBelongingBO.setUpdatedAt(d.getUpdatedAt());

		return orderBelongingBO;
	}

	public static OrderBelongingDO toDO(OrderBelongingDTO bo) {

        if (bo == null) {

			return null;
		}

		OrderBelongingDO orderBelongingDO = new OrderBelongingDO();
		orderBelongingDO.setId(bo.getId());
		orderBelongingDO.setOrderId(bo.getOrderId());
		orderBelongingDO.setUserId(bo.getUserId());
		orderBelongingDO.setUserName(bo.getUserName());
		orderBelongingDO.setProfession(bo.getProfession());
		orderBelongingDO.setPercentage(bo.getPercentage());
		orderBelongingDO.setAchievement(bo.getAchievement());
		orderBelongingDO.setExtraBonus(bo.getExtraBonus());
		orderBelongingDO.setOrderCount(bo.getOrderCount());
		orderBelongingDO.setCustomerCount(bo.getCustomerCount());
		orderBelongingDO.setIsSilent(bo.getIsSilent());
		orderBelongingDO.setBelongType(bo.getBelongType());
		orderBelongingDO.setDisputeType(bo.getDisputeType());
		orderBelongingDO.setDisputeTypeDesc(bo.getDisputeTypeDesc());
		orderBelongingDO.setDisputeReason(bo.getDisputeReason());
		orderBelongingDO.setDisputeSponsor(bo.getDisputeSponsor());
		orderBelongingDO.setOrgType(bo.getOrgType());
		orderBelongingDO.setDepartmentId(bo.getDepartmentId());
		orderBelongingDO.setDepartmentName(bo.getDepartmentName());
		orderBelongingDO.setTopDepartmentId(bo.getTopDepartmentId());
		orderBelongingDO.setTopDepartmentName(bo.getTopDepartmentName());
		orderBelongingDO.setAncestorDepartmentIds(bo.getAncestorDepartmentIds());
		orderBelongingDO.setAncestorDepartmentNames(bo.getAncestorDepartmentNames());
		orderBelongingDO.setProviderId(bo.getProviderId());
		orderBelongingDO.setProviderName(bo.getProviderName());
		orderBelongingDO.setBelongLabel(bo.getBelongLabel());
		orderBelongingDO.setExamineRuleType(bo.getExamineRuleType());
		orderBelongingDO.setDepartmentIdsLatestOfMonth(bo.getDepartmentIdsLatestOfMonth());
		orderBelongingDO.setDepartmentNamesLatestOfMonth(bo.getDepartmentNamesLatestOfMonth());
		orderBelongingDO.setManagerIdLatestOfMonth(bo.getManagerIdLatestOfMonth());
		orderBelongingDO.setSalesTransactionCycle(bo.getSalesTransactionCycle());
		orderBelongingDO.setSalesFollowStage(bo.getSalesFollowStage());
		orderBelongingDO.setSalesFollowStageName(bo.getSalesFollowStageName());
		orderBelongingDO.setTransferredReasonCode(bo.getTransferredReasonCode());
		orderBelongingDO.setIsCrossRegionSale(bo.getIsCrossRegionSale());
		orderBelongingDO.setCreatedAt(bo.getCreatedAt());
		orderBelongingDO.setUpdatedAt(bo.getUpdatedAt());

		return orderBelongingDO;
	}

	public static List<OrderBelongingDTO> toBOList(List<OrderBelongingDO> doList) {

		if (doList == null) {

			return new ArrayList<OrderBelongingDTO>();
		}

		List<OrderBelongingDTO> boList = new ArrayList<OrderBelongingDTO>();
		for (OrderBelongingDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<OrderBelongingDO> toDOList(List<OrderBelongingDTO> boList) {

		if (boList == null) {

			return new ArrayList<OrderBelongingDO>();
		}

		List<OrderBelongingDO> doList = new ArrayList<OrderBelongingDO>();

		for (OrderBelongingDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
