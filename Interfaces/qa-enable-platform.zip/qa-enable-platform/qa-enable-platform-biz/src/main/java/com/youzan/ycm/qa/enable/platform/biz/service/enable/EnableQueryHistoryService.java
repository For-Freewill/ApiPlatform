package com.youzan.ycm.qa.enable.platform.biz.service.enable;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.enable.AddQueryHistoryResquest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableQueryResponse;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableQueryHistoryEntity;

import java.util.List;

/**
 * @author wulei
 * @date 2020/10/27 15:04
 */
public interface EnableQueryHistoryService extends IService<EnableQueryHistoryEntity> {

    /**
     * 查询全部记录：分页查询
     *
     * @param page
     * @return
     */
    PlainResult<IPage<EnableQueryHistoryEntity>> queryAll(IPage page);

    /**
     * 新增记录
     *
     * @param request
     * @return
     */
    PlainResult<Boolean> addQueryHistory(AddQueryHistoryResquest request);

    /**
     * 查询记录 ：根据operatorId
     *
     * @param operatorId
     * @return
     */
    PlainResult<List<EnableQueryHistoryEntity>> queryHistoryByOperatorId(String operatorId);

    /**
     * 查询记录 ：根据id
     *
     * @param id
     * @return
     */
    PlainResult<EnableQueryResponse> queryHistoryById(Long id);


    /**
     * 逻辑删除记录 ：id
     * @return
     */
    PlainResult<Boolean> deleteById(Long id);

}
