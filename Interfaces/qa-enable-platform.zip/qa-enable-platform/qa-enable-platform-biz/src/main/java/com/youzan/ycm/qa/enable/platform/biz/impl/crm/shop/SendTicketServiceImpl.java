package com.youzan.ycm.qa.enable.platform.biz.impl.crm.shop;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.google.inject.internal.Errors;
import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;

import com.youzan.crm.support.api.dto.ticket.*;
import com.youzan.crm.support.api.service.ticket.TicketInfoRemoteService;
import com.youzan.crm.support.api.service.ticket.TicketTaskRemoteService;
import com.youzan.crm.support.api.service.ticket.TicketUserStockRemoteService;
import com.youzan.enable.common.model.entity.UserIdentifier;
import com.youzan.enable.common.model.enums.organization.OrgTypeEnum;
import com.youzan.enable.common.model.error.BizException;
import com.youzan.enable.common.model.error.ErrorCode;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.crm.shop.SendTicketRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.shop.SendTicketService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-04-25 21:36
 */
@Slf4j
@Service(value = "sendTicketService")
public class SendTicketServiceImpl implements SendTicketService {
    @Resource
    private TicketTaskRemoteService ticketTaskRemoteService;

    @Resource
    private TicketUserStockRemoteService ticketUserStockRemoteService;

    @Resource
    private TicketInfoRemoteService ticketInfoRemoteService;


    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Override
    public PlainResult<Boolean> sendTicketToKdtId(SendTicketRequest request) {
//        1、searchTicketTask   根据权益名称，查看券任务
//        2、searchTicketUserStock   根据券任务ID查询券在人身上的情况
//        3、取出stock > 1的第一条数据，取出人的情况
//        4、ticketSendToShop  发放该券到店铺
        REQUEST_LOGGER.info("权益券发放的请求参数 " + request);
        SearchTicketTaskReqDTO searchTicketTaskReqDTO = new SearchTicketTaskReqDTO();
        searchTicketTaskReqDTO.setTicketTaskName(request.getTicketTaskName());
        ListResult<TicketTaskDTO> ticketTaskDTOListResult = ticketTaskRemoteService.searchTicketTask(searchTicketTaskReqDTO);//根据权益名称，查看券任务
        REQUEST_LOGGER.info(String.valueOf(ticketTaskDTOListResult));
        if (ticketTaskDTOListResult == null || ticketTaskDTOListResult.getData().isEmpty()) {
            throw new EnableException(ResultCode.TICKET_NOEXIST.getCode(), ResultCode.TICKET_NOEXIST.getMsg());
        }
        TicketTaskDTO lastTicket = ticketTaskDTOListResult.getData().get(ticketTaskDTOListResult.getData().size() - 1);//如果有多条，只取最新的一条
        REQUEST_LOGGER.info(String.valueOf(lastTicket));
        SearchTicketUserStockReqDTO searchTicketUserStockReqDTO = new SearchTicketUserStockReqDTO();
        searchTicketUserStockReqDTO.setTicketTaskId(lastTicket.getId());
        ListResult<TicketUserStockDTO> userStockDTOListResult = ticketUserStockRemoteService.searchTicketUserStock(searchTicketUserStockReqDTO);//根据券任务ID查询券在人身上的情况
        if (userStockDTOListResult.getData().isEmpty() || userStockDTOListResult == null) {
            throw new EnableException(ResultCode.TICKET_NOEXIST.getCode(), ResultCode.TICKET_NOEXIST.getMsg());
        }
        List<TicketUserStockDTO> userStockDTOList = userStockDTOListResult.getData().stream().sorted(Comparator.comparing(TicketUserStockDTO::getStock).reversed()).collect(Collectors.toList());//取出券和数据后，根据stock倒序排列
        TicketUserStockDTO ticketUserStockDTO = userStockDTOList.get(0);//取出第一条
        if (ticketUserStockDTO == null || ticketUserStockDTO.getStock() == 0) {
            throw new EnableException(ResultCode.TICKET_NOTENOUGH.getCode(), ResultCode.TICKET_NOTENOUGH.getMsg());
        }
        TicketSendToShopReqDTO ticketSendToShopReqDTO = new TicketSendToShopReqDTO();//然后将人封装一下
        UserIdentifier operator = new UserIdentifier();
        operator.setUserId(ticketUserStockDTO.getUserId());
        operator.setType(OrgTypeEnum.QIMA);
        ticketSendToShopReqDTO.setOperator(operator);
        ticketSendToShopReqDTO.setTicketTaskId(lastTicket.getId());
        ticketSendToShopReqDTO.setKdtId(Long.parseLong(request.getKdtId()));
        List<UserIdentifier> receptUser = new ArrayList<>();
        receptUser.add(operator);//接收消息的人暂时先变为券资产的拥有人，实际应该是店铺的归属人，这里不搞这么复杂了
        //先查一下这个店铺有了几张券，如有，设置的基础上加1
        UserSendGiftNumByKdtReqDTO userSendGiftNumByKdtReqDTO = new UserSendGiftNumByKdtReqDTO();
        userSendGiftNumByKdtReqDTO.setKdtId(Long.parseLong(request.getKdtId()));
        userSendGiftNumByKdtReqDTO.setTicketTaskId(searchTicketUserStockReqDTO.getTicketTaskId());
        PlainResult<UserSendGiftNumByKdtResDTO> numByKdtResDTOPlainResult = ticketInfoRemoteService.userSendNumByKdt(userSendGiftNumByKdtReqDTO);


        Integer num = 0;
        if(numByKdtResDTOPlainResult != null || numByKdtResDTOPlainResult.getData() != null){
            REQUEST_LOGGER.info("获取要发放的店铺的已发放权益个数信息"+numByKdtResDTOPlainResult);
            num = numByKdtResDTOPlainResult.getData().getUserSendShopNum();
        }
        ticketSendToShopReqDTO.setNum(num+1);//每次发放多一个券
        ticketSendToShopReqDTO.setSendUser(operator);
        ticketSendToShopReqDTO.setAssetId(lastTicket.getExternalTaskId());
        PlainResult<Boolean> booleanPlainResult = ticketInfoRemoteService.ticketSendToShop(ticketSendToShopReqDTO, receptUser);//发放该券到店铺
        return booleanPlainResult;
    }

}
