package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.enable.AddQueryHistoryResquest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableQueryResponse;
import com.youzan.ycm.qa.enable.platform.biz.commonutils.CovertQueryEntityToResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableQueryHistoryService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.LegalTables;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableQueryHistoryEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableQueryHistoryMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wulei
 * @date 2020/10/27 15:14
 */
@Slf4j
@Service("enableQueryHistoryService")
public class EnableQueryHistoryServiceImpl extends ServiceImpl<EnableQueryHistoryMapper, EnableQueryHistoryEntity> implements EnableQueryHistoryService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private EnableQueryHistoryService enableQueryHistoryService;

    @Resource
    private EnableQueryHistoryMapper enableQueryHistoryMapper;

    /**
     * 分页查询全部记录
     *
     * @param page
     * @return
     */
    @Override
    public PlainResult<IPage<EnableQueryHistoryEntity>> queryAll(IPage page) {
        QueryWrapper<EnableQueryHistoryEntity> wrapper = new QueryWrapper<>();
        IPage<EnableQueryHistoryEntity> result = enableQueryHistoryMapper.selectPage(page, wrapper);
        //3-结果返回
        PlainResult<IPage<EnableQueryHistoryEntity>> plainResult = new PlainResult<>();
        plainResult.setData(result);
        plainResult.setSuccess(true);
        plainResult.setCode(200);
        return plainResult;
    }

    /**
     * 新增记录
     *
     * @return
     */
    @Override
    public PlainResult<Boolean> addQueryHistory(AddQueryHistoryResquest request) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getOperatorId(), "operatorId不能为空");
        AssertUtil.isAllNotNone(request.getRecordName(), "recordName不能为空");
        AssertUtil.isAllNotNone(request.getTables(), "tables不能为空");
        // 请求去重
        List<String> distinctTables = request.getTables().stream().distinct().collect(Collectors.toList());

        // 2-判断是否有不在合法表内的数据
        List<String> tables = LegalTables.legalTables();
        List<String> bad = request.getTables().stream().filter(tb -> !tables.contains(tb)).collect(Collectors.toList());
        if (bad.size() > 0) {
            log.info("请求的tables名称不存在" + bad.toString());
            throw new EnableException(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMsg());
        }

        // 3-属性复制
        EnableQueryHistoryEntity enableQueryHistoryEntity = new EnableQueryHistoryEntity();
        BeanUtils.copyProperties(request, enableQueryHistoryEntity);

        enableQueryHistoryEntity.setTables(distinctTables.toString());

        // 4-查询方案名称+operatorid 相同的记录
        PlainResult<Boolean> result = new PlainResult<>();
        List<EnableQueryHistoryEntity> exists = queryHistoryByOperatorIdAndRecordName(request.getOperatorId(), request.getRecordName());
        Boolean isSave = false;
        // 5-方案名称+operatorid 相同的更新记录，不相同新增记录
        if (exists.size() >= 1) {
            Map<String, Object> allEqMap = new HashMap<>();
            allEqMap.put("operator_id", request.getOperatorId());
            allEqMap.put("record_name", request.getRecordName());
            isSave = enableQueryHistoryService.update(enableQueryHistoryEntity, new UpdateWrapper<EnableQueryHistoryEntity>().allEq(allEqMap));
            result.setMessage("更新成功");
        } else {
            isSave = enableQueryHistoryService.saveOrUpdate(enableQueryHistoryEntity);
            result.setMessage("新增成功");
        }
        result.setData(isSave);
        result.setSuccess(isSave);
        return result;
    }

    /**
     * 查询记录 ：根据operatorId
     *
     * @param operatorId
     * @return
     */
    @Override
    public PlainResult<List<EnableQueryHistoryEntity>> queryHistoryByOperatorId(String operatorId) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(operatorId, "session用户信息获取失败");
        // 2-查询
        List<EnableQueryHistoryEntity> results = enableQueryHistoryService.list(new QueryWrapper<EnableQueryHistoryEntity>().lambda().eq(EnableQueryHistoryEntity::getOperatorId, operatorId).orderByDesc(EnableQueryHistoryEntity::getCreatedAt));
        PlainResult<List<EnableQueryHistoryEntity>> result = new PlainResult<>();
        if (results.size() == 0) {
            return result;
        } else {
            result.setCode(ResultCode.SUCCESS.getCode());
            result.setMessage(ResultCode.SUCCESS.getMessage());
            result.setData(results);
            result.setSuccess(true);
        }
        return result;
    }

    /**
     * 根据ID查询方案详情
     *
     * @param id
     * @return
     */
    @Override
    public PlainResult<EnableQueryResponse> queryHistoryById(Long id) {
        // 1-入参校验
        AssertUtil.isAllNotNone(id, "id不能为空");
        // 2-查询
        EnableQueryHistoryEntity results = enableQueryHistoryService.getOne(new QueryWrapper<EnableQueryHistoryEntity>().lambda().eq(EnableQueryHistoryEntity::getId, id));
        // 3-转换
        EnableQueryResponse enableQueryResponse = CovertQueryEntityToResponse.queryEntityToRes(results);
        PlainResult<EnableQueryResponse> result = new PlainResult<>();
        if (results == null) {
            return result;
        } else {
            result.setCode(ResultCode.SUCCESS.getCode());
            result.setMessage(ResultCode.SUCCESS.getMessage());
            result.setData(enableQueryResponse);
            result.setSuccess(true);
        }
        return result;
    }

    /**
     * 逻辑删除记录 ：id
     *
     * @return
     */
    @Override
    public PlainResult<Boolean> deleteById(Long id) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(id, "Id不能为空");
        // 2-删除记录
        PlainResult<Boolean> result = new PlainResult<>();
        Boolean isSave = null;
        isSave = enableQueryHistoryService.removeById(id);

        if (isSave) {
            result.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }

        return result;
    }

    /**
     * 根据operatorID和recordName查询记录（且未删除）
     *
     * @param operatorId
     * @param recordName
     * @return
     */
    private List<EnableQueryHistoryEntity> queryHistoryByOperatorIdAndRecordName(String operatorId, String recordName) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(operatorId, "operatorId不能为空");
        AssertUtil.isAllNotNone(recordName, "recordName不能为空");

        // 2-构造查询Map
        Map<String, Object> allEqMap = new HashMap<>();
        allEqMap.put("operator_id", operatorId);
        allEqMap.put("record_name", recordName);
        allEqMap.put("is_delete", 0);
        // 3-allEq查询
        return enableQueryHistoryService.list(new QueryWrapper<EnableQueryHistoryEntity>().allEq(allEqMap).orderByDesc("created_at"));
    }

}
