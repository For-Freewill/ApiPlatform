package com.youzan.ycm.qa.enable.platform.biz.impl.repeater;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.base.Preconditions;
import com.google.inject.internal.Errors;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.biz.commonutils.HttpCodeSegmentDefinition;
import com.youzan.ycm.qa.enable.platform.biz.commonutils.JavaCodeSegmentDefinition;
import com.youzan.ycm.qa.enable.platform.biz.request.repeater.RecordCovertRequest;
import com.youzan.ycm.qa.enable.platform.biz.response.repeater.Behavior;
import com.youzan.ycm.qa.enable.platform.biz.response.repeater.HttpRequestBo;
import com.youzan.ycm.qa.enable.platform.biz.response.repeater.ModuleInfoConfig;
import com.youzan.ycm.qa.enable.platform.biz.response.repeater.RestResult;
import com.youzan.ycm.qa.enable.platform.biz.service.repeater.RecordConvertService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableDocEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ModuleConfigEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ModuleInfoEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.RecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ReplayEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.repeater.ModuleConfigMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.repeater.ModuleInfoMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.repeater.RecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.repeater.ReplayMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

/**
 * @author wulei
 * @date 2020/11/19 16:07
 */
@Slf4j
@Service(value = "recordConvertService")
public class RecordConvertServiceImpl implements RecordConvertService{

    @Resource
    private RecordConvertService recordConvertService;

    @Resource
    private RecordMapper recordMapper;

    @Resource
    private ReplayMapper replayMapper;

    @Resource
    private ModuleInfoMapper moduleInfoMapper;

    @Resource
    private ModuleConfigMapper moduleConfigMapper;

    @Override
    public PlainResult<String> recordToCode(RecordCovertRequest request) {
        PlainResult<String> plainResult = new PlainResult<>();
//        String file = System.getProperty("user.dir") + File.separator + "fileData" + File.separator + "GenerateCode_" + request.getId() + ".java";
        //自定义忽略的转码字段（params&headers）
        List<String> ignoreParams = Arrays.asList("x-service-chain", "sec-ch-ua", "sec-ch-ua-platform");
        try {
            //先删除存在的代码
//            if (FileUtils.getFile(file).exists()) {
//                FileUtils.getFile(file).delete();
//            }
//            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            //生成新代码
            String code = generateCode(request, ignoreParams);
//            out.write(code);
//            out.close();
            //返回生成的代码
            plainResult.setData(code);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.toString());
        }
        return plainResult;
    }

    @Override
    public PlainResult<Page<RecordEntity>> listRecord(String appName, String traceId, Integer pageNum, Integer pageSize) {
        Page<RecordEntity> page = new Page<>(pageNum,pageSize);
        page.addOrder(OrderItem.desc("id"));
        QueryWrapper<RecordEntity> wrapper = new QueryWrapper<>();
        if (StringUtils.isNotBlank(appName)) {
            wrapper.eq("app_name", appName);
        }
        if (StringUtils.isNotBlank(traceId)) {
            wrapper.eq("trace_id", traceId);
        }

        Page<RecordEntity> data = recordMapper.selectPage(page, wrapper);

        PlainResult<Page<RecordEntity>> plainResult = new PlainResult<>();
        plainResult.setData(data);
        return plainResult;
    }

    @Override
    public PlainResult<ReplayEntity> listReplay(Long id) {
        PlainResult<ReplayEntity> plainResult = new PlainResult<>();
        plainResult.setData(replayMapper.selectOne(new QueryWrapper<ReplayEntity>().lambda().eq(ReplayEntity::getId, id)));
        return plainResult;
    }

    @Override
    public PlainResult<List<ModuleInfoEntity>> listModuleInfo(String appName, String ip) {
        PlainResult<List<ModuleInfoEntity>> plainResult = new PlainResult<>();
        LambdaQueryWrapper<ModuleInfoEntity> wrapper = new QueryWrapper<ModuleInfoEntity>().lambda();
        if (StringUtils.isNotBlank(appName)) {
            wrapper.eq(ModuleInfoEntity::getAppName, appName);
        }
        if (StringUtils.isNotBlank(ip)) {
            wrapper.eq(ModuleInfoEntity::getIp, ip);
        }
        plainResult.setData(moduleInfoMapper.selectList(wrapper));
        return plainResult;
    }



    @Override
    public PlainResult<Boolean> deleteModuleInfo(Long id) {
        AssertUtil.isAllNotNone(id, "id不能为空");
        PlainResult<Boolean> plainResult = new PlainResult<>();
        plainResult.setData(moduleInfoMapper.deleteById(id) > 0);
        return plainResult;
    }



    @Override
    public PlainResult<Page<ModuleConfigEntity>> listModuleConfig(String appName, String env, Integer page, Integer pageSize) {
        PlainResult<Page<ModuleConfigEntity>> plainResult = new PlainResult<>();
        Page<ModuleConfigEntity> tpage = new Page<>(page,pageSize);
        LambdaQueryWrapper<ModuleConfigEntity> twrapper = new QueryWrapper<ModuleConfigEntity>().lambda();
        if (StringUtils.isNotBlank(appName)) {
            twrapper.eq(ModuleConfigEntity::getAppName,appName);
        }
        if(StringUtils.isNotBlank(env)){
            twrapper.eq(ModuleConfigEntity::getEnvironment,env);
        }
        Page<ModuleConfigEntity> pageResult = moduleConfigMapper.selectPage(tpage,twrapper);
        plainResult.setData(pageResult);
        return plainResult;
    }

    @Override
    public PlainResult<String> detailModuleConfig(Long id) {
        PlainResult<String> plainResult = new PlainResult<>();
        ModuleConfigEntity data = moduleConfigMapper.selectOne(new QueryWrapper<ModuleConfigEntity>().lambda().eq(ModuleConfigEntity::getId, id));
        //配置详情数据
        String config = data.getConfig();
        plainResult.setData(config);
        return plainResult;
    }

    @Override
    public PlainResult<ModuleConfigEntity> addOrUpdateModuleConfig(ModuleConfigEntity params) {
        Preconditions.checkArgument(StringUtils.isNotBlank(params.getAppName()) && StringUtils.isNotBlank(params.getEnvironment()) && StringUtils.isNotBlank(params.getConfig()),
                ResultCode.BAD_REQUEST.getMessage());

        PlainResult<ModuleConfigEntity> plainResult = new PlainResult<>();
        ModuleConfigEntity result = moduleConfigMapper.selectOne(new QueryWrapper<ModuleConfigEntity>().lambda().eq(ModuleConfigEntity::getId, params.getId()));
        if(result != null){
            result.setAppName(params.getAppName());
            result.setEnvironment(params.getEnvironment());
            result.setConfig(params.getConfig());
            result.setUpdatedAt(new Date());
            plainResult.setCode(moduleConfigMapper.updateById(result));
        }
        else {
            ModuleConfigEntity  moduleConfig = new ModuleConfigEntity();
            moduleConfig.setAppName(params.getAppName());
            moduleConfig.setEnvironment(params.getEnvironment());
            moduleConfig.setConfig(params.getConfig());
            moduleConfig.setCreatedAt(new Date());
            moduleConfig.setUpdatedAt(new Date());
            moduleConfig.setGmtCreate(new Date());
            moduleConfig.setGmtModified(new Date());
            plainResult.setCode(moduleConfigMapper.insert(moduleConfig));
        }

        return  plainResult;
    }

    @Override
    public PlainResult<ModuleConfigEntity> deleteModuleConfig(Long id) {
        PlainResult<ModuleConfigEntity> plainResult = new PlainResult<>();
        plainResult.setCode(moduleConfigMapper.delete(new QueryWrapper<ModuleConfigEntity>().lambda().eq(ModuleConfigEntity::getId, id)));
        return plainResult;
    }

    /**
     * 组装代码
     *
     * @return
     */
    private String generateCode(RecordCovertRequest request, List<String> ignoreParams) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        RecordEntity recordEntity = recordMapper.selectOne(new QueryWrapper<RecordEntity>().lambda().eq(RecordEntity::getId, request.getId()));
        if (recordEntity.getId() != null) {
            // 判断请求的request/response不为空
            if (StringUtils.isEmpty(recordEntity.getRequest())) {
                return "录制流量的Request为空";
            }
            if (StringUtils.isEmpty(recordEntity.getResponse())) {
                return "录制流量的Response为空";
            }
            String appName = recordEntity.getAppName();
            //HTTP判断
            if (recordEntity.getEntranceDesc().startsWith("http")) {
                return httpCode(recordEntity, ignoreParams);
            }
            //Java转代码
            if (recordEntity.getEntranceDesc().startsWith("java")) {
                return javaCode(recordEntity,appName);
            }
        }
        log.info("代码拼接错误");
        return "";
    }

    /**
     * Java请求拆分
     */
    public Map<String, List<String>> javaEntranceParse(String entrance_desc) {
        Map<String, List<String>> result = new HashMap<>();
        if (StringUtils.isNotEmpty(entrance_desc) && entrance_desc.contains("~")) {
            String[] entranceArray = entrance_desc.split("~");
            String serviceMethodOriginal = entranceArray[0];
            String requestResponseOriginal = entranceArray[1];
            //获取方法
            String serviceMethod = serviceMethodOriginal.replaceAll("java://", "");
            String method = serviceMethod.split("/")[1];
            result.put("method", Arrays.asList(method));
            //服务impl
            int len = serviceMethod.split("/")[0].split("\\.").length - 1;
            String serviceImpl = serviceMethod.split("/")[0].split("\\.")[len];
            String serviceName = serviceImpl.substring(0, serviceImpl.length() - 4);
            result.put("serviceImpl", Arrays.asList(serviceImpl));
            result.put("serviceName", Arrays.asList(serviceName));

            //请求&响应
            String[] requestResponseOriginalSplit = requestResponseOriginal.split("\\)");
            String[] requestsArray = requestResponseOriginalSplit[0].replaceAll("\\(", "").split(";");
            List<String> requests = new ArrayList<>();
            for (String req : requestsArray) {
                requests.add(req.substring(1).replaceAll("/", "."));
            }
            String responseType = requestResponseOriginalSplit[1].replaceAll("L", "").split(";")[0].replaceAll("/", ".");
            result.put("responseType", Arrays.asList(responseType));
            result.put("requestsType", requests);
        }
        return result;
    }

    /**
     * ModuleConfig匹配
     */
    public Map<String, String> moduleConfigMatch(String appName, Map<String, List<String>> entrance_desc) {
        Map<String, String> result = new HashMap<>();
        ModuleConfigEntity moduleConfigEntity = moduleConfigMapper.selectOne(new QueryWrapper<ModuleConfigEntity>().lambda().eq(ModuleConfigEntity::getAppName, appName));
        ModuleInfoConfig moduleInfoConfig = JSON.parseObject(moduleConfigEntity.getConfig(), ModuleInfoConfig.class);
        List<Behavior> behaviors = moduleInfoConfig.getJavaEntranceBehaviors();
        for (Behavior behavior : behaviors) {
            int len = behavior.getClassPattern().split("\\.").length;
            String serviceName = behavior.getClassPattern().split("\\.")[len - 1];
            for (int i = 0; i < behavior.getMethodPatterns().length; i++) {
                if (entrance_desc.get("method").get(0).equals(behavior.getMethodPatterns()[i]) && entrance_desc.get("serviceName").get(0).equals(serviceName)) {
                    result.put("service", behavior.getClassPattern());
                    result.put("method", entrance_desc.get("method").get(0));
                }
            }
        }
        return result;
    }

    /**
     * HTTP转代码
     */
    public String httpCode(RecordEntity recordEntity, List<String> ignoreParams) {
        if (recordEntity.getEntranceDesc().startsWith("http")) {
            String bo = JSONObject.parseArray(recordEntity.getRequest()).get(0).toString();
            //record记录的request格式化
            HttpRequestBo requestBo = JSONObject.parseObject(bo, HttpRequestBo.class);
            //record记录的response格式化
            RestResult response = JSONObject.parseObject(recordEntity.getResponse(), RestResult.class);

            //拼接返回
            String res = HttpCodeSegmentDefinition.RESPONSE_ASSERT
                    .replace("#respCode#", response.getCode().toString())
                    .replace("#respData#", response.getData().replaceAll("\"", "\\\\\""))//替换 " -> \"
                    .replace("#respMsg#", response.getMsg());

            //拼接GET TEST
            if (requestBo.getMethod().equals("GET")) {
                //拼接headers
                StringBuilder headers = new StringBuilder();
                if (requestBo.getHeaders() != null) {
                    for (String key : requestBo.getHeaders().keySet()) {
                        if (!ignoreParams.contains(key)) {
                            headers.append(HttpCodeSegmentDefinition.HEADERS
                                    .replace("#HeadKey#", "" + key + "")
                                    .replace("#HeadValue#", "" + String.valueOf(requestBo.getHeaders().get(key))) + "");
                        }
                    }
                }
                //拼接@Test
                String getTest = HttpCodeSegmentDefinition.GET_TEST
                        .replace("#URL#", "" + requestBo.getRequestURL() + "")
//                        .replace("#HEADERS#", headers)//组内讨论不需要headers
                        .replace("#HTTP_GET#", HttpCodeSegmentDefinition.HTTP_GET)
                        .replace("#RESPONSE_ASSERT#", res);
                //拼接NEW_JAVA
                String result = HttpCodeSegmentDefinition.NEW_JAVA.replace("#TEST#", getTest);
                log.info("代码拼接成功");
                return result;

            } else if (requestBo.getMethod().equals("POST")) {
                //拼接headers
                StringBuilder headers = new StringBuilder();
                if (requestBo.getHeaders() != null) {
                    for (String key : requestBo.getHeaders().keySet()) {
                        if (!ignoreParams.contains(key)) {
                            headers.append(HttpCodeSegmentDefinition.HEADERS
                                    .replace("#HeadKey#", "" + key + "")
                                    .replace("#HeadValue#", "" + String.valueOf(requestBo.getHeaders().get(key))) + "");
                        }
                    }
                }
                //拼接params--POST 请求实际参数在body
                StringBuilder params = new StringBuilder();
                Map<String, String> body = JSONObject.parseObject(requestBo.getBody(), Map.class);
                if (body != null) {
                    for (String key : body.keySet()) {
                        if (!ignoreParams.contains(key)) {
                            params.append(HttpCodeSegmentDefinition.PARAMS
                                    .replace("#ParamKey#", "" + key + "")
                                    .replace("#ParamValue#", "" + String.valueOf(body.get(key))) + "");
                        }
                    }
                }
                //拼接@Test
                String postTest = HttpCodeSegmentDefinition.POST_TEST
                        .replace("#URL#", "" + requestBo.getRequestURL() + "")
//                        .replace("#HEADERS#", headers)//组内讨论不需要headers
                        .replace("#PARAMS#", params)
                        .replace("#HTTP_POST#", HttpCodeSegmentDefinition.HTTP_POST)
                        .replace("#RESPONSE_ASSERT#", res);
                //拼接NEW_JAVA
                String result = HttpCodeSegmentDefinition.NEW_JAVA.replace("#TEST#", postTest);
                log.info("代码拼接成功");
                return result;
            }
        }
        return "http请求转代码异常";
    }

    /**
     * JAVA转代码
     */
    public String javaCode(RecordEntity recordEntity, String appName) {
        Map<String, List<String>> parsedJavaEntrance = javaEntranceParse(recordEntity.getEntranceDesc());
        log.info("parsedJavaEntrance="+parsedJavaEntrance.toString());
        Map<String, String> resultServiceMethod = moduleConfigMatch(appName, parsedJavaEntrance);
        log.info("resultServiceMethod="+resultServiceMethod.toString());
        //record记录的response格式化
        RestResult response = JSONObject.parseObject(recordEntity.getResponse(), RestResult.class);
        String TEST="";

        //拼接返回
        String res = JavaCodeSegmentDefinition.RESPONSE_ASSERT
                .replace("#respCode#", response.getCode().toString())
                .replace("#respData#", response.getData().replaceAll("\"", "\\\\\""))//替换 " -> \"
                .replace("#respMsg#", response.getMessage());

        //单请求处理
        if(JSONObject.parseArray(recordEntity.getRequest()).size()==1){
            String requestData = JSONObject.parseArray(recordEntity.getRequest()).get(0).toString();

            int len = parsedJavaEntrance.get("requestsType").get(0).split("\\.").length;
            String req = parsedJavaEntrance.get("requestsType").get(0).split("\\.")[len-1];

            //INVOKE
            String INVOKE=JavaCodeSegmentDefinition.INVOKE.replace("#MethodName#",parsedJavaEntrance.get("method").get(0));

            //REQUESTS
            String REQUEST=JavaCodeSegmentDefinition.REQUESTS.replace("#REQUEST#",req);

            //TEST
            TEST = JavaCodeSegmentDefinition.TEST
                    .replace("#MethodName#",parsedJavaEntrance.get("method").get(0))
                    .replace("#REQUEST_DATA#",requestData.replaceAll("\"", "\\\\\""))
                    .replace("#REQUESTS#",REQUEST)
                    .replace("#INVOKE#",INVOKE)
                    .replace("#RESPONSE_ASSERT#",res);
        }

        //多请求处理
        if(JSONObject.parseArray(recordEntity.getRequest()).size()>1){
            JSONArray requestArrayData = JSONObject.parseArray(recordEntity.getRequest());
            log.info(parsedJavaEntrance.get("requestsType").toString());
            Object[] reA = parsedJavaEntrance.get("requestsType").toArray();
            if(requestArrayData.size()!=reA.length){
                return "参数个数不匹配";
            }

            StringBuilder request_loop = new StringBuilder();
            StringBuilder request_param = new StringBuilder();

            for (int i=0;i<requestArrayData.size();i++){
                int len = String.valueOf(reA[i]).split("\\.").length;
                String req = String.valueOf(reA[i]).split("\\.")[len-1];

                request_loop.append(JavaCodeSegmentDefinition.REQUESTS_MUL
                        .replace("#REQUEST#",req)
                        .replace("#loop# ",String.valueOf(i))
                        .replace("#REQ_DATA#",requestArrayData.getString(i)));

                request_param.append("request_"+i+",");
            }

            String INVOKE=JavaCodeSegmentDefinition.INVOKE_MUL
                    .replace("#MethodName#",parsedJavaEntrance.get("method").get(0))
                    .replace("#REQUESTS_MUL_LIST#",request_param.substring(0,request_param.length()-1));

            //TEST
            TEST = JavaCodeSegmentDefinition.TEST_MUL
                    .replace("#MethodName#",parsedJavaEntrance.get("method").get(0))
                    .replace("#REQUESTS#",request_loop)
                    .replace("#INVOKE#",INVOKE)
                    .replace("#RESPONSE_ASSERT#",res);

        }

        //Dubbo Annotation
        String dubbo = JavaCodeSegmentDefinition.DUBBOANNOTATION
                .replace("#ServiceName#",parsedJavaEntrance.get("serviceName").get(0));
        //JAVA
        String result = JavaCodeSegmentDefinition.NEW_JAVA
                .replace("#SERVICEIMPORT#",resultServiceMethod.get("service"))
                .replace("#REQUESTIMPORT#", parsedJavaEntrance.get("requestsType").get(0))
                .replace("#RESPIMPORT#",parsedJavaEntrance.get("responseType").get(0))
                .replace("#ServiceName#",parsedJavaEntrance.get("serviceName").get(0))
                .replace("#DUBBOANNOTATION#",dubbo)
                .replace("#TEST#",TEST);

        return result;

    }
}