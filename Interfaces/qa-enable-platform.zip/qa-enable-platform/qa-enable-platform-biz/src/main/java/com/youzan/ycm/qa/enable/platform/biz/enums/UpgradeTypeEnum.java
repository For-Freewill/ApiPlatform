package com.youzan.ycm.qa.enable.platform.biz.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * @author leifeiyun
 * @date 2022/2/10
 **/
@AllArgsConstructor
@Getter
public enum UpgradeTypeEnum {
    YZ_CHAIN40L_SIGN(18, "yzChain40LSign","微商城单店升级有赞连锁L-高级版"),
    WSC_MULTI_STORE_L_SIGN(18, "wscMultiStore-LSign","微商城单店+多网点升级有赞连锁L-高级版"),
    WSC_YZ_CHAIN40L_PROFESSIONAL(4, "wsc-yzChain40LProfessional","微商城单店升级有赞连锁L-专业版"),
    WSC_YZ_CHAIN40L_FLAGSHIP(4, "wsc-yzChain40LFlagShip","微商城单店升级有赞连锁L-旗舰版"),
    RETAIL_YZ_CHAIN40L_PROFESSIONAL(3, "retail-yzChain40LProfessional","零售单店升级有赞连锁L-专业版"),
    RETAIL_YZ_CHAIN40L_FLAGSHIP(3, "retail-yzChain40LFlagShip","零售单店升级有赞连锁L-旗舰版"),
    EDU_EDU_CHAIN40(71, "edu-eduChain40","教育单店升级教育连锁4.0(多校区2.0)"),
    EDU_CHAIN20_EDU_CHAIN40(112, "eduChain20-eduChain40","教育连锁2.0(多校区1.0)升级教育连锁4.0(多校区2.0)"),
    WSC_RETAIL(9, "wsc-retail","微商城单店升级零售单店"),
    WSC_EDU(13, "wsc-edu","微商城单店升级教育单店"),
    WSC_CHAIN40D_RETAIL_CHAIN40L(21,"wscChain40D-retailChain40L","有赞连锁4.0D升级有赞连锁4.0L");


    private int code;
    private String shopUpgradeType;
    private String desc;


    public static UpgradeTypeEnum findShopUpgradeTypeEnum(String shopUpgradeType) {
        for (UpgradeTypeEnum value : UpgradeTypeEnum.values()) {
            if (StringUtils.equals(shopUpgradeType, value.getShopUpgradeType())) {
                return value;
            }
        }
        return null;
    }
}
