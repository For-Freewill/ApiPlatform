package com.youzan.ycm.qa.enable.platform.biz.jenkins;

import com.alibaba.fastjson.JSONArray;
import com.google.common.collect.Maps;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.model.JobWithDetails;
import com.youzan.api.common.response.PlainResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;


/**
 * @Author qibu
 * @create 2021/8/25 11:22 AM
 */

@Slf4j
@Service
public class JenkinsService {

    @Autowired
    private JenkinsServer jenkinsServer;


    /**
     * 执行指定用例
     *
     * @param line      产品线 ycm，crm
     * @param caseArray 要执行的case，jsonArray 格式
     * @param sc
     * @param extraInfo 原始重试的job，jsonArray 格式
     * @return true 重试成功；false 重试失败
     */
    public PlainResult<Boolean> runCase(String line, JSONArray caseArray, String sc, String extraInfo,String application,String operator) {
        JenkinJobEnum jenkinJobEnum = JenkinJobEnum.findByLine(line);
        PlainResult<Boolean> plainpResult  = new PlainResult<>();
        if (jenkinJobEnum != null) {
            HashMap<String, String> paraMap = Maps.newHashMap();
            paraMap.put("branch", "master");
            paraMap.put("runMethod", caseArray.toJSONString());
            paraMap.put("testFile", "runMethod");
            paraMap.put("sc", sc);
            paraMap.put("type", extraInfo);
            paraMap.put("application",application);
            paraMap.put("operator",operator);
            try {
                JobWithDetails job = jenkinsServer.getJob(jenkinJobEnum.getJobName());
                job.build(paraMap);
                plainpResult.setSuccess(true);
                return plainpResult;
            } catch (IOException e) {
                plainpResult.setSuccess(false);
                plainpResult.setCode(-1);
                plainpResult.setMessage("失败重试用例执行失败，jobName:"+jenkinJobEnum.getJobName());
                log.warn("失败重试用例执行失败，jobName:{}", jenkinJobEnum.getJobName());
                e.printStackTrace();
            }
        } else {
            plainpResult.setCode(-1);
            plainpResult.setSuccess(false);
            plainpResult.setMessage("失败重试用例无法执行，因产品线:"+line+" 找不到重试job");
            log.warn("失败重试用例无法执行，因产品线{} 找不到重试job", line);
        }
        return plainpResult;
    }


}
