package com.youzan.ycm.qa.enable.platform.biz.impl.fileTransfer;

import com.youzan.api.common.response.PlainResult;
import com.youzan.sz.beautystore.commercial.util.TSPUtil;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.fileTransfer.FileTransferService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.*;

/**
 * @author leifeiyun
 * @date 2021/9/14
 **/
@Service("fileTransferService")
public class FileTransferServiceImpl implements FileTransferService {
    @Override
    public Map<String,List> getDiffInterFaceAndMethod(String string1,String string2) {
        PlainResult<Map<String,List>> result = new PlainResult<>();
        List<String> lastMonthMethods = stringTransfer(string1);
        List<String> currentMonthMethods = stringTransfer(string2);
        Map resultMap = new HashMap();
        List<String> deleteMethods = getStringInFirstMethodsNotInSecondMethods(lastMonthMethods,currentMonthMethods);
        List<String> addMethods = getStringInFirstMethodsNotInSecondMethods(currentMonthMethods,lastMonthMethods);
        resultMap.put("deleteMethods",deleteMethods);
        resultMap.put("addMethods",addMethods);
        return resultMap;
    }

    @Override
    public List<String> getInterFaceAndMethod(String string) {
        List<String> stringList = stringTransfer(string);
        PlainResult<List<String>> result = new PlainResult<>();
        for(String s : stringList){
            System.out.println(s);
        }
        return stringList;
    }

    @Override
    public String transferFileToDest(MultipartFile file) {
        //filePath 是相对路径，指向 filePath/ccc.log
        //file.transferTo 方法调用时，判断如果是相对路径，则使用temp目录，为父目录
        //解决办法
        //transferTo 传入参数 定义为绝对路径

        if(!file.isEmpty()){
            String fileName = file.getOriginalFilename();
            String filePath = "fileData/";
            File destFile = new File(new File(filePath).getAbsolutePath()+"/" + fileName);
            if (!destFile.getParentFile().exists()) {
                destFile.getParentFile().mkdirs();
            }
            try {
                file.transferTo(destFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return destFile.getPath();
        }else {
            return null;
        }
    }

    /**
     * 功能：Java读取log文件的内容
     * 1：先获得文件句柄
     * 2：获得文件句柄当做是输入一个字节码流，需要对这个输入流进行读取
     * 3：读取到输入流后，需要读取生成字节流
     * 4：一行一行的输出。readline()。
     * 备注：需要考虑的是异常情况
     *
     * @param filePath
     *            文件路径[到达文件:如： D:\aa.txt]
     * @return 将这个文件按照每一行切割成数组存放到list中。
     */
    public  List<String> readLogFileIntoStringArrList(String filePath)
    {
        List<String> list = new ArrayList<String>();
        try
        {
            String encoding = "GBK";
            File file = new File(filePath);
            if (file.isFile() && file.exists())
            { // 判断文件是否存在
                InputStreamReader read = new InputStreamReader(
                        new FileInputStream(file), encoding);// 考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;

                while ((lineTxt = bufferedReader.readLine()) != null)
                {
                    list.add(lineTxt);
                }
                bufferedReader.close();
                read.close();
            }
            else
            {
                System.out.println("找不到指定的文件");
            }
        }
        catch (Exception e)
        {
            System.out.println("读取文件内容出错");
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 将字符串转化成指定的格式
     * @param filePath
     *
     * 源格式：Interface: com.youzan.ycm.goods.api.GdPurchaseViewRemoteService, Methods: ['queryPurchasablePeriodCountPluginView', 'queryPurchasablePluginMealView', 'queryPurchasablePluginView']
     * 目标格式：[com.youzan.ycm.goods.api.GdPurchaseViewRemoteService.queryPurchasablePeriodCountPluginView, com.youzan.ycm.goods.api.GdPurchaseViewRemoteService.queryPurchasablePluginMealView, com.youzan.ycm.goods.api.GdPurchaseViewRemoteService.queryPurchasablePluginView]
     *
     */
    public List<String> stringTransfer(String filePath){
        List<String> interfaceMethodFormatStringList = new ArrayList<>();

        List<String> stringListFromFile = readLogFileIntoStringArrList(filePath);
        for(String interfaceStringFromFile:stringListFromFile){
            List<String> stringList = new ArrayList<>();
            String tempString = interfaceStringFromFile.replaceAll(" ","");
            String [] result = tempString.split("Interface:|,Methods:|\\['|\\']|','");
//            System.out.println(result);
            for(int i=0;i<result.length;i++){
                if(result!=null && !("".equals(result[i]))){
                    stringList.add(result[i]);
                }
            }
            String interfaceString = stringList.get(0)+".";
            for(int i=1;i<stringList.size();i++){
                interfaceMethodFormatStringList.add(interfaceString+stringList.get(i));
            }

        }

        return interfaceMethodFormatStringList;
    }

    /**
     * 输出firstMethods中有的字符串，而secondMethods没有的字符串
     * @param firstMethods
     * @param secondMethods
     */


    public List<String> getStringInFirstMethodsNotInSecondMethods(List<String> firstMethods,List<String> secondMethods){

      /*  int interfaceMethodsLength = firstMethods.size();
        for(int i = 0;i<interfaceMethodsLength;i++){
            if(secondMethods.contains(firstMethods.get(i))){
                //Exception in thread "main" java.lang.IndexOutOfBoundsException: Index: 23, Size: 23,list每remove一次，长度都会变，所以用set
                firstMethods.remove(i);
            }
        }*/

        //转换当中可能要丢失数据,尤其是从list转换到set的时候,因为set不能有重复数据,但是我能保证这个list是没有重复的
        Set set = new HashSet(firstMethods);
        for(String s : secondMethods){
            if(firstMethods.contains(s)){
                set.remove(s);
            }
        }
        List<String> resultList = new ArrayList<>(set);
        return resultList;
    }

/*    public Map<String,List> getDiffInterfaceAndMethod(List<String> lastMonthMethods,List<String> currentMonthMethods){
       Map resultMap = new HashMap();
       List<String> deleteMethods = getStringInFirstMethodsNotInSecondMethods(lastMonthMethods,currentMonthMethods);
       List<String> addMethods = getStringInFirstMethodsNotInSecondMethods(currentMonthMethods,lastMonthMethods);
       resultMap.put("deleteMethods",deleteMethods);
       resultMap.put("addMethods",addMethods);
       return resultMap;
    }*/


    public static void main(String[] args) {
        String filePath1="/Users/leifeiyun/Documents/Documents/文档整理/流量回放-资料相关/2021-09-14-interface/ycm-trade.log";
//        String filePath2="/Users/leifeiyun/Documents/Documents/文档整理/流量回放-资料相关/2021-09-14-interface/ycm-open的副本 2.log";
        FileTransferServiceImpl f = new FileTransferServiceImpl();
        f.getInterFaceAndMethod(filePath1);
//         f.getInterFaceAndMethod(filePath1,filePath2);
       /* List<String> stringList = new ArrayList<>()com.youzan.ycm.perform.front.api.PfAbilityStatusBaseQueryService.queryStatusByAbilityIdAndApplyYcmId
;
        String interfaceStringtt = "Interface: com.youzan.ycm.goods.api.GdPurchaseViewRemoteService, Methods: ['queryPurchasablePeriodCountPluginView', 'queryPurchasablePluginMealView', 'queryPurchasablePluginView']".replaceAll(" ","") ;
        //正则里面的加号，减号，[都要转义，用\\转义，各个符号之间用|隔开
        String [] result = interfaceStringtt.split("Interface:|,Methods:|\\['|\\']|','");
        System.out.println(result);
        for(int i=0;i<result.length;i++){
            if(result!=null && !("".equals(result[i]))){
               stringList.add(result[i]);
            }
        }
        System.out.println(stringList);

        List<String> interfaceMethodFormatStringList = new ArrayList<>();
        String interfaceString = stringList.get(0)+".";
        for(int i=1;i<stringList.size();i++){
            interfaceMethodFormatStringList.add(interfaceString+stringList.get(i));
        }
        System.out.println(interfaceMethodFormatStringList);*/
//        Interface:com.youzan.ycm.goods.api.PropertyRemoteService,Methods:['getSkuPropertyByPerformType','queryPropertyKey']
    }

}
