package com.youzan.ycm.qa.enable.platform.biz.service.enable;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreInsertRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreQueryRequest;
import com.youzan.ycm.qa.enable.platform.biz.request.enable.EnableProgramScoreUpdateRequest;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableProgramScoreEntity;

import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2021-5-31
 */
public interface EnableProgramScoreService extends IService<EnableProgramScoreEntity> {
    /**
     * 查询全部表 for 前端
     *
     * @return
     */
    PlainResult<Map<String, List>> selectByParam(EnableProgramScoreQueryRequest request);

    /**
     * 项目汇总
     *
     * @param request
     * @return
     */
    PlainResult<Map<String, List>> analyticByParam(EnableProgramScoreQueryRequest request);

    /**
     * 分页查询全部
     *
     * @return
     */
    PlainResult<IPage<EnableProgramScoreEntity>> selectAll(String team, IPage page);

    /**
     * 新增记录
     *
     * @return
     */
    PlainResult<Boolean> insert(EnableProgramScoreInsertRequest request);

    /**
     * 逻辑删除记录
     *
     * @return
     */
    PlainResult<Boolean> updateById(EnableProgramScoreUpdateRequest request);

    /**
     * 逻辑删除记录
     *
     * @return
     */
    PlainResult<Boolean> deleteById(Long id);

    /**
     * 查询记录
     *
     * @return
     */
    PlainResult<EnableProgramScoreEntity> selectById(Long id);
}
