package com.youzan.ycm.qa.enable.platform.biz.service.enable;

import com.baomidou.mybatisplus.extension.service.IService;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableDocRequest;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailUpdateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableDocResponse;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableDocEntity;

import java.util.List;

/**
 * @author wulei
 * @date 2020/11/19 16:05
 */
public interface EnableDocService extends IService<EnableDocEntity> {
    /**
     * 根据类型查询记录
     *
     * @return
     */
    PlainResult<List<EnableDocResponse>> selectAllByType(String doc_type);

    /**
     * 类型+名称模糊查询
     *
     * @return
     */
    PlainResult<List<EnableDocResponse>> selectByYcmDocName(String doc_name, String doc_type);

    /**
     * 新增文档记录
     *
     * @return
     */
    PlainResult<Boolean> insert(EnableDocRequest request);

    /**
     * 更新文档记录（暂不需要实现）
     *
     * @return
     */
    PlainResult<Boolean> updateById(EnableTablesDetailUpdateRequest request);

    /**
     * 逻辑删除记录
     *
     * @return
     */
    PlainResult<Boolean> deleteById(Long id);
}
