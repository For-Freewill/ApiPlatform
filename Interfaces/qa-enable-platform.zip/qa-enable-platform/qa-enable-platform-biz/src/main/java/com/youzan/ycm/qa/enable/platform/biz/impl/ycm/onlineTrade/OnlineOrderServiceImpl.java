package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.onlineTrade;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.acctrans.api.acctrans.AcctransRechargeService;
import com.youzan.pay.acctrans.api.acctrans.dto.AcctransAccountingDTO;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransRechargeRequest;
import com.youzan.pay.acctrans.common.model.enums.AccountType;
import com.youzan.pay.acctrans.common.model.enums.SubTransCodeEnum;
import com.youzan.pay.acctrans.common.model.enums.TransCodeEnum;
import com.youzan.pay.acctrans.common.model.model.AccountInfo;
import com.youzan.pay.core.api.model.response.DataResult;
import com.youzan.pay.core.common.model.enums.CurrencyCode;
import com.youzan.pay.core.common.model.enums.bizcode.ChannelType;
import com.youzan.pay.core.utils.KeyUtils;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.pay.unified.cashier.api.request.v3.result.PreOrderPayResult;
import com.youzan.pay.unified.cashier.api.v3.PreOrderPayService;
import com.youzan.platform.bootstrap.exception.BusinessException;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.onlineTrade.CreateOnlineOrderRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.onlineTrade.OnlineOrderService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.yop.api.BasicQueryRemoteServiceV2;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.PaymentRemoteService;
import com.youzan.yop.api.entity.item.ItemApi;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.ycm.OrderPromotionMutexApi;
import com.youzan.yop.api.form.basic.PurchasablePluginFetchForm;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.pay.PreparePayForm;
import com.youzan.yop.api.response.PurchasablePluginApi;
import com.youzan.yop.api.response.PurchasablePluginItemApi;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by baoyan on 11/30/21.
 */

@Slf4j
@Service("onlineOrderService")
public class OnlineOrderServiceImpl implements OnlineOrderService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private com.youzan.pay.customer.api.ops.UserInfoService payUserInfoService;

    @Resource
    private AcctransRechargeService acctransRechargeService;

    @Resource
    private MarketRemoteService marketRemoteService;

    @Resource
    private BasicQueryRemoteServiceV2 basicQueryRemoteServiceV2;

    @Resource
    private OrderRemoteService orderRemoteService;

    @Resource
    private PreOrderPayService preOrderPayService;

    @Resource
    private PaymentRemoteService paymentRemoteService;


    @Override
    public PlainResult<String> createOnlineOrder(CreateOnlineOrderRequest request) {
        REQUEST_LOGGER.info("创建线上订购:" + request);

        PlainResult<String> createOnlineOrderResult = new PlainResult<String>();

        AssertUtil.isAllNotNone(request.getKdtId(), "店铺id不能为空！");
        AssertUtil.isAllNotNone(request.getItemId(), "sku不能为空！");
        AssertUtil.isAllNotNone(request.getQuantity(), "年限不能为空！");

        //  充值，以防万一
        try {
            rechargeShopBalance(request.getKdtId().toString(),99999);
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //  组装创建订购参数
        PurchasablePluginFetchForm fetchForm = new PurchasablePluginFetchForm();
        PlainResult<ItemApi> appIdResult = marketRemoteService.getItemByItemId(request.getItemId());
        if(appIdResult.getCode() == 200){
            fetchForm.setAppId(appIdResult.getData().getAppid());
            fetchForm.setKdtId(request.getKdtId());
            fetchForm.setItemId(request.getItemId());
        }
        else {
            log.info("获取商品信息失败");
        }

        //  判断是否需要订购服务包
        PlainResult<PurchasablePluginApi> queryResult = basicQueryRemoteServiceV2.fetchPurchasablePluginList(fetchForm);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(request.getItemId());
        orderItemForm.setQuantity(request.getQuantity());
        orderItemFormList.add(orderItemForm);

        if (queryResult.getCode() == 200 && queryResult.getData().getRightsPackageList().size()>0) {
            List<ItemApi> items = queryResult.getData().getRightsPackageList().stream().map(PurchasablePluginItemApi::getItem).collect(Collectors.toList());
            List<Integer>itemIds = items.stream().map(ItemApi::getId).collect(Collectors.toList());
            //构造item参数
            for (Integer itemId1 : itemIds) {
                OrderItemForm orderItemForm1 = new OrderItemForm();
                orderItemForm1.setItemId(itemId1);
                orderItemForm1.setQuantity(1);
                orderItemFormList.add(orderItemForm1);
            }
        }else{
            log.info("无权益商品推荐");
        }

        CreateOrderForm createOrderForm = new CreateOrderForm();
        createOrderForm.setKdtId(request.getKdtId());
        //  先不填店铺名称
        createOrderForm.setKdtName("");
        createOrderForm.setItems(orderItemFormList);
        //  此处不使用有赞币
        createOrderForm.setYzbPrice(0L);
        createOrderForm.setUserId(690258785L);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        PlainResult<String> createNormalOrderResult = orderRemoteService.createNormalOrder(createOrderForm);

        if (createNormalOrderResult.getCode() !=200){
            log.error("创建订单失败!"+createNormalOrderResult.toString());
            throw new EnableException(ResultCode.CREATE_ONLINEORDER_ERROR.getCode(),ResultCode.CREATE_ONLINEORDER_ERROR.getMsg()+":"+createNormalOrderResult.getMessage());
        }

        log.info("创建订单成功："+createNormalOrderResult.toString());

        //  预支付
        PlainResult<PreparePayApi> preparePayApiPlainResult =
                preparePay(Long.parseLong(createNormalOrderResult.getData()),(byte) 4);
        payOrder(String.valueOf(request.getKdtId()), preparePayApiPlainResult);
        createOnlineOrderResult.setData(createNormalOrderResult.getData());
        log.info("线上订购创建成功，订单号为："+createNormalOrderResult.getData());
        return createOnlineOrderResult;
    }


    public void rechargeShopBalance(String kdtId, int money) {
        money = money * 100;
        //根据kdtId 获取userNo
        PlainResult<String> result = new PlainResult<>();
        try {
            result = payUserInfoService.queryUserNoByKdtId(Integer.parseInt(kdtId));
            if (!result.isSuccess() || result.getData() == null) {
                log.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
                throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
            }
        } catch (Exception e) {
            log.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
        }
        String userNo = result.getData();

        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        AcctransRechargeRequest rechargeRequest = new AcctransRechargeRequest();
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setUserNo(String.valueOf(userNo));
        accountInfo.setAccountType(AccountType.BASE_ACCT.getType());
        rechargeRequest.setAccountInfo(accountInfo);
        rechargeRequest.setAppName("biz-commerce");
        rechargeRequest.setClientId(waterNo);
        rechargeRequest.setAcquireNo(waterNo);
        rechargeRequest.setAmount(money);
        rechargeRequest.setChannelCode(ChannelType.BALANCE.getCode());
        rechargeRequest.setCurrencyCode(CurrencyCode.CNY.getNum());
        rechargeRequest.setOperator("qa-syh-test");
        rechargeRequest.setOrderNo(waterNo);
        rechargeRequest.setParternerBizType("301001");
        rechargeRequest.setParternerId("301001");
        rechargeRequest.setRemark("接口测试调用");
        rechargeRequest.setSubTransCode(SubTransCodeEnum.RECHARGE_RECHARGESETTLE.getCode());
        rechargeRequest.setTransCode(TransCodeEnum.RECHARGE.getCode());
        rechargeRequest.setRequestTime("test");
        DataResult<AcctransAccountingDTO> rechargeResult = acctransRechargeService.recharge(rechargeRequest);

        if (!rechargeResult.isSuccess()) {
            log.error("AcctransService 充值接口调用失败,waterNo=" + rechargeResult.getRequestId() + "! ");
            throw new EnableException(ResultCode.RECHARGE_ERROR.getCode(),ResultCode.RECHARGE_ERROR.getMsg()+":"+rechargeResult.getMessage());
        }
        log.info(kdtId + "充值成功");
    }

    /**
     * 预支付
     *
     * @param orderId
     * @param env
     */
    public PlainResult<PreparePayApi> preparePay(Long orderId, Byte env) {
        PreparePayForm preparePayForm = new PreparePayForm();
        preparePayForm.setEnv(env);
        preparePayForm.setOrderId(orderId);
        preparePayForm.setReturnUrl("https://cashier.youzan.com/pay/merchant_cashier?after_pay=true");
        PlainResult<PreparePayApi> preparePayResult = paymentRemoteService.preparePay(preparePayForm);
        if(preparePayResult.getCode()!=200){
            log.error("预支付失败，订单号："+ preparePayForm.getOrderId());
            throw new EnableException(ResultCode.PREPAY_ERROR.getCode(),ResultCode.PREPAY_ERROR.getMsg()+":"+preparePayResult.getMessage());
        }
        return preparePayResult;
    }

    /**
     * @param kdtId
     * @param preparePayResult
     * @desc 收银台扣款动作
     */
    public void payOrder(String kdtId, PlainResult<PreparePayApi> preparePayResult) {
        PreOrderPayRequest request = new PreOrderPayRequest();
        request.setAccount("18099999997");
        request.setBizScene("MERCHANT");
        request.setKdtId(kdtId);
        request.setCashierSign(preparePayResult.getData().getResponse().getCashierSign());
        request.setCashierSalt(preparePayResult.getData().getResponse().getCashierSalt());
        request.setPartnerId(preparePayResult.getData().getResponse().getPartnerId());
        request.setPrepayId(preparePayResult.getData().getResponse().getPrepayId());
        request.setPayTool("BALANCE");
        request.setAcceptPrice(0);
        request.setNewPrice(0);
        PlainResult<PreOrderPayResult> payResultPlainResult = preOrderPayService.preOrderPay(request);
        if(payResultPlainResult.getCode()!=117700200){
            log.error("收银台扣款失败，prepayId："+request.getPartnerId());
            throw new EnableException(ResultCode.PAY_ERROR.getCode(),ResultCode.PAY_ERROR.getMsg()+":"+preparePayResult.getMessage());
        }
        log.info("支付成功！");
    }

}
