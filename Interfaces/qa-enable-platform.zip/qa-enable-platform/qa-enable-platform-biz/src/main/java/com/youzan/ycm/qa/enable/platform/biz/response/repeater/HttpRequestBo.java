package com.youzan.ycm.qa.enable.platform.biz.response.repeater;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HttpRequestBo implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * 请求的URL
     */
    private String requestURL;
    /**
     * 请求的URI
     */
    private String requestURI;
    /**
     * 本地端口号
     */
    private int port;
    /**
     * 请求方法
     */
    private String method;
    /**
     * 内容类型
     */
    private String contentType;
    /**
     * 请求headers
     */
    private Map<String, String> headers;
    /**
     * 请求参数 - 没有拦截post body方式提交;没有同步序列化，导致被更改，只能使用request里面的参数
     */
    private Map<String, String[]> paramsMap;

    /**
     * POST请求的BODY
     */
    private String body;

}
