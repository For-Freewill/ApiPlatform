package com.youzan.ycm.qa.enable.platform.biz.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * @author amos wong
 * @create 2021-10-28 8:02 下午
 */
@AllArgsConstructor
@Getter
public enum ShopTypeEnums {

    /**
     * 微商城单店
     */
    WSC("wsc", "微商城单店"),

    /**
     * 微商城连锁
     */
    WSC_CHAIN("wscChain", "微商城连锁"),

    /**
     * 零售单店
     */
    RETAIL("retail", "零售单店"),

    /**
     * 零售连锁专业版/旗舰版
     */
    RETAIL_CHAIN("retailChain", "零售连锁专业版/旗舰版"),

    /**
     * 零售连锁（高级连锁）
     */
    RETAIL_ADVANCED_VERSION("retail_advanced_version", "零售连锁（高级连锁）"),

    /**
     * 美业基础版
     */
    BEAUTY_BASE("beauty_base", "美业基础版"),

    /**
     * 美业专业版
     */
    BEAUTY_PRO("beauty_pro", "美业专业版"),

    /**
     * 教育单店
     */
    EDU("edu", "教育单店"),

    /**
     * 教育连锁2.0
     */
    EDU_CHAIN("eduChain", "教育连锁2.0"),

    /**
     * 教育连锁4.0
     */
    EDU_CHAIN_40("eduChain40", "教育连锁4.0"),

    /**
     * 企微店铺
     */
    ENTERPRISE_WECHAT_ASSISTANT("ENTERPRISE_WECHAT_ASSISTANT","企微助手"),

    /**
     * 旺小店
     */
    WXD("wxd","旺小店"),

    ;

    /**
     * 店铺类型
     */
    private String shopType;

    /**
     * 店铺类型名称
     */
    private String shopTypeName;

    public static ShopTypeEnums findShopTypeEnum(String shopType) {
        for (ShopTypeEnums value : ShopTypeEnums.values()) {
            if (StringUtils.equals(shopType, value.getShopType())) {
                return value;
            }
        }
        return null;
    }
}
