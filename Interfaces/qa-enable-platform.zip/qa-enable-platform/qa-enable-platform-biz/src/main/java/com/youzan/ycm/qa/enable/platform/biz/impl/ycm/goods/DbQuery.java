package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.goods;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.goods.GdSpuEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.goods.GdSpuSnapshotEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.goods.*;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wulei
 * @date 2021/9/30 16:18
 */
@Slf4j
public class DbQuery implements Runnable {
    @Resource
    private GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Resource
    private GdSkuMapper gdSkuMapper;
    @Resource
    private GdSpuMapper gdSpuMapper;
    @Resource
    private GdSkuSnapshotMapper gdSkuSnapshotMapper;
    @Resource
    private GdSpuSnapshotMapper gdSpuSnapshotMapper;

    private Integer app_id;

    public DbQuery(Integer app_id) {
        this.app_id = app_id;
    }

    @Override
    public void run() {
        Map<String, String> result = new LinkedHashMap<>();
        List<GdSpuEntity> gdSpuEntityList = gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id));
        AssertUtil.isTrue(gdSpuEntityList.size() == 1, " gd_spu表错误");
        //gd_spu.snapshot_no
        Long snapshotNo = gdSpuEntityList.get(0).getSnapshotNo();
        log.info("app_id=" + app_id + ",gd_spu.snapshot_no=" + snapshotNo);
        // 返回值
        GdSpuEntity gdSpuEntity = gdSpuEntityList.get(0);
        GdSpuSnapshotEntity gdSpuSnapshotEntity = gdSpuSnapshotMapper.selectOne(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id).eq(GdSpuSnapshotEntity::getSnapshotNo, snapshotNo));
        //
        result.put("gdSpuEntity", gdSpuEntity.toString());
        result.put("gdSpuSnapshotEntity", gdSpuSnapshotEntity.toString());
    }
}
