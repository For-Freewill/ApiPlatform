package com.youzan.ycm.qa.enable.platform.biz.request.enable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2021/2/19 1:34 PM
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnableProgramScoreQueryRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682718283L;

    /**
     * programName项目名称查询
     */
    private String team;

    /**
     * programName项目名称查询
     */
    private String programName;

    /**
     * programQa项目测试查询
     */
    private String programQa;

    /**
     * scoreTotal 总分
     */
    private String scoreTotal;

    /**
     * 上线时间：开始
     */
    private String beginOnlineTime;

    /**
     * 上线时间：结束
     */
    private String endOnlineTime;
}
