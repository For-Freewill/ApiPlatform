package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.chain;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.shopcenter.shop.entity.ServiceResult;
import com.youzan.shopcenter.shop.entity.request.ShopContactSetRequest;
import com.youzan.shopcenter.shop.service.ShopContactService;
import com.youzan.shopcenter.shopfront.api.dto.request.shop.ShopUpgradeRequest;
import com.youzan.shopcenter.shopfront.api.dto.result.shop.ShopUpgradeResult;
import com.youzan.shopcenter.shopfront.api.service.shop.ShopUpgradeService;
import com.youzan.shopcenter.shopfront.api.service.unsafe.ShopUpgradeUnsafeService;
import com.youzan.shopcenter.shopfront.api.service.workflow.TaskReadService;
import com.youzan.ycm.qa.enable.platform.api.enums.GoodBasicInfo;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.chian.YzChainUpgradeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.SchemeState;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.upgrade.ShopUpgradeRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.CreateOrderService;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.chain.UpgradeChainService;
import com.youzan.ycm.qa.enable.platform.biz.enums.UpgradeTypeEnum;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform.PfSchemeEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.perform.PfSchemeMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.testng.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author leifeiyun
 * @date 2022/2/10
 **/
@Slf4j
@Service("upgradeChainService")
public class UpgradeChainServiceImpl implements UpgradeChainService {
    @Resource
    ShopUpgradeService shopUpgradeService;
    @Resource
    ShopContactService shopContactService;

    @Resource
    PfSchemeMapper pfSchemeMapper;

    @Override
    public PlainResult<ShopUpgradeRep> startUpgrade(YzChainUpgradeRequest yzChainUpgradeRequest) {
        String kdtId = yzChainUpgradeRequest.getKdtId();
        String upgradeType = yzChainUpgradeRequest.getUpgradeType();
        //1.创建订单
        //最后选择在controller中直接创建

        //2.设置联系方式
        ShopContactSetRequest shopContactSetRequest = new ShopContactSetRequest();
        shopContactSetRequest.setKdtId(Long.valueOf(kdtId));
        shopContactSetRequest.setPhoneNumber("15988140519");
        shopContactSetRequest.setAreaCode("");
        shopContactSetRequest.setCounty("西湖区");
        shopContactSetRequest.setCountyId(330106);
        shopContactSetRequest.setAddress("留下街道华泰创业园");
        shopContactSetRequest.setLng("120.09320058917");
        shopContactSetRequest.setLat("30.263271486035");
        ServiceResult serviceResult = shopContactService.setShopContact(shopContactSetRequest);

        //3.准备升级数据以及升级
        ShopUpgradeRequest shopUpgradeRequest = new ShopUpgradeRequest();
        shopUpgradeRequest.setKdtId(Long.valueOf(kdtId));
        Integer shopUpgradeType = UpgradeTypeEnum.findShopUpgradeTypeEnum(upgradeType).getCode();
        shopUpgradeRequest.setUpgradeType(shopUpgradeType);

        //对于多网点升级的，会有特殊处理，体现在yopConversion,加了这个才会自动落单，升级后触发落单
        if("wscMultiStore-LSign".equals(upgradeType)){
            Map<String,String> extraInfo = new HashMap<>();
            extraInfo.put("yopPolicy","yopConversion");
            shopUpgradeRequest.setExtraInfo(extraInfo);
        }

        PlainResult<ShopUpgradeResult> result = new PlainResult<>();
        result = shopUpgradeService.startUpgrade(shopUpgradeRequest);
        PlainResult<ShopUpgradeRep> shopUpgradeRepPlainResult = new PlainResult<>();
        ShopUpgradeRep shopUpgradeRep =new ShopUpgradeRep();

        if(result.getCode()!=200){
            shopUpgradeRep.setWorkflowId("lfy-error");
            shopUpgradeRep.setMsg(result.getMessage());
            shopUpgradeRepPlainResult.setData(shopUpgradeRep);
            return shopUpgradeRepPlainResult;
        }else {
            shopUpgradeRep.setWorkflowId(result.getData().getWorkflowId());
            shopUpgradeRep.setMsg(result.getMessage());
            shopUpgradeRepPlainResult.setData(shopUpgradeRep);
            return shopUpgradeRepPlainResult;
        }
    }

    public PlainResult<SchemeState> schemeState(YzChainUpgradeRequest yzChainUpgradeRequest) {
        String kdtId = yzChainUpgradeRequest.getKdtId();
        String upgradeType = yzChainUpgradeRequest.getUpgradeType();
        String state="wait_perform";
        if (!("wscMultiStore-LSign".equals(upgradeType) || "eduChain20-eduChain40".equals(upgradeType) ||
                "wscChain40D-retailChain40L".equals(upgradeType))) {
            List<PfSchemeEntity> list = new ArrayList<>();
                list = pfSchemeMapper.selectList(new QueryWrapper<PfSchemeEntity>()
                        .eq("owner_id", kdtId)
                        .eq("state", "wait_perform"));
                if (list.size() > 0) {
                    state="wait_perform";
            }else {
                    state="no_scheme";
                };
        }
        SchemeState schemeState = new SchemeState();
        schemeState.setState(state);

        PlainResult<SchemeState> result = new PlainResult<>();
        result.setData(schemeState);
        return result;
    }
}
