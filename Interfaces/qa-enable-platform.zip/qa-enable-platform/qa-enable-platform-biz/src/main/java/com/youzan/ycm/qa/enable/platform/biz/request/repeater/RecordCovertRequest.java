package com.youzan.ycm.qa.enable.platform.biz.request.repeater;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecordCovertRequest implements Serializable {
    private static final long serialVersionUID = 7718929662682618283L;

    /**
     * record id
     */
    private Long id;

}
