package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwProcInstDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwProcInstDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 服务流程实例
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:51
 */
public class FwProcInstTransfer {

	public static FwProcInstDTO toBO(FwProcInstDO d) {

		if (d == null) {

			return null;
		}

		FwProcInstDTO fwProcInstBO = new FwProcInstDTO();
		fwProcInstBO.setId(d.getId());
		fwProcInstBO.setKdtId(d.getKdtId());
		fwProcInstBO.setProcTemplate(d.getProcTemplate());
		fwProcInstBO.setStartTime(d.getStartTime());
		fwProcInstBO.setStartVariable(d.getStartVariable());
		fwProcInstBO.setCreatedAt(d.getCreatedAt());
		fwProcInstBO.setUpdatedAt(d.getUpdatedAt());

		return fwProcInstBO;
	}

	public static FwProcInstDO toDO(FwProcInstDTO bo) {

        if (bo == null) {

			return null;
		}

		FwProcInstDO fwProcInstDO = new FwProcInstDO();
		fwProcInstDO.setId(bo.getId());
		fwProcInstDO.setKdtId(bo.getKdtId());
		fwProcInstDO.setProcTemplate(bo.getProcTemplate());
		fwProcInstDO.setStartTime(bo.getStartTime());
		fwProcInstDO.setStartVariable(bo.getStartVariable());
		fwProcInstDO.setCreatedAt(bo.getCreatedAt());
		fwProcInstDO.setUpdatedAt(bo.getUpdatedAt());

		return fwProcInstDO;
	}

	public static List<FwProcInstDTO> toBOList(List<FwProcInstDO> doList) {

		if (doList == null) {

			return new ArrayList<FwProcInstDTO>();
		}

		List<FwProcInstDTO> boList = new ArrayList<FwProcInstDTO>();
		for (FwProcInstDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwProcInstDO> toDOList(List<FwProcInstDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwProcInstDO>();
		}

		List<FwProcInstDO> doList = new ArrayList<FwProcInstDO>();

		for (FwProcInstDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
