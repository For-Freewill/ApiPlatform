package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.ExcuteDetailBO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.ExcuteDetailEntity;

import java.util.Date;

/**
 * @author hezhulin
 * @date 2021-08-24 14:54
 */
public class ExcuteDetailTransfer {

    public static ExcuteDetailDTO toDTO(ExcuteDetailEntity excuteDetailEntity){
        ExcuteDetailDTO excuteDetailDTO = new ExcuteDetailDTO();
        excuteDetailDTO.setId(excuteDetailEntity.getId());
        excuteDetailDTO.setJobId(excuteDetailEntity.getJobId());
        excuteDetailDTO.setCaseId(excuteDetailEntity.getCaseId());
        excuteDetailDTO.setExcuteResult(excuteDetailEntity.getExcuteResult());
        excuteDetailDTO.setExcuteCost(excuteDetailEntity.getExcuteCost());
        excuteDetailDTO.setExcuteJenkins(excuteDetailEntity.getExcuteJenkins());
        excuteDetailDTO.setErrorDetail(excuteDetailEntity.getErrorDetail());
        excuteDetailDTO.setEnv(excuteDetailEntity.getEnv());
        return excuteDetailDTO;

    }

    public static ExcuteDetailBO toB0(ExcuteDetailEntity excuteDetailEntity){
        ExcuteDetailBO excuteDetailBO = new ExcuteDetailBO();
        excuteDetailBO.setId(excuteDetailEntity.getId());
        excuteDetailBO.setJobId(excuteDetailEntity.getJobId());
        excuteDetailBO.setCaseId(excuteDetailEntity.getCaseId());
        excuteDetailBO.setExcuteResult(excuteDetailEntity.getExcuteResult());
        excuteDetailBO.setExcuteCost(excuteDetailEntity.getExcuteCost());
        excuteDetailBO.setExcuteJenkins(excuteDetailEntity.getExcuteJenkins());
        excuteDetailBO.setErrorDetail(excuteDetailEntity.getErrorDetail());
        excuteDetailBO.setEnv(excuteDetailEntity.getEnv());
        excuteDetailBO.setCreatedAt(excuteDetailEntity.getCreatedAt());
        excuteDetailBO.setUpdatedAt(excuteDetailEntity.getUpdatedAt());
        return excuteDetailBO;

    }

    public static ExcuteDetailEntity toEntity(ExcuteDetailDTO excuteDetailDTO){
        ExcuteDetailEntity excuteDetailEntity = new ExcuteDetailEntity();
        if (null != excuteDetailDTO.getId())
            excuteDetailEntity.setId(excuteDetailDTO.getId());
        excuteDetailEntity.setJobId(excuteDetailDTO.getJobId());
        excuteDetailEntity.setCaseId(excuteDetailDTO.getCaseId());
        excuteDetailEntity.setExcuteResult(excuteDetailDTO.getExcuteResult());
        excuteDetailEntity.setExcuteCost(excuteDetailDTO.getExcuteCost());
        excuteDetailEntity.setExcuteJenkins(excuteDetailDTO.getExcuteJenkins());
        excuteDetailEntity.setErrorDetail(excuteDetailDTO.getErrorDetail());
        excuteDetailEntity.setCaseBelongApp(excuteDetailDTO.getCaseBelongApp());
        excuteDetailEntity.setEnv(excuteDetailDTO.getEnv());
        excuteDetailEntity.setCreatedAt(new Date());
        excuteDetailEntity.setUpdatedAt(new Date());
        return excuteDetailEntity;

    }
}
