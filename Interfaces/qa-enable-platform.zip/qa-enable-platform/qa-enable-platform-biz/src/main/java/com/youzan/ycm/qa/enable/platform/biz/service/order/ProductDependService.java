package com.youzan.ycm.qa.enable.platform.biz.service.order;

import com.youzan.api.common.response.ListResult;
import com.youzan.enable.crm.meta.api.dto.product.*;

import java.util.List;

public interface ProductDependService {
    /**
     * 新增产品
     * @param createDTO 产品创建参数
     * @return 插入是否成功
     */
    Boolean insert(ProductCreateDTO createDTO);

    /**
     * 修改产品
     * @param updateDTO 产品修改参数
     * @return 修改是否生效
     */
    Boolean updateById(ProductUpdateDTO updateDTO);

    /**
     * 根据itemId查询单个产品信息
     * @param itemId 商业化用来区分产品的通用ID
     * @return 产品信息，包含产品类型信息
     */
    ProductExtendDTO getByItemId(Integer itemId);

    /**
     * 根据主键查询单个产品信息
     * @param id 产品ID
     * @return 产品信息，包含产品类型信息
     */
    ProductExtendDTO getById(Long id);

    /**
     * 根据条件查询产品列表
     * tips：不包含失效产品，即isActive=0的产品
     * @param condition 产品查询条件
     * @return 产品信息，包含产品类型信息
     */
    ListResult<ProductExtendDTO> queryProduct(ProductConditionDTO condition);
    /**
     * 查询所有的产品列表
     * @return 产品信息，包含产品类型信息
     */
    List<ProductTypeAggregationDTO> queryAllProduct();
}
