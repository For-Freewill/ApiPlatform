package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.shop;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.MarketActivityService;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.*;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:12
 **/
@Service
public class MarketActivityServiceImpl implements MarketActivityService {

    final static public Logger logger = LoggerFactory.getLogger(MarketActivityServiceImpl.class);

    @Autowired(required = false)
    public MkActivityMapper mkActivityMapper;
    @Autowired(required = false)
    public MkActivityRuleMapper mkActivityRuleMapper;
    @Autowired(required = false)
    public MkActivitySnapshotMapper mkActivitySnapshotMapper;

    @Autowired(required = false)
    public MkCollocationMapper mkCollocationMapper;
    @Autowired(required = false)
    public MkCollocationSnapshotMapper mkCollocationSnapshotMapper;

    @Autowired(required = false)
    public MkPresentMapper mkPresentMapper;
    @Autowired(required = false)
    public MkPresentGiftMapper mkPresentGiftMapper;
    @Autowired(required = false)
    public MkBizRecordMapper mkBizRecordMapper;
    @Autowired(required = false)
    public MkPresentGoodsMapper mkPresentGoodsMapper;
    @Autowired(required = false)
    public MkPresentPointMapper mkPresentPointMapper;

    @Autowired(required = false)
    private MkJoinRecordMapper joinRecordMapper;

    @Autowired(required = false)
    public MkJoinQualificationMapper mkJoinQualificationMapper;
    @Autowired(required = false)
    public MKPromotionResultDetailMapper mkPromotionResultDetailMapper;

    @Autowired(required = false)
    public MkCouponMapper mkCouponMapper;

    @Autowired(required = false)
    public MkCouponRuleMapper mkCouponRuleMapper;

    @Autowired(required = false)
    public MkCouponAssetMapper mkCouponAssetMapper;

    @Autowired(required = false)
    public MkCouponSnapshotMapper mkCouponSnapshotMapper;

    @Autowired(required = false)
    public MkCouponSendRecordMapper mkCouponSendRecordMapper;

    @Autowired(required = false)
    public MkCouponSendRecordDetailMapper mkCouponSendRecordDetailMapper;

    /**
     * 清理某笔订单下所有的营销活动数据，根据活动ID来操作，包括搭配购，打折，满减，买赠
     */
    public void deleteMarketActivityData(Long id) {

        //券的清理
        List<MkCouponEntity> mkCouponEntityList =
                mkCouponMapper.selectList(
                        new QueryWrapper<MkCouponEntity>().lambda().eq(MkCouponEntity::getId, id));

        mkCouponEntityList.forEach(item -> {
            List<MkCouponSendRecordEntity> mkCouponSendRecordEntityList =
                    mkCouponSendRecordMapper.selectList(
                            new QueryWrapper<MkCouponSendRecordEntity>().lambda().eq(MkCouponSendRecordEntity::getCouponId, item.getId()));
            mkCouponSendRecordEntityList.forEach(mkCouponEntityItem -> {

                mkCouponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetailEntity>().lambda().eq(MkCouponSendRecordDetailEntity::getSendRecordId, mkCouponEntityItem.getId()));
                mkCouponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecordEntity>().lambda().eq(MkCouponSendRecordEntity::getCouponId, mkCouponEntityItem.getId()));
            });
            mkCouponRuleMapper.delete(new QueryWrapper<MkCouponRuleEntity>().lambda().eq(MkCouponRuleEntity::getCouponId, item.getId()));
            mkCouponAssetMapper.delete(new QueryWrapper<MkCouponAssetEntity>().lambda().eq(MkCouponAssetEntity::getCouponId, item.getId()));
            mkCouponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshotEntity>().lambda().eq(MkCouponSnapshotEntity::getCouponId, item.getId()));
            mkCouponMapper.delete(new QueryWrapper<MkCouponEntity>().lambda().eq(MkCouponEntity::getId, item.getId()));
        });

        // ------------------------------  搭配购的清理  ------------------------------
        List<MkCollocationEntity> mkCollocationEntityList =
                mkCollocationMapper.selectList(
                        new QueryWrapper<MkCollocationEntity>().lambda().eq(MkCollocationEntity::getId, id));

        List<MkActivityEntity> mkActivityListByCollocation =
                mkActivityMapper.selectList(
                        new QueryWrapper<MkActivityEntity>().lambda().eq(MkActivityEntity::getId, mkCollocationEntityList.get(0).getActivityId()));

        mkActivityListByCollocation.forEach(item -> {
            //搭配购数据，需要额外删除搭配购的表
            List<MkActivityRuleEntity> mkActivityRulesList =
                    mkActivityRuleMapper.selectList(
                            new QueryWrapper<MkActivityRuleEntity>().lambda().eq(MkActivityRuleEntity::getActivityId, item.getId()));

            //获取mk_present表数据，其中id是 mk_present表的actions大字段里的 presentId
            String presentId = "";
            JSONArray jsonArray = JSONArray.parseArray(mkActivityRulesList.get(0).getActions());
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            presentId = jsonObject.getString("presentId");
            List<MkPresentEntity> mkPresentsList =
                    mkPresentMapper.selectList(
                            new QueryWrapper<MkPresentEntity>().lambda().eq(MkPresentEntity::getId, presentId));

            CollectionUtils.isNotEmpty(mkPresentsList);

            //删除买赠类数据
            mkPresentPointMapper.delete(new QueryWrapper<MkPresentPointEntity>().lambda().eq(MkPresentPointEntity::getPresentId, presentId));
            mkPresentGoodsMapper.delete(new QueryWrapper<MkPresentGoodsEntity>().lambda().eq(MkPresentGoodsEntity::getPresentId, presentId));
            mkPresentMapper.delete(new QueryWrapper<MkPresentEntity>().lambda().eq(MkPresentEntity::getId, presentId));
            mkPresentGiftMapper.delete(new QueryWrapper<MkPresentGiftEntity>().lambda().eq(MkPresentGiftEntity::getPresentId, presentId));


            //删除活动类数据
            mkActivityRuleMapper.delete(new QueryWrapper<MkActivityRuleEntity>().lambda().eq(MkActivityRuleEntity::getActivityId, item.getId()));
            joinRecordMapper.delete(new QueryWrapper<MkJoinRecordEntity>().lambda().eq(MkJoinRecordEntity::getMkId, item.getId()));

            //删除活动表数据
            mkActivitySnapshotMapper.delete(new QueryWrapper<MkActivitySnapshotEntity>().lambda().eq(MkActivitySnapshotEntity::getId, mkCollocationEntityList.get(0).getActivityId()));
            mkActivityMapper.delete(new QueryWrapper<MkActivityEntity>().lambda().eq(MkActivityEntity::getId, mkCollocationEntityList.get(0).getActivityId()));

        });

        mkCollocationMapper.delete(new QueryWrapper<MkCollocationEntity>().lambda().eq(MkCollocationEntity::getId, id));
        mkCollocationSnapshotMapper.delete(new QueryWrapper<MkCollocationSnapshotEntity>().lambda().eq(MkCollocationSnapshotEntity::getId, id));


        //------------------------------  单纯活动的清理  ------------------------------
        List<MkActivityEntity> mkActivityList =
                mkActivityMapper.selectList(
                        new QueryWrapper<MkActivityEntity>().lambda().eq(MkActivityEntity::getId, id));

        mkActivityList.forEach(item -> {
            //搭配购数据，需要额外删除搭配购的表
            List<MkActivityRuleEntity> mkActivityRulesList =
                    mkActivityRuleMapper.selectList(
                            new QueryWrapper<MkActivityRuleEntity>().lambda().eq(MkActivityRuleEntity::getActivityId, item.getId()));

            //获取mk_present表数据，其中id是 mk_present表的actions大字段里的 presentId
            String presentId = "";
            JSONArray jsonArray = JSONArray.parseArray(mkActivityRulesList.get(0).getActions());
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            presentId = jsonObject.getString("presentId");
            List<MkPresentEntity> mkPresentsList =
                    mkPresentMapper.selectList(
                            new QueryWrapper<MkPresentEntity>().lambda().eq(MkPresentEntity::getId, presentId));

            CollectionUtils.isNotEmpty(mkPresentsList);

            //删除买赠类数据
            mkPresentPointMapper.delete(new QueryWrapper<MkPresentPointEntity>().lambda().eq(MkPresentPointEntity::getPresentId, presentId));
            mkPresentGoodsMapper.delete(new QueryWrapper<MkPresentGoodsEntity>().lambda().eq(MkPresentGoodsEntity::getPresentId, presentId));
            mkPresentMapper.delete(new QueryWrapper<MkPresentEntity>().lambda().eq(MkPresentEntity::getId, presentId));
            mkPresentGiftMapper.delete(new QueryWrapper<MkPresentGiftEntity>().lambda().eq(MkPresentGiftEntity::getPresentId, presentId));


            //删除活动类数据
            mkActivityRuleMapper.delete(new QueryWrapper<MkActivityRuleEntity>().lambda().eq(MkActivityRuleEntity::getActivityId, item.getId()));
            joinRecordMapper.delete(new QueryWrapper<MkJoinRecordEntity>().lambda().eq(MkJoinRecordEntity::getMkId, item.getId()));

            //删除活动表数据
            mkActivitySnapshotMapper.delete(new QueryWrapper<MkActivitySnapshotEntity>().lambda().eq(MkActivitySnapshotEntity::getId, id));
            mkActivityMapper.delete(new QueryWrapper<MkActivityEntity>().lambda().eq(MkActivityEntity::getId, id));

        });
    }
}
