package com.youzan.ycm.qa.enable.platform.biz.util;

import org.springframework.util.ObjectUtils;

/**
 * @Author qibu
 * @create 2020/11/10 4:04 PM
 * 主要用来断言接口入参的合法性
 */
public class AssertUtil {
    private static Integer DEFAULT_INTEGER = 0;

    public static void isNotNull(Object param, String errorMsg) {
        if (null == param) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    public static void isNull(Object param, String errorMsg) {
        if (null != param) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    /**
     * 断言对象不是空
     *
     * @param param    先判断不为null,
     *                 支持类型：Optional,CharSequence,Array,Collection,Map
     * @param errorMsg
     */
    public static void isNotEmpty(Object param, String errorMsg) {
        if (ObjectUtils.isEmpty(param)) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    public static void isEmpty(Object param, String errorMsg) {
        if (!ObjectUtils.isEmpty(param)) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    public static void isTrue(Boolean condition, String errorMsg) {
        if (!condition) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    public static void isNotTrue(Boolean condition, String errorMsg) {
        if (condition) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    /**
     * null,empty判断
     *
     * @param param
     * @param errorMsg
     */
    public static void isAllNotNone(Object param, String errorMsg) {
        if (null == param || ObjectUtils.isEmpty(param)) {
            throw new IllegalArgumentException(errorMsg);
        }
    }

    /**
     * 不为null或者默认值
     */
    public static boolean notNullOrDefault(Integer value) {
        return value != null && !value.equals(DEFAULT_INTEGER);
    }

    public static boolean nullOrDefault(Integer value) {
        return value == null || DEFAULT_INTEGER.equals(value);
    }
}
