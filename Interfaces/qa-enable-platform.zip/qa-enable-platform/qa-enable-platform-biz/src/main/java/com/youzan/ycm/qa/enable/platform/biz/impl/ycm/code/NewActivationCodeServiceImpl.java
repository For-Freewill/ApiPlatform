package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.code;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.code.NewActivationCodeRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.code.NewActivationCodeResponse;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.code.NewActivationCodeService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.LegalTables;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.code.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 新激活码查询
 *
 * @Author wulei
 * @Date 2021/01/13 15:03
 */
@Slf4j
@Service("newActivationCodeService")
public class NewActivationCodeServiceImpl implements NewActivationCodeService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private CdRedeemCodeApplyMutexMapper cdRedeemCodeApplyMutexMapper;
    @Resource
    private CdRedeemCodeApplyRecordMapper cdRedeemCodeApplyRecordMapper;
    @Resource
    private CdRedeemCodeBatchMapper cdRedeemCodeBatchMapper;
    @Resource
    private CdRedeemCodeDistributeRecordMapper cdRedeemCodeDistributeRecordMapper;
    @Resource
    private CdRedeemCodeMapper cdRedeemCodeMapper;
    @Resource
    private TdActivationCodeApplyRecordMapper tdActivationCodeApplyRecordMapper;
    @Resource
    private TdActivationCodeGoodsItemMapper tdActivationCodeGoodsItemMapper;
    @Resource
    private TdActivationCodeMapper tdActivationCodeMapper;

    @Override
    public PlainResult<NewActivationCodeResponse> selectCodeDetail(NewActivationCodeRequest request) {
        REQUEST_LOGGER.info("激活码查询:" + request);

        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getTables(), "tables 不能为空！");
        AssertUtil.isAllNotNone(request.getCode(), "code 不能为空！");
        // 2-执行查询
        NewActivationCodeResponse newActivationCodeResponse = new NewActivationCodeResponse();
        Map<String, Object> resultMaps = resultMap(request);
        // 3-封装结果
        newActivationCodeResponse.setTotal(Long.valueOf(resultMaps.size()));
        newActivationCodeResponse.setDetails(resultMaps);
        PlainResult<NewActivationCodeResponse> plainResult = new PlainResult<>();
        plainResult.setData(newActivationCodeResponse);
        return plainResult;

    }

    /**
     * 表名校验
     *
     * @return
     */
    private List<String> verifyTables(NewActivationCodeRequest request) {
        // 1-请求列表去重
        List<String> queryTables = request.getTables().stream().distinct().collect(Collectors.toList());
        // 2-合法表名
        List<String> tables = LegalTables.newActivationCodeLegalTables();
        // 3-判断是否有不在合法表内的数据
        List<String> bad = queryTables.stream().filter(tb -> !tables.contains(tb)).collect(Collectors.toList());
        if (bad.size() > 0) {
            log.info("请求的tables名称不存在" + bad.toString());
            throw new EnableException(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMsg());
        }
        return queryTables;
    }

    /**
     * 查询结果数据
     *
     * @param request
     * @return
     */
    private Map<String, Object> resultMap(NewActivationCodeRequest request) {
        Map<String, Object> resultMap = new LinkedHashMap<>();

        //1-校验入参的表格
        List<String> queryTables = verifyTables(request);

        //2-查询code是否存在
        List<CdRedeemCodeEntity> res = cdRedeemCodeMapper.selectList(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, request.getCode()));
        //
        if (res.size() == 0) {
            return resultMap;
        }
        String batch_no = res.get(0).getBatchNo();
        if (batch_no != null) {
            //cd_redeem_code
            if (queryTables.contains("cd_redeem_code") && cdRedeemCodeMapper.selectList(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("cd_redeem_code", cdRedeemCodeMapper.selectList(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, request.getCode())));
            }
            //cd_redeem_code_batch
            if (queryTables.contains("cd_redeem_code_batch") && cdRedeemCodeBatchMapper.selectList(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no)).size() != 0) {
                resultMap.put("cd_redeem_code_batch", cdRedeemCodeBatchMapper.selectList(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no)));
            }
            //td_activation_code
            if (queryTables.contains("td_activation_code") && tdActivationCodeMapper.selectList(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("td_activation_code", tdActivationCodeMapper.selectList(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, request.getCode())));
            }
            //td_activation_code_goods_item
            if (queryTables.contains("td_activation_code_goods_item") && tdActivationCodeGoodsItemMapper.selectList(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("td_activation_code_goods_item", tdActivationCodeGoodsItemMapper.selectList(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, request.getCode())));
            }
            //td_activation_code_apply_record
            if (queryTables.contains("td_activation_code_apply_record") && tdActivationCodeApplyRecordMapper.selectList(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("td_activation_code_apply_record", tdActivationCodeApplyRecordMapper.selectList(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getCode, request.getCode())));
            }
            //cd_redeem_code_apply_record
            if (queryTables.contains("cd_redeem_code_apply_record") && cdRedeemCodeApplyRecordMapper.selectList(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("cd_redeem_code_apply_record", cdRedeemCodeApplyRecordMapper.selectList(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getCode, request.getCode())));
            }
            //cd_redeem_code_apply_mutex
            if (queryTables.contains("cd_redeem_code_apply_mutex") && cdRedeemCodeApplyMutexMapper.selectList(new QueryWrapper<CdRedeemCodeApplyMutexEntity>().lambda().eq(CdRedeemCodeApplyMutexEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("cd_redeem_code_apply_mutex", cdRedeemCodeApplyMutexMapper.selectList(new QueryWrapper<CdRedeemCodeApplyMutexEntity>().lambda().eq(CdRedeemCodeApplyMutexEntity::getCode, request.getCode())));
            }
            //cd_redeem_code_distribute_record
            if (queryTables.contains("cd_redeem_code_distribute_record") && cdRedeemCodeDistributeRecordMapper.selectList(new QueryWrapper<CdRedeemCodeDistributeRecordEntity>().lambda().eq(CdRedeemCodeDistributeRecordEntity::getCode, request.getCode())).size() != 0) {
                resultMap.put("cd_redeem_code_distribute_record", cdRedeemCodeDistributeRecordMapper.selectList(new QueryWrapper<CdRedeemCodeDistributeRecordEntity>().lambda().eq(CdRedeemCodeDistributeRecordEntity::getCode, request.getCode())));
            }

        } else {
            return resultMap;
        }
        return resultMap;
    }
}