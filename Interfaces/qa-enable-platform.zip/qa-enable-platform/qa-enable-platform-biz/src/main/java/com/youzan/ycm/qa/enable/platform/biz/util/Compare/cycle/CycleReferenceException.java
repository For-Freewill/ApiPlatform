package com.youzan.ycm.qa.enable.platform.biz.util.Compare.cycle;

/**
 * {@link CycleReferenceException}
 * <p>
 *
 * @author wulei
 */
public class CycleReferenceException extends Exception {

    public CycleReferenceException(String message) {
        super(message);
    }
}
