package com.youzan.ycm.qa.enable.platform.biz.commonutils;

/**
 * @author wulei
 * @date 2021/11/11 20:48
 * http请求响应转Java代码
 */
public class HttpCodeSegmentDefinition {
    // 新的Java文件
    public static final String NEW_JAVA = "import com.alibaba.fastjson.JSONObject;\n" +
            "import com.youzan.test.quickstart.annotation.Http;\n" +
            "import com.youzan.test.quickstart.utils.HttpUtil;\n" +
            "import lombok.extern.slf4j.Slf4j;\n" +
            "import org.testng.Assert;\n" +
            "import org.testng.annotations.Test;\n" +
            "\n" +
            "import java.util.HashMap;\n" +
            "import java.util.Map;\n" +
            "\n" +
            "@Slf4j\n" +
            "public class RepeaterTest extends BaseTest {\n" +
            "    @Http(\"\")\n" +
            "    protected HttpUtil httpUtil;\n" +
            "\n" +
            "    #TEST#\n" +
            "}";

    // 新的get请求 @Test
    public static final String GET_TEST = "@Test()\n" +
            "\tpublic void doGetReturnResponseJsonTest(){\n" +
            "        String url =\"#URL#\";\n" +
            "        #HTTP_GET#\n" +
            "        log.info(\"result = \" + jsonObject);\n" +
            "        #RESPONSE_ASSERT#\n" +
            "    }";

    // 新的post请求 @Test
    public static final String POST_TEST = "@Test()\n" +
            "    public void doPostReturnResponseJsonTest(){\n" +
            "        String url =\"#URL#\";\n" +
            "        Map<String, String> params = new HashMap<>();\n" +
            "        #PARAMS#\n" +
            "        #HTTP_POST#\n" +
            "        logger.info(\"result = \" + jsonObject);\n" +
            "        #RESPONSE_ASSERT#\n" +
            "    }\n";

    // 新的headers
    public static final String HEADERS = "headers.set(\"#HeadKey#\",\"#HeadValue#\");\n\t\t";

    // 新的params
    public static final String PARAMS = "params.set(\"#ParamKey#\",\"#ParamValue#\");\n\t\t";

    // 新的get请求
    public static final String HTTP_GET = "JSONObject jsonObject = httpUtil.doGetReturnResponseJson(url);\n";

    // 新的post请求
    public static final String HTTP_POST = "JSONObject jsonObject = httpUtil.doPostReturnResponseJson(url, params);\n";

    // response拼接
    public static final String RESPONSE_ASSERT = "if (jsonObject!=null){\n" +
            "\t\t\tAssert.assertEquals(jsonObject.getString(\"code\"),\"#respCode#\");\n" +
            "\t\t\tAssert.assertEquals(jsonObject.getString(\"data\"),\"#respData#\");\n" +
            "\t\t\tAssert.assertEquals(jsonObject.getString(\"msg\"),\"#respMsg#\");\n" +
            "\t\t}";

}
