package com.youzan.ycm.qa.enable.platform.biz.util;

import com.youzan.nsq.client.Producer;
import com.youzan.nsq.client.ProducerImplV2;
import com.youzan.nsq.client.entity.DesiredTag;
import com.youzan.nsq.client.entity.Message;
import com.youzan.nsq.client.entity.NSQConfig;
import com.youzan.nsq.client.entity.Topic;
import com.youzan.nsq.client.exception.NSQException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-15 10:56
 */
public class NSQUtil {
    Logger logger = LoggerFactory.getLogger(this.getClass());

    private String Lookupd ;

    public boolean pubMessage(String topicName, String message, boolean sc) throws NSQException {

        Properties properties = PropertyUtil.getProperties();
        Lookupd = properties.getProperty("nsq.lookup.address");

        final NSQConfig config = new NSQConfig();
        //每个Lookup使用HTTP的端口. Address包含: IP + Port
        //必选项. 设置Lookupd(MetaData)集群(多)地址, 是以","分隔的字符串,就是说可以配置一个集群里的多个节点.
        config.setLookupAddresses(Lookupd);
        final Producer producer = new ProducerImplV2(config);
        producer.start();
        Message msg = Message.create(new Topic(topicName), message);
        if(sc){
            msg.setDesiredTag(new DesiredTag(properties.getProperty("env.sc")));
        }
        logger.info("Lookupd*******"+Lookupd);
        logger.info("sc************"+sc);
        try {
            producer.publish(msg);
        } catch (Exception e) { // 无论是Producer/Consumer,都要对应把最大的Exception处理下
            logger.error("Exception", e);
            return false;
        }
        // Client做下优雅的关闭,通常是在进程退出前做关闭
        producer.close();
        return true;
    }
}
