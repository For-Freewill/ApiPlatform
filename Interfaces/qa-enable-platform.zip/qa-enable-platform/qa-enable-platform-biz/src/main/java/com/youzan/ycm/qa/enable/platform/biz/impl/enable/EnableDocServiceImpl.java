package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableDocRequest;
import com.youzan.ycm.qa.enable.platform.api.request.enable.EnableTablesDetailUpdateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableDocResponse;
import com.youzan.ycm.qa.enable.platform.biz.service.enable.EnableDocService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.enable.EnableDocEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.enable.EnableDocMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wulei
 * @date 2020/11/19 16:07
 */
@Slf4j
@Service(value = "enableDocService")
public class EnableDocServiceImpl extends ServiceImpl<EnableDocMapper, EnableDocEntity> implements EnableDocService {
    private static final Logger REQUEST_LOGGER = LoggerFactory.getLogger("request");

    @Resource
    private EnableDocService enableDocService;

    /**
     * 根据文档类型查询记录
     *
     * @return
     */
    @Override
    public PlainResult<List<EnableDocResponse>> selectAllByType(String doc_type) {
        PlainResult<List<EnableDocResponse>> plainResult = new PlainResult<>();

        List<EnableDocEntity> all = enableDocService.list(new QueryWrapper<EnableDocEntity>().lambda().eq(EnableDocEntity::getDocType, doc_type));

        List<EnableDocResponse> all_result =
                all.stream().map(x -> {
                    EnableDocResponse enableDocResponse = new EnableDocResponse();
                    enableDocResponse.setId(x.getId());
                    enableDocResponse.setDoc_name(x.getDocName());
                    enableDocResponse.setDoc_url(x.getDocUrl());
                    enableDocResponse.setDoc_ext(x.getDocExt());
                    enableDocResponse.setDoc_type(x.getDocType());
                    enableDocResponse.setDoc_author(x.getDocAuthor());
                    enableDocResponse.setCreated_at(x.getCreatedAt());
                    return enableDocResponse;
                }).collect(Collectors.toList());
        plainResult.setData(all_result);
        return plainResult;
    }

    /**
     * 类型+文档名称模糊查询
     *
     * @param doc_name
     * @return
     */
    @Override
    public PlainResult<List<EnableDocResponse>> selectByYcmDocName(String doc_name, String doc_type) {
        // 1-校验入参数
        List<EnableDocEntity> all = new ArrayList<EnableDocEntity>();

        if (doc_name.equals("") || doc_name == null || doc_name == "") {
            all = enableDocService.list(new QueryWrapper<EnableDocEntity>().lambda().eq(EnableDocEntity::getDocType, doc_type));
        } else {
            all = enableDocService.list(new QueryWrapper<EnableDocEntity>().lambda().eq(EnableDocEntity::getDocType, doc_type).like(EnableDocEntity::getDocName, doc_name));
        }

        PlainResult<List<EnableDocResponse>> plainResult = new PlainResult<>();
        // 3-出参复制
        List<EnableDocResponse> all_result =
                all.stream().map(x -> {
                    EnableDocResponse enableDocResponse = new EnableDocResponse();
                    enableDocResponse.setId(x.getId());
                    enableDocResponse.setDoc_name(x.getDocName());
                    enableDocResponse.setDoc_url(x.getDocUrl());
                    enableDocResponse.setDoc_ext(x.getDocExt());
                    enableDocResponse.setDoc_type(x.getDocType());
                    enableDocResponse.setDoc_author(x.getDocAuthor());
                    enableDocResponse.setCreated_at(x.getCreatedAt());
                    return enableDocResponse;
                }).collect(Collectors.toList());
        plainResult.setData(all_result);
        return plainResult;
    }

    /**
     * 新增文档记录
     *
     * @param request
     * @return
     */

    @Override
    public PlainResult<Boolean> insert(EnableDocRequest request) {
        REQUEST_LOGGER.info("新建文档记录请求：" + request);
        // 1-校验入参数
        AssertUtil.isAllNotNone(request.getDocName(), "文档名称不能为空");
        AssertUtil.isAllNotNone(request.getDocUrl(), "文档URL不能为空");
        AssertUtil.isAllNotNone(request.getDocExt(), "文档说明不能为空");
        AssertUtil.isAllNotNone(request.getDocType(), "文档类型不能为空");
        AssertUtil.isAllNotNone(request.getDocAuthor(), "创建者不能为空");

        // 3-属性复制
        EnableDocEntity enableDocEntity = new EnableDocEntity();
        BeanUtils.copyProperties(request, enableDocEntity);

        // 2-文档名称+类型 不能相同
        PlainResult<Boolean> result = new PlainResult<>();
        List<EnableDocEntity> exists = selectExitDoc(request.getDocName(), request.getDocType());
        Boolean isSave = false;

        if (exists.size() >= 1) {
            AssertUtil.isNull(exists.size(), "存在文档名称+文档类型相同的记录");
        } else {
            isSave = enableDocService.saveOrUpdate(enableDocEntity);
        }
        result.setData(isSave);
        result.setSuccess(isSave);
        return result;
    }

    /**
     * 更新文档记录,暂不需要实现
     *
     * @param request
     * @return
     */
    @Deprecated
    @Override
    public PlainResult<Boolean> updateById(EnableTablesDetailUpdateRequest request) {
        return null;
    }

    /**
     * 根据ID删除记录-逻辑删除
     * @param id
     * @return
     */
    @Override
    public PlainResult<Boolean> deleteById(Long id) {
        PlainResult<Boolean> plainResult = new PlainResult<>();

        // 1-校验入参数
        AssertUtil.isAllNotNone(id, "id不能为空");

        // 2-删除记录
        Boolean isSave = null;
        isSave = enableDocService.removeById(id);
        plainResult.setData(isSave);

        if (isSave) {
            plainResult.setData(isSave);
        } else {
            throw new EnableException(ResultCode.FAILURE.getCode(), ResultCode.FAILURE.getMsg());
        }
        return plainResult;
    }

    /**
     * 根据doc_name+doc_type判断是否唯一
     *
     * @return
     */
    private List<EnableDocEntity> selectExitDoc(String doc_name, String doc_type) {
        // 1-校验入参数
        AssertUtil.isAllNotNone(doc_name, "文档名称不能为空");
        AssertUtil.isAllNotNone(doc_type, "文档类型不能为空");

        // 2-构造查询Map
        Map<String, Object> allEqMap = new HashMap<>();
        allEqMap.put("doc_name", doc_name);
        allEqMap.put("doc_type", doc_type);
        allEqMap.put("is_delete", 0);
        // 3-allEq查询
        return enableDocService.list(new QueryWrapper<EnableDocEntity>().allEq(allEqMap));
    }
}