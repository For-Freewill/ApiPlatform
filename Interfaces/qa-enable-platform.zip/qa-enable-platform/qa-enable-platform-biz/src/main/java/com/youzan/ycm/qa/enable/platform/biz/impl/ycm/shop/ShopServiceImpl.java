package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.shop;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.shop.ShopService;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code.CdRedeemCodeApplyRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.code.TdActivationCodeApplyRecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.gift.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.market.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.open.OpenProtocolsEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.trade.*;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeResourcePackageEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeResourcePackageLogEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.yunFee.FcFeeYopProtocolEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.code.CdRedeemCodeApplyRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.code.TdActivationCodeApplyRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.gift.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.market.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.open.OpenProtocolsMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.perform.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.trade.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeResourcePackageLogMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeResourcePackageMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.yunFee.FcFeeYopProtocolMapper;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-03 13:12
 **/
@Service
public class ShopServiceImpl implements ShopService {

    final static public Logger logger = LoggerFactory.getLogger(ShopServiceImpl.class);

    @Resource
    private PfAppStatusRemoteService pfAppStatusRemoteService;

    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    private TdSettleOrderMapper tdSettleOrderMapper;
    @Autowired(required = false)
    private TdPayOrderMapper tdPayOrderMapper;
    @Autowired(required = false)
    private TdOrderItemMapper tdOrderItemMapper;
    @Autowired(required = false)
    private TdPayRefundOrderMapper tdPayRefundOrderMapper;
    @Autowired(required = false)
    private TdOrderItemRefundOrderMapper tdOrderItemRefundOrderMapper;
    @Autowired(required = false)
    private TdPmtResultDetailMapper tdPmtResultDetailMapper;
    @Autowired(required = false)
    private TdPstMapper tdPstMapper;
    @Autowired(required = false)
    private TdYzbGrantOrderMapper tdYzbGrantOrderMapper;
    @Autowired(required = false)
    private TdBizRecordMapper tdBizRecordMapper;
    @Autowired(required = false)
    public TDDeductionResultDetailMapper tdDeductionResultDetailMapper;
    @Autowired(required = false)
    public TdDeductionResultCompositionMapper tdDeductionResultCompositionMapper;


    @Autowired(required = false)
    private PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    private PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    private PfAssetFreezeRecordMapper pfAssetFreezeRecordMapper;
    @Autowired(required = false)
    private PfBizRecordMapper pfBizRecordMapper;
    @Autowired(required = false)
    private PfOrderItemBizMapper pfOrderItemBizMapper;
    @Autowired(required = false)
    private PfFeeResourcePackageMapper pfFeeResourcePackageMapper;
    @Autowired(required = false)
    private PfDebtRepayRecordMapper pfDebtRepayRecordMapper;
    @Autowired(required = false)
    private PfOrderDetailDebtRecordMapper pfOrderDetailDebtRecordMapper;
    @Autowired(required = false)
    private PfOrderPreAcceptOrderMapper pfOrderPreAcceptOrderMapper;
    @Autowired(required = false)
    private PfOrderSplitDetailMapper pfOrderSplitDetailMapper;
    @Autowired(required = false)
    private PfRightsStatusMapper pfRightsStatusMapper;
    @Autowired(required = false)
    private PfCouponRecordMapper pfCouponRecordMapper;
    @Autowired(required = false)
    private PfSchemeOrderRelationMapper pfSchemeOrderRelationMapper;
    @Autowired(required = false)
    private PfStatusLogMapper pfStatusLogMapper;
    @Autowired(required = false)
    private PfStockLogMapper pfStockLogMapper;
    @Autowired(required = false)
    private PfOrderDetailMapper pfOrderDetailMapper;
    @Autowired(required = false)
    public PfOrderDetailActiveRecordMapper pfOrderDetailActiveRecordMapper;
    @Autowired(required = false)
    public PfOrderStockMapper pfOrderStockMapper;
    @Autowired(required = false)
    public PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    public PfOrderDetailAdvanceRecordMapper pfOrderDetailAdvanceRecordMapper;
    @Autowired(required = false)
    public TDPresentRecordMapper presentRecordMapper;
    @Autowired(required = false)
    public PfAssetDeductionMapper pfAssetDeductionMapper;
    @Autowired(required = false)
    public PfRechargeConfigMapper pfRechargeConfigMapper;
    @Autowired(required = false)
    public PfSchemeMapper pfSchemeMapper;
    @Autowired(required = false)
    private PfProtectionPeriodMapper pfProtectionPeriodMapper;
    @Autowired(required = false)
    private PfStockMapper pfStockMapper;


    @Autowired(required = false)
    private GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    private GfBizRecordMapper gfBizRecordMapper;
    @Autowired(required = false)
    private GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    private GfAssetGoodsMapper gfAssetGoodsMapper;
    @Autowired(required = false)
    private GfTemplateGoodsMapper gfTemplateGoodsMapper;


    @Autowired(required = false)
    private MkJoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    private MkCouponAssetMapper mkCouponAssetMapper;


    @Autowired(required = false)
    public MkPresentMapper mkPresentMapper;
    @Autowired(required = false)
    public MkBizRecordMapper mkBizRecordMapper;
    @Autowired(required = false)
    public MkJoinQualificationMapper mkJoinQualificationMapper;
    @Autowired(required = false)
    public MKPromotionResultDetailMapper mkPromotionResultDetailMapper;
    @Autowired(required = false)
    public MKCapitalAccountRecordMapper mkCapitalAccountRecordMapper;
    @Autowired(required = false)
    public MKCapitalAccountMapper mkCapitalAccountMapper;

    @Autowired(required = false)
    private CdRedeemCodeApplyRecordMapper cdRedeemCodeApplyRecordMapper;
    @Autowired(required = false)
    private TdActivationCodeApplyRecordMapper tdActivationCodeApplyRecordMapper;

    @Autowired(required = false)
    private OpenProtocolsMapper protocolsMapper;

    @Autowired(required = false)
    private FcFeeResourcePackageLogMapper feeResourcePackageLogMapper;
    @Autowired(required = false)
    private FcFeeYopProtocolMapper feeYopProtocolMapper;
    @Autowired(required = false)
    FcFeeResourcePackageMapper feeResourcePackageMapper;

    /**
     * 清理店铺下所有数据
     */
    @Override
    public PlainResult<Boolean> deleteDataByKdtId(Long kdtId) {
        //  交易信息
        List<TdOrderEntity> tradeOrderDOs = tdOrderMapper.selectList(new QueryWrapper<TdOrderEntity>().eq("buyer_id", kdtId.toString()));
        List<String> tdNoList = tradeOrderDOs.stream().filter(tradeOrderDO -> "YOUZAN".equals(tradeOrderDO.getChannel())).map(TdOrderEntity::getTdNo).collect(Collectors.toList());
        List<TdOrderItemEntity> tradeOrderItemList = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                //  正向
                tdOrderMapper.delete(new QueryWrapper<TdOrderEntity>().eq("td_no", tdNo));
                tdSettleOrderMapper.delete(new QueryWrapper<TdSettleOrderEntity>().eq("td_no", tdNo));
                //            pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("biz_order_id", tdNo));
                tdPayOrderMapper.delete(new QueryWrapper<TdPayOrderEntity>().eq("td_no", tdNo));
                //  解决td_order_item删不干净的问题==
                do {
                    tdOrderItemMapper.delete(new QueryWrapper<TdOrderItemEntity>().eq("td_no", tdNo));
                    tradeOrderItemList = tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItemEntity>().eq("td_no", tdNo));
                } while (tradeOrderItemList.size() > 0);
                //  逆向
                tdPayRefundOrderMapper.delete(new QueryWrapper<TdPayRefundOrderEntity>().eq("td_no", tdNo));
                tdOrderItemRefundOrderMapper.delete(
                        new QueryWrapper<TdOrderItemRefundOrderEntity>().eq("td_no", tdNo));
                // 营销参与记录
                mkPromotionResultDetailMapper.delete(
                        new QueryWrapper<MKPromotionResultDetailEntity>().eq("td_no", tdNo));
                presentRecordMapper.delete(new QueryWrapper<TdPresentRecordEntity>().eq("td_no", tdNo));
                // 抵扣升级
                tdDeductionResultDetailMapper.delete(
                        new QueryWrapper<TdDeductionResultDetailEntity>().eq("td_no", tdNo));
                tdDeductionResultCompositionMapper.delete(
                        new QueryWrapper<TdDeductionResultCompositionEntity>().eq("trade_no", tdNo));
            }
        }
        //  营销信息
        List<GfAssetEntity> gfAssetDOs =
                gfAssetMapper.selectList(new QueryWrapper<GfAssetEntity>().eq("owner_ycmid", kdtId.toString()));
        List<Long> gfAssetIdList =
                gfAssetDOs.stream().map(GfAssetEntity::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(gfAssetIdList)) {
            gfAssetMapper.deleteBatchIds(gfAssetIdList);
            for (long gfAssetId : gfAssetIdList) {
                gfAssetGoodsMapper.delete(new QueryWrapper<GiftAssetGoodsEntity>().eq("asset_id", gfAssetId));
            }
        }
        if (CollectionUtils.isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                joinRecordMapper.delete(new QueryWrapper<MkJoinRecordEntity>().eq("biz_order_id", tdNo));
            }
        }
        mkCouponAssetMapper.delete(new QueryWrapper<MkCouponAssetEntity>().eq("belongto_yid", kdtId.toString()));

        //  履约信息
        List<PfOrderEntity> pfOrderDOs =
                pfOrderMapper.selectList(new QueryWrapper<PfOrderEntity>().eq("buy_kdt_id", kdtId.toString()));
        List<Long> pfOrderIdList = pfOrderDOs.stream().map(PfOrderEntity::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(pfOrderIdList)) {
            pfOrderMapper.deleteBatchIds(pfOrderIdList);
            List<Long> totalPfAssetIds = new LinkedList<>();
            for (Long pfOrderId : pfOrderIdList) {
                List<PfAssetEntity> pfAssetDOList =
                        pfAssetMapper.selectList(new QueryWrapper<PfAssetEntity>().eq("pf_order_id", pfOrderId));
                totalPfAssetIds.addAll(
                        pfAssetDOList.stream().map(PfAssetEntity::getId).collect(Collectors.toList()));
            }
            if (CollectionUtils.isNotEmpty(totalPfAssetIds)) {
                pfAssetMapper.deleteBatchIds(totalPfAssetIds);
                for (long pfAssertId : totalPfAssetIds) {
                    pfAssetDeductionMapper.delete(
                            new QueryWrapper<PfAssetDeductionEntity>().eq("pf_asset_id", pfAssertId));
                }
            }
            // 服务期和库存
            for ( Long pfOrderId : pfOrderIdList) {
                pfOrderDetailMapper.delete(new QueryWrapper<PfOrderDetailEntity>().eq("pf_order_id", pfOrderId));
            }
            pfOrderStatusMapper.delete(
                    new QueryWrapper<PfOrderStatusEntity>().eq("buy_kdt_id", kdtId.toString()));
            pfStockMapper.delete(new QueryWrapper<PfStockEntity>().eq("apply_kdt_id", kdtId));
            pfOrderStockMapper.delete(
                    new QueryWrapper<PfOrderStockEntity>().eq("buy_kdt_id", kdtId.toString()));
            // 延期激活记录表
            pfOrderDetailActiveRecordMapper.delete(
                    new QueryWrapper<PfOrderDetailActiveRecordEntity>().eq("buy_kdt_id", kdtId.toString()));
            // 库存自动充值
            pfRechargeConfigMapper.delete(
                    new QueryWrapper<PfRechargeConfigEntity>().eq("apply_kdt_id", kdtId.toString()));
            // 方案
            pfSchemeMapper.delete(new QueryWrapper<PfSchemeEntity>().eq("owner_id", kdtId.toString()));
            for (Long pfOrderId : pfOrderIdList) {
                pfSchemeOrderRelationMapper.delete(
                        new QueryWrapper<PfSchemeOrderRelationEntity>().eq("order_id", pfOrderId));
            }
        }

        //  pf_rights_status
        pfRightsStatusMapper.delete(new QueryWrapper<PfRightsStatusEntity>().eq("apply_kdt_id", kdtId.toString()));
        //cd_redeem_code_apply_record
        cdRedeemCodeApplyRecordMapper.delete(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getApplyYcmId, kdtId));
        //td_activation_code_apply_record
        tdActivationCodeApplyRecordMapper.delete(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getApplyYcmId, kdtId));
        //procols
        protocolsMapper.delete(new QueryWrapper<OpenProtocolsEntity>().lambda().eq(OpenProtocolsEntity::getKdtId, kdtId));
        //pf_protection_period
        pfProtectionPeriodMapper.delete(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId, kdtId));

        //云服务费相关
        //pf_fee_resource_package表
        pfFeeResourcePackageMapper.delete(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdtId.toString()));
        //feeResourcePackageLogMapper
        feeResourcePackageLogMapper.delete(new QueryWrapper<FcFeeResourcePackageLogEntity>().lambda().eq(FcFeeResourcePackageLogEntity::getKdtId, kdtId));
        // pf_order_detail_advance_record
        pfOrderDetailAdvanceRecordMapper.delete(new QueryWrapper<PfOrderDetailAdvanceRecordEntity>().eq("apply_ycm_id", kdtId));
        //  pf_order_detail_debt_record
        pfOrderDetailDebtRecordMapper.delete(new QueryWrapper<PfOrderDetailDebtRecordEntity>().eq("apply_ycm_id", kdtId));
        //  pf_debt_repay_record
        pfDebtRepayRecordMapper.delete(new QueryWrapper<PfDebtRepayRecordEntity>().eq("apply_ycm_id", kdtId));
        //  fc_fee_yop_protocol
        feeYopProtocolMapper.delete(new QueryWrapper<FcFeeYopProtocolEntity>().eq("kdt_id", kdtId));
        //  fc_fee_resource_package表
        feeResourcePackageMapper.delete(new QueryWrapper<FcFeeResourcePackageEntity>().eq("kdt_id", kdtId.toString()));

        // 清理服务期缓存，有需要可以自己加
        clearCacheWithAppId(kdtId.toString(),"atom_spu_wsc");
        clearCacheWithAppId(kdtId.toString(),"atom_spu_retail_single");
        clearCacheWithAppId(kdtId.toString(),"atom_spu_software_2021030911105980");

        logger.info("测试数据清理完毕");
        PlainResult<Boolean> result = new PlainResult<>();
        return  result;
    }

    public void clearCacheWithAppId(String kdtId, String appId) {
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setKdtId(kdtId);
        flushAppStatusRequest.setAppId(appId);
        PlainResult<Boolean> result =
                pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        if (result.isSuccess() == true) {
            logger.info("缓存清理成功");
        } else {
            logger.error("缓存清理失败");
        }
    }
}

