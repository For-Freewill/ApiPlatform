package com.youzan.ycm.qa.enable.platform.biz.service.order;

import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ListWithTotal;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.CommonModel;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProduct;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductMainInfo;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.order.OrderProductSO;

import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-14 14:21
 **/
public interface OrderProductService {
    ListWithTotal<OrderProduct> getList(OrderProductSO orderProductSO);

    List<OrderProductMainInfo> searchYopApps(Integer appId, String appName, Integer itemId);

    OrderProduct getById(Long id);

    /**
     * 获取产品分类枚举
     */
    List<CommonModel> getAppTypeList();
}
