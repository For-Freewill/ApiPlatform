package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShopRoleStateHistDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShopRoleStateHistDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 店铺角色状态历史
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwShopRoleStateHistTransfer {

	public static FwShopRoleStateHistDTO toBO(FwShopRoleStateHistDO d) {

		if (d == null) {

			return null;
		}

		FwShopRoleStateHistDTO fwShopRoleStateHistBO = new FwShopRoleStateHistDTO();
		fwShopRoleStateHistBO.setId(d.getId());
		fwShopRoleStateHistBO.setShopRoleId(d.getShopRoleId());
		fwShopRoleStateHistBO.setKdtId(d.getKdtId());
		fwShopRoleStateHistBO.setRoleType(d.getRoleType());
		fwShopRoleStateHistBO.setFromState(d.getFromState());
		fwShopRoleStateHistBO.setToState(d.getToState());
		fwShopRoleStateHistBO.setSeq(d.getSeq());
		fwShopRoleStateHistBO.setCreatedAt(d.getCreatedAt());
		fwShopRoleStateHistBO.setUpdatedAt(d.getUpdatedAt());

		return fwShopRoleStateHistBO;
	}

	public static FwShopRoleStateHistDO toDO(FwShopRoleStateHistDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShopRoleStateHistDO fwShopRoleStateHistDO = new FwShopRoleStateHistDO();
		fwShopRoleStateHistDO.setId(bo.getId());
		fwShopRoleStateHistDO.setShopRoleId(bo.getShopRoleId());
		fwShopRoleStateHistDO.setKdtId(bo.getKdtId());
		fwShopRoleStateHistDO.setRoleType(bo.getRoleType());
		fwShopRoleStateHistDO.setFromState(bo.getFromState());
		fwShopRoleStateHistDO.setToState(bo.getToState());
		fwShopRoleStateHistDO.setSeq(bo.getSeq());
		fwShopRoleStateHistDO.setCreatedAt(bo.getCreatedAt());
		fwShopRoleStateHistDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShopRoleStateHistDO;
	}

	public static List<FwShopRoleStateHistDTO> toBOList(List<FwShopRoleStateHistDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShopRoleStateHistDTO>();
		}

		List<FwShopRoleStateHistDTO> boList = new ArrayList<FwShopRoleStateHistDTO>();
		for (FwShopRoleStateHistDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShopRoleStateHistDO> toDOList(List<FwShopRoleStateHistDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShopRoleStateHistDO>();
		}

		List<FwShopRoleStateHistDO> doList = new ArrayList<FwShopRoleStateHistDO>();

		for (FwShopRoleStateHistDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
