package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.goods;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.service.ycm.goods.GoodsToolsService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.Comparable;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.ComparableFactory;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.CompareResult;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.Difference;
import com.youzan.ycm.qa.enable.platform.biz.util.Compare.comparator.Comparator;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.goods.*;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.goods.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.util.*;

/**
 * @author wulei
 * @date 2021/9/29 17:42
 */

@Slf4j
@Service(value = "goodsToolsService")
public class GoodsToolsServiceImpl implements GoodsToolsService {
    @Resource
    private GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Resource
    private GdSkuMapper gdSkuMapper;
    @Resource
    private GdSpuMapper gdSpuMapper;
    @Resource
    private GdSkuSnapshotMapper gdSkuSnapshotMapper;
    @Resource
    private GdSpuSnapshotMapper gdSpuSnapshotMapper;

    @Override
    public PlainResult<Map<String, Map>> queryAtomPlugin(Integer atom_plugin_app_id_qa) {
        PlainResult<Map<String, Map>> result = new PlainResult<>();
        Map<String, Map> response = new HashMap<>();
        //app_id check
        checkAppId(atom_plugin_app_id_qa);
        //查询SPU
        response.put(atom_plugin_app_id_qa.toString() + "_SPU", dbSPUResult(atom_plugin_app_id_qa));
        //查询SKU
        response.put(atom_plugin_app_id_qa.toString() + "_SKU", dbSKUResult(atom_plugin_app_id_qa));
        //组装结果
        result.setData(response);

        return result;
    }

    @Override
    public PlainResult<List<Difference>> compareSpuResult(Integer atom_plugin_app_id_qa, Integer atom_plugin_app_id_sc) {
        PlainResult<List<Difference>> result = new PlainResult<>();
        Comparable comparable = ComparableFactory.instance().create(Comparator.CompareMode.IGNORE_DATES);//忽略时间
        CompareResult compareResult = comparable.compare(dbSPUResult(atom_plugin_app_id_qa), dbSPUResult(atom_plugin_app_id_sc));

        log.info("+++++++++++++" + JSON.toJSONString(compareResult));
        result.setData(compareResult.getDifferences());
        return result;
    }

    @Override
    public PlainResult<List<Difference>> compareSkuResult(Integer atom_plugin_app_id_qa, Integer atom_plugin_app_id_sc) {
        PlainResult<List<Difference>> result = new PlainResult<>();
        Comparable comparable = ComparableFactory.instance().create(Comparator.CompareMode.IGNORE_DATES);//忽略时间
        CompareResult compareResult = comparable.compare(dbSKUResult(atom_plugin_app_id_qa), dbSKUResult(atom_plugin_app_id_sc));

        log.info("+++++++++++++" + JSON.toJSONString(compareResult));
        result.setData(compareResult.getDifferences());
        return result;
    }


//    public PlainResult<Map<String, Map>> atomPluginCompare1(Integer atom_plugin_app_id_qa, Integer atom_plugin_app_id_sc) {
//        PlainResult<Map<String, Map>> result = new PlainResult<>();
//        Map<String, Map> response = new HashMap<>();
//        //app_id check
//        checkAppId(atom_plugin_app_id_qa,atom_plugin_app_id_sc);
//
//        //查询
//        response.put(atom_plugin_app_id_qa.toString(),dbSPUResult(atom_plugin_app_id_qa));
//        response.put(atom_plugin_app_id_sc.toString(),dbSPUResult(atom_plugin_app_id_sc));
//
//        dbSKUResult(atom_plugin_app_id_qa);
//        dbSKUResult(atom_plugin_app_id_sc);
//
//        result.setData(response);
//        //对比信息
//        //组装结果
//        return result;
//    }

    // 判断输入的原子插件app_id是否正确
    private void checkAppId(Integer qa_id) {
        AssertUtil.isAllNotNone(qa_id, "qa_id不能为空");
        AssertUtil.isTrue(qa_id > 0, " 输入的qa_id不是合法商品ID");

        List<GdGoodsIdMappingEntity> qa_gdGoodsIdMappingEntityList = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMappingEntity>().lambda().eq(GdGoodsIdMappingEntity::getYopId, qa_id));

        // 如果id_mapping表的大小不是1，代表可能不是原子插件
        AssertUtil.isTrue(qa_gdGoodsIdMappingEntityList.size() == 1, " 输入的qa_id不是原子插件商品ID");
    }

//    // 判断输入的原子插件app_id是否正确
//    private void checkAppId(Integer qa_id,Integer sc_id){
//        AssertUtil.isAllNotNone(qa_id, "qa_id不能为空");
//        AssertUtil.isTrue(qa_id>0," 输入的qa_id不是合法商品ID");
//        AssertUtil.isTrue(sc_id>0," 输入的sc_id不是合法商品ID");
//
//        List<GdGoodsIdMappingEntity> qa_gdGoodsIdMappingEntityList = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMappingEntity>().lambda().eq(GdGoodsIdMappingEntity::getYopId,qa_id));
//        List<GdGoodsIdMappingEntity> sc_gdGoodsIdMappingEntityList = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMappingEntity>().lambda().eq(GdGoodsIdMappingEntity::getYopId,sc_id));
//        // 如果id_mapping表的大小不一致，代表不是同一类型的商品
//        AssertUtil.isTrue(qa_gdGoodsIdMappingEntityList.size()==sc_gdGoodsIdMappingEntityList.size(),"输入的商品ID类型不一致");
//        // 如果id_mapping表的大小不是1，代表可能不是原子插件
//        AssertUtil.isTrue(qa_gdGoodsIdMappingEntityList.size()==1," 输入的qa_id不是原子插件商品ID");
//        AssertUtil.isTrue(sc_gdGoodsIdMappingEntityList.size()==1," 输入的sc_id不是原子插件商品ID");
//    }

    // 查询商品信息：SPU
    public Map<String, List<Object>> dbSPUResult(Integer app_id) {
        Map<String, List<Object>> result = new LinkedHashMap<>();
        List<GdSpuEntity> gdSpuEntityList = gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id));
        AssertUtil.isTrue(gdSpuEntityList.size() == 1, " gd_spu表错误");
        //gd_spu.snapshot_no
        Long snapshotNo = gdSpuEntityList.get(0).getSnapshotNo();
        log.info("app_id=" + app_id + ",gd_spu.snapshot_no=" + snapshotNo);
        // 返回值：gd_spu，gd_spu_snapshot
        GdSpuEntity gdSpuEntity = gdSpuEntityList.get(0);
        GdSpuSnapshotEntity gdSpuSnapshotEntity = gdSpuSnapshotMapper.selectOne(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id).eq(GdSpuSnapshotEntity::getSnapshotNo, snapshotNo));

        result.put("gdSpuEntity", JSON.parseObject(JSON.toJSONString(gdSpuEntity), (Type) GdSpuEntity.class));
        result.put("gdSpuSnapshotEntity", JSON.parseObject(JSON.toJSONString(gdSpuSnapshotEntity), (Type) GdSpuSnapshotEntity.class));

        return result;
    }

    // 查询商品信息：SKU
    private Map<String, List<Object>> dbSKUResult(Integer app_id) {
        Map<String, List<Object>> result = new LinkedHashMap<>();
        Map<String, Long> sku_snapshot_no = new LinkedHashMap<>();

        List<GdSkuEntity> gdSkuEntityList = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
        List<GdSkuSnapshotEntity> gdSkuSnapshotEntityList = new ArrayList<>();

        for (GdSkuEntity gdSkuEntity : gdSkuEntityList) {
            sku_snapshot_no.put(gdSkuEntity.getSkuId(), gdSkuEntity.getSnapshotNo());
            gdSkuSnapshotEntityList.add(gdSkuSnapshotMapper.selectOne(new QueryWrapper<GdSkuSnapshotEntity>().lambda().
                    eq(GdSkuSnapshotEntity::getAppId, app_id).eq(GdSkuSnapshotEntity::getSkuId, gdSkuEntity.getSkuId()).eq(GdSkuSnapshotEntity::getSnapshotNo, gdSkuEntity.getSnapshotNo())));
        }

        log.info("sku_snapshot=" + sku_snapshot_no);

        result.put("gdSkuEntity", Collections.singletonList(gdSkuEntityList));
        result.put("gdSkuSnapshotEntity", Collections.singletonList(gdSkuSnapshotEntityList));
        return result;
    }
}
