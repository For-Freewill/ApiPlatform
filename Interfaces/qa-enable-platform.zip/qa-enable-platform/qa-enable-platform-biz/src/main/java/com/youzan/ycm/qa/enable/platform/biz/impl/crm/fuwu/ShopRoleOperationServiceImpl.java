package com.youzan.ycm.qa.enable.platform.biz.impl.crm.fuwu;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.enable.common.model.entity.UserIdentifier;
import com.youzan.enable.common.model.enums.organization.OrgTypeEnum;
import com.youzan.enable.crm.fuwu.role.api.req.BindPoolReq;
import com.youzan.enable.crm.fuwu.role.api.service.ShopRoleRemoteService;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.exception.EnableException;
import com.youzan.ycm.qa.enable.platform.api.request.crm.fuwu.ShopRoleAssignDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.fuwu.ShopRoleOperationService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShoprolePool;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.fuwu.FwShoprolePoolMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author hezhulin
 * @date 2021-05-18 15:24
 */
@Slf4j
@Service(value = "shopRoleOperationService")
public class ShopRoleOperationServiceImpl implements ShopRoleOperationService {
    @Resource
    protected ShopRoleRemoteService shopRoleRemoteService;

    @Resource
    protected FwShoprolePoolMapper fwShoprolePoolMapper;

    @Override
    public PlainResult<Boolean> assignShopRole(ShopRoleAssignDTO shopRoleAssignDTO) {

        AssertUtil.isAllNotNone(shopRoleAssignDTO.getKdtId(),"kdtId 不能为空！");
        AssertUtil.isAllNotNone(shopRoleAssignDTO.getShopRole(),"shopRole 不能为空！");
        AssertUtil.isAllNotNone(shopRoleAssignDTO.getSrcPoolType(),"srcPoolType 不能为空！");

        if (shopRoleAssignDTO.getSrcPoolType().equals("TERRITORY"))
            AssertUtil.isAllNotNone(shopRoleAssignDTO.getPoolName(),"目标角色池类型=公海时 poolName 不能为空！");
        if (shopRoleAssignDTO.getSrcPoolType().equals("PROVIDER"))
            AssertUtil.isAllNotNone(shopRoleAssignDTO.getProviderId(),"目标角色池类型=渠道商时 providerId 不能为空！");
        if (shopRoleAssignDTO.getSrcPoolType().equals("USER"))
            AssertUtil.isAllNotNone(shopRoleAssignDTO.getUserId(),"目标角色池类型=员工时 userId 不能为空！");

        FwShoprolePool fwShoprolePool = new FwShoprolePool();
        if (shopRoleAssignDTO.getSrcPoolType().equals("TERRITORY")){
            Wrapper<FwShoprolePool> queryWrapper = new QueryWrapper<FwShoprolePool>().lambda().eq(FwShoprolePool::getType,shopRoleAssignDTO.getSrcPoolType()).
                    eq(FwShoprolePool::getName,shopRoleAssignDTO.getPoolName());
            fwShoprolePool=fwShoprolePoolMapper.selectOne(queryWrapper);
        }
        if (shopRoleAssignDTO.getSrcPoolType().equals("PROVIDER")){
            Wrapper<FwShoprolePool> queryWrapper = new QueryWrapper<FwShoprolePool>().lambda().eq(FwShoprolePool::getType,shopRoleAssignDTO.getSrcPoolType()).
                    eq(FwShoprolePool::getProviderId,shopRoleAssignDTO.getProviderId());
            fwShoprolePool=fwShoprolePoolMapper.selectOne(queryWrapper);
        }
        if (shopRoleAssignDTO.getSrcPoolType().equals("USER")){
            Wrapper<FwShoprolePool> queryWrapper = new QueryWrapper<FwShoprolePool>().lambda().eq(FwShoprolePool::getType,shopRoleAssignDTO.getSrcPoolType()).
                    eq(FwShoprolePool::getUserId,shopRoleAssignDTO.getUserId());
            fwShoprolePool=fwShoprolePoolMapper.selectOne(queryWrapper);
        }

        if (null == fwShoprolePool){
            log.info("绑定目标不存在角色池");
            throw new EnableException(ResultCode.SHOPROLEPOOL_NOEXIST.getCode(), ResultCode.SHOPROLEPOOL_NOEXIST.getMsg());
        }

        BindPoolReq bindPoolReq = new BindPoolReq();
        bindPoolReq.setKdtId(shopRoleAssignDTO.getKdtId());
        bindPoolReq.setRoleType(shopRoleAssignDTO.getShopRole());
        bindPoolReq.setPoolId(fwShoprolePool.getId());
        bindPoolReq.setReason("商赋测试平台手动分配");
        bindPoolReq.setComment("");
        bindPoolReq.setOperator(new UserIdentifier(OrgTypeEnum.QIMA,2316L));

        PlainResult<Boolean> bindPoolResult = shopRoleRemoteService.bindPool(bindPoolReq);

        PlainResult<Boolean> result = new PlainResult<>();
        if (null == bindPoolResult.getData()){
            log.info("调用底层店铺角色绑定接口绑定失败:" + bindPoolResult.getMessage());
            throw new EnableException(ResultCode.SHOPROLEASSIGN_ERROR.getCode(), bindPoolResult.getMessage());
        }
        if (null != bindPoolResult.getData() && !bindPoolResult.getData()){
            log.info("调用底层店铺角色绑定接口绑定失败:" + bindPoolResult.getMessage());
            throw new EnableException(ResultCode.SHOPROLEASSIGN_ERROR.getCode(), ResultCode.SHOPROLEASSIGN_ERROR.getMsg());
        }
        if (null != bindPoolResult.getData() && bindPoolResult.getData()){
            log.info("调用底层店铺角色绑定接口绑定成功");
            result.setData(bindPoolResult.getData());
        }

        return result;

    }
}
