package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CiJenkinsJobEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * jenkins执行表
 *
 * @author hujiping
 * @email hujiping@youzan.com
 * @date 2021-08-23 11:52:02
 */
public class CiJenkinsJobTransfer {

    public static CiJenkinsJobBO toBO(CiJenkinsJobEntity d) {

        if (d == null) {

            return null;
        }

        CiJenkinsJobBO ciJenkinsJobBO = new CiJenkinsJobBO();
        ciJenkinsJobBO.setId(d.getId());
        ciJenkinsJobBO.setJobName(d.getJobName());
        ciJenkinsJobBO.setJobState(d.getJobState());
        ciJenkinsJobBO.setJobType(d.getJobType());
        ciJenkinsJobBO.setReferJobId(d.getReferJobId());
        ciJenkinsJobBO.setJobEnv(d.getJobEnv());
        ciJenkinsJobBO.setReportUrl(d.getReportUrl());
        ciJenkinsJobBO.setJobGroup(d.getJobGroup());
        ciJenkinsJobBO.setJobCost(d.getJobCost());
        ciJenkinsJobBO.setTotalCase(d.getTotalCase());
        ciJenkinsJobBO.setFailureTotalCase(d.getFailureTotalCase());
        ciJenkinsJobBO.setSkipTotalCase(d.getSkipTotalCase());
        ciJenkinsJobBO.setSuccessTotalCase(d.getSuccessTotalCase());
        ciJenkinsJobBO.setCreatedAt(d.getCreatedAt());
        ciJenkinsJobBO.setUpdatedAt(d.getUpdatedAt());

        return ciJenkinsJobBO;
    }

    public static CiJenkinsJobEntity toDO(CiJenkinsJobBO bo) {

        if (bo == null) {

            return null;
        }

        CiJenkinsJobEntity ciJenkinsJobDO = new CiJenkinsJobEntity();
        ciJenkinsJobDO.setId(bo.getId());
        ciJenkinsJobDO.setJobName(bo.getJobName());
        ciJenkinsJobDO.setJobState(bo.getJobState());
        ciJenkinsJobDO.setJobType(bo.getJobType());
        ciJenkinsJobDO.setReferJobId(bo.getReferJobId());
        ciJenkinsJobDO.setJobEnv(bo.getJobEnv());
        ciJenkinsJobDO.setReportUrl(bo.getReportUrl());
        ciJenkinsJobDO.setJobGroup(bo.getJobGroup());
        ciJenkinsJobDO.setJobCost(bo.getJobCost());
        ciJenkinsJobDO.setTotalCase(bo.getTotalCase());
        ciJenkinsJobDO.setFailureTotalCase(bo.getFailureTotalCase());
        ciJenkinsJobDO.setSkipTotalCase(bo.getSkipTotalCase());
        ciJenkinsJobDO.setSuccessTotalCase(bo.getSuccessTotalCase());
        ciJenkinsJobDO.setCreatedAt(bo.getCreatedAt());
        ciJenkinsJobDO.setUpdatedAt(bo.getUpdatedAt());
        return ciJenkinsJobDO;
    }

    public static List<CiJenkinsJobBO> toBOList(List<CiJenkinsJobEntity> doList) {

        if (doList == null) {

            return new ArrayList<CiJenkinsJobBO>();
        }

        List<CiJenkinsJobBO> boList = new ArrayList<CiJenkinsJobBO>();
        for (CiJenkinsJobEntity d : doList) {

            if (d != null) {

                boList.add(toBO(d));
            }
        }
        return boList;
    }

    public static List<CiJenkinsJobEntity> toDOList(List<CiJenkinsJobBO> boList) {

        if (boList == null) {

            return new ArrayList<CiJenkinsJobEntity>();
        }

        List<CiJenkinsJobEntity> doList = new ArrayList<CiJenkinsJobEntity>();

        for (CiJenkinsJobBO bo : boList) {

            if (bo != null) {

                doList.add(toDO(bo));
            }
        }

        return doList;
    }

}

