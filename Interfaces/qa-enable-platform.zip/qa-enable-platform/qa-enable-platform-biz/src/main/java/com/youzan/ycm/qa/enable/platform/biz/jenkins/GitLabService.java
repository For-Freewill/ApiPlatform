package com.youzan.ycm.qa.enable.platform.biz.jenkins;

import org.apache.commons.lang3.StringUtils;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.RepositoryFileApi;
import org.gitlab4j.api.models.RepositoryFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Author qibu
 * @create 2021/9/3 2:29 PM
 */
@Service
public class GitLabService {

    @Autowired
    private GitLabApi gitLabApi;

    /**
     * 通过通过类名与产品线获取java文件author
     *
     * @param className
     * @param line
     * @return author
     */
    public String getAuthorByClassAndLine(String className, String line) {
        String content = getContentByClassAndLine(className, line);
        if (StringUtils.isNotEmpty(content)) {
            Pattern bugNumber = Pattern.compile("created by.*on", Pattern.CASE_INSENSITIVE);
            Matcher matcher = bugNumber.matcher(content);
            if (matcher.find()) {
                String auth = matcher.group(0);
                auth = auth.toLowerCase();
                return auth.substring(auth.indexOf("created by") + 10, auth.indexOf("on")).trim();
            }
            bugNumber = Pattern.compile("created by.*.", Pattern.CASE_INSENSITIVE);
            matcher = bugNumber.matcher(content);
            if (matcher.find()) {
                String auth = matcher.group(0);
                auth = auth.toLowerCase();
                return auth.substring(auth.indexOf("created by") + 10, auth.indexOf(".")).trim();
            }
            bugNumber = Pattern.compile("create by.*on", Pattern.CASE_INSENSITIVE);
            matcher = bugNumber.matcher(content);
            if (matcher.find()) {
                String auth = matcher.group(0);
                auth = auth.toLowerCase();
                return auth.substring(auth.indexOf("create by") + 9, auth.indexOf("on")).trim();
            }
            bugNumber = Pattern.compile("@auth.*", Pattern.CASE_INSENSITIVE);
            matcher = bugNumber.matcher(content);
            if (matcher.find()) {
                String auth = matcher.group(0);
                if (auth.lastIndexOf(" ") > 0) {
                    auth = auth.substring(auth.lastIndexOf(" ")).trim();
                    if(auth.endsWith("."))
                        return auth.substring(0,auth.length()-1);
                    return auth;
                }
                if (auth.lastIndexOf(":") > 0) {
                    return auth.substring(auth.lastIndexOf(":")+1).trim();
                }
            }
        }
        return "";
    }

    /**
     * 通过类名与产品线获取java文件内容
     *
     * @param className
     * @param line
     * @return content
     */
    public String getContentByClassAndLine(String className, String line) {
        if (StringUtils.isNotEmpty(className) && StringUtils.isNotEmpty(line)) {
            JenkinJobEnum jenkinJobEnum = JenkinJobEnum.findByLine(line);
            if (jenkinJobEnum != null) {
                className = className.replaceAll("\\.", "/");
                String filePath = String.format("src/test/java/%s.java", className);
                try {
                    return gitLabApi.getRepositoryFileApi().getFile(jenkinJobEnum.getProjectId(), filePath, "master")
                            .getDecodedContentAsString();
                } catch (GitLabApiException e) {
                    e.printStackTrace();
                }
            }
        }
        return "";
    }


}
