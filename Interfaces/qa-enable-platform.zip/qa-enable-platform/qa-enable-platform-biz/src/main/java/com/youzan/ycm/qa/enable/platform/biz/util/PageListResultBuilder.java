package com.youzan.ycm.qa.enable.platform.biz.util;

import java.util.List;

public class PageListResultBuilder<T> {

    /**
     * 数据列表
     */
    private List<T> list;

    /**
     * 页码
     */
    private Integer pageNum;

    /**
     * 分页大小
     */
    private Integer pageSize;

    /**
     * 记录总数
     */
    private Integer total;

    public PageListResultBuilder setList(List<T> list) {
        this.list = list;
        return this;
    }

    public PageListResultBuilder setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
        return this;
    }

    public PageListResultBuilder setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    public PageListResultBuilder setTotal(Integer total) {
        this.total = total;
        return this;
    }

    public PageListResultBuilder setPageInfo(PageInfo pageInfo) {
        this.pageNum = pageInfo.getPageNum();
        this.pageSize = pageInfo.getPageSize();
        return this;
    }

    protected List<T> getList() {
        return list;
    }

    protected Integer getPageNum() {
        return pageNum;
    }

    protected Integer getPageSize() {
        return pageSize;
    }

    protected Integer getTotal() {
        return total;
    }

    public PageListResult<T> create() {
        return new PageListResult<>(this);
    }

}
