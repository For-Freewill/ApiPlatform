package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.perform;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.platform.service_chain.Constants;
import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.perform.MovePfOrderStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.perform.PfOrderStatusService;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.goods.GdGoodsIdMappingEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.ycm.perform.PfOrderStatusEntity;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.goods.GdGoodsIdMappingMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.ycm.perform.PfOrderStatusMapper;
import com.youzan.yop.api.MarketRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.regex.Pattern;

/**
 * @author wuwu
 * @date 2021/12/6 7:26 PM
 */
@Slf4j
@Service("pfOrderStatusService")
public class PfOrderStatusServiceImpl implements PfOrderStatusService {
    public static final Pattern patternAtom = Pattern.compile("^atom");
    //public static final Pattern patternCombine = Pattern.compile("^combine");

    @Resource
    private GdGoodsIdMappingMapper gdGoodsIdMappingMapper;

    @Resource
    private PfOrderStatusMapper pfOrderStatusMapper;

    @Resource
    private PfAppStatusRemoteService pfAppStatusRemoteService;

    @Resource
    private MarketRemoteService marketRemoteService;



    @Override
    public PlainResult<Boolean> movePfOrderStatus(MovePfOrderStatusRequest request) {
        PlainResult<Boolean> result = new PlainResult<>();

        String ycmAppId = getYcmAppId(request.getAppId());
        Calendar calendar = Calendar.getInstance();//日历对象
        // 按服务期生效顺序获取服务期，包括已经过期的
        List<PfOrderStatusEntity> orderStatusList = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatusEntity>().lambda()
                .eq(PfOrderStatusEntity::getApplyKdtId, request.getKdtId())
                .eq(PfOrderStatusEntity::getAppId, ycmAppId)
                .eq(PfOrderStatusEntity::getApplyYcmType, "KDT_ID")
                .eq(PfOrderStatusEntity::getState, "valid")
                .orderByAsc(PfOrderStatusEntity::getEffectTime));

        if(orderStatusList.size() == 0) {
            result.setMessage(ResultCode.NO_PERFORM_ORDER.getMsg());
            result.setCode(ResultCode.NO_PERFORM_ORDER.getCode());
            return result;
        }

        //处理服务期平移
        List<PfOrderStatusEntity> waitUpdateList = new ArrayList<>();
        /**
         * 设置生效及失效时间：
         * 计算出request里的过期时间和当前服务期里最大过期时间之间相差的秒数
         * 移动时间按秒来移
         */

        //计算服务期最大过期时间
        Date expireTime = orderStatusList.get(orderStatusList.size()-1).getExpireTime();

        Long second = (request.getExpireTime().getTime() - expireTime.getTime())/1000;

        for (PfOrderStatusEntity pfOrderStatus : orderStatusList) {
            calendar.setTime(pfOrderStatus.getEffectTime());//设置生效日期
            calendar.add(Calendar.SECOND, second.intValue());
            Date orderStatusNewEffectTime = calendar.getTime();

            calendar.setTime(pfOrderStatus.getExpireTime());//设置失效效日期
            calendar.add(Calendar.SECOND, second.intValue());
            Date orderStatusNewExpireTime = calendar.getTime();
            pfOrderStatus.setEffectTime(orderStatusNewEffectTime);
            pfOrderStatus.setExpireTime(orderStatusNewExpireTime);
            waitUpdateList.add(pfOrderStatus);
        }

        for (PfOrderStatusEntity pfOrderStatus : waitUpdateList) {
            try {
                pfOrderStatusMapper.updateById(pfOrderStatus);
            }catch (Exception e) {
                result.setMessage(ResultCode.MOVER_ERROR.getMsg()+e.getMessage());
                result.setCode(ResultCode.MOVER_ERROR.getCode());
                return result;
            }
        }

        //刷新缓存,同步服务期
        setServiceChain(request.getServiceChain());//设置sc
        try {
            FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
            flushAppStatusRequest.setAppId(ycmAppId);
            flushAppStatusRequest.setKdtId(String.valueOf(request.getKdtId()));
            pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
            marketRemoteService.concurrentStatus(request.getKdtId(), request.getAppId().intValue());
        }catch (Exception e) {
            result.setMessage(ResultCode.CONCURRENT_ERROR.getMsg() + e.getMessage());
            result.setCode(ResultCode.CONCURRENT_ERROR.getCode());
        }

        return result;
    }

    /**
     * 根据yop的appid获得ycm的appid
     *
     * @param appId
     * @return
     */
    public String getYcmAppId(Long appId) {
        String ycmAppid = "";
        List<GdGoodsIdMappingEntity> gdGoodsIds = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMappingEntity>().eq("yop_id", appId));
        for (GdGoodsIdMappingEntity gdGoodsId : gdGoodsIds) {
            if (patternAtom.matcher(gdGoodsId.getYcmId()).find()) {
                ycmAppid = gdGoodsId.getYcmId();
                return ycmAppid;
            }
        }
        return ycmAppid;
    }

    private void setServiceChain(String sc) {
        Map serviceChain = new HashMap<String, Object>();
        serviceChain.put(Constants.SERVICE_CHAIN_NAME, sc);
        ServiceChainContext.setInvocationServiceChainContext(serviceChain);
    }

}
