package com.youzan.ycm.qa.enable.platform.biz.impl.crm.kefu;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.base.Preconditions;
import com.youzan.api.common.response.PlainResult;
import com.youzan.nsq.client.exception.NSQException;
import com.youzan.ycm.qa.enable.platform.api.enums.ResultCode;
import com.youzan.ycm.qa.enable.platform.api.request.crm.kefu.TransferRecordRequest;
import com.youzan.ycm.qa.enable.platform.api.service.crm.kefu.TransferRecordService;
import com.youzan.ycm.qa.enable.platform.biz.util.NSQUtil;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.kefu.Servant;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.kefu.ServantMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.kefu.ServiceRecordMapper;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.kefu.ServiceRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.testng.Assert;

import javax.annotation.Resource;
import java.util.List;


/**
 * @program: qa-enable-platform
 * @description
 * @author: hf
 * @Param:$
 * @create: 2021-12-09 21:11
 */
@Slf4j
@Service(value = "transferRecordService")
public class TransferRecordServiceImpl implements TransferRecordService {
    protected NSQUtil nsqUtil = new NSQUtil();

    @Resource
    public ServiceRecordMapper serviceRecordMapper;

    @Resource
    public ServantMapper servantMapper;

    @Override
    public PlainResult<Boolean> transferRecordToServant(TransferRecordRequest transferRecordRequest) {
        PlainResult<Boolean> plainResult = new PlainResult<>();
        String fromServantInfo = transferRecordRequest.getFromServantName();
        String toServantInfo = transferRecordRequest.getToServantName();
        //将客服的名称转成客服坐席ID
        Wrapper<Servant> fWrapper = new LambdaQueryWrapper<Servant>()
                .eq(Servant::getName, fromServantInfo).eq(Servant::getIsDeleted, 0);
        Boolean plainBoolResult = false;
        List<Servant> fromServants = servantMapper.selectList(fWrapper);
        if(fromServants.size() > 1){
            plainResult.setMessage("客服名字不能唯一定位一个人，请换一个试试");
            plainResult.setSuccess(false);
            plainResult.setCode(-1);
            plainResult.setData(plainBoolResult);
            return plainResult;
        }
        if(fromServants.size() == 0){
            plainResult.setMessage("客服不存在");
            plainResult.setSuccess(false);
            plainResult.setCode(-1);
            plainResult.setData(plainBoolResult);
            return plainResult;
        }
        Long FromServantId = fromServants.get(0).getId();
        //转接到的客服名称
        Wrapper<Servant> toWrapper = new LambdaQueryWrapper<Servant>()
                .eq(Servant::getName, toServantInfo).eq(Servant::getIsDeleted, 0);
        List<Servant> toServants = servantMapper.selectList(toWrapper);

        if(toServants.size() > 1){
            plainResult.setMessage("客服名字不能唯一定位一个人，请换一个试试");
            plainResult.setSuccess(false);
            plainResult.setCode(-1);
            plainResult.setData(plainBoolResult);
            return plainResult;
        }
        if(toServants.size() == 0){
            plainResult.setMessage("客服不存在");
            plainResult.setSuccess(false);
            plainResult.setCode(-1);
            plainResult.setData(plainBoolResult);
            return plainResult;
        }
        Long ToServantId = toServants.get(0).getId();

        Long customerId = transferRecordRequest.getCustomerId();
        Preconditions.checkArgument(StringUtils.isNotBlank(transferRecordRequest.getCustomerId().toString()) && StringUtils.isNotBlank(FromServantId.toString()) && StringUtils.isNotBlank(FromServantId.toString()),
                ResultCode.BAD_REQUEST.getMessage());
        String message = "{\"from\":\"servant_" + FromServantId + "\",\"to\":\"customer\",\"toRouterId\":0,\"msgType\":\"text\",\"content\":\"[\\\"reception.transfer\\\",{\\\"req_id\\\":\\\"socket_3\\\",\\\"data\\\":{\\\"to_servant_id\\\":" + ToServantId + ",\\\"customer_id\\\":\\\"" + customerId + "\\\"},\\\"sc_tag\\\":\\\"\\\"}]\",\"msgId\":1725219122,\"appKey\":\"a6e80c416df43dea3a\",\"createTime\":1637637104225}";
        try {
            nsqUtil.pubMessage("mercury_forward_inner", message, false);
        } catch (NSQException e) {
            e.printStackTrace();
        }

        //检查服务记录里的客服变为转接人，即可返回成功
        Wrapper<ServiceRecord> tWrapper = new LambdaQueryWrapper<ServiceRecord>()
                .eq(ServiceRecord::getCustomerId, customerId).eq(ServiceRecord::getStatus, 0).eq(ServiceRecord::getServantId, ToServantId)
                .last("order by id desc limit 1");
        for (int i = 0; i < 2; i++) {
            ServiceRecord serviceRecord = serviceRecordMapper.selectOne(tWrapper);
            log.info("serviceRecord内容为：" + JSON.toJSONString(serviceRecord) + "=======");

            if (serviceRecord == null) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                plainBoolResult = false;
                plainResult.setData(plainBoolResult);
                plainResult.setCode(-1);
                plainResult.setMessage("转接失败，请检查入参");
                plainResult.setSuccess(false);
            } else {
                plainBoolResult = true;
                plainResult.setData(plainBoolResult);
                plainResult.setCode(200);
                plainResult.setMessage("转接成功");
                plainResult.setSuccess(true);
                break;
            }
        }

        return plainResult;
    }
}
