package com.youzan.ycm.qa.enable.platform.biz.service.order;

import com.youzan.enable.crm.meta.api.dto.product.ProductTypeDTO;

import java.util.List;

public interface ProductTypeDependService {

    /**
     * 根据产品类型id获取产品类型
     *
     * @param productTypeId
     * @return 产品类型信息
     */
    ProductTypeDTO getById(Long productTypeId);

    /**
     * 根据产品类型别名获取产品类型
     *
     * @param productTypeAlias 产品类型别名
     * @return 产品类型信息
     */
    ProductTypeDTO getByAlias(String productTypeAlias);

    /**
     * 根据产品线ID获取产品类型列表
     *
     * @param productLineId 产品线ID
     * @return 产品类型信息
     */
    List<ProductTypeDTO> getByProductLineId(Integer productLineId);

    /**
     * 获取所有产品类型
     * @return 产品类型列表
     */
    List<ProductTypeDTO> getAllProductType();

    /**
     * 获取所有意向产品的产品类型（即过滤没有产品线的产品类型）
     * @return 产品类型列表
     */
    List<ProductTypeDTO> getAllIntentionalProductType();
}
