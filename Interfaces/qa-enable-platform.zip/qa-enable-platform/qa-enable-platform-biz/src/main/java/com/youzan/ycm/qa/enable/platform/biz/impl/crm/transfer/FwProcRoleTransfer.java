package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwProcRoleDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwProcRoleDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 流程角色
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:50
 */
public class FwProcRoleTransfer {

	public static FwProcRoleDTO toBO(FwProcRoleDO d) {

		if (d == null) {

			return null;
		}

		FwProcRoleDTO fwProcRoleBO = new FwProcRoleDTO();
		fwProcRoleBO.setId(d.getId());
		fwProcRoleBO.setProcInstId(d.getProcInstId());
		fwProcRoleBO.setKdtId(d.getKdtId());
		fwProcRoleBO.setProcTemplate(d.getProcTemplate());
		fwProcRoleBO.setRoleType(d.getRoleType());
		fwProcRoleBO.setStartTime(d.getStartTime());
		fwProcRoleBO.setStartVariable(d.getStartVariable());
		fwProcRoleBO.setCreatedAt(d.getCreatedAt());
		fwProcRoleBO.setUpdatedAt(d.getUpdatedAt());

		return fwProcRoleBO;
	}

	public static FwProcRoleDO toDO(FwProcRoleDTO bo) {

        if (bo == null) {

			return null;
		}

		FwProcRoleDO fwProcRoleDO = new FwProcRoleDO();
		fwProcRoleDO.setId(bo.getId());
		fwProcRoleDO.setProcInstId(bo.getProcInstId());
		fwProcRoleDO.setKdtId(bo.getKdtId());
		fwProcRoleDO.setProcTemplate(bo.getProcTemplate());
		fwProcRoleDO.setRoleType(bo.getRoleType());
		fwProcRoleDO.setStartTime(bo.getStartTime());
		fwProcRoleDO.setStartVariable(bo.getStartVariable());
		fwProcRoleDO.setCreatedAt(bo.getCreatedAt());
		fwProcRoleDO.setUpdatedAt(bo.getUpdatedAt());

		return fwProcRoleDO;
	}

	public static List<FwProcRoleDTO> toBOList(List<FwProcRoleDO> doList) {

		if (doList == null) {

			return new ArrayList<FwProcRoleDTO>();
		}

		List<FwProcRoleDTO> boList = new ArrayList<FwProcRoleDTO>();
		for (FwProcRoleDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwProcRoleDO> toDOList(List<FwProcRoleDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwProcRoleDO>();
		}

		List<FwProcRoleDO> doList = new ArrayList<FwProcRoleDO>();

		for (FwProcRoleDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
