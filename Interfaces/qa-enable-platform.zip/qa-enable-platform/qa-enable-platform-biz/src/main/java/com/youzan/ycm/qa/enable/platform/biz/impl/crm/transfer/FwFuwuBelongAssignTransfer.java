package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwFuwuBelongAssignDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwFuwuBelongAssignDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 服务归属划拨
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:29:17
 */
public class FwFuwuBelongAssignTransfer {

	public static FwFuwuBelongAssignDTO toBO(FwFuwuBelongAssignDO d) {

		if (d == null) {

			return null;
		}

		FwFuwuBelongAssignDTO fwFuwuBelongAssignBO = new FwFuwuBelongAssignDTO();
		fwFuwuBelongAssignBO.setId(d.getId());
		fwFuwuBelongAssignBO.setKdtId(d.getKdtId());
		fwFuwuBelongAssignBO.setOrderId(d.getOrderId());
		fwFuwuBelongAssignBO.setAssignedFuwuBelongTeam(d.getAssignedFuwuBelongTeam());
		fwFuwuBelongAssignBO.setAssignedFuwuBelongId(d.getAssignedFuwuBelongId());
		fwFuwuBelongAssignBO.setAssignedTime(d.getAssignedTime());
		fwFuwuBelongAssignBO.setOperatorId(d.getOperatorId());
		fwFuwuBelongAssignBO.setOperatorType(d.getOperatorType());
		fwFuwuBelongAssignBO.setCreatedAt(d.getCreatedAt());
		fwFuwuBelongAssignBO.setUpdatedAt(d.getUpdatedAt());

		return fwFuwuBelongAssignBO;
	}

	public static FwFuwuBelongAssignDO toDO(FwFuwuBelongAssignDTO bo) {

        if (bo == null) {

			return null;
		}

		FwFuwuBelongAssignDO fwFuwuBelongAssignDO = new FwFuwuBelongAssignDO();
		fwFuwuBelongAssignDO.setId(bo.getId());
		fwFuwuBelongAssignDO.setKdtId(bo.getKdtId());
		fwFuwuBelongAssignDO.setOrderId(bo.getOrderId());
		fwFuwuBelongAssignDO.setAssignedFuwuBelongTeam(bo.getAssignedFuwuBelongTeam());
		fwFuwuBelongAssignDO.setAssignedFuwuBelongId(bo.getAssignedFuwuBelongId());
		fwFuwuBelongAssignDO.setAssignedTime(bo.getAssignedTime());
		fwFuwuBelongAssignDO.setOperatorId(bo.getOperatorId());
		fwFuwuBelongAssignDO.setOperatorType(bo.getOperatorType());
		fwFuwuBelongAssignDO.setCreatedAt(bo.getCreatedAt());
		fwFuwuBelongAssignDO.setUpdatedAt(bo.getUpdatedAt());

		return fwFuwuBelongAssignDO;
	}

	public static List<FwFuwuBelongAssignDTO> toBOList(List<FwFuwuBelongAssignDO> doList) {

		if (doList == null) {

			return new ArrayList<FwFuwuBelongAssignDTO>();
		}

		List<FwFuwuBelongAssignDTO> boList = new ArrayList<FwFuwuBelongAssignDTO>();
		for (FwFuwuBelongAssignDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwFuwuBelongAssignDO> toDOList(List<FwFuwuBelongAssignDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwFuwuBelongAssignDO>();
		}

		List<FwFuwuBelongAssignDO> doList = new ArrayList<FwFuwuBelongAssignDO>();

		for (FwFuwuBelongAssignDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
