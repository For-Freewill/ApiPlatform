package com.youzan.ycm.qa.enable.platform.biz.response.repeater;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wulei
 * @date 2021/12/7 10:31
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Behavior {
    private String classPattern;
    private String[] methodPatterns;
    private boolean includeSubClasses;
}
