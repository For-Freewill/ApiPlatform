package com.youzan.ycm.qa.enable.platform.biz.jenkins;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @Author qibu
 * @create 2021/8/25 3:28 PM
 */
@AllArgsConstructor
@Getter
public enum JenkinJobEnum {

    YCM("ycm", "bitce", "7606"),
    CRM("crm", "crm-sales-web-base", "7353");


    /**
     * 产品线
     */
    private String line;

    /**
     * 重试job
     */
    private String jobName;

    /**
     * gitLab projectId
     */
    private String projectId;

    /**
     * 根据产品线找找枚举
     *
     * @param line
     * @return
     */
    public static JenkinJobEnum findByLine(String line) {
        for (JenkinJobEnum value : values()) {
            if (Objects.equals(line, value.line)) {
                return value;
            }
        }
        return null;
    }


}
