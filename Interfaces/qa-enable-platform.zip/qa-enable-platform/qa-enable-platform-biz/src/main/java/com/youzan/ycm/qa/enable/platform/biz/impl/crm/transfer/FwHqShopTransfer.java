package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwHqShopDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwHqShopDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 总部店铺列表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwHqShopTransfer {

	public static FwHqShopDTO toDTO(FwHqShopDO d) {

		if (d == null) {

			return null;
		}

		FwHqShopDTO fwHqShopDTO = new FwHqShopDTO();
		fwHqShopDTO.setId(d.getId());
		fwHqShopDTO.setKdtId(d.getKdtId());
		fwHqShopDTO.setCreatedAt(d.getCreatedAt());
		fwHqShopDTO.setUpdatedAt(d.getUpdatedAt());

		return fwHqShopDTO;
	}


	public static List<FwHqShopDTO> toDTOList(List<FwHqShopDO> doList) {

		if (doList == null) {

			return new ArrayList<FwHqShopDTO>();
		}

		List<FwHqShopDTO> boList = new ArrayList<FwHqShopDTO>();
		for (FwHqShopDO d : doList) {

			if (d != null) {

				boList.add(toDTO(d));
			}
		}
		return boList;
	}

}
