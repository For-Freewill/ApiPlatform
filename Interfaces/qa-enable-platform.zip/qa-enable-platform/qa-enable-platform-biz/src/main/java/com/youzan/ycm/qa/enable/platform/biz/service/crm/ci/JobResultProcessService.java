package com.youzan.ycm.qa.enable.platform.biz.service.crm.ci;


import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteFinishProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteStartProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.JenkinsReportDTO;

/**
 * @author hezhulin
 * @date 2021-08-24 21:04
 */
public interface JobResultProcessService {

    /**
     * 处理某次job执行中单条case的执行情况
     * @param suiteFinishProcessRequestDTO
     * @param suite
     * @return
     */
    boolean singleCaseExcuteHandle (SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO, JenkinsReportDTO.Suites suite);

    void asyncSuiteFinishProcess(SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO, CiJenkinsJobBO ciJenkinsJobBO);

    void asyncSuiteStartProcess(SuiteStartProcessRequestDTO suiteStartProcessRequestDTO);



}
