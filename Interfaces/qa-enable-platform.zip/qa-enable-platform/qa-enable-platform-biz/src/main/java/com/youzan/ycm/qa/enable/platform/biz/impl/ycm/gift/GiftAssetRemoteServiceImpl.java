package com.youzan.ycm.qa.enable.platform.biz.impl.ycm.gift;

/**
 * @program: qa-enable-platform
 * @description
 * @author: tianning
 * @create: 2021-01-05 20:09
 **/
//@Service
//public class GiftAssetRemoteServiceImpl implements GiftAssetRemoteService {
//
//    @Resource
//    private GiftAssetRemoteService giftAssetRemoteService;
//
//    /**
//     * 查询礼包
//     */
//    @Override
//    public PlainResult<GetGiftAssetListGeneralResponse> listGfAssetByOwner(GetGiftAssetListByOwnerRequest request) {
//
//        PlainResult<GetGiftAssetListGeneralResponse> result = giftAssetRemoteService.listGfAssetByOwner(request);
//        return result;
//    }
//}
