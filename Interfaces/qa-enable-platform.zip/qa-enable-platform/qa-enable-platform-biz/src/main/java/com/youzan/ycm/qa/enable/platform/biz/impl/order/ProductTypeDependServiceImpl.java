package com.youzan.ycm.qa.enable.platform.biz.impl.order;

import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.enable.crm.meta.api.dto.product.ProductTypeDTO;
import com.youzan.enable.crm.meta.api.service.product.ProductTypeRemoteService;
import com.youzan.ycm.qa.enable.platform.biz.service.order.ProductTypeDependService;
import com.youzan.ycm.qa.enable.platform.biz.util.Unwrapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: qa-enable-platform
 * @description:
 * @author: linliying
 * @create: 2021-04-15 19:05
 **/
@Service
public class ProductTypeDependServiceImpl implements ProductTypeDependService {
    @Resource
    private ProductTypeRemoteService productTypeRemoteService;

    @Override
    public ProductTypeDTO getById(Long productTypeId) {
        PlainResult<ProductTypeDTO> result = productTypeRemoteService.getById(productTypeId);

        return Unwrapper.unwrap(result);
    }

    @Override
    public ProductTypeDTO getByAlias(String productTypeAlias) {
        PlainResult<ProductTypeDTO> result = productTypeRemoteService.getByAlias(productTypeAlias);

        return Unwrapper.unwrap(result);
    }

    @Override
    public List<ProductTypeDTO> getByProductLineId(Integer productLineId) {
        ListResult<ProductTypeDTO> result = productTypeRemoteService.getByProductLineId(productLineId);

        return Unwrapper.unwrap(result);
    }

    @Override
    public List<ProductTypeDTO> getAllProductType() {
        ListResult<ProductTypeDTO> result = productTypeRemoteService.getAllProductType();
        return Unwrapper.unwrap(result);
    }

    @Override
    public List<ProductTypeDTO> getAllIntentionalProductType() {
        ListResult<ProductTypeDTO> result = productTypeRemoteService.getAllIntentionalProductType();
        return Unwrapper.unwrap(result);
    }
}
