package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Preconditions;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.core.model.result.PageResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.api.enums.CiGroup;
import com.youzan.ycm.qa.enable.platform.api.enums.JobStatus;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.CiJenkinsJobRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.PageRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CiJenkinsJobDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CiJenkinsJobService;
import com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer.CiJenkinsJobTransfer;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CiJenkinsJobEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.FailureDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.po.CiJenkinsJobPo;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.CiJenkinsJobMapper;
import com.youzan.ycm.qa.enable.platform.dal.mapper.crm.ci.FailureDetailMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author Jiping.Hu
 * @Description  jenkins job 业务处理类
 * @Date 2021-08-16
 **/
@Slf4j
@Service(value = "CiJenkinsJobService")
public class CiJenkinsJobServiceImpl implements CiJenkinsJobService {

    @Resource
    CiJenkinsJobMapper ciJenkinsJobMapper;

    @Resource
    FailureDetailMapper failureDetailMappe;

    @Override
    public PlainResult<PageResult<CiJenkinsJobDTO>> findJenkinsJobByCondition(PageRequest<CiJenkinsJobRequestDTO> pageRequest) {

        CiJenkinsJobPo ciJenkinsJobPo = new CiJenkinsJobPo();
        CiJenkinsJobRequestDTO ciJenkinsJobRequestDTO  = pageRequest.getDto();

        if (null != ciJenkinsJobRequestDTO.getEnv()){
            ciJenkinsJobPo.setJobEnv(ciJenkinsJobRequestDTO.getEnv());
        }
        ciJenkinsJobPo.setJobGroup(ciJenkinsJobRequestDTO.getJob_group());
        ciJenkinsJobPo.setStartTime(ciJenkinsJobRequestDTO.getStartTime());
        ciJenkinsJobPo.setEndTime(ciJenkinsJobRequestDTO.getEndTime());
        ciJenkinsJobPo.setJobState(pageRequest.getDto().getJobState());

        List<CiJenkinsJobDTO> ciJenkinsJobDTOList =  new ArrayList<>();

        /**
         * 条件查询
         */
        PageInfo<CiJenkinsJobEntity> pageInfo = PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize()).doSelectPageInfo(
                () -> ciJenkinsJobMapper.findByCondition(ciJenkinsJobPo));

        /*List<CiJenkinsJobEntity> ciJenkinsJobEntityList = ciJenkinsJobMapper.findByCondition(ciJenkinsJobPo);
        int totalNum = ciJenkinsJobEntityList.size();
        int limit = pageRequest.getPageSize();
        int from = (pageRequest.getPageNum()-1)*limit;
        int to   = limit * pageRequest.getPageNum();

        if (to > totalNum) {
            to = totalNum;
        }*/

        PageResult<CiJenkinsJobDTO> pageResult = new PageResult<>();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        /**查询结果设置**/
        /*if (totalNum == 0){
            pageResult.setTotalNum(0);
            pageResult.setList(new ArrayList<>());
        } else {
            ciJenkinsJobEntityList =  ciJenkinsJobEntityList.subList(from>totalNum?0:from,to);*/
        pageInfo.getList().forEach(result->
                    {
                        CiJenkinsJobDTO ciJenkinsJobDTO = new CiJenkinsJobDTO();
                        List<FailureDetailEntity> failureDetailEntityList =
                                failureDetailMappe.selectList( new QueryWrapper<FailureDetailEntity>().lambda()
                                        .eq(FailureDetailEntity::getJobId, result.getId())
                                        .eq(FailureDetailEntity::getHandle,0)
                                );
                        if (failureDetailEntityList.size() == 0){
                            ciJenkinsJobDTO.setHandleProcess("已完成");
                        }else {
                            ciJenkinsJobDTO.setHandleProcess("未完成");
                        }
                        ciJenkinsJobDTO.setJobName(result.getJobName());
                        ciJenkinsJobDTO.setJobGroup(CiGroup.of(result.getJobGroup()).getStatus());
                        ciJenkinsJobDTO.setFailureTotalCase(result.getFailureTotalCase());
                        ciJenkinsJobDTO.setJobCost(result.getJobCost());
                        ciJenkinsJobDTO.setJobEnv(result.getJobEnv());
                        ciJenkinsJobDTO.setJobId(result.getId());
                        ciJenkinsJobDTO.setReferJobId(result.getReferJobId());
                        ciJenkinsJobDTO.setJobType(null == result.getReferJobId()?"普通":"重试job");
                        ciJenkinsJobDTO.setJobState(JobStatus.of(result.getJobState()).getDesc());
                        ciJenkinsJobDTO.setReportUrl(result.getReportUrl());
                        ciJenkinsJobDTO.setTotalCase(result.getTotalCase());
                        ciJenkinsJobDTO.setSkipTotalCase(result.getSkipTotalCase());
                        ciJenkinsJobDTO.setSuccessTotalCase(result.getSuccessTotalCase());
                        ciJenkinsJobDTO.setCreateTime(formatter.format(result.getCreatedAt()));
                        ciJenkinsJobDTOList.add(ciJenkinsJobDTO);
                    }
            );

            pageResult.setTotalNum((int)pageInfo.getTotal());
            pageResult.setList(ciJenkinsJobDTOList);


        PlainResult<PageResult<CiJenkinsJobDTO>> plainResult = new PlainResult<>();
        plainResult.setData(pageResult);
        return plainResult;
    }

    @Override
    public Long insert(CiJenkinsJobBO ciJenkinsJobBO) {
        CiJenkinsJobPo ciJenkinsJobPo = new CiJenkinsJobPo();
        ciJenkinsJobPo.setJobName(ciJenkinsJobBO.getJobName());
        List<CiJenkinsJobEntity> ciJenkinsJobEntityList  = ciJenkinsJobMapper.findByCondition(ciJenkinsJobPo);

        if (null !=ciJenkinsJobEntityList && ciJenkinsJobEntityList.size() !=0){
            return 0l;
        }
        if (null == ciJenkinsJobBO.getReferJobId()){
            ciJenkinsJobBO.setReferJobId(0l);
        }
        CiJenkinsJobEntity ciJenkinsJobEntity = CiJenkinsJobTransfer.toDO(ciJenkinsJobBO);
        ciJenkinsJobMapper.insert(ciJenkinsJobEntity);

        return ciJenkinsJobEntity.getId();
    }

    @Override
    public Long update(CiJenkinsJobBO ciJenkinsJobBO) {
        Preconditions.checkArgument(null != ciJenkinsJobBO && null != ciJenkinsJobBO.getId(),"id不能为空");
        return ciJenkinsJobMapper.update(CiJenkinsJobTransfer.toDO(ciJenkinsJobBO));
    }

    @Override
    public CiJenkinsJobBO queryCiJenkinsJobByJobName(String jobName){
        CiJenkinsJobPo ciJenkinsJobPo = new CiJenkinsJobPo();
        ciJenkinsJobPo.setJobName(jobName);
        List<CiJenkinsJobEntity> ciJenkinsJobEntities = ciJenkinsJobMapper.findByCondition(ciJenkinsJobPo);
        if (ciJenkinsJobEntities.size()>0){
            return CiJenkinsJobTransfer.toBO(ciJenkinsJobEntities.get(0));
        }else {
            return null;
        }
    }
}
