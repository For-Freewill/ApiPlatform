package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.CaseDetailEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.crm.ci.ExcuteDetailEntity;

/**
 * @author hezhulin
 * @date 2021-11-19 14:57
 */
public class CaseDetailTransfer {

    public static CaseDetailDTO toDTO(CaseDetailEntity caseDetailEntity){
        CaseDetailDTO caseDetailDTO = new CaseDetailDTO();
        caseDetailDTO.setId(caseDetailEntity.getId());
        caseDetailDTO.setCaseName(caseDetailEntity.getCaseName());
        caseDetailDTO.setIsDelete(0);
        caseDetailDTO.setCaseBelongClass(caseDetailEntity.getCaseBelongClass());
        caseDetailDTO.setCaseBelongApp(caseDetailEntity.getCaseBelongApp());
        caseDetailDTO.setCaseAuthor(caseDetailEntity.getCaseAuthor());
        caseDetailDTO.setCaseUrl(caseDetailEntity.getCaseUrl());
        caseDetailDTO.setCreatedAt(caseDetailEntity.getCreatedAt());
        caseDetailDTO.setUpdatedAt(caseDetailEntity.getUpdatedAt());

        return caseDetailDTO;

    }
}
