package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.CommonResultCode;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.api.enums.CiType;
import com.youzan.ycm.qa.enable.platform.api.enums.JobStatus;
import com.youzan.ycm.qa.enable.platform.api.enums.SuiteBelong;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteFinishProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteStartProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.JenkinsReportDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CaseDetailService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.CiJenkinsJobService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.JenkinsReportService;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.SuiteListenerService;
import com.youzan.ycm.qa.enable.platform.biz.service.crm.ci.JobResultProcessService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author hezhulin
 * @date 2021-08-24 14:16
 */
@Slf4j
@Service(value = "suiteListenerService")
@com.alibaba.dubbo.config.annotation.Service(protocol = {"dubbo"}, registry = {"haunt"})
public class SuiteListenerServiceImpl implements SuiteListenerService {
    @Resource
    public CiJenkinsJobService ciJenkinsJobService;

    @Resource
    public JobResultProcessService jobResultProcessService;


    @Override
    public PlainResult<Boolean> suiteStartProcess(SuiteStartProcessRequestDTO suiteStartProcessRequestDTO) {

        log.info("suiteStartProcess方法入参打印："+JSON.toJSONString(suiteStartProcessRequestDTO));

        PlainResult<Boolean> result = new PlainResult<Boolean>();

        if(null!=ciJenkinsJobService.queryCiJenkinsJobByJobName(suiteStartProcessRequestDTO.getJobBuildUrl())){
            result.setData(true);
            log.info("job表中已经有对应的记录");
            return result;
        }

        jobResultProcessService.asyncSuiteStartProcess(suiteStartProcessRequestDTO);
        result.setData(true);
        return result;
    }

    @Override
    public PlainResult<Boolean>  suiteFinishProcess(SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO) {
        log.info("suiteFinishProcess方法入参打印："+JSON.toJSONString(suiteFinishProcessRequestDTO));

        String jobBuildUrl = suiteFinishProcessRequestDTO.getJobBuildUrl();
        PlainResult<Boolean> result = new PlainResult<Boolean>();
        if (null == jobBuildUrl || jobBuildUrl.isEmpty()){
            result.setErrorMessage(CommonResultCode.EXCEPTION.code,"入参中jobBuildUrl字段不能为空");
            return result;
        }

        CiJenkinsJobBO ciJenkinsJobBO = ciJenkinsJobService.queryCiJenkinsJobByJobName(jobBuildUrl);
        if (null == ciJenkinsJobBO ){
            result.setErrorMessage(CommonResultCode.EXCEPTION.code,"记录中找不到jobBuildUrl对应的jobName");
            return result;
        }

        jobResultProcessService.asyncSuiteFinishProcess(suiteFinishProcessRequestDTO, ciJenkinsJobBO);
        result.setData(true);
        return result;
    }

}
