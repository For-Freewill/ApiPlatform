package com.youzan.ycm.qa.enable.platform.biz.impl.crm.ci;

import com.youzan.api.common.response.CommonResultCode;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.CiJenkinsJobBO;
import com.youzan.ycm.qa.enable.platform.api.bo.crm.ci.FailureDetailBO;
import com.youzan.ycm.qa.enable.platform.api.enums.*;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.CaseDetailRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteFinishProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteStartProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.CaseDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.ExcuteDetailDTO;
import com.youzan.ycm.qa.enable.platform.api.response.ci.JenkinsReportDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.*;
import com.youzan.ycm.qa.enable.platform.biz.jenkins.GitLabService;
import com.youzan.ycm.qa.enable.platform.biz.jenkins.JenkinJobEnum;
import com.youzan.ycm.qa.enable.platform.biz.service.crm.ci.JobResultProcessService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author hezhulin
 * @date 2021-08-24 21:05
 */
@Slf4j
@Service(value = "jobResultProcessService")
public class JobResultProcessServiceImpl implements JobResultProcessService {

    @Resource
    public CiJenkinsJobService ciJenkinsJobService;

    @Resource
    public CaseDetailService caseDetailService;

    @Resource
    public ExcuteDetailService excuteDetailService;

    @Resource
    public FailureDetailService failureDetailService;

    @Resource
    public GitLabService gitLabService;

    @Resource
    public JenkinsReportService jenkinsReportService;


    @Override
    @Transactional
    public boolean singleCaseExcuteHandle(SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO, JenkinsReportDTO.Suites suite) {

        CiJenkinsJobBO ciJenkinsJobBO = ciJenkinsJobService.queryCiJenkinsJobByJobName(suiteFinishProcessRequestDTO.getJobBuildUrl());
        if (null == ciJenkinsJobBO)
            return false;

        Long caseId = 0L ;
        List<CaseDTO> caseDTOList = caseDetailService.query(null,suite.getName(), suite.getClassName(),null, null, null).getData();
        if (null == caseDTOList || caseDTOList.size() == 0){
            //case在系统中还不存在的时候需要落case_detail
            CaseDetailRequestDTO caseDetailRequestDTO = new CaseDetailRequestDTO();
            caseDetailRequestDTO.setCaseName(suite.getName());
            caseDetailRequestDTO.setCaseBelongClass(suite.getClassName());
            SuiteBelong suiteBelong = SuiteBelong.of(suiteFinishProcessRequestDTO.getSuiteName());
            if (suiteBelong==null){
                caseDetailRequestDTO.setCaseBelongApp("未知");
                caseDetailRequestDTO.setCaseAuthor("未知");
                //通过suite名称找不到映射的应用和分组的情况下，归属的应用暂时设置成未知，这种情况是枚举中没有包含该suite，可能需新加配置
                log.warn("suiteName没有映射的应用和分组，需要增加配置");

            }else {
                caseDetailRequestDTO.setCaseBelongApp(suiteBelong.getBelongApp());
                String caseAuthor = gitLabService.getAuthorByClassAndLine(suite.getClassName(),JenkinJobEnum.valueOf(suiteBelong.getBelongGroup().name()).getLine());;
                caseDetailRequestDTO.setCaseAuthor(caseAuthor);
            }
            caseId = caseDetailService.insert(caseDetailRequestDTO).getData();
        }else {
            caseId = caseDTOList.get(0).getId();
        }
        CaseDetailDTO caseDetailDTO =  caseDetailService.queryById(caseId).getData();

        //落excute_detail
        ExcuteDetailDTO excuteDetailDTO = new ExcuteDetailDTO();
        excuteDetailDTO.setJobId(ciJenkinsJobBO.getId());
        excuteDetailDTO.setCaseId(caseId);
        excuteDetailDTO.setExcuteResult(CaseExcuteResult.valueOf(suite.getStatus()).getCode());
        excuteDetailDTO.setExcuteCost(String.valueOf(suite.getDuration()));
        excuteDetailDTO.setExcuteJenkins(suite.getUrl());
        if (CaseExcuteResult.valueOf(suite.getStatus()).getCode().intValue()!=1)
            excuteDetailDTO.setErrorDetail(suite.getLog());
        else
            excuteDetailDTO.setErrorDetail("");
        excuteDetailDTO.setCaseBelongApp(caseDetailDTO.getCaseBelongApp());
        excuteDetailDTO.setEnv(ciJenkinsJobBO.getJobEnv());
        Long caseExcuteId = excuteDetailService.insertExcuteDetail(excuteDetailDTO);

        //失败的用例落failure_detail
        if (CaseExcuteResult.valueOf(suite.getStatus()).getCode().intValue()!=1){
            FailureDetailBO failureDetailBO = new FailureDetailBO();
            failureDetailBO.setExcuteId(caseExcuteId);
            failureDetailBO.setJobId(ciJenkinsJobBO.getId());
            failureDetailBO.setCaseId(caseId);
            failureDetailBO.setFailureCause(FailureCause.EXTERNAL_CAUSE.getCode());
            failureDetailBO.setHandle(Handle.UNTREATED.getCode().intValue());
            failureDetailService.insert(failureDetailBO);
        }
        return true;
    }

    @Async
    @Override
    public void asyncSuiteFinishProcess(SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO, CiJenkinsJobBO ciJenkinsJobBO){

        //延迟3S秒再消费，因为监听器触发的时候jenkins上这个Job还在跑最后的结果数据，这个时候立马查是查不到的
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String jobBuildUrl = suiteFinishProcessRequestDTO.getJobBuildUrl();
        if (ciJenkinsJobBO.getJobState().intValue()==JobStatus.START.getCode().intValue()){
            //调用接口查询本次job是否已执行完毕
            if (!jenkinsReportService.jobIsFinish(jobBuildUrl)){
                log.info(jobBuildUrl+"--job还在执行中，等最后一次才处理");
                return;
            }
            //调用接口查询本次job的具体用例执行情况
            PlainResult<JenkinsReportDTO> jenkinsReportDTOPlainResult = jenkinsReportService.getJenkinsReport(jobBuildUrl);
            if (null == jenkinsReportDTOPlainResult.getData()){
                log.error(jobBuildUrl+"调用获取Jenkins执行结果的接口返回异常");
                return;
            }
            JenkinsReportDTO jenkinsReportDTO = jenkinsReportDTOPlainResult.getData();
            if (null == jenkinsReportDTO.getSuites() || jenkinsReportDTO.getSuites().size() == 0){
                log.error(jobBuildUrl+"调用获取Jenkins执行结果的接口返回中没有执行明细");
                return;
            }else {
                jenkinsReportDTO.getSuites().forEach(suite->{
                    //调用事务性的数据持久化接口落case_detail、excute_detail、failure_detail
                    try{
                        boolean singleCaseExcuteHandleResult = singleCaseExcuteHandle(suiteFinishProcessRequestDTO, suite);
                        if (!singleCaseExcuteHandleResult)
                            log.warn("job执行结果处理异常----> job: {}, case: {}",jobBuildUrl,suite.getClassName()+suite.getName());
                    }catch (Exception e){
                        log.warn("job执行结果处理异常----> job: {}, case: {}",jobBuildUrl,suite.getClassName()+suite.getName());
                        log.warn(e.getMessage());
                    }
                });
                //更新job表
                ciJenkinsJobBO.setJobState(jenkinsReportDTO.isStatus()?JobStatus.SUCCESS.getCode():JobStatus.FAILURE.getCode());
                ciJenkinsJobBO.setJobCost(String.valueOf(jenkinsReportDTO.getDuration()));
                ciJenkinsJobBO.setTotalCase(Integer.valueOf(String.valueOf(jenkinsReportDTO.getCount())));
                ciJenkinsJobBO.setSuccessTotalCase(Integer.valueOf(String.valueOf(jenkinsReportDTO.getPassCount())));
                ciJenkinsJobBO.setFailureTotalCase(Integer.valueOf(String.valueOf(jenkinsReportDTO.getFailCount())));
                ciJenkinsJobBO.setSkipTotalCase(Integer.valueOf(String.valueOf(jenkinsReportDTO.getSkipCount())));
                ciJenkinsJobBO.setUpdatedAt(new Date());
                ciJenkinsJobService.update(ciJenkinsJobBO);
            }
            return;

        }else {
            log.warn(jobBuildUrl+"对应job已处理完毕，无需重复处理");
            return;
        }
    }

    @Async
    @Override
    public void asyncSuiteStartProcess(SuiteStartProcessRequestDTO suiteStartProcessRequestDTO) {

        CiJenkinsJobBO ciJenkinsJobBO = new CiJenkinsJobBO();
        ciJenkinsJobBO.setJobName(suiteStartProcessRequestDTO.getJobBuildUrl());
        ciJenkinsJobBO.setJobState(JobStatus.START.getCode());
        if (suiteStartProcessRequestDTO.getIsReferJob())
            ciJenkinsJobBO.setJobType(CiType.RETRY.getCode());
        else
            ciJenkinsJobBO.setJobType(CiType.NORMAL.getCode());
        ciJenkinsJobBO.setJobEnv(suiteStartProcessRequestDTO.getSc());
        ciJenkinsJobBO.setReportUrl(suiteStartProcessRequestDTO.getJobBuildUrl()+"testReport/");
        SuiteBelong suiteBelong = SuiteBelong.of(suiteStartProcessRequestDTO.getSuiteName());
        if (suiteBelong==null){
            ciJenkinsJobBO.setJobGroup(-1);
            //通过suite名称找不到映射的应用和分组的情况下，分组值暂时设置成-1，这种情况是枚举中没有包含该suite，可能加新加配置
            log.warn("suiteName没有映射的应用和分组，需要增加配置");

        }
        else
            ciJenkinsJobBO.setJobGroup(suiteBelong.getBelongGroup().getCode());
        ciJenkinsJobBO.setJobCost("");
        ciJenkinsJobBO.setTotalCase(0);
        ciJenkinsJobBO.setFailureTotalCase(0);
        ciJenkinsJobBO.setSkipTotalCase(0);
        ciJenkinsJobBO.setSuccessTotalCase(0);
        ciJenkinsJobBO.setCreatedAt(new Date());
        ciJenkinsJobBO.setUpdatedAt(new Date());
        Long jobId = ciJenkinsJobService.insert(ciJenkinsJobBO);
        if (jobId.compareTo(0L)>0){

            if (suiteStartProcessRequestDTO.getIsReferJob() && null!=suiteStartProcessRequestDTO.getSourceJobs())
                //重试job的特殊处理逻辑
                //更新原job的ci_jenkins_job.refer_job_id
                suiteStartProcessRequestDTO.getSourceJobs().forEach(sourceJob->{
                    CiJenkinsJobBO sourceCiJenkinsJobEntity = new CiJenkinsJobBO();
                    sourceCiJenkinsJobEntity.setId(sourceJob);
                    sourceCiJenkinsJobEntity.setReferJobId(jobId);
                    sourceCiJenkinsJobEntity.setUpdatedAt(new Date());
                    ciJenkinsJobService.update(sourceCiJenkinsJobEntity);
                });

            log.info("job数据插入成功");
            return;
        }
        else{
            log.warn("job数据未插入，可能是因为表里已经有对应的记录了");
            return;
        }

    }

}
