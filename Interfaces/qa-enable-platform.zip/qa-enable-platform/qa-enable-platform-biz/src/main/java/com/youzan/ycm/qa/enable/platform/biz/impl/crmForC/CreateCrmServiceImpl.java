package com.youzan.ycm.qa.enable.platform.biz.impl.crmForC;

import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.api.enums.GoodBasicInfo;
import com.youzan.ycm.qa.enable.platform.api.request.ycm.crmForC.CrmCreateRequest;
import com.youzan.ycm.qa.enable.platform.api.response.ycm.order.CreateOfflineOrderRep;
import com.youzan.ycm.qa.enable.platform.api.service.ycm.crmForC.CreateCrmService;
import com.youzan.ycm.qa.enable.platform.biz.util.AssertUtil;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.form.order.OrderItemFormV2;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2021/8/26
 **/
@Slf4j
@Service("createCrmService")
public class CreateCrmServiceImpl implements CreateCrmService {
    @Resource
    MarketRemoteService marketRemoteService;

    @Override
    public PlainResult<CreateOfflineOrderRep> CreateOfflineOrderV2(CrmCreateRequest crmCreateRequest) {
        OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();
        offlineOrderFormV2.setDiscountAmount(0L);
        offlineOrderFormV2.setNeedAdminSign((byte) 0);
        offlineOrderFormV2.setNeedInvoice(true);
        offlineOrderFormV2.setUserId(2135L);
        offlineOrderFormV2.setRealPrice(1);
        offlineOrderFormV2.setOriginPrice(1L);
        List<OrderItemFormV2> itemFormV2List = new ArrayList<>();
        String crmGoods = crmCreateRequest.getCrmGoods();
        String kdtId = crmCreateRequest.getKdtId();
        Integer storeCount = crmCreateRequest.getStoreCount() == null ? 1 : crmCreateRequest.getStoreCount();

        AssertUtil.isAllNotNone(crmGoods, "crmGoods 不能为空！");
        AssertUtil.isAllNotNone(kdtId, "kdtId 不能为空！");

        CreateOfflineOrderRep createOfflineOrderRep = new CreateOfflineOrderRep();
        switch (crmGoods) {
            //订购CRM插件
            case "crm":
                itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.CRM.getItemId(), (byte) 1, kdtId, false, 1));
                createOfflineOrderRep.setCreateContent("成功订购CRM插件1年");
                break;
            //订购【CRM-门店】
            case "crmStore":
                for (int i = 0; i < storeCount; i++) {
                    itemFormV2List.add(getOrderItemFormV2(GoodBasicInfo.CRM_STORE.getItemId(), (byte) 1, null, false, 1));
                }
                createOfflineOrderRep.setCreateContent("成功订购【CRM-门店】1年，" + storeCount + "个！");
                break;
            default:
                break;
        }
        offlineOrderFormV2.setItems(itemFormV2List);
        offlineOrderFormV2.setKdtId(kdtId);
        offlineOrderFormV2.setKdtName("");
        PlainResult<CreateOfflineOrderResponse> createResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
        PlainResult<CreateOfflineOrderRep> result = new PlainResult<>();

        List<Long> failedKdtIds = createResult.getData().getFailedKdtIds();

        createOfflineOrderRep.setFailedKdtIds(failedKdtIds);
        if (failedKdtIds.size() > 0) {
            createOfflineOrderRep.setCreateContent("暂无订购任何产品！");
        }
        result.setData(createOfflineOrderRep);
        return result;
    }

    public OrderItemFormV2 getOrderItemFormV2(Integer itemId, Byte buyType, String applyKdtId, Boolean newMigration, Integer quantity) {
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setApplyKdtId(applyKdtId);
        orderItemFormV2.setItemId(itemId);
        orderItemFormV2.setBuyType(buyType);
        orderItemFormV2.setNewMigration(newMigration);
        orderItemFormV2.setQuantity(quantity);
        return orderItemFormV2;
    }
}
