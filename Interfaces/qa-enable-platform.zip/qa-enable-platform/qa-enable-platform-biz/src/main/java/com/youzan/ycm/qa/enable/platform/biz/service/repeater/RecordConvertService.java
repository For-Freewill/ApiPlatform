package com.youzan.ycm.qa.enable.platform.biz.service.repeater;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youzan.api.common.response.PlainResult;
import com.youzan.ycm.qa.enable.platform.biz.request.repeater.RecordCovertRequest;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ModuleConfigEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ModuleInfoEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.RecordEntity;
import com.youzan.ycm.qa.enable.platform.dal.entity.repeater.ReplayEntity;

import java.util.List;

/**
 * @author wulei
 * @date 2021/11/11 12:00:00
 * 流量回放：记录服务
 */
public interface RecordConvertService {
    /**
     * 记录转代码
     *
     * @return
     */
    PlainResult<String> recordToCode(RecordCovertRequest request);

    PlainResult<Page<RecordEntity>> listRecord(String appName, String traceId, Integer pageNum, Integer pageSize);

    PlainResult<ReplayEntity> listReplay(Long id);

    PlainResult<List<ModuleInfoEntity>> listModuleInfo(String appName, String ip);

    PlainResult<Page<ModuleConfigEntity>> listModuleConfig(String appName,String environment,Integer page,Integer pageSize);

    PlainResult<String> detailModuleConfig(Long id);

    PlainResult<ModuleConfigEntity> addOrUpdateModuleConfig(ModuleConfigEntity  moduleConfigEntity);

    PlainResult<ModuleConfigEntity> deleteModuleConfig(Long id);

    PlainResult<Boolean> deleteModuleInfo(Long id);


}
