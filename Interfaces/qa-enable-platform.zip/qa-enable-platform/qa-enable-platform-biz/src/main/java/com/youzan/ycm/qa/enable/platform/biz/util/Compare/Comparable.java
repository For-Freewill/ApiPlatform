package com.youzan.ycm.qa.enable.platform.biz.util.Compare;

/**
 * {@link Comparable}
 * <p>
 *
 * @author wulei
 */
public interface Comparable {

    /**
     * compare to object
     *
     * @param left  left object to be compare
     * @param right right object to be compare
     * @return compare result
     */
    CompareResult compare(Object left, Object right);
}
