package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.ShopDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.ShopDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 店铺基础数据和CRM业务关键数据
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:30:55
 */
public class ShopTransfer {

	public static ShopDTO toBO(ShopDO d) {

		if (d == null) {

			return null;
		}

		ShopDTO shopBO = new ShopDTO();
		shopBO.setId(d.getId());
		shopBO.setKdtId(d.getKdtId());
		shopBO.setCustomerId(d.getCustomerId());
		shopBO.setContactId(d.getContactId());
		shopBO.setName(d.getName());
		shopBO.setMobile(d.getMobile());
		shopBO.setShopType(d.getShopType());
		shopBO.setCategoryId(d.getCategoryId());
		shopBO.setCountryCode(d.getCountryCode());
		shopBO.setProvinceId(d.getProvinceId());
		shopBO.setCityId(d.getCityId());
		shopBO.setCountyId(d.getCountyId());
		shopBO.setAddress(d.getAddress());
		shopBO.setOpenStatus(d.getOpenStatus());
		shopBO.setCurrentItemId(d.getCurrentItemId());
		shopBO.setCurrentAppId(d.getCurrentAppId());
		shopBO.setSalesUserId(d.getSalesUserId());
		shopBO.setSalesDepartmentId(d.getSalesDepartmentId());
		shopBO.setSalesOrgType(d.getSalesOrgType());
		shopBO.setInnerFlag(d.getInnerFlag());
		shopBO.setIsLock(d.getIsLock());
		shopBO.setCreatedTime(d.getCreatedTime());
		shopBO.setShopRole(d.getShopRole());
		shopBO.setRootKdtId(d.getRootKdtId());
		shopBO.setShopSource(d.getShopSource());
		shopBO.setShopTopic(d.getShopTopic());
		shopBO.setShopEntrance(d.getShopEntrance());
		shopBO.setIsSimplified(d.getIsSimplified());
		shopBO.setSourceChannel(d.getSourceChannel());
		shopBO.setSaasSolution(d.getSaasSolution());
		shopBO.setChainOnlineShopMode(d.getChainOnlineShopMode());
		shopBO.setFranchisorKdtId(d.getFranchisorKdtId());
		shopBO.setShopChainRole(d.getShopChainRole());
		shopBO.setUpdatedAt(d.getUpdatedAt());
		shopBO.setCreatedAt(d.getCreatedAt());

		return shopBO;
	}

	public static ShopDO toDO(ShopDTO bo) {

        if (bo == null) {

			return null;
		}

		ShopDO shopDO = new ShopDO();
		shopDO.setId(bo.getId());
		shopDO.setKdtId(bo.getKdtId());
		shopDO.setCustomerId(bo.getCustomerId());
		shopDO.setContactId(bo.getContactId());
		shopDO.setName(bo.getName());
		shopDO.setMobile(bo.getMobile());
		shopDO.setShopType(bo.getShopType());
		shopDO.setCategoryId(bo.getCategoryId());
		shopDO.setCountryCode(bo.getCountryCode());
		shopDO.setProvinceId(bo.getProvinceId());
		shopDO.setCityId(bo.getCityId());
		shopDO.setCountyId(bo.getCountyId());
		shopDO.setAddress(bo.getAddress());
		shopDO.setOpenStatus(bo.getOpenStatus());
		shopDO.setCurrentItemId(bo.getCurrentItemId());
		shopDO.setCurrentAppId(bo.getCurrentAppId());
		shopDO.setSalesUserId(bo.getSalesUserId());
		shopDO.setSalesDepartmentId(bo.getSalesDepartmentId());
		shopDO.setSalesOrgType(bo.getSalesOrgType());
		shopDO.setInnerFlag(bo.getInnerFlag());
		shopDO.setIsLock(bo.getIsLock());
		shopDO.setCreatedTime(bo.getCreatedTime());
		shopDO.setShopRole(bo.getShopRole());
		shopDO.setRootKdtId(bo.getRootKdtId());
		shopDO.setShopSource(bo.getShopSource());
		shopDO.setShopTopic(bo.getShopTopic());
		shopDO.setShopEntrance(bo.getShopEntrance());
		shopDO.setIsSimplified(bo.getIsSimplified());
		shopDO.setSourceChannel(bo.getSourceChannel());
		shopDO.setSaasSolution(bo.getSaasSolution());
		shopDO.setChainOnlineShopMode(bo.getChainOnlineShopMode());
		shopDO.setFranchisorKdtId(bo.getFranchisorKdtId());
		shopDO.setShopChainRole(bo.getShopChainRole());
		shopDO.setUpdatedAt(bo.getUpdatedAt());
		shopDO.setCreatedAt(bo.getCreatedAt());

		return shopDO;
	}

	public static List<ShopDTO> toBOList(List<ShopDO> doList) {

		if (doList == null) {

			return new ArrayList<ShopDTO>();
		}

		List<ShopDTO> boList = new ArrayList<ShopDTO>();
		for (ShopDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<ShopDO> toDOList(List<ShopDTO> boList) {

		if (boList == null) {

			return new ArrayList<ShopDO>();
		}

		List<ShopDO> doList = new ArrayList<ShopDO>();

		for (ShopDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
