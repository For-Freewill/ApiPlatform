package com.youzan.ycm.qa.enable.platform.biz.impl.crm.transfer;

import com.youzan.ycm.qa.enable.platform.api.response.crm.fuwu.FwShoproleBindingHistoryDTO;
import com.youzan.ycm.qa.enable.platform.dal.entity.fuwu.FwShoproleBindingHistoryDO;

import java.util.ArrayList;
import java.util.List;


/**
 * 店铺角色绑定历史表
 *
 * @author jiping
 * @email hujiping@youzan.com
 * @date 2021-04-13 10:28:06
 */
public class FwShoproleBindingHistoryTransfer {

	public static FwShoproleBindingHistoryDTO toBO(FwShoproleBindingHistoryDO d) {

		if (d == null) {

			return null;
		}

		FwShoproleBindingHistoryDTO fwShoproleBindingHistoryBO = new FwShoproleBindingHistoryDTO();
		fwShoproleBindingHistoryBO.setId(d.getId());
		fwShoproleBindingHistoryBO.setShopRoleId(d.getShopRoleId());
		fwShoproleBindingHistoryBO.setKdtId(d.getKdtId());
		fwShoproleBindingHistoryBO.setRoleType(d.getRoleType());
		fwShoproleBindingHistoryBO.setFromPoolId(d.getFromPoolId());
		fwShoproleBindingHistoryBO.setFromPoolType(d.getFromPoolType());
		fwShoproleBindingHistoryBO.setFromPoolName(d.getFromPoolName());
		fwShoproleBindingHistoryBO.setToPoolId(d.getToPoolId());
		fwShoproleBindingHistoryBO.setToPoolType(d.getToPoolType());
		fwShoproleBindingHistoryBO.setToPoolName(d.getToPoolName());
		fwShoproleBindingHistoryBO.setBoundAt(d.getBoundAt());
		fwShoproleBindingHistoryBO.setReason(d.getReason());
		fwShoproleBindingHistoryBO.setRuleId(d.getRuleId());
		fwShoproleBindingHistoryBO.setTpRuleId(d.getTpRuleId());
		fwShoproleBindingHistoryBO.setTpRuleExecutionId(d.getTpRuleExecutionId());
		fwShoproleBindingHistoryBO.setSceneType(d.getSceneType());
		fwShoproleBindingHistoryBO.setScene(d.getScene());
		fwShoproleBindingHistoryBO.setOperatorId(d.getOperatorId());
		fwShoproleBindingHistoryBO.setOperatorType(d.getOperatorType());
		fwShoproleBindingHistoryBO.setCreatedAt(d.getCreatedAt());
		fwShoproleBindingHistoryBO.setUpdatedAt(d.getUpdatedAt());

		return fwShoproleBindingHistoryBO;
	}

	public static FwShoproleBindingHistoryDO toDO(FwShoproleBindingHistoryDTO bo) {

        if (bo == null) {

			return null;
		}

		FwShoproleBindingHistoryDO fwShoproleBindingHistoryDO = new FwShoproleBindingHistoryDO();
		fwShoproleBindingHistoryDO.setId(bo.getId());
		fwShoproleBindingHistoryDO.setShopRoleId(bo.getShopRoleId());
		fwShoproleBindingHistoryDO.setKdtId(bo.getKdtId());
		fwShoproleBindingHistoryDO.setRoleType(bo.getRoleType());
		fwShoproleBindingHistoryDO.setFromPoolId(bo.getFromPoolId());
		fwShoproleBindingHistoryDO.setFromPoolType(bo.getFromPoolType());
		fwShoproleBindingHistoryDO.setFromPoolName(bo.getFromPoolName());
		fwShoproleBindingHistoryDO.setToPoolId(bo.getToPoolId());
		fwShoproleBindingHistoryDO.setToPoolType(bo.getToPoolType());
		fwShoproleBindingHistoryDO.setToPoolName(bo.getToPoolName());
		fwShoproleBindingHistoryDO.setBoundAt(bo.getBoundAt());
		fwShoproleBindingHistoryDO.setReason(bo.getReason());
		fwShoproleBindingHistoryDO.setRuleId(bo.getRuleId());
		fwShoproleBindingHistoryDO.setTpRuleId(bo.getTpRuleId());
		fwShoproleBindingHistoryDO.setTpRuleExecutionId(bo.getTpRuleExecutionId());
		fwShoproleBindingHistoryDO.setSceneType(bo.getSceneType());
		fwShoproleBindingHistoryDO.setScene(bo.getScene());
		fwShoproleBindingHistoryDO.setOperatorId(bo.getOperatorId());
		fwShoproleBindingHistoryDO.setOperatorType(bo.getOperatorType());
		fwShoproleBindingHistoryDO.setCreatedAt(bo.getCreatedAt());
		fwShoproleBindingHistoryDO.setUpdatedAt(bo.getUpdatedAt());

		return fwShoproleBindingHistoryDO;
	}

	public static List<FwShoproleBindingHistoryDTO> toBOList(List<FwShoproleBindingHistoryDO> doList) {

		if (doList == null) {

			return new ArrayList<FwShoproleBindingHistoryDTO>();
		}

		List<FwShoproleBindingHistoryDTO> boList = new ArrayList<FwShoproleBindingHistoryDTO>();
		for (FwShoproleBindingHistoryDO d : doList) {

			if (d != null) {

				boList.add(toBO(d));
			}
		}
		return boList;
	}

	public static List<FwShoproleBindingHistoryDO> toDOList(List<FwShoproleBindingHistoryDTO> boList) {

		if (boList == null) {

			return new ArrayList<FwShoproleBindingHistoryDO>();
		}

		List<FwShoproleBindingHistoryDO> doList = new ArrayList<FwShoproleBindingHistoryDO>();

		for (FwShoproleBindingHistoryDTO bo : boList) {

			if (bo != null) {

				doList.add(toDO(bo));
			}
		}

		return doList;
	}

}
