package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import com.youzan.ycm.qa.enable.platform.api.request.enable.EnablePageQueryRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;
/**
 * @author wulei
 * @date 2020/11/12 11:07
 */
@RunWith(PowerMockRunner.class)
public class EnableQueryHistoryServiceTest {
    @InjectMocks
    private EnableQueryHistoryServiceImpl enableQueryHistoryService;
//
//    @Test
//    public void queryAll() {
//        EnablePageQueryRequest enablePageQueryRequest = new EnablePageQueryRequest();
//        enablePageQueryRequest.setCurrent(1);
//        enablePageQueryRequest.setSize(5);
//        Assert.assertEquals(5, 5);
//        enableQueryHistoryService.queryAll(null);
//    }
}
