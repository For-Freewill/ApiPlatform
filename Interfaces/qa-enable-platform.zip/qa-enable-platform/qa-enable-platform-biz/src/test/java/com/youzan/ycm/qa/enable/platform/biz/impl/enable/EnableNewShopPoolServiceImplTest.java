package com.youzan.ycm.qa.enable.platform.biz.impl.enable;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wuwu
 * @date 2021/2/16 11:30 PM
 */
@Slf4j
public class EnableNewShopPoolServiceImplTest {

}